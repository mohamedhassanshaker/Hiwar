# Hiwar — build handoff

Hiwar (حوار): customers build AI agents, deploy them as a chat widget on their website, watch conversations live in an inbox, and let staff take over from the AI and hand back.

## Read first
1. `docs/Hiwar-UI-Specification.md` — screen-by-screen UI spec (source of truth for behaviour).
2. The original product spec ("Hiwar: Product Specification") — requirement IDs referenced in the UI spec. Not included here; add it to `docs/`.

## Design reference (prototype, not production code)
- `design/boards/*.dc.html` — one file per screen/component in a design-canvas markup (`<x-dc>`, `{{ holes }}`, small `DCLogic` class per screen). Treat as visual + behaviour reference; re-implement in the real stack. Open the HTML for markup, CSS classes and the prototype state machines (e.g. `C-Inbox` takeover/handback).
- `design/assets/hiwar.css` — design tokens and shared components (colors, `.card`, `.table`, `.stt` status dot, `.tabs`, `.seg`, `.switch`, `.dialog`, `.toast`). Port tokens to the real theme.
- `design/canvas.json` — board layout and page grouping.
- The canvas runtime `support.js` is provided by the design tool and is not included, so boards will not render standalone.

## Build scope
- P1: Control panel (boards `C-*`, shell `PanelNav`, `PanelTop`) + public site (`W-Home`, `W-Pricing`).
- Operator portal (`O-*`): shell only; content still carries the previous product's wording — redesign before building.
- Ignore `Sidebar`, `Topbar`, `Profile`, `Payments`, `OrgProfile`, `TablePager`, `TableSearch` unless reused; they come from the earlier shell.

## Non-negotiable rules
- Single owner per conversation (AI or one person); `ownership_version` increments on every ownership change; no double replies; first valid claim wins.
- Status = dot + text label (`.stt`); no alert banners/pill badges except plan limits.
- Widget supports English and Arabic (RTL); control panel is English for now.
- Prices are placeholders ("AED [price]").

## Palette
Indigo #12143a / #2a2f6b, teal #0d9488 / #14b8a6.
