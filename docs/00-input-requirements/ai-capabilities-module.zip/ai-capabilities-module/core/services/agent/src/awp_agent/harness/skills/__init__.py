"""The Agent Skills loader."""
