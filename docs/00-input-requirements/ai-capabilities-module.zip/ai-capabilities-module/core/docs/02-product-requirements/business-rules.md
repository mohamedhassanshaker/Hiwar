# Business rules

| Item | Value |
| --- | --- |
| Purpose | The rules that apply across every screen and module, each traced to its source requirement |
| Audience | Business analysts, testers, developers |
| Related | [Glossary](../glossary.md) · [Requirements](../specs/requirements.md) · [Acceptance document](../Tahseel_AWP_Screens_Use_Cases.md) · [Data model integrity rules](../04-data-model/overview.md) · [Decision register](../harness-decisions.md) |
| Last verified against code | 2026-10-29 |

This document holds only the cross-cutting rules. A rule that belongs to one screen is in that
module's "Business rules" section (index at the end). Rule wording follows the handoff
specification §6.2 and §9 and the acceptance document; the source column names where each rule is
stated and the scenario that tests it.

## Cross-cutting rules

| Area | Rule | Source |
| --- | --- | --- |
| Approvals | A person decides T2 tool calls; no agent decides an approval, and a sub-agent's approval goes to the person (D18). An agent named as a request step's "Can act" audience takes that step's actions, Approve, Return and Reject included (D135, D215). The requester cannot approve their own request unless the step names them, as a person, among its "Can act" audiences (D217); an agent acting for the requester that takes an approving action waits for a bound approval decided by somebody else (D141). An author or assignee cannot approve their own work item. In a room and in the assistant panel the person who asked decides the approvals of their own run, without needing `approvals:decide`; in a room a call that changes who may reach what goes to the other holders of `approvals:decide` (D105, D253, D267, D269, D281, D284). A rejection carries a reason: the Inbox asks for one, and the assistant panel records "Not approved." when none is given (D285). The room card's Reject sends "Not approved." without asking ([open questions §8](../specs/open-questions.md#8-requirements-the-code-does-not-meet)). | Specification §9; `UC-12.1-06`, `UC-12.1-10`, `UC-25.2-04`, `UC-29.2-07`; NFR-11 |
| Approvals | When two members of a group decide at the same moment, the first decision wins; the second user sees "Already decided by …". | `UC-12.1-11` |
| Permissions | Permission sets, not role names; explicit deny wins. A role assignment scoped to an org unit or a project applies only within that scope (D330). Agents are limited by the person they act for, their grant, tool tiers, project policy and file scope (D31, D227); agent trust is stored but no run reads it ([open questions §8](../specs/open-questions.md#8-requirements-the-code-does-not-meet)). | Specification §9, §7.3.2; `COM-07`, `COM-08`; NFR-09 |
| Permissions | A user who lacks permission does not see the navigation item; direct access shows "You don't have access". A user who can view but not act sees action buttons hidden or disabled, and server-side checks still reject forced calls. | `COM-07`, `COM-08` |
| Tool tiers | Project policies can only make tool tiers stricter, never looser. | Specification §7.2.1; `UC-21.2-03`, `UC-21.2-04` |
| Versioning | Agents, skills, request types, storylines and memory are versioned. Running items keep the version they started with; a request in flight keeps its version's routing and answers to the audiences of the same-named step in the type's newest published version (D217). | Specification §9; `UC-51.3-02`, `UC-30.4-01`, `UC-64.1-09` |
| Estimated cost | Shown on the rooms list, agents, budgets, dashboard records and the dashboard; always labelled as estimated ("Estimated" or "(est.)", with the currency AED). The run viewer and a room's agent messages do not show it (D216, D300). A run has no money ceiling; cost is a measurement (D73). | Specification §6.2, §9; `COM-15`; AD-20 |
| Audit | All configuration changes, permission changes, approvals, publishes, secret reveal attempts, exports and logins are written to the append-only audit log, with the actor, action, object and time. | Specification §9; `COM-18`, `UC-73.1-05`; NFR-14 |
| Audit | An agent's write is audit-logged with its mission id. | D26 (open task) |
| Secrets | Shown once on creation and never returned afterwards ("Reveal denied (never returned)"). | Specification §9; `UC-77.1-01`, `UC-73.1-04`; NFR-10 |
| Secrets | Agents never handle secrets: credentials are entered by people in Connectors, Channels, Models and Settings → Email, and no agent tool takes one (D277, D294). A stored credential's secret fields are write-only (D296). | Specification §7.5.1; D277, D294 |
| Codes | Users never type codes first. The code field sits at the end of a form and is suggested from the name or title; the user can accept or edit it. Codes are unique; duplicates are rejected with a message. Applies to project keys, request type codes, skill names, collection IDs, client IDs and route aliases. | Specification §6.2, §9; `COM-13` |
| Concurrency | When two users edit the same record, the second save is rejected with "This record was changed by someone else"; the user can reload and reapply. | `COM-10`; D59 for agent edits |
| Localisation | Every label is in English and Arabic; layout mirrors in RTL; record names have English and Arabic fields, and an empty Arabic name falls back to English. | Specification §9; `COM-01`, `COM-02`; NFR-19, NFR-20 |
| Theming | Light and dark themes; the brand colour from Settings applies to the console and widget after a WCAG 2.2 AA contrast check. | Specification §9; `COM-03`, `UC-75.2-04`; NFR-18 |
| Notifications | Per-user preferences in My profile: approvals, mentions, SLA warnings, daily digest, and the emails for a request created, a request updated, a request finished and a work item finished. Turning one off stops only external notifications; the item still appears in the Inbox. The four emails are sent through the platform mail server while the person's switch, the template and the server are on (D240, D247); the other four switches are stored and no external notification is sent for them ([open questions §8](../specs/open-questions.md#8-requirements-the-code-does-not-meet)). | Specification §9; `UC-04.2-01` … `-03` |
| Every action is real | Every button opens a modal, drawer or detail screen that shows what the function does. Where no dedicated design exists, a generic action modal asks for confirmation and states that the change is recorded in the audit log. | Specification §6.2; `COM-11` |
| Destructive actions | Delete and deactivate explain the consequence (e.g. "Deleting removes it from the project. Audit records are kept."). Closing a modal with unsaved edits asks to confirm discarding them. | Specification §6.2; `COM-17` |
| Empty states | Every filtered list has an empty message (e.g. "No discussion rooms match these filters."), with Clear when filters caused it. | Specification §6.2; `COM-05` |
| Errors | A server error shows a non-technical banner with Retry; no raw error text or stack trace is displayed. | `COM-06` |
| Validation | A required or invalid field is highlighted with a message in the current language, and Save or Create stays disabled or is blocked. | `COM-12` |
| Detail layout | Requests, sub requests and work items use the same order: header (title, key, tags, actions) → main info (details, description, attributes, attachments) → tabs. | Specification §6.2 |
| Drill-down | Dashboard cards open a records list of the matching items, with search, a status filter, export and navigation to each record's detail. | Specification §6.2; `UC-10.2-01` … `-04` |

## Data integrity rules

The ten integrity rules of the logical data model (unique codes, pinned versions, insert-only audit,
non-overlapping budget periods and the rest) are stated once, with the acceptance criterion that
tests each, in [04-data-model/overview.md](../04-data-model/overview.md).

## Agent authorisation principles

Agents work under the same rules as people, plus their own limits. The mechanisms are specified in
the [agent runtime specification](../agent-runtime-spec.md); the principles, each a recorded
decision, are:

| Principle | Decision |
| --- | --- |
| Effective permission = the person's permission ∩ the agent's grant. A grant never widens what a person may do. | D31 |
| Deny by default: a token with no tool grant grants nothing. | D28 |
| The model is shown only the tools its token grants, and every call is re-checked at the server. | D29, D30, D37 |
| A run reaches every enabled connector, narrowed by its project's allowed connectors; which of their tools it is offered is its agent version's grant. A connector keeps no list of allowed agents. | D227 |
| An approval binds to the tool, the exact arguments, the record version, the mission and the person; it expires and is single use. | D20, D21 |
| A sub-agent's approval goes to the human; a parent agent can never approve its child. | D18 |
| In a room and in the assistant panel the approver is the person who asked; elsewhere the platform's separation of duties stands. In the assistant panel the person may set approval mode Auto, which approves their own approvals as they arrive. | D19, D105, D281, D282, D284 |
| Reads are free; writes, publishes, deletes and production configuration may need approval. | D17 |
| An agent's reads in a room are bounded by what every human member may see, except `knowledge_search`, which is bounded by the agent's own knowledge grant and the requester's permissions. | D104, D291 |
| An agent changes another agent's configuration or grant only through the `agent_*` tools, and a connector only through the `connector_*` tools, each T2 and decided by a holder of `approvals:decide` other than the requester, in a room too, except in the assistant panel, where the person asking decides it. Roles, permissions, credentials and invitations have no tool. | D108, D253, D277, D284 |
| A run is bounded by delegation depth and fan-out, never by money, and by model requests and tool calls only when the platform sends a limit, which it does not: a run carries on until it finishes (D389). Exhausting a limit it was given ends it BudgetExceeded. | D73, D93, D103, D129, D142, D389 |
| There are no setup tools: the Setup Director and its tools are removed. | D371 |
| The outcome of a mission is decided by the platform, never by what the model wrote. | D102 |

## Rules by module

| Module | Rules |
| --- | --- |
| Shell and account | [shell-and-account.md](../05-modules/shell-and-account.md#business-rules) |
| Home: dashboard, records, inbox | [home.md](../05-modules/home.md#business-rules) |
| Projects | [projects.md](../05-modules/projects.md#business-rules) |
| Discussion rooms | [discussion-rooms.md](../05-modules/discussion-rooms.md#business-rules) |
| Work items | [work-items.md](../05-modules/work-items.md#business-rules) |
| Requests and request types | [requests.md](../05-modules/requests.md#business-rules) |
| Scheduled work items | [scheduled-work.md](../05-modules/scheduled-work.md#business-rules) |
| Artifacts and files | [artifacts-and-files.md](../05-modules/artifacts-and-files.md#business-rules) |
| Organisation | [organisation.md](../05-modules/organisation.md#business-rules) |
| Agents and runs | [agents-and-runs.md](../05-modules/agents-and-runs.md#business-rules) |
| Skills | [skills.md](../05-modules/skills.md#business-rules) |
| Connectors | [connectors.md](../05-modules/connectors.md#business-rules) |
| Memory | [memory.md](../05-modules/memory.md#business-rules) |
| Knowledge | [knowledge.md](../05-modules/knowledge.md#business-rules) |
| Models and routes | [models-and-routes.md](../05-modules/models-and-routes.md#business-rules) |
| Channels, embedded deployments, storylines | [engage.md](../05-modules/engage.md#business-rules) |
| Budgets | [budgets.md](../05-modules/budgets.md#business-rules) |
| Audit, logs, settings, system, documentation | [governance.md](../05-modules/governance.md#business-rules) |
| Integrations | [integrations.md](../05-modules/integrations.md#business-rules) |
