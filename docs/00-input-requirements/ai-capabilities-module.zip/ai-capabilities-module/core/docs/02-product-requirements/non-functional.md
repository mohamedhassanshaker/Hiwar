# Non-functional requirements

| Item | Value |
| --- | --- |
| Purpose | The measurable quality criteria (NFR-01 … NFR-36) and how each is measured |
| Audience | Architects, developers, testers, operators |
| Related | [Requirements](requirements.md) · [Open questions §5, unmeasured claims](open-questions.md#5-unmeasured-claims) · [Security](../03-architecture/security.md) · [Architecture](../03-architecture/overview.md) |
| Last verified against code | 2026-10-29 |

Only what the source documents state or clearly imply. Each criterion is measurable and names how it
is measured. `NFR-nn` identifiers sit outside the traceability test's pattern on purpose, so naming
one in a test title is safe.

Sources: the handoff specification §10 and §9 and the stack specification §10 and §11, both archived
in [_reference](../_reference/README.md). This document replaces specification §10: every row of it
is covered below (NFR-34 … NFR-36 carry the three it states that had no criterion).

## Performance

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-01 | A list or detail screen responds in under 300 ms at p95. | Server timing on the screen's data path, excluding browser render, over a representative session. |
| NFR-02 | The first streamed agent token appears in under 1.5 s at p95, excluding provider delay. | Time from the AG-UI request to the first `TEXT_MESSAGE_CONTENT` event, with provider latency subtracted from the gateway span. |
| NFR-03 | A retrieval test returns in under 500 ms at p95. | The duration the retrieval popup already reports (`UC-58.1-01`). |

## Durability and availability

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-04 | An agent run survives a service restart and resumes from the last completed step without repeating a side effect. | Restart the agent service mid-run; the run viewer timeline shows the resume with no duplicate step (`UC-52.1-10`). No test in `services/agent/tests` restarts a worker mid-run yet ([open questions U-6](open-questions.md#5-unmeasured-claims)). |
| NFR-05 | A run waiting for an approval or an answer consumes no worker capacity. | Temporal worker slots while a run is in Waiting. |
| NFR-06 | 99.9% availability, with at least two replicas of `web` and `agent-service` and a highly available PostgreSQL cluster of 3 instances in Live. | Helm values per environment; replica counts in the cluster. Not measurable locally: a kind install runs 1 instance. |

## Security

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-07 | People authenticate by OIDC SSO with WebAuthn passkeys and server-side sessions. | `UC-05.1-01`, `UC-04.3-01` … `-03`. Passkeys are registered and listed but not used at sign-in ([open questions §8](open-questions.md#8-requirements-the-code-does-not-meet)). |
| NFR-08 | The product meets OWASP ASVS L2. | The security stage's control mapping, with evidence per control. |
| NFR-09 | Authorisation is enforced in server code on every protected read and mutation. Hiding a control in the UI is never the control. | `COM-07`, `COM-08`: a forced call with a valid foreign identity is rejected. |
| NFR-10 | A secret is shown once on creation and is never returned afterwards; a reveal attempt is audited as Denied. | `UC-77.1-01`, `UC-73.1-04`. |
| NFR-11 | An agent never decides an approval, and a requester or author cannot approve their own work. Decided exceptions: a requester the step names as a person among its "Can act" audiences may approve their own request (D217); in a room and in the assistant panel the person who asked decides the approvals of their own run (D105, D267, D281, D284). | `UC-12.1-10`, `UC-25.2-04`, `UC-29.2-07`. |
| NFR-12 | Tool results and ingested documents are screened for prompt injection, and skill scripts run in a sandbox whose only network path out is the egress proxy's allow-list (D209). | Skill scan panel (`UC-53.2-04`, `-06`); the `awp-sandbox` NetworkPolicies allow DNS and the egress proxy only (`infra/policies/network-policies.yaml`). The local kind cluster's proxy lets every destination through (`egressProxy.allowAll`, D297). |
| NFR-13 | The browser never connects to the agent service. Run tokens are minted server-side and never reach the browser. | Network policy and the absence of any agent-service origin in the client bundle. |
| NFR-14 | Every configuration change, permission change, approval, publish, secret attempt, export and login is written to the append-only audit log. | `COM-18`, `UC-73.1-01`, `-05`. |
| NFR-34 | Tool results and documents are screened for data exfiltration. | TODO: needs input — the specification §10 states the control; no measurement is defined. Sandbox egress denial (NFR-12) covers skill scripts only. |

## Privacy

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-15 | PII is masked in run context, memory writes and knowledge pre-processing, and the run viewer shows the hook that did it. | `UC-52.1-02`, `UC-55.3-03`, `UC-57.2-01`. Knowledge ingestion masks with `PiiMaskHook` (`services/agent/src/awp_agent/ingestion/activities.py`); the generic runtime composes no PII guardrail on the mission path ([agent runtime spec, conflict 4](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code), D110). |
| NFR-16 | A log line containing PII or a secret shows the value masked. | `UC-74.1-05`. |
| NFR-35 | Retention rules apply to stored data. | Phoenix traces are kept 60 days (`traceRetentionDays: 60`, `infra/charts/phoenix/values.yaml`); the `awp` Temporal namespace keeps workflow history 7 days (D204); objects in the `run-payloads` bucket expire after 30 days (D287). TODO: needs input — retention periods for domain data, run steps, messages and audit; the specification names "retention rules" without values. |
| NFR-36 | Personal data can be erased across stores. | TODO: needs input — no erasure procedure or code exists (no match for erasure in `apps/web/src` or `services/`); the stores it would have to cover are listed in [04-data-model](../04-data-model/overview.md). |

## Accessibility

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-17 | The console and the widget meet WCAG 2.2 AA. | `COM-16`: every control keyboard-reachable with a visible focus, icons named, modals trapping focus and closing with Esc. |
| NFR-18 | A brand colour that fails the WCAG 2.2 AA contrast check cannot be saved. | `UC-75.2-04`, `UC-63.1-05`. |

## Localisation

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-19 | Every label, message, date and number has an English and an Arabic form, and the layout mirrors in RTL. | `COM-01`, `COM-02`. The two Playwright projects each save a session that has made the choice through the console's own controls, so one runs the console in English and light and the other in Arabic and dark. The browser's locale does not decide it. |
| NFR-20 | A record name falls back to its English value when the Arabic one is empty. | `COM-02`. |
| NFR-21 | Arabic search matches across diacritics and letter-form variations. | `UC-02.1-04`; the normalised search key in PostgreSQL. |
| NFR-22 | Knowledge ingestion normalises Arabic text and can OCR scanned PDFs. | `UC-57.2-01`, `UC-57.1-09`. |

## Observability

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-23 | Every run is traced to Phoenix with the gateway's LLM spans inside the run's trace, reachable from Open trace. | `UC-52.1-07`, `UC-23.1-04`. The mission records the agent run, each model call with its prompt and answer, and each tool call in the run's trace; the spans do not carry `awp.mission_id` yet ([agent runtime spec, conflict 11](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code)). |
| NFR-24 | Every run's workflow history is kept in Temporal. | The run viewer timeline and the Temporal UI. |
| NFR-25 | Each service emits structured JSON logs to stdout, queryable by level, service and run from the Logs screen. | `UC-74.1-01`, `-02`, `-03`. The Logs screen reads `gov.log_entry`, which only failed knowledge ingestions write; it does not read the services' stdout ([governance.md, Known gaps](../05-modules/governance.md#known-gaps)). |
| NFR-26 | Every service reports health, aggregated on the System screen. | `UC-78.1-01`, `-04`; `/api/health`. |

## Installability

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-27 | A local environment comes up with `make kind-up` then `make deploy`, with every workload Ready. | `kubectl get pods -A` showing nothing outside Running or Completed. |
| NFR-28 | Test and Live use the same Helm charts with a different values file. The only manual step is supplying secrets. | `infra/charts/values/`. |
| NFR-29 | No secret is committed. Locally secrets come from `.env`; elsewhere from the organisation's secret store. | Secret scanning in the security stage. |

## Engineering constraints

| ID | Criterion | How it is measured |
| --- | --- | --- |
| NFR-30 | The same verification entry point runs locally and in CI, with the same runtimes and lock-file resolutions. | One command per gate; CI calls it rather than reimplementing it. |
| NFR-31 | Images are declared by tag and packages resolve through lock files; `versions.lock.md` records each image's tag, the digest it resolved to, and its licence. | `versions.lock.md` (digests refreshed by `make versions-lock`), the Helm values, `apps/web/package-lock.json` and `services/agent/uv.lock`. |
| NFR-32 | UI is built from the Tahseel Design System tokens and components. A screen does not invent local spacing, typography or colour. | The design system's adherence config is vendored at `apps/web/vendor/tahseel-ds/_adherence.oxlintrc.json`; no check runs it, and the repository's lint is ESLint ([open questions §8](open-questions.md#8-requirements-the-code-does-not-meet)). |
| NFR-33 | Only the web application connects to the `awp` database. The agent service reaches domain data through the platform MCP server under the run token's identity. | The database roles, the NetworkPolicies, and the second audit row naming the agent as caller. |
