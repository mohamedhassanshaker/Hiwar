# Budgets and estimated costs

| Item | Value |
| --- | --- |
| Purpose | Agent budgets: the list, the budget form, budget detail, and how a run's estimated cost is counted against a budget period |
| Audience | Developers, business analysts, testers, administrators |
| Related | [Flow F-09](../specs/flows.md#f-09-budget-enforcement) · [Agent runtime: limits](../agent-runtime-spec.md#13-limits) · [Agents and runs](agents-and-runs.md) · [Models and routes](models-and-routes.md) · [Data dictionary: budgets](../04-data-model/data-dictionary/budgets.md) · [Glossary](../glossary.md) |
| Last verified against code | 2026-10-29 |

## Purpose

"Budgets apply to agents. All costs are estimates based on token usage and list prices."

An agent budget is a spending limit for one agent over a period, with effective dates, a warning
threshold and an action at 100%. It is separate from a run's own effort limits: since
[D73](../harness-decisions.md) a single run has no money ceiling, and the limits that stop a
runaway run are steps, tool calls and delegation depth
([agent runtime §13](../agent-runtime-spec.md#13-limits)). Agent budgets are the remaining money
control, and act between runs, not inside one.

The Budgets screen has no navigation entry. It is reached from the Dashboard's estimated-cost card
and from an Inbox budget notification (`components/shared/nav.ts:24-25`).

## Screens

### Budgets list (S-71)

- KPIs (`countBudgets` in `features/budgets/repository.ts`): estimated month to date (the current
  period's estimated spend summed over Active budgets), agents with an Active budget out of all
  agents, Active budgets over 90% of their limit, and windows ending within the next 90 days.
- Status filter: All, Active, Scheduled, Expired, applied to the loaded list.
- Columns: agent, effective dates, status, usage this period (a bar with the percentage, Active
  budgets only), estimated spend, limit with its period ("/ mo"), and History / Edit. Sorted by
  this period's estimated spend, highest first; 25 rows a page (D230). A row opens its detail.
- Actions: Export, New agent budget.

### Budget form

- Agent (fixed once the window exists), limit (AED, estimated), and period (daily, weekly, monthly
  or quarterly).
- **Effective from / to**, with **Keep forever (no end date)**.
- Warn at (%).
- **At 100%:** notify only, switch to a cheaper alias, or pause the agent. Choosing the cheaper
  alias asks for the route to switch to.
- Save budget, disabled until there is a start date and a limit above 0; a saved budget is
  confirmed in a toast, a refused one shows the reason.

### Budget detail (S-72)

Opened at `/budgets?budget=<window id>`; its period history and change log are read for that window
alone (D349).

- Header: the agent, the budget's status, Open agent and Edit budget.
- Cards: limit (with its period), estimated spend for the current period, estimated forecast (the
  spend so far scaled to the whole period, shown in danger when above the limit), and the action at
  100%.
- **Consumption history** (estimated): every period of the window, oldest first, coloured by usage
  band (under 75%, 75–90%, over 90%).
- **Runs by period**, in place of the handoff's "This month by day" chart
  (`features/budgets/components/budget-detail.tsx:108`).
- **Period history:** period, limit, estimated spend, usage, runs and the period's latest event
  (Warning sent, Hard limit reached, Action applied).
- **Budget changes** log, newest first, with who saved it: every create and edit writes "Limit set
  to AED <limit> per <period>." ("No changes recorded." when empty).

**Beyond the handoff design** (`features/budgets/components/budgets.tsx`): the "Switch to route"
picker for the cheaper-alias action, a save refusal message, a read-only view without
`budgets:write`, a working CSV export, the "Action applied" history tag, and empty states ("No
history yet" for a new budget).

## Business rules

| Rule | Source |
| --- | --- |
| Every money figure is an estimate and is labelled "Estimated" or "(est.)"; the export names every money column `…_aed_estimated`. | Spec §9; `COM-15`; `UC-71.1-08` |
| A budget's status (Active, Scheduled, Expired) is derived from its dates. | `UC-71.1-03`, SC-BUD-03 |
| The limit must be above 0 and at most 1,000,000, warn at % between 1 and 99, and effective to after effective from. | `UC-71.1-06`; `features/budgets/schema.ts`, `resolveWindow` in `write-service.ts` |
| Two budgets for the same agent may not overlap; the refusal names the one it hits. Windows are half-open, so one that ends on the day another starts does not overlap it (D322). | `UC-71.1-07`; data model integrity rule 10; `write-service.ts:71-80`, `overlappingBudget` in `repository.ts` |
| "Switch to a cheaper alias" needs a route that exists. A database check enforces it. | `UC-71.1-05`; `agent_budget_cheaper_route_check` (`db/schema/gov.ts:162-163`) |
| An edit names the version it read; a window saved since is refused, to be read again. The agent of a window cannot change. | `COM-10`; `updateBudget` in `write-service.ts` and `repository.ts` |
| A run counts against the budget in force when it finishes: the window whose effective from is on or before then and whose effective to is after it, or none. | `budgetInForce` in `repository.ts` |
| Each finished run adds its estimated cost to the current period of the agent's budget in force. | `UC-72.1-01`, flow F-09 step 1 |
| Crossing the warning percentage raises one `WarningSent` event per period and notifies the person the agent reports to with an Inbox item (kind `SlaWarning`, source `Budget`). An agent reporting to an agent notifies nobody. | `UC-72.1-04`, SC-BUD-01; `spend-service.ts:56-72, 97-102`; `notifyBudget` in `repository.ts` |
| Reaching the limit raises one `HardLimitReached` event per period and notifies the same person. With "pause agent" the agent is paused, unless it is in Error, and a paused agent cannot start a run. With "notify only" runs continue. | `UC-72.1-05`, `-06`; `spend-service.ts:74-93`; `pauseAgent` in `repository.ts`; `features/agents/run-start-service.ts:94-100` |
| A new period starts a new spend total; the previous period moves to history. | `UC-72.1-07` |
| An agent changing a budget through `budget_edit` needs a person's approval for `limitAed`, `effectiveFrom`, `effectiveTo` and `actionAt100`; `period`, `warnAtPct` and `cheaperRouteAlias` do not. | [D57](../harness-decisions.md), [D58](../harness-decisions.md); `features/budgets/privileges.ts` |
| Exporting is audited as `exports:create` with the row count, never the rows. The file is `budgets-estimated.csv`. | `COM-18`; `service.ts:33-75` |
| Creating and editing a budget is audited as `budgets:write`, an edit with each changed field before and after. A budget window cannot be deleted: the console and the tool catalogue offer no delete, and `deleteBudget`, which only the Setup Director's rollback called (D329), was removed with it (D371). | `write-service.ts` |
| An edit returns what changed and what it takes with it: whether the agent is left with no budget in force, and whether the pause at 100% was removed. | D56; `BudgetDiff` in `write-service.ts` |

## Requirements and acceptance

| Requirement | Screen | Scenarios |
| --- | --- | --- |
| [FR-080](../specs/requirements.md#govern) set an agent's budget | [S-71](../Tahseel_AWP_Screens_Use_Cases.md#s-71-budgets--estimated-costs--list) | `UC-71.1-01` … `-09` |
| [FR-081](../specs/requirements.md#govern) budget detail, history and change log | [S-72](../Tahseel_AWP_Screens_Use_Cases.md#s-72-budget-detail) | `UC-72.1-01` … `-08` |

Original scenarios (Spec §7.5.2): **SC-BUD-01** warning threshold notifies the owner and logs the
event; **SC-BUD-02** 100% with "switch to a cheaper alias" moves runs to the cheaper route;
**SC-BUD-03** a scheduled budget becomes Active on its effective-from date and an expired budget no
longer applies. The end-to-end journey is [flow F-09](../specs/flows.md#f-09-budget-enforcement).

## Implementation

| Part | Where |
| --- | --- |
| Page | `/budgets` → `app/(console)/budgets/page.tsx` |
| Feature folder | `apps/web/src/features/budgets/` — `service.ts` (list, export), `write-service.ts` (create, update, overlap check), `spend-service.ts` (`recordRunSpend`), `privileges.ts` (field rules), `repository.ts` |
| Components | `features/budgets/components/budgets.tsx`, `budget-form.tsx`, `budget-detail.tsx` |
| Server actions | `features/budgets/actions.ts`: `saveBudget` (a create without `budgetId`, otherwise an edit at the stored version), `exportBudgets` |
| Detail | `/budgets?budget=<window id>` reads that window's period history and change log only (`loadBudgets`, `readDetails`, D349) |
| Spend path | `run_finish` (harness token) → `finishRun` in `features/agents/run-service.ts:274` → `budgets.recordRunSpend` |
| Platform MCP tools | `budget_list` (T0, `budgets:read`), `budget_create` (T1, `budgets:write`), `budget_edit` (T1, `budgets:write`, escalated per field), all in the default grant (`features/budgets/tools.ts`, `features/agents/default-tools.ts`) |
| Enumerations | Periods `Daily`, `Weekly`, `Monthly`, `Quarterly`; actions `NotifyOnly`, `SwitchToCheaperAlias`, `PauseAgent`; events `WarningSent`, `HardLimitReached`, `ActionApplied` (`db/schema/enums.ts:96-97, 290`) |
| Tables | `gov.agent_budget`, `gov.budget_period`, `gov.budget_event`, `gov.budget_change` — [data dictionary: budgets](../04-data-model/data-dictionary/budgets.md) |
| Privileges | `budgets:read` (screen and export), `budgets:write` (create, edit, delete) |

## Known gaps

| Gap | Evidence |
| --- | --- |
| **Missions report an estimated cost of 0.** The generic runtime finishes a mission through `finalize` with its token counts and tool calls but without `estimated_cost_aed`, which defaults to 0, so `run_finish` records 0 and no mission moves a budget. Warnings, pauses and period totals therefore only change from runs that report a cost. Spend is counted on a Valkey key by `harness/spend.py` ([D92](../harness-decisions.md)), but nothing calls that module ([runtime spec conflicts 4 and 10](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code)). | `_record_outcome` in `services/agent/src/awp_agent/mission/runtime.py:786`; `harness/activities/finalize.py:54` |
| **"Switch to a cheaper alias" is recorded, not applied.** The route is stored (`cheaper_route_id`), but nothing reads it when a run starts, and no code raises the `ActionApplied` event. SC-BUD-02 has no implementation. | `features/budgets/repository.ts:254`; no reader in `features/agents/run-start-service.ts`; `ActionApplied` appears only in `enums.ts` and `budget-detail.tsx` |
| A budget paused by "pause agent" stays paused until somebody changes the agent's status; nothing resumes it when a new period starts. Unverified whether this is intended. | `features/budgets/repository.ts` `pauseAgent`; no resume path found |
| D329 records `deleteBudget` under a `budgets:delete` privilege; no such permission exists, and the service checks `budgets:write` and uses `budgets:delete` only as the audit action. | `authz/permissions.ts`; `deleteBudget` in `features/budgets/write-service.ts` |
