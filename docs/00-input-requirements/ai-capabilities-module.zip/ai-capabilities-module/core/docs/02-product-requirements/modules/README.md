# Modules

| Item | Value |
| --- | --- |
| Purpose | Index of the module documents, and the screen inventory: each screen, its prototype component and the route and feature folder that implement it |
| Audience | Developers, business analysts, testers |
| Related | [Documentation index](../README.md) · [Functional requirements](../specs/requirements.md) · [Use cases and scenarios](../Tahseel_AWP_Screens_Use_Cases.md) · [Solution design](../03-architecture/solution-design.md) |
| Last verified against code | 2026-10-29 |

Each module document follows the same order: purpose, screens (the specification's description of
each screen, then what the built screen adds), business rules with their source scenarios,
requirements and acceptance, implementation, and known gaps.

## Module documents

| Module | Document | Screens |
| --- | --- | --- |
| Shell and account | [shell-and-account.md](shell-and-account.md) | Navigation, top bar, search palette, AI assistant panel, My profile, sign-in, invitation acceptance and signed out (S-01 … S-05) |
| Home | [home.md](home.md) | Dashboard, records drill-down, Inbox, card comments and quick requests (S-10 … S-12) |
| Projects | [projects.md](projects.md) | Projects list and project detail (S-20, S-21) |
| Discussion rooms | [discussion-rooms.md](discussion-rooms.md) | Rooms list, New Discussion Room, the room (S-22, S-23) |
| Work items | [work-items.md](work-items.md) | Board, list and search, New Work Item, the drawer (S-24, S-25) |
| Requests | [requests.md](requests.md) | Requests, Request types, New Request, request detail, request type designer (S-27 … S-30) |
| Scheduled work | [scheduled-work.md](scheduled-work.md) | Scheduled Work Items (S-31) |
| Artifacts and files | [artifacts-and-files.md](artifacts-and-files.md) | Artifacts and Files (S-32, S-33) |
| Organisation | [organisation.md](organisation.md) | Org chart, People & roles, Org units (S-40 … S-42) |
| Agents and runs | [agents-and-runs.md](agents-and-runs.md) | Agents, agent detail, run viewer (S-50 … S-52) |
| Skills | [skills.md](skills.md) | Skills (S-53) |
| Connectors | [connectors.md](connectors.md) | Connectors (S-54) |
| Memory | [memory.md](memory.md) | Memory (S-55) |
| Knowledge | [knowledge.md](knowledge.md) | Collections, collection page, retrieval test (S-56 … S-58) |
| Models and routes | [models-and-routes.md](models-and-routes.md) | Providers and routes (S-59, S-60) |
| Engage | [engage.md](engage.md) | Channels, Embedded Deployment, storyline editor, widget, Conversations (S-61 … S-65) |
| Budgets | [budgets.md](budgets.md) | Budgets list and detail (S-71, S-72) |
| Governance | [governance.md](governance.md) | Audit, Logs, Settings (including Email), System, Documentation, User guide (S-73 … S-75, S-78, S-79) |
| Integrations | [integrations.md](integrations.md) | Integration clients and client detail (S-76, S-77) |

## Screen inventory

The prototype is the design handoff v2 in [`docs/prototype/`](../prototype/CHANGELOG.md). Its
files were reorganised in v2, so the file names here replace those in the archived
specification's appendix (`awp-screens-1.jsx`, `awp-screens-5.jsx` and most of
`awp-screens-2/3/4/6.jsx` no longer hold these components). Routes are under
`apps/web/src/app/(console)/` unless marked; feature folders under `apps/web/src/features/`.

| Screen or component | Prototype component | Prototype file | Route | Feature folder |
| --- | --- | --- | --- | --- |
| Shell, navigation, top bar, user menu | `App` | `awp-app.jsx` | console `layout.tsx` | `components/shared/` (not a feature) |
| My profile | `MyProfile` | `awp-app.jsx` | `/profile` | `organisation` |
| Signed out, sign-in | `SignedOut` | `awp-app.jsx` | `/signed-out`, `/sign-in` (`app/(auth)/`) | `organisation` |
| Invitation acceptance | — (not in the prototype) | — | `/invite/[token]` (`app/(auth)/`, D248) | `organisation` |
| AI assistant launcher and panel | `AiOrb`, assistant panel | `awp-orb.jsx`, `awp-assist3.jsx` | every console page | `assistant`, `components/shared/` |
| Inbox peek | inbox peek | `awp-inboxpeek.jsx` | top bar | `inbox`, `components/shared/` |
| Search palette | `SearchPalette` | `awp-screens-4.jsx` | top bar | `home` (search) |
| Dashboard (Dashboard 3) | `Dashboard3` | `awp-dash3.jsx`, `awp-range3.jsx`, `awp-report3.jsx`, `awp-tour3.jsx` | `/dashboard` | `home` |
| Card comments, quick requests | comments layer | `awp-collab3.jsx` | dashboard | `comments` |
| Records (drill-down) | `Records` | `awp-records.jsx` | `/records` | `home` |
| Inbox | `Inbox` | `awp-screens-2.jsx` | `/inbox` | `inbox` |
| Projects, project detail, New Project | `Projects`, `NewProjectModal` | `awp-projects.jsx` | `/projects` | `projects` |
| Discussion Rooms list, room, New Discussion Room | `SessionsList`, `SessionRoom`, `NewRoomModal` | `awp-rooms.jsx` | `/discussion-rooms`, `/discussion-rooms/[key]` | `rooms` |
| Work Items, drawer, New Work Item | `Tasks`, `TaskDrawer`, `NewWorkItemModal` | `awp-work.jsx` | `/work-items` | `work-items` |
| Requests, request detail | `Requests`, `RequestDetail` | `awp-requests.jsx` | `/requests` | `requests` |
| Request types, request type designer | `Requests` (types tab), `RequestTypeDetail` | `awp-requests.jsx` | `/request-types` (D246) | `requests` |
| New Request | `NewRequestModal` | `awp-newreq.jsx` | top bar, `/requests` | `requests` |
| New request type | `NewRequestTypeModal` | `awp-records.jsx` | `/request-types` | `requests` |
| Scheduled Work Items, New Scheduled Work Item | `Routines`, `NewScheduleModal` | `awp-sched.jsx` | `/scheduled-work-items` | `schedules` |
| Artifacts, Files, Upload file | `Artifacts`, `Files`, `UploadFileModal` | `awp-sched.jsx` | `/artifacts`, `/files` | `files` |
| Org chart, People & roles, Org units | `OrgChart`, `People`, `OrgUnits` | `awp-org.jsx` | `/org-chart`, `/people`, `/org-units` | `organisation` |
| Agents, agent runs, run viewer | `Agents`, `AgentRuns`, `RunViewer` | `awp-agents.jsx` | `/agents`, `/agents/runs` | `agents` |
| Skills, Import skill, New skill | `Skills`, `ImportSkillModal`, `NewSkillModal` | `awp-org.jsx`, `awp-records.jsx` | `/skills` | `skills` |
| Connectors, connector drawer | `Connectors`, `ConnectorDrawer` | `awp-connectors.jsx` | `/connectors` | `connectors` |
| Memory | `Memory` | `awp-memory.jsx` | `/memory` | `memory` |
| Knowledge, collection detail, retrieval test | `Knowledge`, `CollectionDetail`, `RetrievalTest` | `awp-knowledge.jsx` | `/knowledge` | `knowledge` |
| Models & routes, provider drawer, connection editor, custom provider, route editor | `Models`, `ProviderDrawer`, `ConnEditor`, `CustomProviderModal`, `RouteEditor` | `awp-models.jsx` | `/models` | `models` |
| Channels, Embedded Deployment list and detail | `Channels`, `Deployments`, `DeploymentDetail` | `awp-engage.jsx` | `/channels`, `/embedded-deployment` | `engage` |
| Storyline editor, widget preview | `Storyline`, `Widget` | `awp-screens-3.jsx` | `/embedded-deployment` | `engage` |
| Widget frame and loader | `Widget` | `awp-screens-3.jsx` | `/embed/v1/frame/[code]`, `/embed/v1/widget.js` (`app/embed/`, D231) | `engage` |
| Conversations, conversation | — (not in the prototype) | — | `/conversations`, `/conversations/[id]` (D342 … D344) | `engage` |
| Budgets, budget detail, budget form | `Budgets`, `BudgetDetail`, `BudgetForm` | `awp-budgets.jsx` | `/budgets` (no nav entry) | `budgets` |
| Runs | — (not in the prototype) | — | `/runs` (D383) | `agents` |
| Audit, Logs | `Audit`, `Logs` | `awp-engage.jsx` | `/audit`, `/logs` | `governance` |
| Settings | `Settings` | `awp-screens-6.jsx` | `/settings` | `governance` |
| Integrations, client detail, New client | `Integrations`, `ClientDetail`, `NewClientModal2` | `awp-govern.jsx`, `awp-records.jsx` | `/integrations` (no nav entry, D226) | `integrations` |
| System | `SystemPage` | `awp-govern.jsx` | `/system` | `governance` |
| Documentation | `Docs` | `awp-govern.jsx` | `/documentation` (no nav entry, D226) | `governance` |
| User guide | — (not in the prototype) | — | `/guide` (no nav entry, D226) | `components/guide/` |
| Shared states (banners, empty states, delete dialogs, unsaved changes) | shared states | `awp-states.jsx` | every screen | `components/shared/` |
| Shared UI (Card, Modal, Drawer, Tabs, Toggle, Seg, Kpi, Bar, avatars, tags) | `Card`, `Modal`, `Drawer`, … | `awp-shell.jsx` | every screen | `components/ui/` |
| Code field | `CodeField` | `awp-records.jsx` | every form with a code | `components/shared/forms.tsx` |
| Generic action modal | `ActionModal` | `awp-actions.jsx` | every screen | `components/shared/action-modal.tsx` |
| Design system | Tahseel Design System tokens, components, RTL | handoff `_ds/` | — | `apps/web/vendor/tahseel-ds/`, generated wrapper `apps/web/src/ds/` |

The prototype also carries `AgentTrust` (now in `awp-org.jsx`). The platform has no screen for it:
trust is a field on the agent, shown on the agent's Configuration card (see
[Agents and runs](agents-and-runs.md)).
