# Memory

| Item | Value |
| --- | --- |
| Purpose | The Memory screen: scoped, versioned agent memory, its review, comparison and restore, and what a run may remember |
| Audience | Developers, business analysts, reviewers, administrators |
| Related | [Glossary](../glossary.md) · [Agent runtime specification §10](../agent-runtime-spec.md#10-memory) · [Agents and runs](agents-and-runs.md) · [AI platform](../03-architecture/ai-platform.md) · [Use cases S-55](../Tahseel_AWP_Screens_Use_Cases.md#s-55-memory) |
| Last verified against code | 2026-10-29 |

## Purpose

"Manage persistent knowledge, agent context and governance." Memory is what agents keep between
runs. It is organised by scope (Organisation, Business unit, Agent, Session), every change is a new
version, and a new memory can be held for another person's review before any run uses it. An
agent's memory of a person is private to that pair (D68).

## Screens

### Memory (S-55)

- **Header:** New memory, and Clear my memory (with the count) when the person has private agent
  memory.
- **Cards:** Total memories, Pending review and Needs attention, counted over the scopes the person
  may read, and Active agents, the agents with a version that has agent memory on.
- **Search:** across memories, policies, agents and keywords.
  - The **Filters** button opens advanced filters: owner, status, last reviewed and source.
  - **Scope chips:** All scopes, Organisation, Business unit, Agent, Session.
- **Memory explorer:** a collapsible tree (Organisation → business units → agents → sessions)
  of one page (50) of the memories that match, with Previous and Next. Items pending review or
  needing attention show a status dot.
- **Detail panel:**
  - Scope label (the agent, unit, room or organisation; "— your memory" added for the
    person's own agent memory), path, status and Delete memory.
  - Version number with **History**.
  - Memory entries: the current version's blocks, each a heading and body, with its source.
  - **Memory details:** scope, owner, last reviewed, access and write policy (e.g. "PII filter · human
    approval for new rules").
  - **Edit memory.**
  - An overdue-review warning with Review now, which records an approving review against the
    person.
  - For pending memories ("Proposed by the agent. Approve before it is used in runs."): Approve and
    Reject.
- **Modals:**
  - **Version history:** each version's change note, author and date, with Compare (that version
    and the current one side by side) and Restore ("Creates version 15 with this content. The
    change is audited.") for every version but the current one.
  - **Edit:** content (Markdown, each block a heading and body, up to 20,000 characters), owner and
    access shown read only, and a change note, saved as the next version.
  - **New memory:** title, scope (the scopes the person may write to), content and "Needs review
    before it is used" (on unless cleared). The path is the scope's path and a slug of the title; a
    path already taken is refused.

Verified in `features/memory/`:

- Statuses are Active, Pending review, Needs attention, Rejected and Archived.
- A person reads the Organisation scope, a Business unit scope or an agent's shared scope in an org
  unit their `memory:read` reaches, a room's Session scope when they are a participant of the room,
  and their own private (agent, person) scopes; nobody reads another person's private scope. A
  scope out of reach is absent from the tree rather than refused (`UC-55.1-07`, D68). Every change
  is confined the same way, with `memory:write`.
- The search, the scope chips and the advanced filters are applied on the server, in the
  address (`?q=`, `?scope=`, `?owner=`, `?status=`, `?reviewed=`, `?source=`, `?page=`), and
  count the total with the same conditions (D349). The search reads the title and the current
  version's content. Source is who wrote the current version's entries (a run or a person).
  The detail opens the memory `?open=` names, or the page's first; its version history is read
  with it, and another memory's when its History opens. Review now records a review. Filters
  that match nothing keep the screen: the explorer says no memory matches and offers Clear
  (COM-05, D359); "No memory yet." is only for a person who can read no memory at all.
- The person who proposed a memory's newest version cannot approve or reject it; the screen
  disables Approve and Reject for them and says somebody else has to review it (`mayReview`). An
  agent cannot review a memory at all.
- Saving checks the row lock the screen read (`memory.version`); a memory changed since is refused
  as changed by someone else (D185). Approving sets the memory Active and Last reviewed; rejecting
  sets it Rejected.
- Saving shows when the PII filter masked something. A change note is required. New memory has a
  "Needs review before it is used" option.
- Delete memory, after a confirmation, removes the memory with its version history and its review;
  it, New memory, Edit memory and Clear my memory are shown only to people who may write.
- Clear my memory removes every memory in the person's own private scopes, after a confirmation,
  and nothing else.
- A run's `memory_write` appends a block to one memory per (agent, person), `…/remembered`, as a
  new version; the oldest blocks fall off past 20,000 characters.

## Business rules

| Rule | Source |
| --- | --- |
| An agent proposes a new rule in Finance memory. It shows as Pending review. A reviewer approves it, and later runs use it. | SC-MEM-01, FR-065. See the conflict below |
| An administrator compares version 12 with the current version and restores it. A new version is created. | SC-MEM-02, FR-066 |
| A memory passes its review date. It shows "Needs attention" until reviewed. | SC-MEM-03, FR-065. See the conflict below |
| Agents use memory only within the scopes their configuration allows. | Specification §7.4.6, FR-064; the agent's Memory tab ([Agents and runs](agents-and-runs.md)). See the conflict below |
| New organisation-scope rules need review. | Specification §7.4.6. See the conflict below |
| The PII filter applies to memory writes. | Specification §7.4.6, NFR-15, flag `pii-filter-on-memory-writes` (read by `features/memory/policy-service.ts`) |
| Edits and restores create a new version, as [flow F-08](../specs/flows.md#f-08-memory-review) step 4 states. | F-08, FR-066 |
| The proposer of a memory cannot also approve it; an agent's proposal is decided by a person. | FR-065, `UC-55.2-04`, D18 |
| Memory is scoped per (agent, person); never shared across people. A run's write lands in the scope of the token's agent and the acting person, and the model has no argument to move it. | D68, D116, [runtime spec §10](../agent-runtime-spec.md#10-memory) |
| A memory a run writes is Active at once and carries no review: it is private to the agent and person, so nobody else would review it. | `features/memory/run-memory-service.ts` (`rememberForRun`) |
| A run reads, through `memory_search`, only Active memories in the organisation's scope, its agent's shared scope and its agent's memory of the acting person. | D68, `scopePathsForRun` in `features/memory/repository.ts` |
| A review is a person's decision: an agent acting through the MCP server is refused, and reviewing is not in the catalogue. | D18, D108, `features/memory/service.ts` |
| A person can view and clear their own memory; `clearMyMemory` takes no argument. | D68, `features/memory/service.ts` |

## Requirements and acceptance

End-to-end journey: [F-08 Memory review](../specs/flows.md#f-08-memory-review).

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Memory | FR-064, FR-065, FR-066 | [S-55](../Tahseel_AWP_Screens_Use_Cases.md#s-55-memory): `UC-55.1`, `UC-55.2`, `UC-55.3` |

## Implementation

| Concern | Where |
| --- | --- |
| Route | `/memory` under `apps/web/src/app/(console)/` |
| Feature module | `apps/web/src/features/memory/` (`service.ts`, `policy-service.ts`, `run-memory-service.ts`, `repository.ts`, `tools.ts`) |
| Server actions | `features/memory/actions.ts`: `saveMemory`, `reviewMemory`, `loadVersions`, `compareVersions`, `restoreVersion`, `createMemory`, `clearMyMemory`, `deleteMemory` |
| Permissions checked | `memory:read` for reads and run search; `memory:write` for every write |
| Review policy | Whether a new memory waits for review is the New memory option, stored as the memory's own write policy (`ai.memory.write_policy_json`, `requiresReview`), which the detail shows; it does not come from a feature flag (`features/memory/repository.ts`) |
| MCP tools | `memory_search` (T0; `query`, `limit` up to 20, default 5; filtered in SQL), `memory_write` (T1; `content` up to 8,000 characters, no scope argument) — both in `apps/web/src/mcp/tools.ts`; `memory_list` (T0; `q`, `scope`, `status`, `reviewed`, `open`, `limit` up to 200, default 50, `offset`), with `memory_write` the only agent write (D116); `memory_rollback` and `memory_delete` are T2, grantable but not default. Reviewing memory is not in the catalogue (D108) |
| Tables | `ai.memory_scope` (with `person_id`, migration `0038`), `ai.memory`, `ai.memory_version`, `ai.memory_entry`, `ai.memory_review`, `ai.agent_memory_access` — see the [data model](../04-data-model/overview.md) |
| Content storage | Version content is held in `ai.memory_version.content`. Each version also records a `content_ref` (`memory/<path>/<n>.md`) and `lib/objects.ts` declares a `memory` bucket, but no code in `apps/web/src` writes to that bucket |

## ⚠ Unresolved conflicts

| Topic | Requirement or decision says | Code does |
| --- | --- | --- |
| Org-scope review flag | "New organisation-scope rules need review (feature flag 'Memory writes require review for org scope')" (Specification §7.4.6). | The flag `memory-writes-require-review-for-org-scope` is seeded (default on) but read by no code; whether a new memory waits for review is the New memory option. |
| Memory recall at run time | Approved memory becomes Graphiti episodes in per-scope groups (`mem_org`, `mem_unit_<id>`, `mem_agent_<id>`, `mem_session_<id>`) so superseded rules are not recalled (stack specification §6.5). | Those group names appear only in the docstring of `services/agent/src/awp_agent/ingestion/graph.py`; no code in `apps/web/src` or `services/agent` writes memory into Graphiti. A run reads memory through `memory_search` (`searchForRun`), a SQL search over the current version of Active memories. |
| Agent proposals | SC-MEM-01: an agent proposes a rule in a shared scope, and it waits for review. | A run's only memory write, `memory_write`, goes to its private (agent, person) scope and is Active at once. Nothing in the platform lets an agent write to a shared scope or creates an `ai.memory_review` row; a memory is Pending review only when a person creates it with "Needs review before it is used". |
| Review due date | SC-MEM-03: a memory past its review date shows Needs attention until reviewed. | The overdue warning and the "Review overdue" filter read `ai.memory.review_due_at`, and the Needs attention count reads the status NeedsAttention; no product code sets either (only the browser-test fixture does). Review now sets Last reviewed and the status Active but leaves `review_due_at`, so the overdue warning stays after it. |
| Memory access at run time | Agents use memory only within the scopes their configuration allows (Specification §7.4.6, FR-064). | The agent's Memory tab grants (`ai.agent_memory_access`) reach the run payload as `memory`, which the agent service does not read (`services/agent/src/awp_agent/mission/`); the agent memory switch (`agent_version.memory_enabled`) is read only by the Overview and the Active agents count. What a run reads and writes is decided by `scopePathsForRun` and `rememberForRun` from the run's agent and person, and by whether `memory_search` and `memory_write` are in its tool grant. |

## Known gaps

| Gap | Evidence |
| --- | --- |
| The handoff's editable owner and access in the detail panel, and a separate agent picker in New memory, are not built: owner and access are read only in the Edit dialog, and New memory takes one scope from a list. | `features/memory/components/memory.tsx` |
| A memory's title is one language: New memory stores the title it is given as both the English and the Arabic title. | `features/memory/components/memory.tsx` (`createMemory` call) |
