# Connectors

| Item | Value |
| --- | --- |
| Purpose | The Connectors screen: adding MCP servers and REST APIs, testing them and setting a tier per tool |
| Audience | Developers, business analysts, administrators |
| Related | [Glossary](../glossary.md) · [Agents and runs](agents-and-runs.md) · [Projects](projects.md) · [AI platform](../03-architecture/ai-platform.md) · [Connector runtime](../../services/connectors/README.md) · [MCP connectors integration](../06-integrations/mcp-connectors.md) · [Use cases S-54](../Tahseel_AWP_Screens_Use_Cases.md#s-54-connectors) |
| Last verified against code | 2026-10-29 |

## Purpose

"MCP servers that give agents controlled access to systems. Each connector sets the tier of every
tool it exposes." The tier decides whether a call runs, asks for confirmation, waits for a human
approval or never runs. An agent's own mode for a tool can only be stricter than the tier
([Agents and runs](agents-and-runs.md)), and a project policy can only raise it
([Projects](projects.md)).

## Screens

### Connectors (S-54)

- **List:** every connector, with its switch, its name (with its code beneath), transport, auth, a
  summary of tool tiers (`T1 × 3`), and status: Healthy when it is on and Connected, Degraded when
  it is on and in Error, Disabled when it is off. The connector title opens its configuration. The
  screen has no tabs and no catalogue to browse; the catalogue entries not yet installed are listed
  to agents by `connector_list` (D334).
- **Connector:** the one way to add a connector. The drawer opens empty and asks its **Type** first:
  an MCP server or a REST API (OpenAPI) (D296).
- **Connector drawer** (add or configure):
  - Connector enabled, on a saved connector. When off, agents cannot call any of its tools.
  - Name in English and Arabic, and the code agents call its tools by (`code/tool`), which is
    set when the connector is added and fixed after (D224). The code is 2 to 64 lowercase
    letters, digits and hyphens. A blank name falls back to the catalogue entry's name, then the
    code.
  - An MCP server: its transport (Remote MCP (streamable HTTP) with a server URL, or Local MCP
    (stdio) with a command). A REST API: its OpenAPI or Swagger file and an optional server URL
    when added, and its server URL after; it has no transport to choose, and the list shows its
    transport as REST API (OpenAPI) (D283).
  - **Authentication** (not for a stdio server, whose secrets are its environment): None, API key
    (in a named header or query parameter), Bearer token, Basic (user name and password), OAuth 2
    client credentials (client ID, secret and scope; a token URL, or for an MCP server the
    authorization server discovered from it, optionally pinned by issuer), and for an MCP server
    OAuth 2.1 sign-in. Each has its own fields; a secret is never shown back, and an edit that
    leaves it empty keeps the stored one (D296).
  - **Connect** (OAuth 2.1 sign-in, on a saved connector): the administrator signs in at the
    server's authorization server, the platform registering itself there when no client ID is
    given; the callback stores the tokens and the drawer shows Connected or why not. The redirect
    address to register a client by hand is shown beside it. Connect is enabled only once the
    connector is saved with OAuth 2.1 sign-in and its URL is unchanged.
  - **Test connection**, which performs the MCP handshake and lists the tools ("Handshake OK · 12
    tools listed"), or on a saved REST API reaches the API ("The API answered (HTTP 200) · 13
    tools"). It is not offered while a REST API is being added.
  - **Refresh tools**, on a saved MCP connector.
  - **Default tier for new tools**, with the note: "Read-only tools default to T0 and destructive
    tools to T2 from MCP annotations. Project policies can only raise tiers." For a REST API it is
    the **Default tier for a writing operation**: "A GET or HEAD operation reads only, so it is
    registered at T0."
  - **Tools and tiers:** a tier (T0–T3) per tool, named `code/tool`. A tool the server started or
    stopped offering is tagged Unavailable, and a warning lists those tools until their tier is set
    and the drawer saved.
  - Remove, and Save changes (Add connector when new).
- **Platform connector** (`platform`, `internal://platform`, migration 0052): the platform's own
  tools, read from the catalogue (`grantableCatalogue` in `features/agents/platform-catalogue.ts`)
  with their tiers, and never stored as tool rows; a tool the harness answers itself is tagged
  Harness. Its drawer is read-only and its switch is always on: it cannot be removed, changed or
  switched off, refused in the connectors service (`refuseBuiltin`). An agent is granted its tools
  on the agent's Connector tools tab (D228).

Verified in `features/connectors/`:

- Transports are Streamable HTTP, stdio and OpenAPI (`CONNECTOR_TRANSPORTS`). A stdio connector has
  a Command field. A REST API is registered from its OpenAPI document (`importApiConnector`); its
  operations are rows, called by name `<connector>/<operation>` through the platform MCP server.
- The drawer adds a new connector Disabled. Saving a connector with Connector enabled on is checked
  by the server first: an MCP server is registered with the connector runtime and must list its
  tools, and a REST API must answer a GET of its server URL below 500. A failure is refused with
  "It can be added as Disabled" (`saveConnector`). A server URL must be http or https, and a stdio
  connector needs a command. A stored stdio connector without one (only a seed made one) is not sent
  to the runtime, which would refuse the whole set for it; the seeded `sandbox-fs` is Disabled (D372).
- A REST API import reads an OpenAPI 3.x or Swagger 2.0 document, JSON or YAML (`openapi.ts`).
  Each operation is a tool named by its `operationId`, or by its method and path; a second
  operation with a taken name is named by method and path. Deprecated operations and names still
  taken are skipped and reported back after the import. A GET or HEAD operation is registered at
  T0 and any other at the default tier. The server URL is the one given, else the document's; it
  must be http or https.
- An operation call is built from the operation's path, query, header and body parameters and the
  model's arguments; a missing required parameter is refused before the call. The call goes
  through the egress proxy with the stored credential, waits up to 30 seconds, and returns the
  API's status and body to the agent, a 4xx or 5xx included (`openapi-call.ts`, D234).
- A connector's credential is one typed object (`credential.ts`), encrypted in
  `ai.connector.secret_ref`, whose type is the connector's `auth_type`; a credential saved before
  D296 as a bare string is read in its old form. `credential-auth.ts` turns it into request headers
  for both kinds: a REST API's calls (`openapi-call.ts`), and the headers the connector runtime
  opens an MCP session with, sent with the registry and held in its memory only. OAuth flows are
  the MCP SDK's `auth()` (`ClientCredentialsProvider`, and a provider over the stored credential
  for sign-in and refresh), through the egress proxy. A client-credentials or OAuth token is
  reused until a minute before it expires, and the runtime is sent fresh headers before then
  (`viaRuntime`). A Connect is bound to the person who started it and expires after 10 minutes
  (`/api/connectors/oauth/callback`); a lapsed OAuth sign-in that cannot be refreshed is refused
  with "needs to be connected again".
- Test connection fills the tool list from the server and keeps tiers already set; a failed
  handshake shows the error and leaves the draft disabled.
- Refresh tools re-reads the server and reports the tools added and removed; tools that are new
  after a refresh are off until a tier is set, and tools the server no longer offers are marked
  unavailable. A refresh that fails sets the connector to Error.
- Saving the drawer stores every listed tool available at the tier shown, and deletes a tool the
  drawer no longer lists, with the modes agents set for it.
- A saved REST API (OpenAPI) connector has no MCP server: Test connection sends one GET of its
  server URL with the stored credential through the egress proxy, as a run's call is sent, and
  records Connected for any answer below 500 and Error for a server error or no answer, with the
  reason (`testApiConnector`). Its tools are its document's operations, so Refresh tools is not
  offered for it and the server refuses one (D268).
- The list's switch turns a connector on or off at the version the screen holds and sets its status
  to Connected or Disabled (`setConnectorEnabled`).
- A disabled connector's tools are not offered to a run, and a call to one is refused with
  "`<code>` is disabled."
- Remove first shows which agents lose tools (the agent versions whose grant names one of its
  tools), then asks for confirmation; the agents' modes for its tools are deleted with it. A
  connector served by the platform (`internal://`) cannot be removed (D228).
- A connector has no list of allowed agents. A run reaches every enabled connector, narrowed by its
  project's allowed connectors (`UC-21.2-02`, `connectorsForRun` in
  `features/agents/run-start-service.ts`); which of its tools the run is offered is the agent
  version's own grant (`ai.agent_tool_mode`), checked again at the MCP server (D30, D227). A tool
  added from the agent's grant picker is granted at Auto when its tier is T0 and at Approval
  otherwise (D264).
- Without `connectors:write` the screen is read-only. An empty tool list has its own message.

## Business rules

| Rule | Source |
| --- | --- |
| An administrator adds a connector, tests it and sets "submit purchase order" to T2; two agents are granted the tool on their Connector tools tabs. | SC-CON-01, FR-062, D227 |
| An administrator disables a connector. Agents that try its tools receive a clear "connector disabled" result. | SC-CON-02, FR-063 |
| Tool tiers: T0 runs immediately; T1 asks for confirmation in the room or widget; T2 pauses the run and creates an approval in the Inbox, or a card in the room, and the decision resumes the run; T3 never runs. | Specification §5.3, [glossary](../glossary.md); see the conflicts below |
| A new tool's tier defaults from its MCP annotations: `destructiveHint` → T2, `readOnlyHint` → T0, otherwise the connector's default tier for new tools. | FR-062, `UC-54.1-03`, `tierForTool` in `features/connectors/discovery-service.ts` |
| A REST API operation's tier defaults from its HTTP method: GET and HEAD → T0, any other method the connector's default tier. | `UC-54.1-09`, `import-service.ts` |
| Project policies can only raise a tool's tier, never lower it. | FR-019, `UC-21.2-03`, `-04` |
| A failed handshake allows adding the connector only as Disabled. | `UC-54.1-05` |
| Removing a connector names the agents that lose its tools before it is removed. | FR-063, `UC-54.2-05` |
| An agent's mode for a connector tool is never looser than the tool's tier. | FR-055, `UC-51.2-04` |
| A connector tool is called only by an agent run whose grant names it; a T2 tool needs a bound approval for that exact call, and the approval reference is removed before the API sees the arguments. An integration client cannot call connector tools. | D30, D49, D171, `callConnectorOperation` in `mcp/server.ts` |
| A connector tool is listed to a model as `<connector>__<tool>`, because providers refuse `/` in a function name, and read back as `<connector>/<tool>` for the grant, tier, approval and audit. In the tool part `-` is written `--` and `.` is written `-_` (`erp/claims.read` → `erp__claims-_read`), and read back exactly. | D223, D363, `tool-name.ts`, agent `mission/deps.py` |
| Connector writes through the agent tool catalogue are T2 and decided by somebody other than the requester, except in the assistant panel; no tool carries a credential. | D277, D284 |

## Requirements and acceptance

End-to-end journey: [F-10 Connector and tool tiers](../specs/flows.md#f-10-connector-and-tool-tiers).

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Connectors | FR-062, FR-063 | [S-54](../Tahseel_AWP_Screens_Use_Cases.md#s-54-connectors): `UC-54.1`, `UC-54.2` |

## Implementation

| Concern | Where |
| --- | --- |
| Route | `/connectors` under `apps/web/src/app/(console)/`; `?open=<code>` opens a connector's drawer, and an OAuth Connect returns there with `connect=connected` or `connect=failed` and the reason |
| Feature module | `apps/web/src/features/connectors/` (`service.ts`, `discovery-service.ts`, `import-service.ts`, `credential.ts`, `credential-auth.ts`, `openapi.ts`, `openapi-call.ts`, `tool-name.ts`, `repository.ts`, `tools.ts`) |
| Server actions | `features/connectors/actions.ts`: `saveConnector`, `setConnectorEnabled`, `setToolTier`, `testConnector`, `testApiConnector`, `refreshConnectorTools`, `removeConnector`, `importApiConnector`, `connectOAuth` |
| OAuth callback | `GET /api/connectors/oauth/callback` (`app/api/connectors/oauth/callback/route.ts`): exchanges the code for the person who started the Connect and redirects (303) to `/connectors` |
| Permissions checked | `connectors:read` for reads; `connectors:write` for every change, test, refresh and Connect |
| Connector runtime | `services/connectors` holds the registry and runs one Pod per stdio connector. The web app pushes the whole set of enabled MCP connectors with `PUT /connectors` (hot reload), lists tools with `GET /mcp/{code}/tools` and calls one with `POST /mcp/{code}` (`apps/web/src/lib/connector-runtime.ts`, `CONNECTOR_RUNTIME_URL`). A connector restored without its credential answers 409, and the web app sends the set again and retries. The runtime opens remote MCP sessions through the egress proxy (D297). See its [README](../../services/connectors/README.md) |
| OpenAPI operations | Served by the platform MCP server (`apps/web/src/mcp/server.ts`), agent callers only, using the credential stored against the connector row |
| MCP connector tools to agents | Listed and called through the platform MCP server as `<connector>__<tool>`, with the schema the server declares, read from the connector runtime; forwarded to the connector runtime after the grant and approval checks (D223) |
| MCP tools | `connector_list` and `connector_operation_list` (T0, default grant); `connector_test_create` and `connector_refresh_create` (T1, the built-in Assistant's defaults, grantable); `connector_create`, `connector_api_create`, `connector_edit`, `connector_activation_edit`, `connector_tool_edit` (T2, decided by somebody other than the requester) and `connector_delete` (T2), grantable, not default. No tool takes a credential: an agent's import of an API that needs one is stored Disabled until a person adds it in the console (D277) |
| Tables | `ai.connector_catalog_entry`, `ai.connector`, `ai.connector_tool`, `ai.agent_tool_mode`, and `ai.agent_platform_tool` for the Platform connector's tools — see the [data model](../04-data-model/overview.md). `ai.connector_allowed_agent` is not read or written; dropping it is an open decision (D227) |
| Seeded connectors | Production seed: `platform` only (the built-in Platform connector, D228; D245), and the catalogue entries `connector_list` offers (`CATALOG` in `apps/web/src/db/seed/data/connectors.ts`). The browser-test fixture adds `knowledge`, `m365`, `erp`, `cards` and `sandbox-fs`; `erp`, `knowledge` and `sandbox-fs` are seeded Disabled, because no cluster has a server for them (D372, D374). Every seeded connector is stored with authentication None |

## ⚠ Unresolved conflicts

| Topic | Requirement or decision says | Code does |
| --- | --- | --- |
| T1 confirmation | T1 asks for confirmation in the room or widget. | The mission runtime pauses only T2 platform tools for approval (`_needs_approval` in `mission/runtime.py`); no T1 confirmation step was found in the mission path. |
| T3 never runs | T3 never runs. | Nothing refuses a T3 connector tool. A T3 tool granted at Approval is offered to the run at T3 (`tierUnderMode` in `features/agents/repository.ts`); the harness pauses only T2 (`APPROVAL_TIERS`), and the MCP server requires an approval only for T2 (`callConnectorOperation`). Only a mode of Denied keeps it from the run. |
| Handshake before enabling | A connector whose handshake failed may be added only as Disabled (`UC-54.1-05`). | The drawer and `saveConnector` hold to it, but the list's switch and `connector_activation_edit` enable a connector with no handshake and record it Connected (`setEnabled` in `repository.ts`). |

## Known gaps

| Gap | Evidence |
| --- | --- |
| The handoff's Platform MCP transport and Run token authentication are not stored values. A connector at an `internal://` URL is shown as Platform MCP and stored as Streamable HTTP; the seed stores Run token as authentication None. | `kindOf` in `features/connectors/repository.ts`; `TRANSPORT` and `CONNECTOR_AUTH` in `apps/web/src/db/seed/capabilities.ts` |
