# Models and routes

| Item | Value |
| --- | --- |
| Purpose | The Models & routes screens: model providers, their connections and allowed models, and the route aliases agents call through agentgateway |
| Audience | Developers, business analysts, administrators |
| Related | [Glossary](../glossary.md) · [AI platform: agentgateway](../03-architecture/ai-platform.md#agentgateway) · [Model providers](../06-integrations/model-providers.md) · [Agents and runs](agents-and-runs.md) · [Budgets](budgets.md) · [Use cases S-59, S-60](../Tahseel_AWP_Screens_Use_Cases.md#s-59-models--routes--providers) |
| Last verified against code | 2026-10-29 |

## Purpose

"Providers hold one or more connections; each connection allows specific models. Routes chain
provider › connection › model." Agents never name a model: they name a route alias, and the route's
chain decides which provider, connection and model answer, with fallbacks tried in order. The web
app renders each route into agentgateway, which every model call goes through
([AI platform](../03-architecture/ai-platform.md)).

## Screens

### Models & routes — providers (S-59)

Header actions: **Add custom provider** and **Add cloud provider** on the Providers tab, **New
route** on the Routes tab.

**Providers tab.**
- Filters: All, Active, Not active, Custom and Cloud.
- Each provider card shows its switch, cloud or custom (a custom provider names its engine, such as
  "Custom · vLLM"), number of connections, models allowed, and "Not connected" when it has none.
  Otherwise its tag is the worst health of its switched-on connections: Failed, then Not checked,
  then Healthy; Disabled when the provider or every connection is off.
- **Provider drawer:**
  - Provider active. When off, every connection and route step using the provider is skipped, and
    every route through it is republished to the gateway without its steps.
  - Connections, with Add connection. Each connection card shows its endpoint, authentication,
    region, health tag and allowed models ("None — no route can use it" when it allows none), with
    Configure, Test and Remove.
  - Models offered by the provider: every model any of its connections allows.
  - **Test** (on a connection): sends a short call to each allowed model at the endpoint its kind
    answers at, and stores each model's result and the time on the connection. The results are
    shown in the drawer.
  - Each connection's health comes from that stored test, never from its switch: Not checked until
    a test has run, Healthy when every model answered, Failed when any did not (the failing models
    and their reasons are listed), with when it was last tested. A switched-off connection reads
    Disabled. A connection on a workload identity (IAM role, Entra ID), or to a provider the
    console cannot call on the OpenAI wire format (anything but OpenAI, Anthropic, Groq, Mistral and
    a custom engine), cannot be tested from the console, so it stays Not checked. Saving an edited
    connection clears its result, and a model kind the console has no test for (audio or video
    generation) is listed but left out of the verdict (D196).
  - Delete provider.
- **Connection editor:**
  - connection name (e.g. Production), region, endpoint, authentication (API key, Entra ID, IAM
    role, Bearer token, OAuth 2.1, None) and secret ("Leave blank to keep the stored one");
  - **allowed models on this connection** ("Routes can only use models allowed here"), each with
    the kind it answers at, and a field to add a model name;
  - connection active;
  - Test, which tests what the editor holds, and Save connection.
- **Add custom provider** (on-prem):
  - inference engine: Ollama, vLLM, LM Studio, Hugging Face TGI, llama.cpp server, LocalAI, NVIDIA
    Triton/NIM, OpenRouter, or another OpenAI-compatible engine;
  - display name, base URL (the engine's OpenAI-compatible base, ending `/v1` for every engine
    offered, Ollama and TGI included) and optional API key;
  - **Discover models**, then choose which to allow. Discovery calls `<base>/models`; when the
    engine answers an error its refusal names the URL called, and the model names can be typed
    instead (D337).

Verified in `features/models/`:

- **Add cloud provider** adds OpenAI, Anthropic, Azure OpenAI, AWS Bedrock, Google Gemini, Google
  Vertex AI, Mistral AI, Cohere, Groq or DeepSeek, with a display name, an optional API key and the
  model names, and an endpoint field where the provider needs one (Azure's resource name, Bedrock's
  region host, Vertex AI's project ID). A provider carries its agentgateway identity
  (`GATEWAY_PROVIDERS`) as data, so renaming it does not break the routes through it. A provider
  name already taken is refused.
- A custom provider's engine is shown by its name, read back from the stored value (D175).
- Each allowed model has a kind (Chat, Embedding, Image, Speech, Transcription, Rerank, Decision,
  Audio, Video). Voice input in rooms, the AI Assistant panel and the widget uses the first
  Transcription model (by provider, connection, model name) on an active connection that the console
  can call: an OpenAI-compatible provider with an API key, bearer token or OAuth secret, or none
  (D386). Without one the microphone answers "Voice input is not set up". A model name can be added by hand; a connection with no models shows a warning, and
  testing one is refused.
- The secret is write-only. A connection can be tested before it is saved, with an OK or FAILED
  result per model; that draft test stores nothing. The test calls the provider directly with the
  credential, through the egress proxy, not through the gateway.
- Saving a connection republishes every route through it to the gateway.
- Deleting a provider, connection or route is refused while something uses it, and the refusal lists
  what.
- Without `models:write` the screen is read-only.

### Models & routes — routes (S-60)

**Routes tab.**
- Columns: alias (with its use beneath, a Typesafe tag with the schema title, or a Voice tag with a
  summary), chain (each step marked Primary or Fallback as provider › connection › model, tagged
  Inactive when its provider or connection is off), the number of active agent versions using it as
  their primary route, and Edit.
- **Route editor:**
  - Alias: "Agents reference this alias". A new route's alias is suggested from the use and the
    primary model; an edit can rename it.
  - **Use**: Standard, Typesafe, Voice, Embedding or Decision.
  - **Typesafe:** an output schema; "Responses must validate against the schema; invalid output is
    retried, then routed to the fallback". Also a confidence threshold and max retries on invalid
    output. Example route: `classifier-typed`. The schema is entered as free JSON Schema, and the
    server refuses one that is not JSON or has no `type`, `properties` or `$ref`.
  - **Voice:**
    - Mode: realtime speech-to-speech, or a pipeline STT → LLM → TTS. A realtime route can use
      only realtime models.
    - Speech-to-text and text-to-speech voice.
    - Languages.
    - Barge-in: allowed or off.
    - Max call length.
  - **Embedding:** used by knowledge collections; the vector size comes from the model's response.
  - **Decision:** picks one of the options its caller names, at the provider's decisions endpoint
    (`/api/alpha/decisions` on OpenRouter). Its steps offer only models whose kind is Decision, and
    no other route offers them; the server refuses either mix (D290). Example route: `agent-choice`.
  - **Chain:** primary and fallbacks, each a provider, connection and model. Add fallback and
    Remove. A step offers only active providers and connections, and only models the connection
    allows. A route needs at least one complete step.
  - Delete route, and Save route.

## Business rules

| Rule | Source |
| --- | --- |
| An administrator adds an on-prem vLLM server, discovers its models, allows two of them, and uses one as a fallback in `reasoning-default`. | SC-MDL-01, FR-071 |
| An administrator creates a typesafe classification route used by agentic request entry. Invalid outputs are retried, then fall back. | SC-MDL-02, FR-072, F-02 step 2 |
| A provider is switched off. Routes skip its steps and use their fallbacks. | SC-MDL-03, FR-071 |
| Routes can only use models allowed on the connection. | FR-071, S-59 |
| A route alias is suggested and unique. | FR-072, `UC-60.1-06`, `COM-13` |
| A provider, connection or route in use cannot be deleted. | FR-071, FR-072 |
| An agent runs only on a chat route (Standard or Typesafe); a knowledge collection embeds on an Embedding route and extracts its graph on a chat route. | D257, D337 |
| Provider credentials are stored encrypted on the connection and written to a Kubernetes Secret per connection, which the rendered agentgateway resources reference; a rendered route never carries the credential. | Stack specification §6.1; `apps/web/src/agentgateway/secrets.ts` |
| Every money figure derived from model usage is an estimate. | AD-20, `COM-15` |

## Requirements and acceptance

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Providers | FR-071 | [S-59](../Tahseel_AWP_Screens_Use_Cases.md#s-59-models--routes--providers): `UC-59.1` |
| Routes | FR-072 | [S-60](../Tahseel_AWP_Screens_Use_Cases.md#s-60-models--routes--routes): `UC-60.1` |

## Implementation

| Concern | Where |
| --- | --- |
| Route | `/models` under `apps/web/src/app/(console)/` |
| Feature module | `apps/web/src/features/models/` (`provider-service.ts`, `route-service.ts`, `repository.ts`) |
| Server actions | `features/models/actions.ts`: `setProviderActive`, `saveConnection`, `testConnection`, `testConnectionDraft`, `discoverModels`, `addCustomProvider`, `addCloudProvider`, `removeProvider`, `removeConnection`, `saveRoute`, `removeRoute` |
| Permissions checked | `models:read` for reads; `models:write` for every change and test |
| Connection test | `apps/web/src/lib/model-probe.ts`: one call per allowed model at the endpoint its kind answers at (`/chat/completions`, `/embeddings`, the decisions path and the others), 20 seconds each, through the egress proxy; stored on the connection (`last_test_at`, `last_test_result_json`) |
| Rendering to agentgateway | `apps/web/src/agentgateway/render.ts` turns a route into one internal `AgentgatewayModel` per chain step and one for the alias, whose `virtualModel.failover` lists the steps in priority order. A Decision route's step is a custom provider at the connection's origin whose chat format is sent to the decisions path, because agentgateway has no decisions format: the caller posts the decisions request, with an empty `messages`, to the alias as a chat call (D290); `publish.ts` applies them through a narrow Kubernetes service account; `secrets.ts` writes provider credentials. `republishRoutes` re-applies every route when the web server starts (`apps/web/src/instrumentation.ts`). Where no service account is configured, rendering is skipped |
| Typesafe classification | The agent service's `classify.py` calls the `classifier-typed` route for agentic request entry (`POST /classify/request`) and answers 503 when the route cannot produce valid output after its retries |
| Decisions | `gateway_client.decide` asks a Decision route its questions; a discussion room chooses its answering agent on `agent-choice` (`POST /classify/agent`, D290) |
| MCP tools | None. Models and routes are not in the agent tool catalogue |
| Tables | `ai.model_provider`, `ai.provider_connection`, `ai.connection_allowed_model`, `ai.route`, `ai.route_step` — see the [data model](../04-data-model/overview.md) |
| Seed | Routes `reasoning-default`, `small-fast`, `vision`, `embedding-default`, `classifier-typed`, `agent-choice`, `voice-realtime`, `local-private` (`apps/web/src/db/seed/data/models.ts`). The failover order is decided at seed time from the provider keys that are configured (`apps/web/src/db/seed/models.ts`). On OpenRouter, `small-fast`, `classifier-typed` and `vision` use `nvidia/nemotron-3.5-super-vl:free`, and `reasoning-default` uses `nvidia/nemotron-3-ultra-550b-a55b:free` (D208, D245, D362); `agent-choice` uses the decision model `cloudflare/clef-flash` (D290) |

## ⚠ Unresolved conflicts

| Topic | Screen or requirement says | Code does |
| --- | --- | --- |
| Typesafe and voice settings | A typesafe route holds responses to its output schema, retries invalid output and applies its confidence threshold; a voice route has its mode, voices, languages, barge-in and call length. | These are stored on the route and read by nothing that serves it: `render.ts` renders the chain only. Agentic request entry holds its answer to its own Pydantic type with 2 retries and a confidence floor of 0.72 (`classify.py`), not to the route's schema, threshold or retries. |
| A route in use cannot be deleted | A route used by an agent or a collection is refused with the users named (`UC-60.1-09`). | `routeUsers` counts agent versions that use it as their primary route, and collections by an `embedding` key that collections do not store (they store `embeddingRoute` and `extractionRoute`). A route used only by a collection is deleted; one used only as an agent's fallback route is stopped by the database's foreign key as an unexpected error rather than a named refusal. |

## Known gaps

| Gap | Evidence |
| --- | --- |
| Not built from the handoff: a connection on/off switch on the drawer's connection card, route "uses", named output schemas with a preview, and speech model lists for voice routes. | `features/models/components/` |
| Whether agentgateway's open-source edition supports failover priority groups, voice and realtime routes and structured-output passthrough is an open stack decision (SD-7). | [Open questions](../specs/open-questions.md) |
