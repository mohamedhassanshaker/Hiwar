# Engage: channels, embedded deployments, storylines and the widget

| Item | Value |
| --- | --- |
| Purpose | The Channels, Embedded Deployment, Storyline editor, Conversations and Widget screens, and the public routes a visitor or channel provider reaches |
| Audience | Developers, business analysts, agent designers, administrators |
| Related | [Glossary](../glossary.md) · [Requests](requests.md) · [Discussion rooms](discussion-rooms.md) · [Solution design](../03-architecture/solution-design.md) · [Use cases S-61 … S-65](../Tahseel_AWP_Screens_Use_Cases.md#s-61-channels) · [Embedded widget specification](../06-integrations/embedded-widget-spec.md) · [Host websites](../06-integrations/host-websites.md) |
| Last verified against code | 2026-10-29 |

## Purpose

"Agents published to websites and channels, with branding, security and storylines"
(Specification §7.4.10). The [business overview](../01-business/overview.md) places embedded
deployments in the product; this module covers the screens that build them. Channels are the messaging surfaces those conversations, room mirroring
and request intake arrive through.

## Screens

### Channels (S-61)

"Enable or disable a channel and configure its credentials. Changes are hot-reloaded."

**Live channels table.** Columns: enable toggle, channel (Web widget, WhatsApp, Microsoft Teams),
status (Enabled, Degraded, Disabled), bound to, and Configure.

**Configure drawer.**
- Credentials for the channel type.
- **Bind to:** an embedded deployment, Discussion rooms (mirror) or Request intake.
- **Unknown senders:** treat as an external contact, or ignore.
- Rate limit (messages per minute).
- Business hours: always on, or the working calendar.
- Save. "Changes are hot-reloaded."

**Test channel modal.**
- Send to and Message, then Send test message.
- Checks: credentials valid, outbound message delivered (a real message posted to the channel's
  outbound endpoint) and inbound webhook reachable (a call to this platform's own
  `/api/channels/<type>/inbound`), each with its time in milliseconds.
- The result is stored on the channel, so an enabled channel whose checks failed reads Degraded,
  and the test is audited as `channels:test` with each check's result.

**Coming soon.** Slack, Email, SMS, Voice/IVR, Telegram, Webex, Google Chat, Instagram, Facebook
Messenger. They cannot be enabled.

Verified in `features/engage/`: each row has a Test link; each check reports its own result and
timing, and a check that cannot run says why (`channel-test.ts`). The drawer also takes the inbound
webhook signing secret, the outbound endpoint URL, the specific deployment a binding points at, and
offline messages in English and Arabic. Secrets are write-only.

**What a binding does with an inbound message** (`features/engage/gateway.ts`):

- **Embedded deployment:** the sender becomes an external contact and the deployment's storyline
  runs for them as for a widget visitor, without an origin check. The reply is the assistant's
  newest messages, at most 3, in their text form (`degrade`). Out of hours the message is taken in
  and the script does not run.
- **Discussion rooms (mirror):** the message names its conversation (`conversation` in the
  webhook body) and is posted in the room mirrored to it, as the person whose email is the sender
  or as an external contact; a message naming no mirrored conversation is recorded and goes
  nowhere. A reply posted in a mirrored room is sent to the channel's outbound endpoint as
  "author: text" (`mirrorOutbound`); a failure there is logged and the room carries on.
- **Request intake:** the message raises a request of the one published request type that takes
  intake from that channel, with the sender as an external contact, and the reply gives the request
  key. With no such type, or more than one, the message is recorded and not routed.

### Embedded Deployment — list (S-62)

"Agents published to websites and channels, with branding, security and storylines."

Columns: deployment, default agent, surfaces (Widget, WhatsApp, Teams), storyline (the running
version's code, version and mode), status (Enabled, Disabled, Draft), rating ("No ratings yet" when
empty). Action: New deployment (English and Arabic name, default agent, the surfaces it is
published on, and an ID generated from the name), which creates a Draft with no allowed origins and
opens it. Deleting a deployment shows how many conversations it has, and removes its surfaces,
storylines and conversation history; it is refused while a channel binds to it. With the
`embedded-deployments` flag off, the screen says the feature is off instead of showing an empty list
(`UC-62.1-04`).

### Embedded Deployment — detail (S-63)

Header actions: Copy embed code, Publish (while the saved status is not Enabled: the same save
with the status Enabled, refused with the reason when the deployment cannot be enabled, D263),
Save changes and Delete deployment. Three tabs.

**Tab — Deployment details.**

| Card | Fields |
| --- | --- |
| Main details | Name (English), name (Arabic), default agent with Agent details, status (Enabled, Disabled, Draft), surfaces (Widget, WhatsApp, Teams) |
| Security & access | Allowed origins, each a scheme and a host with any port (`https://example.com`, `http://localhost:8080`); a page opened as a file sends `null` (the loader names it so, whatever `location.origin` reads, D273), which works only when `null` is listed on its own, and admits any page, sandboxed frames included (D219, D220); visitor identity (anonymous with OTP step-up, or a signed JWT from the host site); human handoff queue (a project, or None); Agent acts as (a person, or "Nobody — the agent does not answer"; the picker is enabled only for a holder of `agents:configure`, D221); rate limit per visitor (1–1000 messages a minute) |
| Branding | Widget title (English and Arabic), accent colour, welcome message (English and Arabic) |
| Widget | Disclaimer (English and Arabic) and whether a visitor may close it; voice input; read aloud; session idle timeout in minutes (1–1440, default 30); saved progress retention in minutes (0–43200, default 1440) (D231) |
| Quick actions | The chips under the greeting, in order: id, label (English and Arabic), the storyline it starts, the pages it is offered on (`*` is every page), and the identity needed to start it (Anyone, Verified by OTP, Signed in); Move up, Move down, Remove, Add quick action (D231) |
| Last 30 days | Conversations, rating, OTP success, and per scenario: started, completed and handed off (as a share of started), and the steps where stopped scenarios most often stood (D231) |

For a signed-JWT identity the card takes the token secret (at least 16 characters, write-only) and
what happens when no valid token arrives (treat as anonymous, or refuse the conversation). The
handoff queue is chosen from real projects. An accent colour that fails the contrast check is
refused with a suggested colour, which the message offers as "Use #…" (`UC-63.1-05`). A save is
refused when the status is Enabled with the Widget surface and no allowed origin (`UC-63.1-04`),
when a quick action names a storyline the deployment does not have, or when two quick actions share
an id; a deployment holds at most 12 quick actions. A quick action left without an id gets one
derived from its English label. Changing Agent acts as needs `agents:configure` and accepts only an
active person. Saves are audited as `channels:deployment` with the status, surfaces and number of
origins.

**Tab — Storylines.** A picker of the deployment's storylines, New storyline (a code of lowercase
letters, digits and underscores, and a name), and the storyline editor below for the one picked.
The storyline under the deployment's own code opens every conversation; each other storyline is a
scenario a quick action starts (D231).

**Tab — Preview.** The real widget frame on a placeholder page, with the embed code and Restart
preview, below.

### Storyline editor (S-64)

- **Header:** the storyline's code, its draft version and the running version ("Draft version 4 ·
  running version 3"), mode (**Guided** or **Strict**), Simulate (test variables → Start
  simulation) and Publish.
- **Steps list:** each step shows its type and whether it is configured or overrides the agent.
  Action: Add step, which takes a new step name (lowercase letters, digits and underscores) and adds
  an empty Message step after the selected one.
- **Step types:** Message, Ask, Form, Confirm, Decide, Classify, Tool, Skill, Verify, Create work,
  Handoff, Wait, Subflow, Go to, End.
- **Step panel:**
  - step name and step type;
  - **Agent for this step:** "Uses the deployment default agent", or an override ("Overrides the
    default agent for this step only");
  - message (for Message, Ask, Confirm and End), in English and Arabic, or configuration;
  - **Send verbatim (exact)**;
  - **Phase mode:** the storyline's mode, or Guided or Strict for this step only (D231, D339);
  - type-specific fields: slot and max attempts (Ask), method (Verify: OTP, SSO or UAE Pass),
    queue (Handoff), tools (Tool), skills (Skill), request type and "Sync fields from the request
    type" (Form: copies the type's form attributes, those asked at no step, with a List attribute's
    choices), request type (Create work);
  - **Field type** (Ask): the control the widget shows and the rules the value must meet, one of
    text, textarea, number, amount, phone, email, date, time, datetime, select, multiselect,
    lookup, file, consent and location (a Verify step asks for the one-time code), with label
    (English and Arabic), placeholder, example, pattern, help, minimum, maximum, mask and whether
    free text is allowed beside the control;
  - **Choices:** value, English and Arabic, used as quick replies and as a select field's options;
  - **Show the result as** (Tool): nothing, a list, a card or a timeline, with the result field
    that holds the rows and the fields a row's id, title, subtitle, meta and badge are read from;
  - next step, and On error (Retry once, Go to a step, Hand to a person);
  - Delete step, which lists the steps that point at it and must be fixed.
- **Step settings:** a step's `config` takes only the keys the engine reads, checked by
  `stepConfigInput` (`features/engage/schema.ts`) on the editor's save and on
  `storyline_step_edit` alike: `choices` and `field` (Ask), `choices` (Classify), `branches` and
  `otherwise` (Decide), `present` (Tool), `requestTypeCode` and `formFields` (Form, Create work),
  `waitSeconds` (Wait), `subflowCode` (Subflow), `gotoStepName` (Go to), and on any step `mode`,
  `onErrorStepName` and `branch`. Any other key, here or inside `field`, `present`, a choice, a
  branch or a form field, is refused with its name.
- **A menu** is an Ask step whose slot stores the answer and whose choices the visitor sees as
  buttons, followed by a Decide step, which shows nothing and routes on that slot: the first
  branch (`{slot, equals, goto}`) whose slot holds a choice's value, else `otherwise`, else the
  next step.

Editing a published storyline copies it to a new draft first. The editor shows a note in Strict
mode. Publish lists every problem that blocks it, per step, and the list stays on screen
(`storyline-publish.ts`): no steps (D279); a Message, Ask or Confirm step with no English message,
an Ask step with no slot, or a Form step with no fields (not configured); a step other than End or
Handoff with no next step; a step no path from the first reaches; a missing Arabic message; and a
Tool step naming a tool its agent is not granted. A step is saved once typing pauses, in order and
without a toast; a refusal is shown (D280). Simulate takes test variables and visitor replies, one
per line, and shows the transcript, the slots and the outcome; nothing is written and no tool is
called, every effect is reported as succeeded, and a reply of `fail` takes the step's On error path.
Creating and publishing a storyline are audited (`channels:storyline`, `channels:publish_storyline`);
step edits are not.

### Conversations (D342)

AI Capabilities → **Conversations** lists every visitor conversation of every deployment, newest
first, 50 a page, filtered on the server by period (last 24 hours, 7 or 30 days, or a from and to
date), deployment, status (agent answering, taken over, handed off, ended) and text, which is
matched literally against what was said and the visitor's key. Columns: started, deployment, what
the visitor first wrote, messages, last activity, status (with who has taken it over) and rating.
With the `embedded-deployments` flag off the screen says the feature is off. A row opens the
conversation at `/conversations/<id>`: its transcript, updated live through
`/api/sse/conversations/[id]` (the `conversation:<id>` channel, published whenever a line is
written), its channel, rating, request and handoff room.

**Take over** pauses the agent: the visitor is told a member of the team has joined, their
messages are kept but neither the script nor the agent answers them, a reply a run was already
writing is dropped, and the widget shows free text without the step's chips. The person writes
to the visitor, who sees it as a human agent's message. **Resume agent** hands the conversation
back from where the script stands; **End conversation** ends it as Completed. Only one person can
hold a conversation at a time. Reading needs `conversations:read`; taking over, writing, resuming and
ending need `conversations:answer` (D343), which configuring channels and deployments does not give.
Each of take over, resume and end is audited (`conversations:takeover`, `conversations:resume`,
`conversations:end`). A person's messages reach widget visitors
only: a conversation that arrived on WhatsApp or Teams is answered in the webhook's own response,
and nothing sends to that channel later.

Beside the open conversation a panel lists the **open conversations** (D344): every one not ended
that the agent is answering, once its visitor has written and while they have been active within the
deployment's idle timeout, and every one this person has taken over, most recently active first. One a colleague has
taken over is not listed. The panel refreshes from the `conversations` channel, which says that a
conversation started (with the visitor's first line: a widget opens its conversation before anybody
writes), that a line was written (whether a visitor wrote it, and who holds it) or
that its state changed, never what was said; `/api/sse/conversations` gives it to holders of
`conversations:read`. The panel also turns on **desktop alerts**: once the browser allows
notifications, every console screen alerts on a new visitor conversation and on a visitor's
message in a conversation the agent is answering or this person holds, one notification per
conversation, naming the deployment and never the visitor's text, and not for the conversation on
screen. Clicking an alert opens the conversation (`components/conversation-notifier.tsx`, mounted
in the shell).

### Widget (S-65)

The prototype shows a host website with the widget open: a title, quick replies, a confirmation
card, a "Talk to a person" handoff, a message box, Minimise and a launcher. As built, the widget
draws no step progress (D341) and says "Identity verified." as a notice once a visitor passes a
Verify step.

The widget follows the [embedded widget specification](../06-integrations/embedded-widget-spec.md)
(D231); its section 19 lists what is built and what is not. The host contract (embed code, routes,
refusals) is in [Host websites](../06-integrations/host-websites.md).

**Embed code.** Copy embed code gives the loader and the deployment:

```html
<script
  src="https://<console host>/embed/v1/widget.js"
  data-deployment="<deployment code>"
  data-lang="auto"
  data-position="bottom-right"
  defer></script>
```

**Loader.** `/embed/v1/widget.js` holds no secret. It reads `data-deployment`, `data-lang` (`auto`
follows the page's `<html lang>`, then the browser), `data-position` (flipped in Arabic),
`data-open` and `data-context` (`{"page": "…"}`), asks `/embed/v1/config/<code>?host=<page origin>`
first, and draws nothing, with a console warning, for a deployment that is not Enabled or a page
it does not allow. Otherwise it draws the launcher (title, accent colour, an unread dot while
closed) and opens the frame `/embed/v1/frame/<code>` in a sandboxed `iframe`, full width below
480 px. It exposes `window.AnyPlatformAssistant`: `open()`, `close()`, `startAction(storyline code)`,
`setLanguage("en" | "ar")` and `on(name, handler)`, which fires `open` and `close`.

**Frame.** The chat runs in the frame, served from the platform, so the host page reaches it only
through `postMessage`, checked by origin on both sides. The proxy lets only the deployment's allowed
origins and the console frame it (`frame-ancestors`; `null` listed admits every page, `* file:`, D220, D278). The frame
keeps the session token in its own session storage and the visitor key in its own local storage, both
under the platform's origin. It has the console assistant panel's shape (D348): a card tinted with the
deployment's accent colour and rounded to 24 px, the header on it with round controls, and the
conversation in an inset rounded card. It has a header with the title, a menu (language, Talk to a person when the
deployment has a handoff queue, Start a new conversation), Expand (the panel fills the host page;
Restore puts it back, D340) and Minimise (also Escape); the disclaimer,
whose dismissal lasts for the browser session; the messages; and a composer that is free text with a
microphone beside Send (Voice input, on by default; D386: the recording is turned into text by the platform's
Transcription model and added to the draft for the visitor to edit and send), one field's control, or locked.
Assistant messages carry a speaker (Read aloud, through the browser's speech synthesis, reading the
message's `speakable` text without masked values) and thumbs up and down; an ended conversation asks
for a 1–5 rating. A field control with an example offers "Show me an example", which shows the
example under the control. Chips in earlier messages are inactive, except the greeting's quick actions. Unsent
messages are kept while offline and resent; a rate-limited composer counts down. A conversation the
visitor comes back to with a half-finished scenario offers Continue or Start over.

**Session.** `POST /embed/v1/sessions` starts a session, or picks up the visitor's open conversation
while it is within the deployment's idle timeout, or while a half-finished scenario in it is within the
saved-progress retention, when the widget offers to continue; an older one is ended as Abandoned and a
new one opened. It checks the deployment is Enabled and published on the Widget surface, and that the
host origin the frame passes is an allowed origin. Every call presents a session token (HS256 under a
key derived from `AUTH_SECRET`, 30 minutes) naming the conversation, the visitor key, the language and
the page, and every answer returns a fresh one (`widget-session.ts`). The calls and their refusals are
in [Host websites](../06-integrations/host-websites.md).

**Messages.** Every assistant turn is a message of ordered blocks (text, chips, list, card, summary,
receipt, timeline, notice, handoff), an `input` instruction for the composer and, while a
scenario runs, its `flow` (scenario, phase mode, step, progress). No "Step x of y" bar is drawn, and the
visitor's own messages have no bubble colour (D341). They are built from the stored
transcript and the conversation's state (`protocol.ts`), so a reload, the stream and a second tab show
the same thing. The stream (`/stream`, server-sent events) sends an agent's reply as it is written
(`message.start`, `message.delta`), each finished message (`message.end`), `typing`, `handoff.update`
and `session.update` with a fresh token.

**Storyline engine.** The storyline under the deployment's own code opens every conversation; a quick
action starts another of the deployment's published storylines in the same conversation. One that
needs Verified by OTP is refused with `IDENTITY_REQUIRED` until the visitor has verified, and one that
needs Signed in is always refused, since the widget has no sign-in. Each step runs in its phase mode,
or the storyline's:

- **Guided:** a step's choices are suggestions. A reply that is none of them, or anything typed where
  the script asks nothing, is answered by the deployment's agent (below), and the step's choices are
  offered again under the answer. A typed field's value is still checked. Back returns to the previous
  question and Main menu to the first, clearing the answers given from there. An End step shows its
  message and leaves the conversation open, so the agent answers what the visitor writes next; it ends
  when the visitor ends it or it goes idle (D286). When the visitor typed details that no Tool or Create
  work step acted on, the End step's message is not shown: the agent receives the choices and details
  and does what it can or says it cannot (D339).
- **Strict:** only the current step's value is taken. A question gets a fixed redirect and the step is
  asked again; after more than 2 off-script turns a person is offered.

In Guided, an answer may also carry values for later Ask steps: each later field with a
pattern takes the value its pattern finds, checked by its own rules, the widget echoes "Got it: …", and
those steps are skipped. An Ask step with a field type is checked on the server (`fields.ts`): a refused
value is told why, with the field's example, and counts as an attempt. A Form step shows all its fields
in one control, each labelled and with a select for a field with choices, and sends them together; only the form's own fields, and a listed choice, are taken. A Confirm step shows a summary of the values its message names
(or every value), each with Edit, and Confirm and Cancel; Edit goes back to the step that collected the
value. Cancel ends the conversation Cancelled with "Cancelled. Nothing was submitted." A Tool step calls each
`connector/tool` with the slots as arguments: an OpenAPI connector's operation is issued by the web app
with the connector's stored credential, an MCP connector's tool goes to the connector runtime. With a
presentation set, the result is shown as a list (a tapped row's id is the next reply), a card or a
timeline. A file field's upload goes to `/files`, is checked against the field's types and size (10 MB
unless set), the platform's upload rules and quarantine, and is stored in the attachments bucket as a
`work.attachment` owned by the conversation. A Verify step's code is 6 digits, valid 5 minutes, with 3
attempts and 3 resends; it is sent to the phone or email slot through the conversation's channel
endpoint, never written to the transcript, and shown in the console preview only.

**Agent answers.** A deployment with no opening storyline, an off-script question in Guided, and the
details a Guided script ended without acting on are answered by the deployment's default agent acting as the deployment's "Agent acts as"
person (D221), with the conversation's earlier turns and in the visitor's language. The reply streams
into the widget and is written when the run ends; a run that does not succeed, or does not start,
leaves a line saying the assistant could not answer and offering a person; with no identity set, the
visitor is told the assistant is not set up to answer. A reply that arrives after a person has taken
the conversation over is dropped (D342). The agent can start one of the deployment's services for a
visitor who asked for it in their own words: `conversation_scenario_list` lists the quick actions'
scenarios and `conversation_scenario_create` starts one in the visitor's conversation, with the values
the visitor already gave as a prefill the engine checks like any answer. Both work only in a run
answering that visitor's conversation, read from the run row, and a scenario whose quick action needs
more than an anonymous visitor is refused (`scenario-service.ts`, D231).

**Handoff.** Talk to a person is offered, and accepted by the server, only when the deployment has a
handoff queue; without one the conversation would go to nobody (D340). It moves the conversation into a discussion room with its transcript (the
deployment's handoff queue). After that, each visitor message is posted in the room as a System message
"Visitor: …", and a person's message in the room reaches the widget as a human agent's message
(`mirrorOutbound` in `gateway.ts`). The handoff block reads queued until a person has written in the
room, then connected.

**Events.** The widget's events are stored in `ai.widget_event`, never with a value the visitor typed:
`widget.opened`, `widget.closed`, `widget.minimized`, `widget.language`, `widget.restarted`, `quick_action.clicked`, `scenario.started`,
`scenario.step_completed`, `scenario.validation_failed`, `scenario.handoff`, `scenario.ended`,
`identity.step_up` and `feedback.submitted`. The deployment's Last 30 days card reads them.

**Preview.** The Preview tab embeds the real frame with `?preview=1`. Starting a preview session
needs `channels:write`; it skips the origin and surface checks, keeps the conversation under the
designer's own key, and shows the one-time code, which a preview has nowhere to deliver.

## Business rules

| Rule | Source |
| --- | --- |
| While a person has taken a conversation over, the agent answers nothing in it; the person writes until they resume the agent or end the conversation. | D342 |
| A tapped choice reads in the transcript as its label, with its value kept beside it. | D342 |
| An administrator configures WhatsApp, binds it to the website-assistant deployment, sends a test, and enables it. | SC-CH-01, FR-073 |
| An administrator binds Teams to discussion rooms. Rooms mirror into Teams. | SC-CH-02, FR-073, flag `mirror-rooms-to-microsoft-teams` |
| A designer builds a strict card-replacement storyline, simulates it with test variables, publishes it and copies the embed code. | SC-EMB-01, FR-076 |
| A visitor completes the storyline. A request is created ("Create work" step) and the reference is returned. | SC-EMB-02, FR-077 |
| A visitor chooses "Talk to a person". The conversation moves to the human handoff queue with its context. | SC-EMB-03, FR-077 |
| In Strict mode the agent may only perform the current step, and exact messages are sent verbatim. | Specification §7.4.11 |
| In Guided mode the agent answers side questions and replies that are none of a step's choices, and the step's choices are offered again. | Specification §7.4.11, D221, D339 |
| A step's phase mode, when set, replaces the storyline's mode for that step. | D231, `modeAt` in `features/engage/storyline.ts` |
| In Guided mode one answer may fill later fields that recognise their value by pattern; Strict takes the current step's value alone. | D231, `extractByPattern` in `features/engage/fields.ts` |
| A typed field's value is checked on the server; the widget's own hints decide nothing. | D231, `checkField` in `features/engage/fields.ts` |
| Publishing creates a new storyline version. Conversations in progress keep their version. | Specification §7.4.11, data model integrity rule 6, `UC-64.1-09` |
| In Strict mode, after more than 2 off-script turns the visitor is offered a person. | `UC-65.1-07`, `OFF_SCRIPT_LIMIT` in `features/engage/storyline.ts` |
| An Ask step allows 3 attempts unless it says otherwise. | `UC-65.1-06`, `DEFAULT_MAX_ATTEMPTS` |
| A deployment with no storyline is given one from its Storylines tab, as an empty draft the editor fills and publishes (D219). Further storylines are named; the one under the deployment's code opens conversations and the others are started by quick actions (D231). | `storyline-service.ts` `createStoryline`, `repository.ts` `publishStorylineVersion` |
| A Tool step's tools are checked against the active version's grant of the step's agent, or of the deployment's default agent (D227); a tool outside it is flagged. | `UC-64.1-12`, `toolsAllowedTo` in `repository.ts`, `storyline-service.ts` |
| The widget answers only for an enabled deployment published on the Widget surface, framed by an allowed origin; each visitor is rate-limited per minute (`RATE_LIMITED`, retry after 60 seconds). A page that is not allowed gets no launcher and cannot frame the widget. | FR-075, FR-077, D231, `UC-65.1-10`, `UC-65.1-12` |
| After a handoff, the visitor's messages reach the handoff room and a person's reply there reaches the widget. | D231, `noteVisitorInRoom`, `mirrorOutbound` |
| A deployment bound to WhatsApp or Teams sends the same messages as text: chips and lists numbered, cards and summaries as label and value lines. | D231, `degrade` in `features/engage/protocol.ts` |
| An inbound channel message is accepted only with a valid HMAC signature over the raw body (`x-awp-signature`) against the channel's inbound secret; a channel without a secret accepts nothing. | `app/api/channels/[channelType]/inbound/route.ts`, `features/engage/gateway.ts` |
| An inbound message is processed, answered with the offline message (outside business hours or on a holiday), throttled, or dropped (Coming soon channel, disabled channel, ignored unknown sender); the decision is recorded. | FR-073, `features/engage/inbound.ts`, `ai.channel_message` |
| Coming soon channels cannot be enabled. | FR-073, [overview: out of scope](../01-business/overview.md) |
| A web widget cannot be enabled without an allowed origin; a deployment cannot be deleted while a channel binds to it. | `UC-63.1-04`, `saveDeployment` and `deleteDeployment` in `features/engage/deployment-service.ts` |
| Who a deployment's agent acts as is set only by a holder of `agents:configure`, and only to an active person. The system role Widget visitor (`agents:invoke`, `knowledge:read`, `knowledge:search`) exists for that identity; the platform does not require it, so a deployment may act as any active person (D332). | D221, D332, `saveDeployment`, `WidgetVisitor` in `apps/web/src/authz/permissions.ts` |
| Turning off the `embedded-deployments` flag stops every widget (the loader draws nothing and no session starts) and shows the Embedded Deployment and Conversations screens as off. | D231, `UC-75.3-01`, `publicConfig` and `startSession` in `widget-session.ts` |
| Every write on these screens is audited: `channels:write` (on or off), `channels:configure` (whether the secret changed, never the secret), `channels:test`, `channels:deployment`, `channels:delete`, `channels:storyline`, `channels:publish_storyline`, `rooms:moderate` for a room mirror, and the takeover actions. | `COM-18`, `features/engage/service.ts`, `deployment-service.ts`, `storyline-service.ts`, `conversations-service.ts` |
| Channels are read-only in the agent tool catalogue. An agent builds deployments and storylines; a deployment save that changes its default agent, surfaces, allowed origins, visitor identity, JWT secret or run-as person, or makes it live, and publishing a storyline, wait for an approval by somebody other than the requester. | D108, D253, `exposureChanges` in `features/engage/tools.ts` |

## Requirements and acceptance

End-to-end journey: [F-05 Embedded widget with a strict storyline and handoff](../specs/flows.md#f-05-embedded-widget-with-a-strict-storyline-and-handoff).

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Channels | FR-073 | [S-61](../Tahseel_AWP_Screens_Use_Cases.md#s-61-channels): `UC-61.1` |
| Embedded Deployment — list | FR-074 | [S-62](../Tahseel_AWP_Screens_Use_Cases.md#s-62-embedded-deployment--list): `UC-62.1` |
| Embedded Deployment — detail | FR-075 | [S-63](../Tahseel_AWP_Screens_Use_Cases.md#s-63-embedded-deployment--detail): `UC-63.1` |
| Storyline editor | FR-076 | [S-64](../Tahseel_AWP_Screens_Use_Cases.md#s-64-storyline-editor): `UC-64.1` |
| Widget | FR-077 | [S-65](../Tahseel_AWP_Screens_Use_Cases.md#s-65-widget-visitor-experience-and-preview): `UC-65.1` |

## Implementation

| Concern | Where |
| --- | --- |
| Routes | `/channels` (S-61), `/embedded-deployment` (S-62 … S-65, the storyline editor and preview are tabs) and `/conversations` with `/conversations/[id]` (D342) under `apps/web/src/app/(console)/`; the widget frame `/embed/v1/frame/[code]` under `apps/web/src/app/embed/v1/` |
| Feature module | `apps/web/src/features/engage/`: `storyline.ts` (the storyline engine, one pure function shared by the widget, the simulation and inbound channel messages), `fields.ts` (typed fields, their checks and pattern extraction), `conversation.ts`, `conversation-view.ts` and `conversation-effects.ts` (the visitor runtime that performs the engine's effects), `visitor-agent.ts` (agent answers, D221), `scenario-service.ts` (the agent starting a scenario, D231), `conversations-service.ts` (take over, write, resume, end, D342), `protocol.ts` (the widget's messages and their text form), `widget-session.ts`, `widget-http.ts` and `widget-stream.ts` (the `/embed/v1` session, its edges and its event stream), `components/widget-frame.tsx` (the frame), `components/conversations.tsx`, `conversation-detail.tsx`, `active-conversations.tsx` and `conversation-notifier.tsx` (D342, D344), `storyline-service.ts`, `storyline-publish.ts`, `deployment-service.ts`, `gateway.ts`, `inbound.ts`, `identity.ts`, `channel-test.ts` |
| Server actions | `features/engage/actions.ts`: `setChannelEnabled`, `configureChannel`, `testChannel`, `mirrorRoom`, `createDeployment`, `saveDeployment`, `deleteDeployment`, `deploymentConversationCount`, `createStoryline`, `addStorylineStep`, `saveStorylineStep`, `deleteStorylineStep`, `setStorylineMode`, `publishStorylineDraft`, `simulateStoryline`, `requestTypeFields`, `takeOverConversation`, `resumeConversationAgent`, `sendConversationMessage`, `endConversationByPerson` |
| Permissions checked | `channels:read` for reads; `channels:write` for channels, deployments and storylines, and to start a widget preview session; `agents:configure` to change who a deployment's agent acts as; `rooms:moderate` to mirror a room; `conversations:read` for the Conversations screen and its streams, `conversations:answer` for its actions (D343); `agents:invoke` for the `conversation_scenario_*` tools |
| Public routes | `GET /embed/v1/widget.js` (the loader, carries no credential); `GET /embed/v1/config/[code]` (the launcher's settings, or 403); `/embed/v1/frame/[code]` (the frame page); `/embed/v1/sessions` and `/embed/v1/sessions/[id]/…` (the session API, see [Host websites](../06-integrations/host-websites.md)); `GET`/`POST /api/channels/[channelType]/inbound` (provider webhook; GET is a reachability check). The per-request-type intake form `/api/request-widget/...` belongs to [Requests](requests.md) |
| Console streams | `GET /api/sse/conversations` (the `conversations` channel, D344) and `GET /api/sse/conversations/[id]` (one conversation, D342): 403 without `conversations:read`, 501 without live updates |
| Connector calls | A storyline Tool step issues an OpenAPI connector's operation from the web app with the stored credential (`features/connectors/openapi-call.ts`) and calls an MCP connector's tool through the connector runtime (`callConnectorTool` in `apps/web/src/lib/connector-runtime.ts`) |
| Feature flags | `embedded-deployments` (read by `deployment-service.ts` for the deployment list, `service.ts` for the Conversations screen, and `widget-session.ts` for the loader's configuration and session start), `mirror-rooms-to-microsoft-teams` (read by `service.ts` `mirrorRoom`); `voice-ivr-channel` and `visitor-ratings-in-widget` are seeded but not read |
| MCP tools | `channel_list`, `deployment_list`, `storyline_problem_list`, `storyline_simulation_create` and `conversation_scenario_list` (T0, default grant); `conversation_scenario_create` (T1, default grant); `deployment_create`, `deployment_edit` (escalates, D253), `storyline_create`, `storyline_edit`, `storyline_step_create`, `storyline_step_edit`, `storyline_step_delete` (T1, in the built-in Assistant's defaults and granted to other agents only by choice, D265); `deployment_delete`, `storyline_publish` (T2, grantable, not default) (`features/engage/tools.ts`, `features/agents/default-tools.ts`) |
| Tables | `ai.channel`, `ai.channel_message`, `ai.embedded_deployment`, `ai.deployment_surface`, `ai.storyline`, `ai.storyline_version`, `ai.storyline_step`, `ai.deployment_conversation`, `ai.conversation_message`, `ai.widget_event`, and `work.attachment` for a visitor's uploads — see the [data dictionary](../04-data-model/data-dictionary/engage.md) |

## ⚠ Unresolved conflicts

| Topic | Requirement or decision says | Code does |
| --- | --- | --- |
| Free conversation | A deployment with no published storyline still talks. | The default agent answers, acting as the deployment's "Agent acts as" identity, which only an administrator sets; with none set the visitor is told the assistant is not set up (D221). |
| Agent per step and the scripted profile | A step can override the deployment's agent; the harness runs strict storylines in the `scripted` profile (Specification §5.2). | Storylines run in the web app's engine, not on the agent runtime. Classify matches the visitor's text exactly against the choices; a Skill step only records which skills applied; a Wait step continues at once; a Subflow step is not run and follows its On error. The model is called only for a free conversation and for an off-script question or unacted details in Guided, always by the deployment's default agent (D221, D339). |
| Side questions in Strict mode | Widget specification 7.1 and 10.1: a short answer, then the same step again. | A fixed redirect and the same step again; no agent is asked (`offScript` in `storyline.ts`, `UC-65.1-07`). |

## Known gaps

| Gap | Evidence |
| --- | --- |
| UAE Pass as a visitor identity is not built (identities are anonymous with OTP step-up, or signed JWT). A quick action that needs Signed in is therefore refused with `IDENTITY_REQUIRED` whatever the visitor verified. | `VISITOR_IDENTITIES` in `apps/web/src/db/schema/enums.ts`; `sendAction` in `widget-session.ts` |
| A Verify step's method picker offers OTP, SSO and UAE Pass, but every Verify step asks for a one-time code. | `components/storyline.tsx`; the `Verify` case in `storyline.ts` |
| The widget has no way to pass a host-signed visitor token, so a Signed JWT deployment treats every widget visitor as having none: anonymous, or refused with `IDENTITY_REQUIRED`, per its fallback. | `startSession` in `widget-session.ts` passes no identity token to `openConversation` |
| A widget OTP is undeliverable: a code goes only through a channel conversation's outbound endpoint, and a widget conversation has none, so the visitor reads "We could not send a one-time code." No SMS sender exists for a number the visitor types (D231). | `deliverOtp` in `conversation-effects.ts` |
| A refused origin is not written to the server log (`UC-65.1-10` asks for it to be logged); the loader writes a console warning and the browser refuses to frame the widget. | `config/[code]/route.ts`, `logRefusal` in `widget-session.ts` logs only unexpected failures |
| Not built (D231): a payment page, the entities' own back-ends, a live position in the handoff queue, and WhatsApp and Teams drawing blocks as controls (they receive the text form). | [Widget specification, section 19](../06-integrations/embedded-widget-spec.md#19-implementation-status) |
| The handoff's four accent swatches are replaced by a free hex input. | `features/engage/components/deployment-detail.tsx` |
| The Configure drawer has no Enabled switch; a channel is enabled from the toggle in its table row. | `features/engage/components/channel-modals.tsx`, `channels.tsx` |
| WhatsApp phone and business IDs and Teams app and tenant IDs are not separate fields in the Configure drawer. | `features/engage/components/channel-modals.tsx` |
| WhatsApp and Teams have not been proven end to end against the real providers; no real credentials exist (U-4). | [Open questions](../specs/open-questions.md) |
