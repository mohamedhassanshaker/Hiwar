# Agents and runs

| Item | Value |
| --- | --- |
| Purpose | The Agents list, Agent detail (configuration, versions, playground, run list) and Run viewer screens, and the built-in Platform Assistant |
| Audience | Developers, business analysts, agent designers |
| Related | [Glossary](../glossary.md) · [Agent runtime specification](../agent-runtime-spec.md) · [Agent-runtime decisions](../harness-decisions.md) · [AI platform](../03-architecture/ai-platform.md) · [Skills](skills.md) · [Connectors](connectors.md) · [Memory](memory.md) · [Knowledge](knowledge.md) · [Models and routes](models-and-routes.md) · [Use cases S-50 … S-52](../Tahseel_AWP_Screens_Use_Cases.md#s-50-agents--list) |
| Last verified against code | 2026-10-31 |

## Purpose

"Versioned workers with skills, tools, memory and an org position." An agent is configured here and
nowhere else: its instructions, model routes, trust, granted tools, skills, knowledge and memory
access. Every agent, the built-in Platform Assistant included, runs on one generic runtime and
differs from the others only by this configuration (D64). How a run behaves once started — the
mission loop, approvals, outcomes, limits — is specified in the
[agent runtime specification](../agent-runtime-spec.md) and not repeated here.

## Screens

### Agents — list (S-50)

- **Cards:** agent (avatar, name), org unit, version, status (Idle, Running, Waiting, Paused,
  Error, Retired), execution profile, model, runs and estimated cost. The built-in Assistant is listed.
  An installation seeded before D371 still holds the Setup Director's agent `dir` until a migration
  the owner approves retires it.
- **New Agent modal** (`agents:write`): English and Arabic names, org unit, execution profile
  (Conversational, Task, Planner, Reviewer, Triage, Scripted, Routine; Task unless changed), agent
  trust (Standard unless changed), model route, and a code suggested from the English name. The new
  agent opens on its Instructions tab, unpublished.
- **Model routes:** an agent runs on a chat route, one whose kind is Standard or Typesafe. New
  Agent (which defaults to the first such route by alias) and the Configuration card's primary
  and fallback pickers offer only those, and `createAgent` and `saveDraft`, which the agent tools
  `agent_create` and `agent_edit` call, refuse an Embedding, Voice or Decision route in both
  languages: a Decision route such as `agent-choice` answers only at the provider's decisions
  endpoint, so every run on it would fail at the gateway.

Verified in `features/agents/components/`: the name search and status chips are kept in the URL; an
"N agents in error" link filters to them; a failed agent shows its last failure on hover; an empty
result offers Clear. New Agent does not offer the System trust (`UC-50.2-04`), and refuses a code
already in use. Delete agent needs `agents:publish` and is refused
while the agent is in use (runs, people or agents reporting to it, embedded deployments using it as
their default agent, memory reviews it proposed, a memory scope of its own, storyline steps that
override to it); the refusal names its newest 10 runs by key, so they can be deleted with
`run_delete`. Its own configuration (versions, skills, tool modes, budget) goes with it.

### Agent detail (S-51)

**Header.** Agent name, org unit, active version and status. Actions:
- **No Test in playground** (D382, owner's decision 2026-11-03, departing from the Specification's
  S-51 header). An agent is tried from the Assistant with the tool `agent_test_run_create` (T2,
  `agents:invoke`): a real run on surface `Playground` that appears in the run list, waiting up to
  60 seconds for its text.
- **Publish new version** (`agents:publish`): release notes, required → publish. The draft becomes
  the active version. A draft whose evaluation score is below 70 is refused with the score
  (`UC-51.3-04`).
- **Delete agent** (`agents:publish`), for every agent but the built-in Assistant, and **Reset to
  defaults** (`agents:configure`), for the built-in Assistant only.

While an agent has an open draft, the tabs show it, with "Showing draft vN. Runs use vM until you
publish it." (`UC-51.2-01`). Trust, run budget, model and statistics are the active version's.
Editing controls are offered to holders of `agents:write`, and for the built-in Assistant also
`agents:configure`; anybody else sees the configuration read only.

**Tabs** as built (`features/agents/components/agents.tsx`):

| Tab | Content |
| --- | --- |
| Overview | **Configuration** card: execution profile, primary model, fallback route, reports to, **agent trust**, memory ("Agent memory on" or Off) and run budget (soft and hard, in AED). Its Edit opens the Configuration dialog: execution profile, primary and fallback model routes (chat routes only; the fallback can be cleared), agent trust (not offered for the built-in Assistant), run budget soft and hard, and the agent memory switch, which no run reads (see [Memory](memory.md#-unresolved-conflicts)). Profile, routes and memory are saved to the draft; trust and budget are written to the active version, each with the version lock the last write left (D174). **Last 30 days:** runs, success rate, estimated cost and eval score, with View runs. |
| Instructions | System instructions (markdown) and Edit. Saved as a draft revision, never onto the running version. |
| Skills | Enabled skills. "Add or remove skills" opens one list of published skills to tick and untick, saved as one change (D238); each row's switch removes one. A skill whose declared tools the agent cannot reach is flagged, and one a run leaves out says "Not applied to runs" with the reason: its version is not published, or, for a skill that is not bundled, its security scan is missing or failed ([Skills](skills.md#business-rules)). |
| Connector tools | The agent's whole tool grant, one record per connector with the built-in Platform connector first, each opening onto its granted tools with a remove control (D228). A Platform tool (a platform tool or a harness-answered built-in, D38, D80) is granted or not; a tool of another connector carries its mode for this agent (Auto, Approval or Denied), shown with the tool's tier and changed from a select, which refuses a mode looser than the tier allows (`setToolMode`). A skill that declares a tool this grant does not reach is named above the list. "Add or remove tools", above the list, opens every connector collapsed to a checkbox and a count, ticked whole or opened to leave single tools out, and saves the additions and removals as one change, a connector tool that reads (T0) at Auto and any other at Approval (`changeToolGrant`, D238, D264). Granting an approval-class Platform tool (T2 or T3) asks for confirmation in the popup; removing does not. `?tab=grant` opens this tab. |
| Knowledge | Every knowledge collection with its indexing state, each granted or revoked with a switch. |
| Memory | Every memory scope with its kind, each set to no access, read, or read and write. The run payload carries these grants and no run reads them (see [Memory](memory.md#-unresolved-conflicts)). |
| Agent run list | Status filter, a search over run key and the title of the work item or room it ran for, and a Started period (any time, 24 hours, 7 or 30 days), newest first, 50 runs a page with the total; filtered and paged on the server, read only while the tab is open, with the filters in the URL (`runStatus`, `runPeriod`, `runQ`, `page`) (D300, D349). Columns: run (goal, key and what it ran for), status, started and duration. A run waiting on an approval or a question links to where it is decided: its room, its work item, or the Inbox. A row opens the run viewer. A running or waiting run can be cancelled from here, after a confirmation, by a holder of `agents:invoke`. |
| Versions | Version, published date, published by, eval score and Active flag. Action: Roll back, which makes that version the active one (`agents:publish`). |

**Agent trust presets** (one value per agent, stored on its active version). The defaults are the
handoff's; no run reads trust (see [the conflict](#-unresolved-conflicts)):

| Preset | Defaults |
| --- | --- |
| Restricted | Own items only · T0 tools |
| Standard | T0/T1 · T2 via approval |
| Elevated | Cross-project · can assign |
| Coordinator | Can propose new agents |
| System | Not assignable; held by no seeded agent since D371 |

No agent ever has the approve permission. A system agent's trust (`pa`) is fixed: `setTrust`
refuses it (`features/agents/service.ts`).

**Permissions at the agent.** Every configuration write, publish, roll back and delete checks the
permission in the agent's own org unit, or organisation-wide for an agent in none; creating an agent
checks it in the org unit it is created in (`requireAgentPermission`, D330).

**The configuration screen and the grant.** The Connector tools tab, the approval-class warning and
the "skill declares a tool the agent is not granted" check all read the same sources the run token
uses: each tool's tier from the platform catalogue (`grantableCatalogue` in
`features/agents/platform-catalogue.ts`), and `grantedToolNames()` for what the agent
reaches (D79, D228, [runtime spec §9](../agent-runtime-spec.md#9-agent-configuration-screen)). No second list
of tools is kept in the screen. A connector has no list of allowed agents: a run reaches every
enabled connector, narrowed by its project's allowed connectors, and is offered the tools this grant
names (D227). A connector tool's mode reaches the run: a Denied tool is not offered, and Approval
makes a T0 or T1 tool pause for a person on every call (`tierUnderMode` in
`features/agents/repository.ts`).

### Runs (D383)

`/runs`, first item of the Govern navigation, `agents:read`. Every agent's runs, filtered on the server
by agent (All agents or one) and by how long ago they started (Any time, 24 hours, 7 days, 30 days),
both kept in the address. Newest first by default; the Agent, Status, Started, Duration and Cost
headers sort by that column, a second press reverses it (`?sort=&dir=`, an unknown column is newest
first, a still-running run has no duration and sorts last). 50 runs to a page with the pager; the
count names every match. A row opens the run viewer. Owner request, 2026-11-03.

### Run viewer (S-52)

Reached at `/agents/runs?id=<run key>`, or with no id for the most recent run (of the agent
`?agent=` names, if any), which is read alone (D349). With no run at all it says that no agent has
run yet; an id that names no run is 404 (D249). The page follows the run's event stream
(`/api/sse/runs/<run id>`) and refreshes as it changes.

- **Header:** run key, goal, agent and version, status, with the actions Open trace, Replay
  (`agents:invoke`), Cancel run while it is Running or Waiting, and Delete run once it has finished
  (D300). Cancel and Delete ask for confirmation, are offered to holders of `agents:invoke`, and the
  server decides who may (D295).
- **KPIs:**
  - duration (including waiting time, e.g. "+ 6m waiting");
  - tokens, with cache hit %;
  - tool calls, with how many approvals are pending; choosing it shows only the tool steps.
- **Timeline** of steps, including waiting steps: one per model response with text, one per tool
  call (Done, Refused, or Unanswered when the mission ended first) and a closing Handoff step with
  the answer, recorded by the runtime when the mission ends, each result cut at 4,000 characters
  (`mission/timeline.py`, D300). A step opens in place: a tool step shows its arguments and its
  result, any other step its text, with hooks applied and, for a waiting step, Open in Inbox. A
  run that finished before steps were recorded has only its finish step, and the timeline says how
  many of its counted tool calls are not listed (D307). While the run is Queued, Running or Waiting
  nothing is recorded yet, so the timeline follows the run's live event stream instead: the model's
  text as it arrives and each tool call as a step, Running until its result comes back, with a
  working indicator; the recorded timeline replaces it when the run ends (UC-52.1-04,
  `features/agents/components/live-run-steps.tsx`, the same stream a room reply reads).
- **Context composition:** tokens by context block, read from a Start step's composition; shown
  only when the run has one.
- **Delete run** removes a finished run with its steps, approvals and their decisions, questions,
  playground tests and the Inbox items they raised; a replay or a delegated run keeps existing and
  loses the link, and what the run produced (messages, artifacts, emails) stays. Who may is who may
  cancel it (D295). Refused for a run still going.
- **Open trace** links to the run's trace in Phoenix. It is shown only to people holding `logs:read`,
  and uses the browser-facing Phoenix address (`PHOENIX_PUBLIC_ORIGIN`).

Replay starts a new run of the same agent with the original goal, linked to the run it replays
(trigger `Replay`), and opens it; the original is left as it is. Replaying from a step requires a
reason, and the step and reason are recorded in the audit entry. Run statuses are Queued, Running,
Waiting, Blocked, Succeeded, Failed, Cancelled and BudgetExceeded (`RUN_STATUSES`). What each final
status means is decided by the platform, not by the model
([runtime spec §3](../agent-runtime-spec.md#3-outcomes), D102).

### The built-in Platform Assistant

The AI Assistant panel always runs the agent with code `pa`, which is marked `is_builtin`
(D65, D99). On this screen:

- **Delete** is refused by the server ("is the platform's built-in assistant and cannot be
  deleted"), not only hidden (`features/agents/lifecycle-service.ts`).
- **Configuration** stays editable. Saving any configuration of the built-in agent needs
  `agents:configure` in addition to `agents:write`, checked in the service (D117,
  `features/agents/version-service.ts`).
- **Its trust** is fixed and the Configuration dialog does not offer it.
- **Reset to defaults** asks for confirmation, then writes the configuration in
  `features/agents/builtin.ts` (`BUILTIN_DEFAULTS`) onto the draft: instructions, platform-tool
  grant, skills and budgets. It needs `agents:configure`. Runs, memory and audit entries are kept,
  and the draft is published like any other change. The production seed creates `pa` from the same
  defaults (D133). `agent.default_version` records which generation of the defaults the agent is
  on; version 4 carries the `guided-platform-creation` and `platform-operations` skills (D228).
- **Its default grant** is the default tool grant, plus the platform writes only the Assistant
  holds by default (deployments, storylines, rooms and schedules, D265) and the T2 agent tools
  `agent_create` … `agent_delete` (`BUILTIN_AGENT_TOOLS`, D254).

The rest of its behaviour is in [runtime spec §7](../agent-runtime-spec.md#7-the-built-in-platform-assistant).

## Business rules

| Rule | Source |
| --- | --- |
| A designer edits the instructions, tests them in the playground, and publishes v8 with release notes. New runs use v8; running runs keep their version. | SC-AGT-01, FR-056, `UC-51.3-02` |
| An eval drop after publishing leads the designer to roll back to v7. | SC-AGT-02, FR-057 |
| An administrator changes an agent's trust from Standard to Restricted. Its T1 tools stop running autonomously. | SC-AGT-03, FR-054. See the conflict below |
| No agent ever has the approve permission. | S-51, NFR-11, `UC-12.1-10` |
| A tool mode is never looser than the tool's tier: a T2 or T3 tool cannot be set to Auto. The service refuses a looser mode. | FR-055, `UC-51.2-04`, data model integrity rule 4 |
| Edits go to a draft revision; publishing makes the draft the active version. One active version per agent. | `UC-51.3-02`, data model integrity rule 6 |
| The New Agent modal never offers System trust; a system agent's trust cannot be changed. | `UC-50.2-04` |
| The built-in assistant cannot be deleted; editing or resetting it needs `agents:configure`. | D65, D99, D100, D117 |
| An agent is deleted only when nothing uses it. | FR-053 |
| Effective permission of a run is the user's permission AND the agent's grant. | D31, [runtime spec §6](../agent-runtime-spec.md#6-permissions-and-grants) |
| The requester, the room owner or an admin may terminate a mission; termination ends it CANCELLED, never done. `cancelRun` refuses anybody else: an admin is a holder of `system:operate`, who may pause every agent (`cancelScopeOf`, D295). The assistant panel's Stop (`stopOwnRun`) cancels only a run the person started. | D67, [runtime spec §4](../agent-runtime-spec.md#4-user-termination). See the conflict below |
| A finished run may be deleted, by whoever may cancel it, with its steps, approvals and their decisions, questions, playground tests and the Inbox items they raised. A run still Queued, Running or Waiting is refused. | D300, D295 |
| A run's live event stream is given to its requester, to someone holding `agents:read`, and, for a run in a room, to whoever may read that room. Anybody else gets 403; an id that names no run gets 404. | D124, D161 |
| An agent runs only on a chat route (Standard or Typesafe). | D337 |
| Publishing needs release notes and an evaluation score of at least 70 when the draft has one. | `UC-51.3-03`, `UC-51.3-04`, `features/agents/publish-service.ts` |

## Requirements and acceptance

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Agents — list, New Agent | FR-053 | [S-50](../Tahseel_AWP_Screens_Use_Cases.md#s-50-agents--list): `UC-50.1`, `UC-50.2` |
| Agent detail | FR-054 … FR-057 | [S-51](../Tahseel_AWP_Screens_Use_Cases.md#s-51-agent-detail): `UC-51.1` … `UC-51.4` |
| Run viewer | FR-058 | [S-52](../Tahseel_AWP_Screens_Use_Cases.md#s-52-run-viewer): `UC-52.1` |

The acceptance checks run against the cluster for the runtime decisions are recorded in
[reports/acceptance-2026-10-19.md](../reports/acceptance-2026-10-19.md).

## Implementation

| Concern | Where |
| --- | --- |
| Routes | `/agents` (list and detail, `?agent=<code>&tab=<tab>`), `/agents/runs` (run viewer, `?id=<run key>`) under `apps/web/src/app/(console)/` |
| Feature module | `apps/web/src/features/agents/`: `lifecycle-service.ts` (create, delete), `version-service.ts` (draft, tool modes, skills, knowledge, memory, grant), `publish-service.ts`, `builtin.ts` and `builtin-service.ts`, `platform-catalogue.ts` (the Platform connector's tools), `run-start-service.ts` and `run-payload.ts` (assembling a run), `grants.ts` (`grantedToolNames`, `childGrant`, `resumeGrant`), `default-tools.ts`, `tool-configuration-service.ts` (`loadToolConfiguration`, the Connector tools tab's read, D320), `run-service.ts` (the harness plumbing calls: start, ask, finish, refresh credentials), `delegation-service.ts`, `approval-service.ts`, `credentials-service.ts`, `test-run-service.ts` (playground and replay) |
| Server actions | `features/agents/actions.ts`: `createAgent`, `deleteAgent`, `saveDraft`, `setTrust`, `setRunBudget`, `setToolMode`, `revokeTool`, `grantConnector`, `changeToolGrant`, `changeSkills`, `setSkill`, `setKnowledgeAccess`, `setMemoryAccess`, `setPlatformTool`, `publishVersion`, `activateVersion`, `testAgent`, `cancelRun`, `deleteRun`, `stopOwnRun`, `replayRun`, `resetBuiltinToDefaults` |
| Permissions checked | `agents:read` for every read; `agents:write` for create and configuration (with `agents:configure` for the built-in Assistant); `agents:publish` for publish, roll back and delete; `agents:configure` for Reset to defaults; `agents:invoke` for playground, replay, cancel and delete run, the last two also bounded by `cancelScopeOf` (D295) |
| MCP tools | `agent_list`, `agent_get`, `run_list` (runs newest first, by agent code and status, 50 unless given and at most 200, as the run list shows them), `run_get` (one run as the run viewer shows it) (T0, default grant; `agents:read`); `agent_create`, `agent_edit`, `agent_tool_grant_edit`, `agent_skill_edit`, `agent_knowledge_access_edit`, `agent_memory_access_edit`, `agent_trust_edit`, `agent_run_budget_edit`, `agent_publish`, `agent_rollback` (makes an earlier version active, D293), `agent_delete` (T2; decided by somebody other than the requester, in a room too, D253; the built-in Assistant holds them by default, other agents when granted, D254); `agent_test_run_create`, `run_replay_create`, `run_cancellation_create` (T2, grantable, not default: each starts or stops a mission, so a person approves it, D294); `run_delete` (T2, D300) (`features/agents/tools.ts`) |
| API routes | `/api/copilotkit/[[...slug]]` and `/api/agui/[agentCode]` (one POST starts a run with the panel's conversation, at most its latest 100 turns, and streams its AG-UI events), `/api/sse/runs/[runId]` (a run's events from `Last-Event-ID` or `?after=`, for the requester, `agents:read` or, for a room run, the room's readers) — see [solution design](../03-architecture/solution-design.md) |
| Agent service | Runs start as `MissionWorkflow` on the `agent-runs` task queue through `POST /agui/runs`; cancel is `POST /agui/runs/{run_id}/cancel`, which signals the workflow; a run's events are `GET /agui/runs/{run_id}/stream` and `/events`, its status `GET /agui/runs/{run_id}`, and decisions and answers `POST …/approve` and `…/answer` (`services/agent/src/awp_agent/api/runs.py`) |
| Tables | `ai.agent`, `ai.agent_version`, `ai.agent_skill`, `ai.agent_tool_mode`, `ai.agent_platform_tool`, `ai.agent_memory_access`, `ai.agent_knowledge_access`, `ai.playground_test`, `ai.run`, `ai.run_step` — see the [data model](../04-data-model/overview.md) |
| Seeded agents | The production seed creates `pa` (built-in assistant, system) and `def` (Default Agent); it no longer creates `dir` (D371), and retiring `dir` on an existing installation needs a migration the owner approves. The browser-test fixture adds six demo agents (`apps/web/tests/fixtures/demo`) |
| Feature flags | `capture-full-traces-raw-events` (default off) lets AG-UI `RAW` events through the CopilotKit middleware (`apps/web/src/agents/runtime.ts`, `middleware.ts`). `allow-agents-to-assign-work-to-other-agents`, `verifier-step-on-every-t2-tool-call` and `mixture-of-agents-for-high-stakes-outputs` are seeded but read by no code in `apps/web/src` or `services/` |

## ⚠ Unresolved conflicts

These were found by reading the source; the first of them are logged in
[DOCS_REFACTOR_REPORT.md](../../DOCS_REFACTOR_REPORT.md). The code is described as it is; whether
the code or the requirement is wrong is the owner's decision.

| Topic | Requirement or decision says | Code does |
| --- | --- | --- |
| Run budget in money | The Configuration card shows a soft and hard run budget in AED; the screen hint reads "Soft warns, hard stops" (`configuration-modal.tsx`). D73 removed money ceilings: soft and hard are seeded at 0, meaning no limit. | The values are stored on `ai.agent_version` and sent in the run payload as `soft_cost_aed` and `hard_cost_aed` (`run-start-service.ts`), but the runtime's `RunBudget` has no such fields (`services/agent/src/awp_agent/harness/types.py`). A non-zero hard budget therefore stops nothing. |
| Effort limits and execution profile | Profiles set `max_steps` and `max_tool_calls` ([runtime spec §13](../agent-runtime-spec.md#13-limits), D73, D93). | The mission bounds every run with `UsageLimits` from `RunBudget` (D129), but the web app sends no `max_steps` or `max_tool_calls`, so every run gets the defaults, 60 and 300. The profile chosen here is stored and sent as `profile`; `services/agent/src/awp_agent/harness/profiles/*.yaml` are loaded by nothing on the mission path, so the profile has no effect on a run. |
| Trust at run time | SC-AGT-03: Restricted trust stops T1 tools running autonomously. | No code path reads trust when a run calls a tool. The mission runtime pauses tools whose tier is T2 (`APPROVAL_TIERS` in `mission/runtime.py`): the catalogue's T2 tools, and connector tools at Approval mode. Trust is stored, fixed for system agents and excluded from New Agent. |
| T3 tool mode | T3 is Forbidden: "Never runs" ([connectors](connectors.md#business-rules)). | `setToolMode` accepts Approval as the loosest mode for a T3 tool (`LOOSEST_MODE` in `features/agents/version-service.ts`), and the grant popup and Grant a whole connector grant a T3 tool at Approval (`grantTools`, D264); only the seed maps T3 to Denied (`apps/web/src/db/seed/agents.ts`). A T3 tool at Approval is offered to the run as T3 (`tierUnderMode`), which the runtime does not pause (it pauses T2 only) and the MCP server does not hold for an approval (`callConnectorOperation` requires one for T2 only, `apps/web/src/mcp/server.ts`), so it runs without a person. |
| Run termination | D67: termination voids pending approvals and questions and cancels child missions. | `cancelRun` marks the run Cancelled and signals the workflow, which cancels the in-flight model or tool call and ends waiting approval and question steps (`mission/runtime.py`). The approval and question rows and their Inbox items are not changed by the cancel (`repository.cancelRun`). Whether a child mission is cancelled is **Unverified**. |
| Run viewer figures | The run viewer shows waiting time, cache hit %, the run's trace (Open trace, for holders of `logs:read`) and its context composition (`UC-52.1`). | They read `ai.run.waiting_seconds`, `cache_hit_pct`, `trace_id` and a Start step's composition, which no code writes; only the browser-test fixture sets them (`apps/web/tests/fixtures/demo/runs.ts`). For a real run the waiting note, the cache hit note, Open trace and Context composition do not appear ([runtime spec conflict 11](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code)). |
| Replay from a step | `UC-52.1-06`: replay a run from one of its steps. | The step is stored on the new run (`replay_from_step`) and sent to the agent service, which does not read it; the new run starts the mission again from the original goal (`services/agent/src/awp_agent/mission/runtime.py`). |

## Known gaps

| Gap | Evidence |
| --- | --- |
| The handoff's reason field on Cancel run, tokens per step in the timeline, and an inline trust select on the Overview are not built; trust is edited in the Configuration modal. | `features/agents/components/agent-runs.tsx`, `run-viewer.tsx`, `configuration-modal.tsx` |
| The playground starts a real run on the generic runtime (surface `Playground`) and polls for its answer; it is not a separate sandbox. | `features/agents/test-run-service.ts` |
