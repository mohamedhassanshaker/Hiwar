# Governance: audit, logs, settings, system, documentation and user guide

| Item | Value |
| --- | --- |
| Purpose | The Govern screens that are not budgets or integrations: Audit, Logs, Settings (general, branding, email), System, Documentation, and the in-product user guide; the platform's mail service |
| Audience | Developers, business analysts, testers, administrators, auditors |
| Related | [Business rules](../01-business/business-rules.md) · [Security](../03-architecture/security.md) · [Observability in the AI platform](../03-architecture/ai-platform.md) · [Shell and account](shell-and-account.md) · [Data dictionary: governance](../04-data-model/data-dictionary/governance.md) · [Glossary](../glossary.md) |
| Last verified against code | 2026-10-29 |

## Purpose

These screens let administrators and auditors see what happened, configure the organisation's
identity and optional behaviour, watch the health of the platform's services, and stop agent
activity during an incident. The Documentation screen and the user guide explain the rules the
product enforces where people meet them.

## Screens

### Audit (S-73)

"Append-only record of configuration, permissions, approvals, publishes, secret access, exports and
logins."

- Filters: actor (All actors; People, which is every actor that is not an agent; Agents), period
  (Any time, last 24 hours, 7, 30 or 90 days) and action, a text matched literally against the
  start of the action code (`settings:` finds every settings change), applied on Enter or when the
  field is left. The filters live in the URL and are applied in the query on the server. With no
  match the table says so and offers Clear.
- Columns: time, actor, action, object, an Allowed / Denied outcome, and detail, newest first.
  Examples: "Reveal denied (never returned)",
  "T2 tool erp/purchase_order.submit".
- An entry's object links to the screen that holds its type (people, org units, agents, settings,
  System, projects, work items, requests, schedules, artifacts, files, the
  Inbox, budgets); a type with no screen is named without a link (`UC-73.1-06`).
- Paged on the server, 50 entries a page, with `?page=` in the address and the total count; a
  changed filter returns to the first page (D230, `lib/paging.ts`).
- Action: Export, a CSV (`audit-<period>.csv`) of the entries under the screen's filter, which is
  itself audited.

An audit entry names its actor as one of `Person`, `Agent`, `Client`, `ExternalContact` or `System`
(`AUDIT_ACTOR_TYPES` in `db/schema/enums.ts`). An agent's or integration client's tool call writes
the service's own entry for the acting person plus a second entry, `mcp:<tool>`, naming the agent
or client as caller with the person in `onBehalfOf`; a refused call is written as `Denied`
(`mcp/server.ts`).

### Logs (S-74)

Application and run logs across services, read from `gov.log_entry`: time, level, service, run and
message, newest first. Filters: level (All levels, Error, Warn, Info, Debug), a service dropdown
built from the services present in the log, and a run field matched exactly against a line's
correlation id. Filters live in the URL and are applied in the query. A run id in a line filters
the log to that run's lines (`UC-74.1-03`); with no match the table offers Clear. Paged on the
server like Audit, 50 lines a page with `?page=` and the total count (D230). Every message is
masked on the way out (`loadLogs` in `features/governance/service.ts`, `lib/log-masking.ts`).

A failed knowledge ingestion writes one Error line per failure, with the collection's id as the
run, so the Knowledge screen's failure can be followed here (`features/knowledge/repository.ts`).

### Settings (S-75)

"Validated against schema. Every change is kept in history." Four tabs: General, Branding, Feature
flags (with the number of flags) and Email. Save changes writes the General tab, the brand colour
when it changed, and each flag whose switch moved; it is disabled while the brand colour fails the
contrast check. Logos, the favicon and the Email tab save from their own controls. Each save of
general settings, the brand colour or the mail server writes a new settings version; the header
shows the current version.

**General.**

- Organisation name in English and Arabic (required, up to 200 characters).
- Time zone, checked against the server's own IANA time-zone database, and languages (`en`, `ar`,
  at least one, typed comma-separated).
- Working calendar (e.g. Mon–Fri 07:30–15:30) and holidays (e.g. UAE public holidays 2026), shown by
  name. A save keeps the stored calendars; one that no longer exists is refused ("That calendar no
  longer exists."). The audit entry (`settings:write`, object `general`) names each field that
  moved with its old and new value.

**Branding.**

- Logos for the light and dark themes (upload; SVG or PNG, at least 240×80), each with its own
  upload, checks and preview. The sidebar, the sign-in and signed-out pages and the Settings
  preview draw the uploaded logo for the theme, the other theme's when only one is uploaded, and
  the Juman mark when none is (`components/shared/brand-logo.tsx`, D232). "Use the default"
  removes an uploaded logo or favicon (`removeBrandingAsset`, `settings:write`, audited as
  `settings:branding`). The card counts the stored branding assets.
- Favicon (64×64 PNG), applied to every browser tab including the sign-in screen and the public
  widget (`faviconUrl` in `app/layout.tsx`).
- **Application colours:**
  - primary brand colour with a colour picker, a hex field and five preset swatches;
  - a live preview of a primary button, a secondary button and a progress bar;
  - the colour applies to buttons, links, active navigation and the embedded widget;
  - saving a logo, a favicon or the colour re-renders the whole layout, so the shell shows it at
    once (D232);
  - "Contrast is checked against WCAG 2.2 AA before saving." The live result shows the ratio
    against white and, when the colour fails, suggests an accessible shade with "Use the
    suggestion". A saved colour is audited as `settings:write` (`branding.brandColour`).

**Email (D240).** The platform's mail server and its system notifications, saved with their own
Save as a settings version (`saveMailSettings`, `settings:write`, audited without the secret):

- on or off, host, port, security (STARTTLS, TLS, or none for a local sink), username, password
  (write-only: encrypted under `APP_KEK`, never shown; left blank it is kept, and "Remove the
  stored password" removes it), from address and from name. A server that is on needs a host and
  a from address; the save is refused otherwise;
- a table of the platform's emails (D247): Request created, Request updated, Request finished,
  Work item finished and User invitation, each with who receives it, its subject and whether it is
  on. Edit opens a popup with an on switch, the English and Arabic subjects, and the English and
  Arabic bodies in a rich text editor (bold, italic, underline, a heading, lists, links, and chips
  that insert the template's placeholders). Saved one template at a time (`saveMailTemplate`,
  `settings:write`). The body is HTML, sanitised when saved and again when sent (`lib/mail-html.ts`:
  paragraphs, emphasis, lists, headings, quotes, code, rules and http, https or mailto links only);
  a value filled into it is escaped, and every email carries a plain-text copy of it. A body saved
  as plain text before is read as paragraphs. An email goes in the recipient's language. The
  placeholders each template offers: Request created `key`, `title`, `step`, `at`, `link`; Request
  updated those and `outcome`, `summary`; Request finished and Work item finished `key`, `title`,
  `outcome`, `summary`, `completedAt`, `link`; User invitation `name`, `inviter`, `role`,
  `organisation`, `link`, `expiresAt`. An unknown placeholder is left empty;
- Notices beyond the five templates: an Inbox item is also emailed as an `Alert` (D394, see Home → Inbox), with
  no template of its own and listed under Recent emails with kind `Alert`;
- A "Configuration saved" mark on the Mail server card while a host and a from address are stored, and
  Test saved settings, which connects to the stored server and signs in, sending nothing, and says
  "Connected to host:port" or why it could not (`testSavedMailSettings`, `settings:write`; off while no host
  is stored). It tests what is stored, not what is typed;
- Send test email to one address, recorded as a `Test` row with Sent or Failed and the server's
  reason, and the latest 50 emails of every kind (notifications, invitations, tests and agent
  emails) with when, kind, recipient, outcome, status (Queued, Sending, Sent, Failed, Skipped) and
  why (`features/governance/notification-service.ts`).

When a request reaches Completed, Rejected, Closed or Cancelled, or a top-level work item reaches
Done or Cancelled, the people it is for are emailed by the platform itself, with no agent involved:
a request's requester; a work item's creator, person assignee and person reviewer; never the
person who finished it themselves. A request's requester is also emailed a receipt when it is
created, and an update when it moves to another step or is returned by somebody else (D247). A
template switched off writes no row at all. A person who is not active, has no email address or turned the
email off in Profile → Notifications, or a platform whose mail server is off, gets a Skipped row
with the reason. A row's key is the kind, the item, the event and the person, so a retried
transaction writes nothing twice (`db/queries/mail.ts`). Sending is asynchronous: each web process
starts a consumer (`startMailConsumer`, from `instrumentation.ts`) that reads the Valkey stream
`awp:mail`, and a sweep every minute sends the rows that are due, including a row left Sending for
over 10 minutes; without Valkey the sweep alone sends. A send is tried again after a transient
failure (a connection error or a 4xx reply; 1, 5, 15 minutes; 4 tries in all), and never changes
the finished item. A mail server outside the cluster needs an egress rule for its host and port:
SMTP does not go through the HTTP egress proxy (`lib/mailer.ts`).

Inviting a person queues the User invitation email with the invitation (D248). It carries the
accept link `/invite/<token>`, and the stored token is cleared once the email is sent. With the
mail server off or the invitation template off, the row is Skipped with the reason and the person
inviting is told no email was sent.

An agent's email (D242) is the T2 tool `email_create` (`features/governance/tools.ts`), off unless
an agent is granted it. Each send waits for a person to approve the exact message (D49), goes only
to active people of the platform by their e-mail address, is signed with the agent and the person
it acts for, and is queued, sent and retried like a notification, kind `AgentEmail`, one row per
recipient keyed by the run, the message and the recipient. A person's preferences do not apply to it.
It is refused outside an agent run, when the mail server is not configured, and for any address
that is not an active person, naming the address (`sendAgentEmail` in `notification-service.ts`).

#### Feature flags

The Settings screen has no Feature flags tab (owner request, 2026-11-15). A flag is changed through
the `feature_flag` agent tool (`settings:write`), which audits each write as `settings:feature_flag`.
The screens that obey a flag are unchanged.

The 16 seeded flags and their seeded defaults (`FLAGS` in `apps/web/src/db/seed/data/platform.ts`;
key = English name lower-cased, non-alphanumerics replaced by `-`):

| Group | Flag (key) | Seeded | Read by |
| --- | --- | --- | --- |
| Agents & runs | `allow-agents-to-assign-work-to-other-agents` | on | not read |
| Agents & runs | `mixture-of-agents-for-high-stakes-outputs` | off | not read |
| Agents & runs | `verifier-step-on-every-t2-tool-call` | on | not read |
| Agents & runs | `capture-full-traces-raw-events` | off | `agents/runtime.ts` (keeps AG-UI `RAW` events in the CopilotKit stream when on) |
| Memory & knowledge | `memory-writes-require-review-for-org-scope` | on | not read |
| Memory & knowledge | `graph-retrieval-graphiti` | on | `features/knowledge/service.ts` |
| Memory & knowledge | `pii-filter-on-memory-writes` | on | `features/memory/service.ts`, `run-memory-service.ts` (masks a memory write when on) |
| Collaboration | `mirror-rooms-to-microsoft-teams` | on | `features/engage/service.ts` |
| Collaboration | `agentic-interactive-request-entry` | off | `features/requests/classification.ts` (offers agentic request entry when on, D310) |
| Engage | `embedded-deployments` | on | `features/engage/deployment-service.ts`, `service.ts`, `widget-session.ts` |
| Engage | `voice-ivr-channel` | off | not read |
| Engage | `visitor-ratings-in-widget` | on | not read |
| Platform | `plugins` | on | not read |
| Platform | `page-assistant` | on | not read (constant only) |

The `setup-director` and `setup-director-can-propose-new-agents` flags are removed with the Setup
Director (D371); no code reads them, so a row an installation seeded earlier still holds changes
nothing. An unknown key reads as off (`isFeatureEnabled` in `features/governance/repository.ts`), and a
flag is read from its row on each request. "Not read" means no code in `apps/web/src` or
`services/` looks the key up; toggling it changes nothing but the row.

### System (S-78)

"Versions and health of every platform service."

- **KPIs:** active runs (Running or Waiting), queue depth (Queued runs), active rooms, and
  "Dependencies healthy x / y".
- **Last checked** time of the probes, then a card per service with its version and health
  (Healthy, Error, Disabled); a failing service shows the probe's reason, or "Did not answer."
  (`UC-78.1-04`). The services are the probes of `health` in `lib/health.ts`: `web`,
  `agent-service`, `temporal`, `agentgateway`, `phoenix`, `postgres`, `neo4j`, `valkey`,
  `object-storage`, each bounded at 2 seconds, then one line per Temporal task queue
  (`agent-runs worker`, `ingestion worker`, `maintenance worker`): Healthy while a worker polls the
  queue, Error with "No worker is polling this queue, so its work never starts." when none does,
  because Temporal can answer while no run can execute (2026-10-31). The agent service reads the
  pollers from Temporal (`GET /healthz/workers`). A probe whose service is not configured shows as
  Disabled. The same list is `GET /api/health`, always 200 and never cached, with an overall
  `ok` or `degraded`.
- **Pause all agents**, after a confirmation ("Running workflows are drained; new runs are queued.
  Every agent reads Paused until you resume."), and **Resume all agents**, without one. While
  paused the page says: "All agents are paused. No new run starts. Runs already going are draining:
  they finish, and read Running until they do." (D182). Each is audited as `system:pause_agents` or
  `system:resume_agents`.

### Documentation (S-79)

In-product guides: the pages of `gov.doc_page` listed in their order on the left, the chosen page's
title and body on the right, and "No documentation yet." when there are none. The test fixture's
pages are Getting started, Discussion rooms, Requests, Approvals ("Agents never approve their own
work. A T2 tool call pauses the run…"), Storylines, Connectors & tiers, Agents and Estimated costs.
Any signed-in person reads them.

A page body is one paragraph in which `[label](/path)` becomes a link when the target is a path on
the console (a single leading `/`); any other target is shown as the text it is, and the screen
linked to applies its own permission (`UC-79.1-03`,
`features/governance/components/guide-body.tsx`).

### User guide (`/guide`)

A screen beyond the handoff: 12 task scenarios grouped by six roles (Everyone, Requester, Doer,
Approver, Designer, Administrator), with search and an empty state. Each scenario has
prerequisites, numbered steps with screenshots, "Open this screen", the expected result and
troubleshooting. The content is `apps/web/src/components/guide/scenarios.ts`; the pictures are
checked in under `apps/web/public/guide/<lang>/` (the capture script was removed on 2026-10-31, so a changed screen's picture is replaced by hand), and the guide tests in `tests/e2e/` fetch each one. It needs only a
session. It has no navigation entry and is reached by its address; Documentation is the same (D226).

## Business rules

| Rule | Source |
| --- | --- |
| The audit log is append-only: nobody can edit or delete an entry. The `audit` schema has insert and select grants only, a guard trigger rejects UPDATE, DELETE and TRUNCATE, and entries sit in monthly partitions. | Spec §9; `UC-73.1-05`; `infra/postgres/04-audit-guard.sql`, `03-partitions.sql` |
| All configuration changes, permission changes, approvals, publishes, secret reveal attempts, exports and logins are written to the audit log. | Spec §9; `COM-18`; NFR-14 |
| A denied action is shown with the Denied outcome. | `UC-73.1-04` |
| An export needs `exports:create` and `audit:read`, and leaves its own audit entry (`exports:create`) with the filter and the row count, never the rows. | `UC-73.1-03`; `exportAudit` in `features/governance/service.ts` |
| A log line containing PII or a secret is shown masked. | `UC-74.1-05`; NFR-16 |
| General settings are validated, and each save is a new settings version. Calendars affect SLAs and schedules. | `UC-75.1-01` |
| A logo (PNG or SVG) below 240×80 or a favicon that is not a 64×64 PNG is refused with the required size, measured from the image bytes; an SVG logo has no pixel size and is not size-checked. | `UC-75.2-02`; `assertBrandingAsset` in `lib/branding.ts` |
| A brand colour that fails the WCAG 2.2 AA contrast check against white cannot be saved; the check runs in the service, not only on the screen. | `UC-75.2-04`; NFR-18; `saveBrandColour` in `settings-service.ts` |
| The mail password is encrypted under `APP_KEK`, never returned to a screen or to `settings_get`, and audited only as `passwordChanged`; an email body is sanitised when saved and when sent. | D240, D247; `settings-service.ts`, `lib/mail-html.ts` |
| Turning off "Graph retrieval (Graphiti)" makes retrieval vector-only and disables the Graph and Hybrid modes. | `UC-75.3-03` |
| Pausing all agents makes every agent read as Paused, and a paused agent cannot start a run. A run already going drains under its own status: pausing and resuming write nothing onto runs, so a run that was Queued before the pause is still Queued after the resume. | `UC-78.1-02`, `-03`, D182; `readRunnableAgent` in `features/agents/repository.ts`, `run-start-service.ts`, `setAgentsPaused` in `features/governance/repository.ts` |
| Settings, Logs and System are hidden from people without their read privilege; System actions need `system:operate`. | `UC-74.1-04`, `UC-75.4-01`, `UC-78.1-05`; `COM-07` |

## Requirements and acceptance

| Requirement | Screen | Scenarios |
| --- | --- | --- |
| [FR-082](../specs/requirements.md#govern) audit log | [S-73](../Tahseel_AWP_Screens_Use_Cases.md#s-73-audit) | `UC-73.1-01` … `-06` |
| [FR-083](../specs/requirements.md#govern) logs | [S-74](../Tahseel_AWP_Screens_Use_Cases.md#s-74-logs) | `UC-74.1-01` … `-05` |
| [FR-084](../specs/requirements.md#govern) settings, branding, feature flags | [S-75](../Tahseel_AWP_Screens_Use_Cases.md#s-75-settings) | `UC-75.1-01`, `UC-75.2-01` … `-04`, `UC-75.3-01` … `-03`, `UC-75.4-01` |
| [FR-091](../specs/requirements.md#govern) system health, pause and resume agents | [S-78](../Tahseel_AWP_Screens_Use_Cases.md#s-78-system) | `UC-78.1-01` … `-05` |
| [FR-092](../specs/requirements.md#govern) in-product documentation | [S-79](../Tahseel_AWP_Screens_Use_Cases.md#s-79-documentation) | `UC-79.1-01` … `-03` |

## Implementation

| Part | Where |
| --- | --- |
| Pages | `/audit`, `/logs`, `/settings`, `/system`, `/documentation`, `/guide` under `app/(console)/` |
| Feature folder | `apps/web/src/features/governance/` — `service.ts` (audit, logs, system, docs, pause), `settings-service.ts` (general, branding, flags, mail server and templates), `notification-service.ts` (sending, the consumer and sweep, the agent's email, test send, recent emails), `schema.ts`, `tools.ts`, `repository.ts` |
| Mail | `lib/mailer.ts` (`sendMail`, nodemailer, one SMTP transport per send), `lib/mail-html.ts` (sanitising, filling, plain-text copy), `db/queries/mail.ts` (the mail settings and the queueing of notices in the finishing transaction) |
| Components | `features/governance/components/govern.tsx` (Audit, Logs), `settings.tsx`, `branding-upload.tsx`, `mail-settings.tsx`, `system-page.tsx`, `docs.tsx`, `guide-body.tsx`; `components/guide/`; `components/shared/brand-logo.tsx`; `components/ui/rich-text.tsx` (the template editor) |
| Server actions | `features/governance/actions.ts`: `setAgentsPaused`, `saveMailSettings`, `saveMailTemplate`, `saveBrandColour`, `saveBrandingAsset`, `removeBrandingAsset`, `setFeatureFlag`, `saveGeneralSettings`, `flagConsequences`, `exportAudit`, `sendTestEmail`, `loadRecentNotifications` |
| API routes | `GET /api/health` (`app/api/health/route.ts`) |
| Platform MCP tools | `settings_get` (T0, default grant; the mail password is never in it); `email_create` (T2, `organisation:read`, grantable, not default, D242); `general_settings_edit`, `feature_flag_edit`, `brand_colour_edit`, `mail_server_edit` (every field but the password, which only a person sets, D277), `mail_template_edit`, `test_email_create`, `agent_pause_edit` (`system:operate`) (T2, grantable, not default, D294) (`features/governance/tools.ts`) |
| Tables | `audit.audit_entry`; `gov.settings_version` (general settings, branding colour, mail server and templates), `gov.branding_asset`, `gov.feature_flag`, `gov.system_state`, `gov.doc_page`, `gov.log_entry`, `gov.mail_notification`; `core.notification_preference` — [data dictionary: governance](../04-data-model/data-dictionary/governance.md) |
| Privileges | `audit:read`, `logs:read`, `settings:read` (also the recent emails), `settings:write` (also the mail server, templates and test send), `system:read`, `system:operate`, `exports:create`; Documentation and the user guide need only a session |

## Known gaps

| Gap | Evidence |
| --- | --- |
| **The Logs screen shows almost nothing in production.** `gov.log_entry` is written only by failed knowledge ingestions (`features/knowledge/repository.ts`) and by the test fixture `apps/web/tests/fixtures/demo/governance.ts`. Services log JSON to stdout (see [observability](../03-architecture/ai-platform.md)), which the screen does not read. The stack specification's design was a query against the cluster log store. | `listLogs` in `features/governance/repository.ts`; no other writer of `logEntry` |
| **Documentation pages are not seeded.** `gov.doc_page` is filled only by the test fixture, so a fresh install shows the empty state. | `DOC_PAGES` in `apps/web/tests/fixtures/demo/governance.ts`; no `docPage` insert in `db/seed` |
| Time zone, working calendar and holidays are plain text inputs. The calendar inputs are not bound to the saved value and the save sends the stored calendars, so the calendar cannot be changed from this screen. | `features/governance/components/settings.tsx` |
| The audit Export carries at most the newest 200 entries matching the filter, while the screen pages through every match: the screen sends no limit and the repository's default is 200 (up to 5000 when one is given). | `exportAudit` in `features/governance/actions.ts`, `listAudit` in `features/governance/repository.ts` |
| No "Uptime (30d)" KPI on System. | `features/governance/components/system-page.tsx`; handoff v2 §10 |
| Nine of the 16 seeded flags are read by no code (table above). | `apps/web/src/lib/feature-flags.ts`; grep of `apps/web/src` and `services/` |
