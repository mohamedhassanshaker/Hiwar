# Knowledge

| Item | Value |
| --- | --- |
| Purpose | The Knowledge screens: collections, their document sources and configuration, and the retrieval test |
| Audience | Developers, business analysts, administrators |
| Related | [Glossary](../glossary.md) · [AI platform: knowledge stores and ingestion](../03-architecture/ai-platform.md#knowledge-pgvector-and-graphiti) · [Agents and runs](agents-and-runs.md) · [Models and routes](models-and-routes.md) · [Use cases S-56 … S-58](../Tahseel_AWP_Screens_Use_Cases.md#s-56-knowledge--collections) |
| Last verified against code | 2026-10-29 |

## Purpose

"Collections ingested into vector and graph stores for cited retrieval." A collection is a set of
document sources that the platform parses, chunks and indexes so that agents with access to it can
retrieve cited passages and graph facts. This page covers the screens; how ingestion and the
pgvector and Graphiti stores work is in [AI platform](../03-architecture/ai-platform.md).

## Screens

### Knowledge — collections (S-56)

- KPIs: collections, documents, chunks (in thousands), entities.
- Columns: collection (with its project and visibility beneath), index type, chunking (technique ·
  size/overlap), embedding route, documents and status (Ready, Error, or "Ingesting 62%").
- Row actions: Test retrieval and Configure.
- Header actions: **Test knowledge retrieval** and **New collection**.
- **New collection modal:** name, project, index type (Hybrid, Vector, Graph), chunking technique,
  embedding route (the routes whose kind is Embedding), visibility, and the collection ID
  (suggested from the name: lowercase letters, digits and hyphens). **Create and configure**
  creates the collection with the name in both languages, then saves its configuration: chunks of
  800 tokens with 80 overlap, every pre-processing option on, top-k 8, minimum score 0.35,
  re-ranker on, sync Manual, a 1024 MB ceiling, and the first chat route (Standard or Typesafe) as
  the entity-extraction route (D257). A refusal, such as a taken ID, stays in the modal.

Collection statuses are Ready, Ingesting and Error. Visibility is chosen from the data
classification levels (Public, Internal, Confidential, Restricted; default Internal), not the
handoff's Project / Organisation / Public.

### Knowledge — collection page (S-57)

Opened by `?open=<collection id>`. Header: the collection's id and store (pgvector, Neo4j, or
both), its status, and the actions Test retrieval, Save changes and **Delete collection**. Delete
first names how many sources and documents go and that agents granted the collection lose access.
KPIs: documents, chunks, entities, last sync. Two tabs.

**Tab 1 — Details: document sources.**
- The collection opened (`?open=`) has its sources read one page (50) at a time, newest first,
  with a search by name on the server (`?q=`, `?page=`); no other collection's sources are read
  (D349).
- Columns: source, type (Upload, URL crawl or MCP resource), document count, status (Indexed,
  Indexing, Error, with the reason beside an Error) and updated.
- Actions: Add source and Re-index all on the card; Re-index and Remove on each source.
- **Add source modal:**
  - Upload: a name (the first file's name unless one is typed) and one or more PDF, DOCX, XLSX,
    HTML, MD or plain-text files.
  - URL crawl: start URL (http or https).
  - MCP resource: resource path.
  - Then **Add and index**.

**Tab 2 — Configuration**, as built (`features/knowledge/components/collection-detail.tsx`):

| Group | Settings |
| --- | --- |
| Index | Index type (Vector, Graph, Hybrid), visibility, maximum collection size (MB, with the current size beside it) |
| Chunking | Technique (Fixed, Recursive, Semantic, SentenceWindow, TableAware), chunk size (tokens), overlap (tokens), pre-processing: OCR for scanned PDFs, Arabic normalisation, strip headers/footers, PII masking. With OCR off the screen notes that a scanned PDF is indexed with no text |
| Models | Embedding route ("Changing the embedding route re-indexes the whole collection"), entity-extraction route for the graph, re-ranker on or off |
| Retrieval & sync | top-k, minimum score, sync schedule (Manual, Daily, Weekly) |

Verified in `features/knowledge/`:

- Ingestion progress is polled every 4 seconds while a collection ingests and shown as
  "Ingesting 40% · indexing"; when the run reports `done` or `idle`, its totals and failures are
  recorded (`recordIngestionOutcome`), the collection leaves Ingesting, and the screen says how
  many documents were indexed or the first failure. A failed ingestion shows a banner with each
  reason, Re-index, and a link to the run's log for holders of `logs:read`. Each source shows its
  own error reason.
- Upload takes several files at once and shows the server's refusal reason. A file type the parser
  cannot read, a start URL that is not http or https, and a collection at its size ceiling are
  refused with the reason. Uploaded files are stored in the `raw-docs` bucket with their SHA-256.
- Add source, Re-index, Re-index all and a save that re-indexes say whether the ingestion run
  started; one that did not start is reported as a refusal with its reason (`UC-56.2-04`). A source
  whose indexing did not start is set to Error with the reason, and the collection is set to Error
  when the ingestion service refused the run or did not answer.
- Removing a source and deleting a collection both ask first.
- Saving a change to the embedding route re-indexes the collection automatically. The overlap must be
  smaller than the chunk size. The embedding route lists the routes whose kind is Embedding, and
  the entity-extraction route those whose kind is Standard or Typesafe, from Models & routes; a
  route that does not embed is refused as an embedding route (D257).
- A save is refused when somebody saved the collection since it was read (the row version).
- A route whose model is changed in Models & routes re-indexes nothing: the collection indexes and
  searches the new model's dimension, and its passages from the earlier model are skipped until
  Re-index all replaces them (D256).
- Without `knowledge:write` the page is read-only.

### Test knowledge retrieval (S-58)

Opens from the page header (all collections), a collection row, or the collection page.
- Inputs: a query box, a Vector / Graph / Hybrid switch, and the collection (or All collections).
  The form starts from the last stored test. The result limit is the collection's top-k, or 8 for
  All collections.
- Results:
  - passages with their source reference and score, marked re-ranked when the collection's
    re-ranker is on;
  - graph facts as (subject) —[predicate]→ (object);
  - retrieval time (e.g. "Retrieved in 182 ms").

The test runs a real retrieval through the agent service and shows no-result, failure and re-ranked
states, and stores the result as the last test (`ai.retrieval_test`). All collections means every
collection in a project the person may read for `knowledge:read`, and collections with no project;
a collection outside them is refused. Each collection is queried with its own embedding route. When
one collection fails and another answers, the answers are shown. Graph and Hybrid are disabled when
the `graph-retrieval-graphiti` flag is off in Settings.

## Business rules

| Rule | Source |
| --- | --- |
| An administrator creates an "HR policies" collection, uploads PDFs with Arabic normalisation and OCR on, and watches ingestion progress. | SC-KN-01, FR-067, FR-068 |
| An administrator tests a query in Hybrid mode and sees cited passages and graph facts. | SC-KN-02, FR-070 |
| An administrator changes the embedding route, is warned about a full re-index, confirms, and the collection re-indexes. | SC-KN-03, FR-069 |
| An agent retrieves only from the collections its configuration grants. `knowledge_search` reads the collections the run's agent version is granted on its Knowledge tab that the person behind the run may read; in a room it is not bounded by the room's read floor. | [F-07](../specs/flows.md#f-07-knowledge-collection) step 5, FR-055, `UC-58.1-05`, D151, D291 |
| A collection ID is suggested from the name and unique. | FR-067, `UC-56.2-02`, `COM-13` |
| Removing a source removes its content from every store: its passages from `awp_kb` and its graph episodes, with the facts and entities only they asserted, before its rows go; deleting a collection drops its passages, indexes and graph group. Both are refused while the collection is being indexed. If the index cannot be cleared, nothing is removed and the refusal says why. | FR-068, D258 |
| Deleting a collection takes its sources, documents, ingestion history, retrieval tests and agents' access to it. | `collection-service.ts` |
| One ingestion run per collection: a second start while one runs joins it. Each document is parsed, indexed and, unless the index type is Vector, graph-extracted; each stage is retried up to 3 times, and a document that still fails is listed with its reason while the run goes on. | `IngestionWorkflow` in `services/agent/src/awp_agent/ingestion/workflow.py` |
| Graph extraction runs on the collection's entity-extraction route, saves each chunk's episode under its chunk id, heartbeats after each chunk, and resumes after the last chunk done on a retry, within 6 hours per document. | D259, D260, D276 |
| A collection's vector index is per embedding dimension, and a search reads only rows of its query's dimension. | D256 |
| Retrieval tests return in under 500 ms at p95. | NFR-03 |
| Ingestion normalises Arabic text and can OCR scanned PDFs. | NFR-22 |
| On a collection, `visibility`, `preprocessing` and `embeddingRoute` are sensitive fields: an agent changing them needs a bound approval. | `features/knowledge/privileges.ts`, D57, D58 |

## Requirements and acceptance

End-to-end journey: [F-07 Knowledge collection](../specs/flows.md#f-07-knowledge-collection).

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Knowledge — collections, New collection | FR-067 | [S-56](../Tahseel_AWP_Screens_Use_Cases.md#s-56-knowledge--collections): `UC-56.1`, `UC-56.2` |
| Knowledge — collection page | FR-068, FR-069 | [S-57](../Tahseel_AWP_Screens_Use_Cases.md#s-57-knowledge--collection-page): `UC-57.1`, `UC-57.2` |
| Test knowledge retrieval | FR-070 | [S-58](../Tahseel_AWP_Screens_Use_Cases.md#s-58-test-knowledge-retrieval-popup): `UC-58.1` |

## Implementation

| Concern | Where |
| --- | --- |
| Route | `/knowledge` under `apps/web/src/app/(console)/`; `?open=`, `?q=` and `?page=` select a collection and its page of sources |
| Feature module | `apps/web/src/features/knowledge/` (`collection-service.ts`, `source-service.ts`, `ingestion-service.ts`, `ingestion-poll.ts`, `retrieval-service.ts`, `repository.ts`, `privileges.ts`, `tools.ts`) |
| Server actions | `features/knowledge/actions.ts`: `createCollection`, `loadCollection`, `collectionCounts`, `saveCollectionConfig`, `deleteCollection`, `addSource`, `removeSource`, `reindex`, `reindexCollection`, `ingestionProgress`, `recordIngestionOutcome`, `testRetrieval`, `routeAliases` |
| Permissions checked | `knowledge:read` for reads, progress and retrieval tests; `knowledge:write` for every change, including recording an ingestion's outcome |
| Agent service | The web app starts ingestion with `POST /ingestion/runs` (one workflow per collection, `ingest-<collection id>`), reads progress from `GET /ingestion/runs/{collection_id}` (a workflow query; `idle` when none runs) and the finished run's totals and failures from `GET /ingestion/runs/{collection_id}/result`. `POST /ingestion/collections/{id}/removals` and `DELETE /ingestion/collections/{id}` clear the index and answer 409 while the collection is being indexed (D258). `IngestionWorkflow` runs on the `ingestion` task queue. Retrieval is `POST /knowledge/retrieve`, 503 when the embedding route cannot be reached (`services/agent/src/awp_agent/api/`). All need `AGENT_SERVICE_URL` |
| Feature flag | `graph-retrieval-graphiti` (default on), read by `features/knowledge/service.ts` |
| MCP tools | `knowledge_search` (T0: retrieval over the collections the run's agent is granted and the person may read, D151), `knowledge_collection_list` (T0; with a `collectionId`, one page of its sources: `q`, `limit` up to 200, default 50, `offset`), `knowledge_collection_get` (T0); `knowledge_collection_create`, `knowledge_collection_edit` (escalated to an approval when an agent names a sensitive field), `knowledge_source_create`, `knowledge_source_reindex_create`, `knowledge_collection_reindex_create` (T1, D293); `knowledge_collection_delete` and `knowledge_source_delete` (T2, grantable, not default) |
| Tables | `ai.knowledge_collection`, `ai.knowledge_source`, `ai.knowledge_document`, `ai.ingestion_job`, `ai.retrieval_test`, `ai.agent_knowledge_access`; passages live in the separate `awp_kb` database — see the [data model](../04-data-model/overview.md) |
| Object storage | Uploaded raw documents go to the `raw-docs` bucket (`features/knowledge/source-service.ts`). An upload source takes its files as `data:` URLs or as `heldFiles`, a file or artifact the platform holds named by id and copied server-side, refused unless the person may read it (`readHeld`, D266) |
| Parsing | The agent image installs the `parsers` extra (docling, Presidio, Tesseract) in every stage (`services/agent/Dockerfile`) |
| Seed | The production seed creates one collection, `default-kb` "Default knowledge base" |

## ⚠ Unresolved conflicts

| Topic | Screen or decision says | Code does |
| --- | --- | --- |
| Chunking | The collection's chunk size and technique are what ingestion uses. | The web app sends `chunking: {technique, size, overlap}`; the agent service's `ChunkingConfig` reads `chunk_size`, so every collection is chunked at its default of 1200 tokens. Its techniques are Fixed, Recursive, Semantic and ByHeading, so a collection set to SentenceWindow or TableAware is refused at `POST /ingestion/runs` with a validation error and never indexes. Measured against `ChunkingConfig` on 2026-10-29. |
| Pre-processing | Arabic normalisation and strip headers/footers are per-collection switches. | Ingestion is sent only OCR and PII masking (`reindexCollection`). Arabic normalisation is applied to every document (`parse_document`), and nothing strips headers or footers. |
| Retrieval settings | Minimum score and re-ranker are per-collection settings. | Neither is sent to retrieval (`retrieveFrom`). Hybrid retrieval always re-ranks and Vector never does (`retrieval.search`), whatever the switch; the retrieval test marks passages re-ranked from the switch. No minimum score is applied. `knowledge_search` uses its own `limit` (default 8), not the collection's top-k. |
| Sync schedule | A collection syncs Daily, Weekly or Manually. | The schedule is stored only; nothing runs a sync. |
| Embedding route change by an agent | The `knowledge_collection_edit` description says a changed embedding route starts a run. | `updateKnowledgeCollection` reports `cascade.reindexRequired` and starts nothing; the console's Save starts the re-index, and an agent has to call `knowledge_collection_reindex_create`. |

## Known gaps

| Gap | Evidence |
| --- | --- |
| Not built from the handoff's configuration tab: distance metric, HNSW `m` / `ef_construct`, quantisation, embedding dimensions, a choice of re-ranker, and the "every 6 hours", "daily at 02:00" and "on change" sync options. | `features/knowledge/components/collection-detail.tsx` |
| Not built from the Add source modal: URL crawl max depth and include pattern; the connector picker for an MCP resource (only the resource path is asked). | `features/knowledge/components/collection-detail.tsx` |
| A URL crawl or MCP resource source is stored with no documents, and nothing fetches any: the ingestion run reads only stored documents, and the agent service has no crawler or MCP resource reader. | `documentsOf` in `features/knowledge/repository.ts`; `services/agent/src/awp_agent/ingestion/` |
| The collection list, a collection's sources and its configuration are shown to every holder of `knowledge:read`, and every change needs only `knowledge:write`, whatever the collection's project. Only retrieval is limited to collections in the person's visible projects. | `loadKnowledge` and `listCollections`; `collectionIdsVisibleTo` in `retrieval-service.ts` |
