# Integration clients

| Item | Value |
| --- | --- |
| Purpose | Integration clients: external systems with their own keys, allowed permissions, MCP access to the platform and AG-UI access to agents |
| Audience | Developers, business analysts, testers, administrators, integrators |
| Related | [Flow F-11](../specs/flows.md#f-11-integration-client) · [Security](../03-architecture/security.md) · [Solution design](../03-architecture/solution-design.md) · [External systems](../06-integrations/README.md) · [Data dictionary: integrations](../04-data-model/data-dictionary/integrations.md) · [Glossary](../glossary.md) |
| Last verified against code | 2026-10-29 |

## Purpose

"External clients and what they may do. Each client has its own keys, MCP connection and AG-UI
exposure." An integration client is the identity an external system uses to call the platform:
it never borrows a person's session. Every call is limited to the client's allowed permissions and
is audited.

## Screens

The screens have no navigation entry; they are reached at `/integrations` (D226).

### Integrations list (S-76)

Columns: client (with its ID beneath), owner, allowed permissions, agents, keys, MCP (On/Off),
AG-UI (On/Off), status. Action: New client: client name in English and Arabic, owner (any person),
allowed permissions, and the client ID, derived from the English name (lowercase letters, digits
and hyphens, at most 40 characters) and shown read-only. Creating a client needs both names, an
owner, an ID of at least 3 characters and at least one permission; a client is created Active with
MCP and AG-UI exposure off, and its page opens.

### Client detail (S-77)

Header actions: Activate or Deactivate, and Delete client (after a confirmation). Changes save as
they are made; there is no Save changes button. Four tabs:

| Tab | Content |
| --- | --- |
| Keys | Create key (key name, expiry: 30 days, 90 days, 1 year or Never). "The secret is shown once." Per key: name, key prefix, last used, expiry, status, Rotate, Revoke. |
| MCP connection | **Expose platform as MCP server**, endpoint (`<platform>/api/mcp`), auth (API key, or OAuth 2.1 client credentials), exposed tools (every tool in the platform catalogue, as checkboxes). **Run test** calls `tools/list` with a key the administrator pastes (e.g. "Handshake OK · protocol 2025-06-18 · 3 tools listed", "Refused: …" or "No answer: …") and stores the result and time. Shows a message when MCP access is off. |
| AG-UI expose | **Expose agents over AG-UI**, stream endpoint (`<platform>/api/integrations/<client>/agui`), agents available to this client, events (`TEXT_MESSAGE_CONTENT`, `TOOL_CALL_START`, `STATE_SNAPSHOT`, `STATE_DELTA`, `RUN_FINISHED`), allowed origins (CORS, comma-separated, saved when the field loses focus). Shows a message when AG-UI streaming is off. |
| Permissions | Allowed permissions, as checkboxes: `agents:invoke` and every permission a catalogue tool checks, each with its name. |

**Beyond the handoff design** (`features/integrations/components/`): messages explaining what
deactivate, rotate (the screen gives the old key 24 hours), revoke and a permission change do; a
key status column; the show-once secret after create or rotate; and English and Arabic client
names. The MCP test asks the administrator to paste the key, because the secret is never read back
from storage, and calls the server's own listener rather than the public address
(`testMcpConnection` in `features/integrations/service.ts`). The protocol version the test reports
is the one the MCP SDK negotiates, not a fixed `2025-06-18` ([D91](../harness-decisions.md),
proposed).

## Business rules

| Rule | Source |
| --- | --- |
| A key's secret is shown once on creation or rotation; afterwards only its prefix is shown. The platform stores the prefix and a SHA-256 hash, never the secret. | `UC-77.1-01`; Spec §9; data model integrity rule 8; `createKey` in `repository.ts` |
| Rotating issues a new secret under the same key name, with the old key's lifetime measured from now, and leaves the old key working until the grace period ends (0–168 hours, default 24) or its own expiry, whichever is sooner. | `UC-77.1-02`; `rotateKeyInput` in `schema.ts`, `rotateKey` in `repository.ts` |
| A revoked key, a key past its expiry, and every key of an inactive client are refused at once, in one function both endpoints use. A key that works records its last use. | `UC-77.1-03`, `-04`, `UC-77.5-01`; `authenticateClientKey` in `repository.ts` |
| A client reaches only the tools it was exposed, and only when MCP exposure is on, its allowed permissions include the tool's permission, and the client has an owner. A client cannot call connector tools. | `UC-77.2-01`, `UC-77.4-01`; `callTool` and `callConnectorOperation` in `mcp/server.ts` |
| A client's tool call runs as the client's owner, so the owner's permission checks and audit apply; the audit entry names the client as actor. | Flow F-11 step 5; `callTool` in `mcp/server.ts` |
| A refused call is audited against the client with outcome Denied, and the client is answered only "not permitted". | `UC-77.4-02`; `recordClientRefusal` in `client-access-service.ts`; `refusal` in `mcp/server.ts` |
| An AG-UI call needs AG-UI exposure on, an allowed origin, the `agents:invoke` permission, an allowed agent and an owner; any other call is refused and logged. The run starts as the client's owner on the `Deployment` surface. When the client was given events, the stream carries only those; with none chosen it carries every event. | `UC-77.3-01`, `-03`, D179; `startClientRun` in `client-access-service.ts`; `app/api/integrations/[clientCode]/agui/route.ts` |
| Deleting a client removes its keys, permissions, agents and exposures; deactivating stops every key and can be reversed. | `UC-77.5-01`; `deleteClient` in `service.ts` |
| Client IDs are suggested from the name and unique. | `COM-13`, `UC-76.1-03` |
| No agent tool creates or changes a client. | D108, D253 |

## Requirements and acceptance

| Requirement | Screen | Scenarios |
| --- | --- | --- |
| [FR-085](../specs/requirements.md#govern) create a client | [S-76](../Tahseel_AWP_Screens_Use_Cases.md#s-76-integrations--clients) | `UC-76.1-01` … `-03` |
| [FR-086](../specs/requirements.md#govern) keys shown once, rotate, revoke | [S-77](../Tahseel_AWP_Screens_Use_Cases.md#s-77-integration-client-detail) | `UC-77.1-01` … `-04` |
| [FR-087](../specs/requirements.md#govern) MCP exposure | S-77 | `UC-77.2-01` … `-03` |
| [FR-088](../specs/requirements.md#govern) AG-UI exposure | S-77 | `UC-77.3-01` … `-03` |
| [FR-089](../specs/requirements.md#govern) permissions and audited refusals | S-77 | `UC-77.4-01` … `-02` |
| [FR-090](../specs/requirements.md#govern) deactivate a client | S-77 | `UC-77.5-01` |

Original scenario (Spec §7.5.6): **SC-INT-01** — an administrator creates a "CRM integration"
client and a key (shown once), enables MCP with three tools, tests it, and allows AG-UI for one
agent from one origin. The end-to-end journey is
[flow F-11](../specs/flows.md#f-11-integration-client).

## Implementation

| Part | Where |
| --- | --- |
| Page | `/integrations` → `app/(console)/integrations/page.tsx`; no navigation entry (`components/shared/nav.ts`, D226) |
| Feature folder | `apps/web/src/features/integrations/` — `service.ts` (clients, keys, exposure, MCP test), `client-access-service.ts` (key authentication, AG-UI run start, refusal audit), `repository.ts`, `tools.ts` |
| Components | `features/integrations/components/integrations.tsx`, `new-client.tsx`, `client-view.tsx`, `client-keys.tsx` |
| Server actions | `features/integrations/actions.ts`: `createClient`, `createKey`, `revokeKey`, `rotateKey`, `setClientStatus`, `deleteClient`, `setPermissions` (permissions and agents together), `setMcp`, `setAgui`, `testMcpConnection` |
| Public routes | `POST /api/mcp` — the platform MCP server; a client presents `Authorization: Bearer <key>`, and a run token is tried first (`handleMcpRequest` in `mcp/server.ts`). `OPTIONS, POST /api/integrations/<client>/agui` — body `{ "agent": "<code>", "prompt": "…" }`, answers an SSE stream of AG-UI events with header `x-awp-run-id`; refusals are 400 (no agent or prompt), 401 (`NoCredential`), 403 (`OriginNotAllowed`, `AguiOff`, `AgentNotAllowed`, `NotPermitted`), 503 (`RunNotStarted`, when the agent or the agent service is unavailable), each with `{ reason, refusal }`, and 503 when the run's stream does not open |
| How a client run starts | `startClientRun` starts the run as the client's owner on the `Deployment` surface, then the route relays `AGENT_SERVICE_URL/agui/runs/<run>/stream` |
| Platform MCP tools | `integration_client_list` (T0, `integrations:read`, default grant). No tool creates or changes a client: connectors and integrations are read-only in the catalogue ([D108](../harness-decisions.md), [D253](../harness-decisions.md)) |
| Client permissions | Offered: `agents:invoke` and the permissions of the platform catalogue's tools (`loadIntegrations`). Stored: `gov.client_permission`, whose check accepts `CLIENT_PERMISSIONS` (`db/schema/enums.ts`) |
| Tables | `gov.integration_client`, `gov.client_key`, `gov.client_permission`, `gov.client_agent`, `gov.client_mcp_exposure`, `gov.client_agui_exposure` — [data dictionary: integrations](../04-data-model/data-dictionary/integrations.md) |
| Privileges | `integrations:read`, `integrations:write` |

## ⚠ Unresolved conflicts

| Topic | Screen says | Code does |
| --- | --- | --- |
| Allowed permissions | The New client form and the Permissions tab offer `agents:invoke` and every permission a catalogue tool checks. | The database's `client_permission_check` accepts only `agents:invoke`, `requests:write`, `work_items:read`, `rooms:read`, `knowledge:search` and `webhooks:receive` (migration 0000), so saving any other permission the screen offers, such as `knowledge:read`, is refused by the database. `knowledge:search` and `webhooks:receive` are accepted but offered by no screen and checked by no tool. |
| MCP authentication | The MCP connection tab offers "OAuth 2.1 (client credentials)". | The choice is stored only; `/api/mcp` authenticates a client by its key as a bearer token, and there is no OAuth flow for clients. |

## Known gaps

| Gap | Evidence |
| --- | --- |
| Allowed agents cannot be chosen in New client; they are set afterwards on the AG-UI tab. `UC-76.1-02` names them in the create form. | `features/integrations/components/new-client.tsx` |
| There is one shared MCP endpoint, `/api/mcp`, rather than one per client. | handoff v2 §10; `mcp/server.ts` |
| The AG-UI preflight (`OPTIONS`) reflects any origin; only the `POST` checks the allowlist. A disallowed origin still gets 403 on the call itself, but its comment says the preflight gets no allowance. | `OPTIONS` in `app/api/integrations/[clientCode]/agui/route.ts` |
| The client code in the AG-UI path is not compared with the key: the key decides the client, and the path's code is used only in logs. | `POST` in `app/api/integrations/[clientCode]/agui/route.ts` |
| `tools/list` shows a client every tool it was exposed, also while its MCP exposure is off or it lacks the tool's permission; `tools/call` refuses those. | `catalogue` and `callTool` in `mcp/server.ts` |
| A T2 tool exposed to a client runs without an approval: the approval backstop and per-field escalation apply to agent callers only. | `callTool` in `mcp/server.ts` |
| "Receive outbound events" (`webhooks:receive`) has no outbound sender. | No code sends events to a client |
