# Skills

| Item | Value |
| --- | --- |
| Purpose | The Skills screen: installed and authored Agent Skills, package import with a security scan, the package's files and publishing |
| Audience | Developers, business analysts, agent designers, administrators |
| Related | [Glossary](../glossary.md) · [Bundled skills](../../packages/skills-bundled/README.md) · [Agents and runs](agents-and-runs.md) · [AI platform](../03-architecture/ai-platform.md) · [Use cases S-53](../Tahseel_AWP_Screens_Use_Cases.md#s-53-skills) |
| Last verified against code | 2026-11-01 |

## Purpose

"Reusable capabilities in the Agent Skills standard format." A skill is a package with a `SKILL.md`
whose frontmatter tells an agent when to load it. Skills are enabled per agent on the agent's Skills
tab ([Agents and runs](agents-and-runs.md)); this screen is where they enter the platform and are
reviewed and published.

The skills every installation ships with are listed in
[packages/skills-bundled/README.md](../../packages/skills-bundled/README.md).

## Screens

### Skills (S-53)

- **Tabs:**
  - **Installed:** every skill whose current version is not awaiting a scan (badge Bundled or
    Installed).
  - **My Skills:** skills with the source Authored, whatever their state (an unpublished one carries
    the badge Pending scan).
  - Each card shows the skill name, its badge, description, tags, source and version, and "Enabled
    for N agents" (agent versions carrying its current version).
- **Import skill package**, in two steps:
  1. Choose a `.zip` (a file picker), or give a Git URL, which wins when both are given; Validate
     package.
  2. The review: the package's `name`, its file count and `allowed-tools`, whether the `SKILL.md`
     frontmatter is valid (read as YAML, so a folded `description: >-` over several lines is its
     text; a header YAML refuses is read line by line), no embedded secrets, no prompt-injection patterns, warnings (e.g.
     "Script makes network calls — will run in sandbox only") and blockers. Choose one agent to
     enable it for, or none, then Import skill; Back returns to step 1 with nothing stored.
- **New skill modal:** title, description ("Agents read this to decide when to load the skill") and
  the skill name for `SKILL.md`, suggested from the title. It creates the skill with the source
  Authored at version `v1`, the title and description used for both languages, as a Draft.
- **Skill detail:** name, source and version, badge, and three columns:
  - **Files:** every file of the current version's package by path, `SKILL.md` first. The selected
    one is shown beside the list: text (Markdown, scripts, JSON, YAML, CSV, HTML, CSS, SVG and
    similar) as text, a PNG, JPEG, GIF or WebP as an image, any other type by its size with
    Download.
  - **Security scan:** scripts, network calls, prompt-injection patterns, embedded secrets, each
    with its count, or "Not scanned yet".
  - **Where used:** the agent versions carrying the current version ("<agent> vN").
  - **Download as .zip**, Publish, and Delete for a skill that is not bundled. Publish and Delete
    report the server's refusal as a toast; Publish reports which agents use the skill and on which
    version.
  - There is no test bench (owner's decision). Test cases stored before are kept in
    `ai.skill_test_case` and nothing reads or writes them.

Verified in `features/skills/` and `apps/web/src/lib/skill-package.ts`:

- A blocker disables Import, and the server validates the package again before storing it. A
  package is read with at most 5 MB and 200 files, a `\` in its paths (Windows PowerShell's
  Compress-Archive) read as `/`. Its `name` becomes the registry name (lower case,
  hyphens) and must not be taken. An imported skill's first version is `1.0.0`, Published, with its
  scan stored, and the source Uploaded or Git.
- Import enables the skill on the active version of each chosen agent, so it reaches their next
  runs without a publish of the agent; the console chooses one agent, and `importSkill` takes up to
  50. The import checks only `skills:write`.
- **Update from .zip** on a skill's detail (not offered for a bundled skill, refused by the service)
  opens the same two-step dialog for that skill. The package is validated as an import is and
  stored as the skill's next version (`1.0.0` → `1.1.0`, `v1` → `v2`, never a label the skill
  already has), Published with its scan, under `skills/<skill>/<version>`; it becomes the current
  version and the skill's description follows the new `SKILL.md`. The earlier version and its files
  stay. "Move the agents using it to the new version", on by default, moves the agents' active
  versions and open drafts that carry the skill to it, as Import pins an active version; earlier
  published agent versions keep their pin. The update is audited with both versions and the agents
  moved (`updateSkillPackage`, `skills:write`).
- A bundled skill ships with the platform and cannot be deleted: the screen offers no Delete and
  the service refuses it (D228). Any other skill can be deleted unless an agent's active version or
  open draft carries it; the refusal names those versions. Earlier published versions lose their pin, and a rollback to one runs
  without the skill (D211). Publishing sets the current version Published; an agent pinned to an
  older version does not move.
- The Files list and Download as .zip read the current version's files from the object store, under
  its `package_ref` prefix (`package-service.ts`). A file is served by
  `GET /api/skills/<skill>/files?path=<path>` and the package by `GET /api/skills/<skill>/package`,
  both requiring `skills:read`. A path with an empty, `.` or `..` segment, a leading `/` or a `\`
  is refused (400), so a read stays under that prefix. A file is served as `text/plain`, a raster
  image type or `application/octet-stream`, with `nosniff`, never as a type the browser would run.
  The zip holds the files under a folder named after the skill and is bounded like an import: 5 MB
  and 200 files. A bundled skill's files are in the agent image, which the console's image does not
  carry, so for a bundled skill the list says where they are in the source
  (`packages/skills-bundled/<skill>`) and Download as .zip is disabled; the routes answer 409. An
  authored skill has no stored package: the list is empty and the zip answers 404.
- An imported package's files are stored in the `skills` bucket of the object store under
  `<skill>/<version>/<path>`, laid out as the Agent Skills loader reads a package: `SKILL.md` at
  the root (the folder a zip carries around it is dropped) and its frontmatter `name` set to the
  skill's registry name, which has to match the package folder (`packageToStore` in
  `lib/skill-package.ts`, called by `import-service.ts`). The version's `package_ref` is
  `skills/<skill>/<version>`. A package an earlier import stored inside its zip's own folder is read
  from that folder (`_unwrapped` in `mission/skills.py`); one whose `name` is a title rather than
  the registry name is refused by the loader and logged as `skills.not_loaded` until re-imported.

## Business rules

| Rule | Source |
| --- | --- |
| An administrator imports a skill from a Git URL. The scan flags network calls, so the skill is limited to the sandbox. It is enabled for two agents and appears on their Skills tab. | SC-SKL-01, FR-060 |
| A package with no `SKILL.md`, an embedded secret or a prompt-injection pattern is blocked; it cannot be imported. | FR-060, `UC-53.2-06`, `lib/skill-package.ts` |
| A script that reaches the network is a warning, not a blocker, and marks the package sandbox-only. | FR-060, `UC-53.2-04` |
| A Git package is fetched only over HTTPS and only from a host listed in `SKILL_GIT_HOSTS`, through the egress proxy, with no redirects and a 20-second limit. | `features/skills/import-service.ts` |
| Creating, importing, publishing and deleting a skill change what every unit's agents may load, so each needs `skills:write` granted organisation-wide; a grant scoped to an org unit or a project does not reach them. | D330, `features/skills/service.ts` |
| A run's instructions list its granted skills by name and description. The model loads a skill's body with `skill_load` when a task needs it, and reads the files it links to (`references/x.md`, `#anchor` for one section, `../other-skill/…`) with `skill_file_read`; only a file the package lists is read. Both come with the skill, not a grant. | Specification §5.1, D88, D377 |
| A granted skill's scripts run only in a sandbox Pod of the run's own, and only a script the skill ships (`skill_script_run`). | D209, [runtime spec §2](../agent-runtime-spec.md#2-the-mission-loop) |
| A skill's name is suggested from its title and is unique. | FR-061, `COM-13` |
| A bundled skill cannot be deleted. The built-in `platform-operations` skill, which teaches one or many consecutive platform actions as the person asking, is in the built-in Assistant's defaults and the default agent's skills. | D228, `features/skills/service.ts` |
| Skills are versioned; running items keep the version they started with. | Specification §9 ([business rules](../01-business/business-rules.md)) |
| A pinned skill reaches a run only when its version is Published. A skill that is not bundled also needs a security scan that passed: no embedded secret and no prompt-injection pattern, the same findings that block an import. The agent service then reads its files from the object store and loads them with the harness's loader, as it does the bundle. The agent's Skills tab marks any other "Not applied to runs" with the reason. | Owner's decision, D127, D156, `whyNotApplied` and `scanFailures` in `lib/skill-package.ts` |
| A skill may declare only tools that the agents holding it can reach; a test over the seeded data enforces this, and the agent screen warns when a grant leaves a declared tool unreachable. | D79 |

## Requirements and acceptance

| Screen | [Requirements](../specs/requirements.md#ai-capabilities) | Use cases |
| --- | --- | --- |
| Skills | FR-059, FR-060, FR-061 | [S-53](../Tahseel_AWP_Screens_Use_Cases.md#s-53-skills): `UC-53.1`, `UC-53.2`, `UC-53.3` |

## Implementation

| Concern | Where |
| --- | --- |
| Route | `/skills` under `apps/web/src/app/(console)/`; `GET /api/skills/[name]/package` and `GET /api/skills/[name]/files` under `apps/web/src/app/api/` |
| Feature module | `apps/web/src/features/skills/` (`service.ts`, `import-service.ts`, `package-service.ts`, `repository.ts`, `tools.ts`); the package scanner is `apps/web/src/lib/skill-package.ts`, which is pure (no database, network or filesystem) |
| Server actions | `features/skills/actions.ts`: `createSkill`, `validateSkillPackage`, `importSkill`, `updateSkillPackage`, `deleteSkill`, `publishSkill`, `loadSkillFiles` |
| Permissions checked | `skills:read` for reads, the file list, a file and the zip; `skills:write`, organisation-wide, for validate, create, import, publish and delete (D330). The two routes answer 403 without `skills:read`, 400 for a path outside the package, 404 for no such skill or file, 409 for a bundled skill or a package past the limits, and 503 when the object store is not configured |
| MCP tools | `skill_list` (T0), `skill_create` (T1); `skill_publish` and `skill_delete` are T2, grantable but not in the default grant. `skill_version_create` (T2) updates an installed skill from the full text of its files, as Update from .zip does, and moves the agents carrying it unless told not to; the built-in Assistant holds it by default, other agents when granted (D376). Importing a skill is not in the catalogue (D108). A stored grant that still names a removed test bench tool reaches nothing, because no such tool is listed or callable |
| Tables | `ai.skill`, `ai.skill_version` (with declared tools), `ai.skill_scan_result`, `ai.agent_skill`; `ai.skill_test_case` is kept with its rows and unused — see the [data model](../04-data-model/overview.md) |
| Configuration | `SKILL_GIT_HOSTS` (comma-separated hosts allowed for Git import) — see [configuration](../07-operations/configuration.md) |

## ⚠ Unresolved conflicts

| Topic | Requirement or decision says | Code does |
| --- | --- | --- |
| Git import | SC-SKL-01 imports from a Git URL. | No environment sets `SKILL_GIT_HOSTS` (not in `.env.example` or the Helm values), so every Git import is refused with "Packages may only be fetched from a configured host". |

## Known gaps

| Gap | Evidence |
| --- | --- |
| A bundled skill's files cannot be listed or downloaded from the console, because its image does not carry `packages/skills-bundled`. | `features/skills/package-service.ts` |
| Drag-and-drop import with a package version is not built. | `features/skills/components/skills.tsx`, `features/projects/components/skill-modals.tsx` |
| An authored skill (New skill) has a title and description but no package, no `SKILL.md` body and no scan, so it is never applied to a run, published or not: the agent's Skills tab says it has not passed a security scan. Nothing edits an authored skill's content. | `features/skills/repository.ts` (`createSkill`), `whyNotApplied` in `lib/skill-package.ts` |
