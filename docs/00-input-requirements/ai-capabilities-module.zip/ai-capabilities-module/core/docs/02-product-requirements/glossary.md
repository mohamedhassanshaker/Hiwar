# Glossary

| Item | Value |
| --- | --- |
| Purpose | One definition for every business and technical term the documentation uses |
| Audience | Everyone: developers, architects, business analysts, stakeholders |
| Related | [Business overview](01-business/overview.md) · [Business rules](01-business/business-rules.md) · [Agent runtime specification](agent-runtime-spec.md) · [Decision register](harness-decisions.md) |
| Last verified against code | 2026-10-29 |

The product uses these names in the UI. Code, documentation and the data model use the same names.
Where a term has a code identifier, it is given in `code`. Business terms come from the handoff
specification §3 (archived in [_reference](_reference/Tahseel_AWP_Specification.md)); runtime terms
come from the [decision register](harness-decisions.md) and the code.

## Product and business terms

| Term | Meaning |
| --- | --- |
| **AWP** | Agentic Work Platform. The project and repository name: Tahseel AWP. |
| **Juman** | The product name shown to users. The console's page title is `Juman Console` (`apps/web/src/app/layout.tsx`) and the sidebar carries the Juman logo (design handoff v2). |
| **Organisation** | The single organisation served by the installation. |
| **Org unit** | A department or team. People and agents belong to org units and report up a line. |
| **Project** | A container for work, with its own members, sensitivity and policies. Discussion rooms, work items, requests, scheduled work items, artifacts and files belong to a project. |
| **Discussion room** | A topic-scoped room inside a project where people and agents talk. It has a type, a source (console, Teams, widget, routine…), a turn-taking mode and a context handoff. |
| **Turn-taking** | The rule that decides which agent answers a person's message in a room: Mention only, or Autonomous, where a message that names no agent goes to the room's one agent or, with several, to the agent the **Decision route** `agent-choice` chooses, the lead agent when it cannot (`apps/web/src/features/rooms/turns.ts`, D289, D290). One agent acts on a message (D213). |
| **Context handoff** | The summary a run or a closed room leaves for the next one: goal, decisions, open questions, next step. |
| **Request** | Something a person (or external contact) asks for. A request has a request type, belongs to a project, moves through the type's transition steps and may have sub requests and work items. |
| **Request type** | A configurable kind of request: category, attributes, transition steps, audiences, routing rules, intake channels, entry modes (template form / agentic interactive), decomposition, SLA, default project. Versioned (Draft / Published / Retired). |
| **Transition step** | A stage in a request type's flow. It has an SLA, audiences (Can act / Notify only / View only) and routing rules that lead to the next step. A step can be terminal; a terminal step's outcome (Completed or Rejected) decides the request's final status. |
| **Audience** | A person, role, group, agent or the requester attached to a transition step with one access level: Can act, Notify only or View only. |
| **Routing rule** | A condition (for example `amount_aed >= 5000`), an action (Submit, Return, Approve, Reject, Paid), or an action guarded by a condition (`Approve if amount_aed >= 5000`, D262) on a transition step, with the step it leads to. Rules are tried in order and the first match wins. |
| **Entry mode** | How a request is raised: Template form, or Agentic interactive (a classifier proposes the type and attribute values in a conversation). Agentic interactive is behind the `agentic-interactive-request-entry` flag, seeded off (D310). |
| **Work item** | A unit of work assigned to a person or an agent: **Task**, **Sub item** or **Bug**. Statuses: Backlog, To do, In progress, In review, Blocked, Done (plus Cancelled). |
| **Sub item** | A work item inside a parent work item (formerly "subtask"). It shares its parent's project. |
| **Hot items** | Open work items that are high priority, blocked, or due within 2 days. |
| **Scheduled work item** | A work item (or request) created on a schedule or event and assigned to an agent, a person or a group. |
| **Artifact** | An output produced by an agent or a person in a project, versioned and linked to its run. |
| **File** | A file a person uploads into a project, with a scope of use (only me / selected people and agents / everyone in the project). |
| **Card comment** | A comment thread attached to a dashboard card, which can be turned into a work item ("Make it a task") (design handoff v2; `apps/web/src/features/comments/`). |
| **Agent** | A versioned AI worker with instructions, skills, tools (through connectors), memory, knowledge, a model route, an execution profile, an org position, an agent trust level and a budget. |
| **Agent trust** | A single field on the agent version: Restricted, Standard, Elevated, Coordinator or System. It is specified to set what the agent may read, which tool tiers it may call and whether it may assign work; it is stored, and no run reads it yet ([open questions §8](specs/open-questions.md#8-requirements-the-code-does-not-meet)). |
| **Platform Assistant** | The built-in agent `pa` (`is_builtin = true`) that the AI Assistant panel always runs. It cannot be deleted; its configuration can be edited and reset to defaults (D65, D99). |
| **Page assistant** | The AI Assistant side panel bound to the current page and the person's permissions. It runs the Platform Assistant. |
| **Approval mode** | A choice in the assistant panel's composer, per conversation: Manual, the default, where the person decides each approval of their run on its card, or Auto, where those approvals are approved as they arrive and recorded as theirs (D282, D284, D298). |
| **Change set**, **Blueprint version** | Records of the removed Setup Director (D371): a proposed group of configuration changes, and the configuration version an applied one produced. Their tables were dropped by migration `0075` (D375). |
| **Run** | One execution of an agent version, with a timeline of model and tool steps, tool calls, tokens and context composition. Stored as an `ai.run` row. |
| **Skill** | A reusable capability in the Agent Skills standard (a package with `SKILL.md`). A granted skill whose version is Published and, unless it is bundled, passed its security scan is listed in a run's instructions by name and description; the model loads its body with `skill_load` and reads its files with `skill_file_read`, and its scripts run in the run's sandbox Pod (D206, D209, D377). |
| **Connector** | An MCP server, or a REST API registered from its OpenAPI document, that gives agents controlled access to a system. Each connector sets the **tier** of every tool it exposes. The built-in **Platform connector** (`platform`) presents the platform tools and cannot be removed (D228). |
| **Tool tier** | T0 Autonomous, T1 Confirm, T2 Human approval, T3 Forbidden. Defaults come from MCP annotations (read-only → T0, destructive → T2), and for a REST API operation from its HTTP method (GET and HEAD → T0). Project policies can only raise tiers. At run time a mission pauses T2 calls and calls the server escalates (D58, D139); T1 and T3 have no run-time behaviour of their own yet ([agent runtime spec, conflict 12](agent-runtime-spec.md#-unresolved-conflicts-with-the-code)). |
| **Tool mode** | How one agent may use one connector tool: Auto, Approval or Denied. It is never looser than the tool's tier. A tool granted from the grant picker starts at Auto for a T0 tool and Approval otherwise (D264). |
| **Memory** | Persistent knowledge for agents, organised by scope (Organisation, Business unit, Agent, Session), versioned and reviewed. Agent memory is scoped per agent and person (D68). |
| **Knowledge collection** | A set of document sources ingested into vector and graph stores for cited retrieval, with its own index, chunking, model and sync configuration. |
| **Provider / Connection / Route** | A provider (cloud or custom/on-prem) holds one or more connections; each connection allows specific models. A **route** (alias) chains provider › connection › model with fallbacks. Routes can be standard, **typesafe** (schema-validated output), **voice**, **embedding** or **decision**. An agent runs only on a standard or typesafe route (D337). |
| **Decision route** | A route of kind Decision whose models answer at the provider's decisions endpoint, with one choice among given options. The room's `agent-choice` route uses it to pick the answering agent (D290). |
| **Channel** | A messaging surface (Web widget, WhatsApp, Microsoft Teams) bound to an embedded deployment, room mirroring or request intake. |
| **Embedded deployment** | An agent published to websites and channels, with branding, security, surfaces and storylines. |
| **Storyline** | A versioned script for an embedded deployment, in Guided or Strict mode, made of typed steps (D339). In Guided the deployment's agent answers what the script does not offer; in Strict only the current step is taken. |
| **Visitor** | A person who is not signed in and reaches an agent through an embedded deployment (website, WhatsApp). |
| **Visitor conversation** | One visitor's conversation with a deployment, listed on AI Capabilities → Conversations (D342). |
| **Takeover** | A person holding `conversations:answer` taking a visitor conversation from the agent: the agent stops answering and the person writes to the visitor as a human agent until they resume the agent or end the conversation (D342, D343). |
| **External contact** | A requester from outside the organisation, such as a widget visitor, shown instead of an internal requester. |
| **Budget** | A spending limit for an agent, with a period, effective dates, a warning threshold and an action at 100% (notify only, switch to a cheaper alias, or pause the agent). It is distinct from a run's effort limits: a single run has no money ceiling (D73). |
| **Estimated cost** | Every cost figure in the product is an estimate based on token usage and list prices, and is labelled as such ("Estimated" or "(est.)", in AED). |
| **Integration client** | An external system with its own keys, allowed permissions, MCP access to the platform and AG-UI access to agents. |
| **Permission set** | The set of privileges (for example `work_items:write`) a role grants. Authorisation is evaluated on permission sets, never role names; explicit deny wins. The 54 privilege codes are in `apps/web/src/authz/permissions.ts`. |
| **Feature flag** | A switch in Settings → Feature flags, stored in `gov.feature_flag` and read per request. |

## Agent runtime terms

| Term | Meaning |
| --- | --- |
| **Mission** | One agent working on one prompt until it reaches an outcome. Mission id = Temporal workflow id = trace id (D44). Each mission is one `MissionWorkflow` with workflow id `run-<run id>`. |
| **Generic runtime** | The single Pydantic AI agent `awp-mission` in `services/agent/src/awp_agent/mission/runtime.py` that runs every agent, configured per run (D64, D87, D120). |
| **Harness** | The agent service's code around the generic runtime: workflows, activities, approvals, outcome recording. The name comes from the handoff specification's "in-house agent harness". |
| **Outcome** | How a mission ended, decided by the platform after the run, never by the model: Succeeded, Failed, Blocked, BudgetExceeded or Cancelled (D102). See [agent-runtime-spec.md §3](agent-runtime-spec.md#3-outcomes). |
| **Effort limits** | `max_steps`, `max_tool_calls` and the delegation depth and fan-out that bound a mission, as opposed to money (D73, D103, D129, D142). |
| **Run surface** | Where a run was started: `AssistantPanel`, `Playground`, `Room`, `WorkItem`, `Request` or `Deployment`. Named by server code, never by the caller (D70; `apps/web/src/features/agents/run-start-service.ts:25`). |
| **Context type** | The consequence of the run surface (for example `Console` for the assistant panel and the playground, `Room` for a discussion room). Derived server-side (D34, D53). The `Setup` value is kept for runs recorded before D371 and is no longer written. |
| **Execution profile** | The kind of work an agent is configured for: `conversational`, `task`, `planner`, `reviewer`, `triage`, `scripted` or `routine` (`services/agent/src/awp_agent/harness/profiles/*.yaml`). |
| **Grant** | The list of tools a run may reach: the person's permissions intersected with the agent's configuration, recorded on the run row (`ai.run.granted_tools`) (D31, D35). |
| **Run token** | The short-lived signed token minted by the web application for one run. The **model token** carries the granted tools; the **harness token** carries plumbing only (such as `run_finish`, `approval_create` and `run_token_refresh`) and works only on its own run (D33, D52). Both are refreshed while the run works and re-minted with an approval or an answer (D82, D251). |
| **Platform MCP server** | The MCP server inside the web application (`/api/mcp`) through which agents and integration clients read and change domain data under the same permission checks and audit as a person. |
| **Platform tool** | A tool in the platform MCP catalogue, named `<subject>_list/_get/_create/_edit/_delete/_publish` (D61). The catalogue is shown as the built-in Platform connector (`platform`), which cannot be removed (D228). |
| **Harness-answered built-in** | A tool the agent service answers itself rather than the platform MCP server: `delegate_to_agent`, `ask_person`, `generate_document`, `write_handoff`, and in the run's sandbox `skill_script_run`, `workspace_file_write`, `workspace_file_read` and `workspace_file_save` (D74, D80, D131, D209). They are granted like any tool. `knowledge_search` is granted in the same list and served by the platform MCP server (D151). |
| **Approval binding** | The link between an approval and the exact call it approves: tool name, canonical arguments hash, target record version, mission and person. It expires and is single use (D20, D21). |
| **Delegation** | A mission handing part of its work to another configured agent through `delegate_to_agent`, which starts a child mission (D08, D114, D142). |
| **Read floor** | In a room, the limit that keeps an agent's reads within what every human member may see (D104). `knowledge_search` is not bounded by it (D291). |
| **Refusal reason code** | The structured reason a tool call was refused: `user_permission`, `agent_grant`, `approval_required`, `run_binding`, `room_read_floor` (D32, D69, D104). |

## Abbreviations

| Abbreviation | Expansion |
| --- | --- |
| A2A | Agent-to-Agent protocol |
| AED | UAE dirham, the currency of every estimated cost |
| AG-UI | Agent–User Interaction protocol: the event stream between an agent and its UI |
| ASVS | OWASP Application Security Verification Standard |
| CNPG | CloudNativePG, the PostgreSQL operator |
| COM | Common scenario ID prefix in the acceptance document |
| D*nn* | Agent-runtime decision ID in [harness-decisions.md](harness-decisions.md) |
| AD-*nn* | Platform architecture decision ID ([decisions/platform.md](03-architecture/decisions/platform.md)) |
| SD-*n* | Stack decision ID ([decisions/stack.md](03-architecture/decisions/stack.md)) |
| R*nn* | Code-structure decision ID ([decisions/code-structure.md](03-architecture/decisions/code-structure.md)) |
| DD*nn* | Documentation refactor decision ID ([DOCS_DECISIONS.md](../DOCS_DECISIONS.md)) |
| FR-*nnn* | Functional requirement ([specs/requirements.md](specs/requirements.md)) |
| NFR-*nn* | Non-functional requirement ([specs/non-functional.md](specs/non-functional.md)) |
| F-*nn* | End-to-end flow ([specs/flows.md](specs/flows.md)) |
| S-*nn* | Screen ID in the acceptance document |
| SC-… | Scenario ID in the handoff specification |
| UC-*nn.n*-*nn* | Use-case scenario ID in the [acceptance document](Tahseel_AWP_Screens_Use_Cases.md) |
| KEK | Key-encryption key (`APP_KEK`) used for envelope encryption of stored credentials |
| MCP | Model Context Protocol |
| OIDC | OpenID Connect |
| PII | Personally identifiable information |
| RTL | Right-to-left layout (Arabic) |
| SLA | Service-level agreement: the time a step or request is due within, on the working calendar |
| SSO | Single sign-on |
| T0–T3 | Tool tiers (see Tool tier) |
