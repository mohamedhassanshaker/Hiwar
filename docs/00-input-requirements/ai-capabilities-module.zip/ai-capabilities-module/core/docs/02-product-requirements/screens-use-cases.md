# Tahseel AWP — Screens, Use Cases and Scenarios

| Item | Value |
| --- | --- |
| Version | 1.3 |
| Date | 30 Oct 2026 |
| Companion to | `Tahseel_AWP_Specification.md` v3.3 and `Tahseel_AWP_Data_Model.md` v1.2 |
| Scope | Every screen, modal and drawer in the handoff prototype `AWP Console.html` |
| Use | Acceptance criteria for implementation, test design and UAT |

---

## 1. How to read this document

Each screen has an ID (`S-xx`), its purpose, the actors who use it, how they reach it, and the use cases (`UC-xx.n`) it supports. Each use case lists its scenarios in one table.

| Column | Meaning |
| --- | --- |
| ID | Scenario ID (`UC-xx.n-yy`) used in test cases and defects |
| Type | **M** main path · **A** alternative path · **V** validation · **E** error or exception · **P** permission · **B** boundary or edge case · **N** empty state |
| Scenario | The situation and what the user does |
| Expected result | What the system must do |

The common scenarios in §2 apply to **every** screen and are not repeated per screen. Screen-specific tables only list behaviour unique to that screen.

**Actors**

| Actor | Description |
| --- | --- |
| Owner | Platform Owner |
| Admin | Administrator |
| Designer | Agent Designer |
| Publisher | Publisher of agent, skill and storyline versions |
| Lead | Work Lead |
| Member | Any signed-in member |
| Approver | Person in an approver role or group |
| Auditor | Read-only governance user |
| Visitor | Website or WhatsApp user of an embedded deployment (not signed in) |
| Agent | An AI agent acting through the harness |
| System | Scheduler, ingestion, budget enforcement and other platform processes |

---

## 2. Common scenarios (all screens)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| COM-01 | M | The user opens any screen in English. | Labels in English, layout left-to-right, and the active navigation item is highlighted. Detail screens highlight their parent item. |
| COM-02 | A | The user switches language to ع. | All labels, dates and numbers switch to Arabic. Layout mirrors to RTL. Record names show their Arabic value, falling back to English when it is empty. The choice is remembered. |
| COM-03 | A | The user toggles the theme. | Light and dark themes switch using design tokens. The logo switches to its dark/light variant. The choice is remembered. |
| COM-04 | B | Data is loading. | Skeletons or a loading state are shown; layout does not jump. |
| COM-05 | N | A list has no records, or no records match the filters. | An empty message for that list is shown (e.g. "No discussion rooms match these filters."). When filters caused it, a Clear option is available. |
| COM-06 | E | The server cannot be reached or returns an error. | A non-technical error banner with Retry is shown. No raw error text or stack trace is displayed. |
| COM-07 | P | The user lacks permission to view the screen. | The navigation item is hidden. Direct access shows "You don't have access". The attempt is audited when it involves protected data. |
| COM-08 | P | The user can view but not act. | Action buttons are hidden or disabled with a tooltip. Server-side checks still reject forced calls. |
| COM-09 | E | The user's session expires while working. | The user is asked to sign in again (password or UAE PASS, D387) and is returned to the same screen. Unsaved form input is kept where possible. |
| COM-10 | E | Two users edit the same record. | The second save is rejected with "This record was changed by someone else". The user can reload and reapply. |
| COM-11 | A | The user clicks any action without a dedicated design. | The generic action modal explains what will happen and asks for confirmation. On Done, the change is applied and "The change is recorded in the audit log" is shown. |
| COM-12 | V | A required field is empty or invalid. | The field is highlighted with a message in the current language. Save or Create stays disabled or is blocked. |
| COM-13 | A | A form has a code or key field. | The code is suggested from the name or title ("auto"). The user can accept the suggestion or edit it. Duplicates are rejected with a message. |
| COM-14 | B | The screen is viewed on a narrow window. | The layout reflows. Tables scroll horizontally inside their card. Drawers become full-width. |
| COM-15 | M | Any cost value is displayed. | The value is labelled "Estimated" or "(est.)" with the currency (AED). |
| COM-16 | M | A keyboard or screen-reader user uses the screen. | Every control is reachable by keyboard with a visible focus. Icons have accessible names. Modals trap focus and close with Esc. |
| COM-17 | M | The user closes a modal or drawer without saving. | Nothing is changed. If there were edits, the user confirms discarding them. |
| COM-18 | M | The user performs an action that changes data. | The change is written to the audit log with the actor, action, object and time. |

---

## 3. Shell and account

### S-01 Shell — navigation and top bar

**Purpose.** The frame around every screen: navigation, global creation actions, language, theme, assistant, inbox and user menu.
**Actors.** All signed-in users.

#### UC-01.1 Navigate the platform

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-01.1-01 | M | The user signs in. | The Dashboard opens as the landing page. |
| UC-01.1-02 | M | The user clicks a navigation item. | The screen opens, scrolled to the top, and the item is highlighted. |
| UC-01.1-03 | A | The user opens a detail screen (room, run, storyline, widget, visitor conversation, records). | The parent item stays highlighted (Discussion Rooms, Agents, Embedded Deployment, Conversations, Dashboard). |
| UC-01.1-04 | A | The user returns later. | Theme and language are restored. |
| UC-01.1-05 | P | The user's role hides a group (e.g. Govern for a Member). | The group and its items are not shown. |
| UC-01.1-06 | B | The Inbox has new items. | The Inbox badge in the sidebar and the bell in the top bar show the same count, which updates live. |

#### UC-01.2 Create from the top bar

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-01.2-01 | M | The user clicks New Work Item. | The New Work Item modal opens (S-24b). |
| UC-01.2-02 | M | The user clicks New Request. | The New Request modal opens (S-28). |
| UC-01.2-03 | M | The user clicks New Discussion Room. | The New Discussion Room modal opens (S-22b). |
| UC-01.2-04 | P | The user cannot create in any project. | The button is disabled with a tooltip explaining why. |

#### UC-01.3 Use the user menu

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-01.3-01 | M | The user opens the menu. | The menu shows the user's name, email, My profile, Settings and Log out. |
| UC-01.3-02 | M | The user clicks My profile or Settings. | The screen opens and the menu closes. |
| UC-01.3-03 | M | The user clicks Log out. | The session ends and the sign-in screen (S-05) is shown; there is no separate signed-out screen (owner, 2026-11-05). |
| UC-01.3-04 | A | The user clicks outside the open menu. | The menu closes. |
| UC-01.3-05 | P | The user cannot access Settings. | The Settings entry is hidden. |

### S-02 Search palette (⌘K)

**Purpose.** Find anything the user may access. **Entry.** The top-bar search box, or ⌘K / Ctrl+K.

#### UC-02.1 Search everything

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-02.1-01 | M | The user presses ⌘K and types "travel". | Results are grouped by kind: discussion room, work item, request, agent, skill, connector, knowledge, artifact. |
| UC-02.1-02 | M | The user selects a result. | The palette closes and the record's screen or detail opens. |
| UC-02.1-03 | A | The user moves through results with the arrow keys and presses Enter. | The highlighted result opens. |
| UC-02.1-04 | A | The user searches in Arabic. | Arabic names and titles match, including with diacritics or letter-form variations. |
| UC-02.1-05 | N | There are no matches. | "No results" is shown. |
| UC-02.1-06 | P | A matching record is in a project the user cannot see. | The record is not shown. Counts do not reveal it. |
| UC-02.1-07 | A | The user presses Esc. | The palette closes and the previous focus is restored. |

### S-03 Page assistant

**Purpose.** The AI Assistant panel, which runs the built-in Platform Assistant bound to the current page and the user's permissions. **Entry.** The floating AI Assistant launcher in the inline-end bottom corner.

#### UC-03.1 Ask about the current page

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-03.1-01 | M | The user opens the assistant on the Dashboard and picks "What needs my attention today?". | A streamed answer summarises approvals, SLA risks and errors visible to the user, with links. |
| UC-03.1-02 | M | The user asks "Summarise this page" on a project. | The summary uses only that page's data. |
| UC-03.1-03 | A | The user asks the assistant for a change. | The assistant makes it as the person who asked, within `pa`'s grant. A call that needs approval pauses for that person's decision in the panel, unless they chose Auto for the conversation (D281, D284). There is no hand-off to another agent (D371). |
| UC-03.1-04 | P | The user asks about data they cannot access. | The assistant says it cannot see that data and does not reveal it. |
| UC-03.1-05 | E | The model route is unavailable. | The assistant shows "The assistant is unavailable, try again" and the page keeps working. |
| UC-03.1-06 | A | The user hides the panel and navigates. | The panel stays hidden. Its conversation, and an answer still arriving, are there when it is shown again (D239). |
| UC-03.1-07 | A | The user asks a question, then navigates to another page with the panel open. | The panel and the conversation survive the navigation. The next question is answered about the new page. New chat is what ends a thread. |

### S-04 My profile

**Entry.** User menu → My profile.

#### UC-04.1 Maintain own profile

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-04.1-01 | M | The user edits their English and Arabic names and mobile, then clicks Save changes. | The profile is updated and the new name shows in the top bar. |
| UC-04.1-02 | M | The user changes the preferred language. | The default UI language and notification language follow the choice. |
| UC-04.1-03 | M | The user uploads a new photo with Change photo. | The avatar updates everywhere. |
| UC-04.1-04 | V | The mobile number is invalid. | A validation message is shown and the profile is not saved. |
| UC-04.1-05 | V | The photo is too large or in an unsupported format. | The upload is rejected with the allowed formats and size. |
| UC-04.1-06 | B | The email is the sign-in address an administrator set. | The email is read-only. |

#### UC-04.2 Manage notification preferences

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-04.2-01 | M | The user turns off "Daily email digest". | No digest is sent from the next day. |
| UC-04.2-02 | M | The user turns off "Mentions in discussion rooms". | No mention notifications are sent. Mentions still appear in the Inbox. |
| UC-04.2-03 | B | The user turns off "Approvals waiting for me". | Approvals still appear in the Inbox. Only external notifications stop. |

#### UC-04.3 Review security

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-04.3-01 | M | The user views Security. | The page shows the sign-in method (Password · WebAuthn, with UAE PASS when linked), the Emirates ID masked (D387), the passkey count and active sessions. |
| UC-04.3-02 | A | The user registers or removes a passkey. | The passkey list updates and the change is audited. |
| UC-04.3-03 | A | The user signs out another active session. | That session is revoked immediately. |

### S-05 Signed out / sign in

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-05.1-01 | M | The user signs in with email and password, or with UAE PASS (D387). | The user lands on the Dashboard (or the page they were on, after a session expiry). |
| UC-05.1-02 | E | The password is wrong, or UAE PASS fails or is cancelled. | The sign-in screen stays, with an error message (UAE PASS's own wording for its cases, D387). |
| UC-05.1-03 | P | The user's account is suspended. | Sign-in is refused with "Your access is suspended — contact your administrator". |
| UC-05.2-01 | M | A visitor opens Create an account and registers with a name, email, organization and password, or with UAE PASS, an email and an organization (D393). | The registration is stored as Pending and the sign-in screen says it is waiting for approval; nobody is signed in. |
| UC-05.2-02 | P | A Pending person tries to sign in, with either method. | Sign-in is refused with "Your registration is waiting for approval. We will email you when it is approved." |
| UC-05.2-03 | M | A person registers. | Everyone who holds `registrations:approve` gets an Inbox item (a Review) and an email; the item opens People on the Pending filter. |
| UC-05.2-04 | M | An approver approves a registration. | The person becomes Active as a Member in the organization they chose (any role or organization, for an approver who also holds `permissions:write`), is emailed, and can sign in; every approver's Inbox item closes. |
| UC-05.2-05 | M | An approver declines a registration. | The registration is removed, so the address can register again; every approver's Inbox item closes. |
| UC-05.2-06 | E | No organization is chosen, the email is already on the platform, the password breaks the rules, or one network address registers more than 20 times in an hour. | Refused with the reason; nothing is stored. |
| UC-05.1-04 | B | A brand-new installation has no organisation set up yet. | The Platform Owner lands on the Dashboard, like every other person (D371). |

---

## 4. Home

### S-10 Dashboard

**Purpose.** An overview of work, runs, approvals, errors, estimated cost and SLA.
**Actors.** All. Figures are limited to what each user may see.

#### UC-10.1 Monitor the organisation

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-10.1-01 | M | The user opens the Dashboard. | The page shows a greeting with the user's first name, one date range for every card, and nine cards: AI Assistant (automation rate), Agent runs, Estimated cost, Month budget, Tasks finished, Run outcomes, Needs attention (agents in error, approvals waiting, SLA at risk), Runs in progress and Discussion room activity. |
| UC-10.1-02 | M | A run changes status or a new approval arrives. | The affected cards update without a page reload. |
| UC-10.1-03 | A | No agent is in error. | The card shows 0 and stays clickable, opening an empty list. |
| UC-10.1-04 | B | It is the first day of the month. | Budget burn shows month-to-date, with the elapsed percentage near 0%. |
| UC-10.1-05 | P | A Member without cost permission views the page. | Cost cards are hidden or show only the costs of their own projects. |
| UC-10.1-06 | N | The installation is brand new. | All values show 0, with a link to New Work Item. |

#### UC-10.2 Drill into a card

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-10.2-01 | M | The user clicks "SLA at risk". | The Records list (S-11) opens with items due within 4 hours. |
| UC-10.2-02 | M | The user clicks a run in "Runs in progress". | The run viewer (S-52) opens. |
| UC-10.2-03 | M | The user clicks "All discussion rooms". | The Discussion Rooms list opens. |
| UC-10.2-04 | A | The user clicks New Discussion Room or New Work Item in the greeting. | The corresponding modal opens. |

### S-11 Records (dashboard drill-down)

#### UC-11.1 Work with a drill-down list

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-11.1-01 | M | The list opens from a card. | The title and description match the card. Columns match the record kind. A record count is shown. |
| UC-11.1-02 | M | The user searches by key or title. | The list filters when the search is applied: on Enter or when the box loses focus (D349, D356). |
| UC-11.1-03 | M | The user filters by status. | Only matching records are shown and the count updates. |
| UC-11.1-04 | M | The user clicks a row. | The record's own detail opens: work item drawer, request detail, run viewer, Inbox item or agent. |
| UC-11.1-05 | A | The user clicks Export. | A CSV/Excel file of the filtered rows is produced, with estimated costs labelled. The export is audited. |
| UC-11.1-06 | N | No records match. | "No records match." is shown. |
| UC-11.1-07 | B | A record leaves the condition while the list is open (e.g. an SLA item is completed). | It is removed on refresh. Its "Time left" counts down live. |
| UC-11.1-08 | A | The user clicks back. | The Dashboard opens. |

### S-12 Inbox

**Purpose.** Approvals, agent questions, mentions and SLA warnings for the user and their groups.

#### UC-12.1 Decide an approval

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-12.1-01 | M | The approver opens a pending approval. | The item shows: requested by, run, work item, policy, action and arguments (redacted), and evidence. |
| UC-12.1-02 | M | The approver clicks Approve. | The waiting run resumes ("Approved — run resumed"). The item moves to Resolved, the badge decreases, and the decision is audited and recorded in the project's decisions. |
| UC-12.1-03 | A | The policy is sequential (Fatima → Khalid). The first approver approves. | The item moves to the second approver's Inbox. The run keeps waiting. |
| UC-12.1-04 | A | The policy is "any of" a group. One member approves. | The item is resolved for all group members. |
| UC-12.1-05 | M | The approver clicks Request changes with a comment. | The run receives the feedback and continues to revise. The item is resolved as "Changes requested". |
| UC-12.1-06 | V | The approver clicks Reject with no reason. | Reject is blocked with "Reason (required to reject)". |
| UC-12.1-07 | M | The approver rejects with a reason. | The run is told, the action is not performed, the reason is recorded in the decision log, and the item moves to Resolved. |
| UC-12.1-08 | E | The approval expired before the decision. | Buttons are disabled with "Expired — escalated to …". |
| UC-12.1-09 | E | The underlying run was cancelled. | The item shows "Run cancelled — no decision needed" and moves to Resolved. |
| UC-12.1-10 | P | The approver is also the requester of the work, and the approval was raised outside a room and the assistant panel. | Approve is not offered, with the note "You cannot approve your own request". In a room the person who asked decides their own run's approval, except a call that changes who may reach what (D105, D253, D267); in the assistant panel they decide every approval of their run (D281, D284). |
| UC-12.1-11 | B | Two group members decide at the same moment. | The first decision wins. The second user sees "Already decided by …". |
| ~~UC-12.1-12~~ | A | Retired by D371: the approval was for a Setup Director change set. | The Setup Director is removed; no change-set approval is raised. |

#### UC-12.2 Answer an agent question

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-12.2-01 | M | The user types an answer and clicks Send answer. | The run resumes with the answer ("Your answer resumes the run") and the item moves to Resolved. |
| UC-12.2-02 | V | The answer is empty. | Send is disabled. |
| UC-12.2-03 | A | The question offers options. | The user picks one option instead of typing. |
| UC-12.2-04 | E | The question was already answered by another group member. | "Answered by …" is shown with their answer. |

#### UC-12.3 Filter and review

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-12.3-01 | M | The user switches between the tabs All, Approvals, Questions and Resolved. | The list filters and the tab counts are correct. |
| UC-12.3-02 | M | The user opens a mention item. | The discussion room opens, scrolled to the message. |
| UC-12.3-03 | M | The user opens an SLA warning. | The work item drawer or request detail opens. |
| UC-12.3-04 | N | Nothing is waiting. | An empty state is shown and the badge is hidden. |
| UC-12.3-05 | M | A request of the user's is raised, updated or finished, or a work item is given to them or finished (D394). | An Update appears in the Inbox naming the event; Open leads to the request or work item. |
| UC-12.3-06 | M | The user opens an Update and clicks Mark as read. | The Update moves to Resolved and the badge falls by one. |
| UC-12.3-07 | A | Something is put in a person's Inbox: an approval, a question, a mention, a review, a budget warning or an Update. | The person is also emailed, in their language, with a link to it, unless the mail server is off, they are not active, or they turned that email off. |

---

## 5. Work

### S-20 Projects — list

#### UC-20.1 Browse projects

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-20.1-01 | M | The user opens Projects. | Projects the user belongs to (or may see) are listed with key, status, owner, org unit, sensitivity, work item count and progress. |
| UC-20.1-02 | M | The user filters by status or org unit, or searches. | The list filters. |
| UC-20.1-03 | M | The user clicks a project. | The project detail (S-21) opens. |
| UC-20.1-04 | P | A Restricted project the user is not a member of exists. | It is not listed. |

#### UC-20.2 Create a project (New Project modal)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-20.2-01 | M | An admin enters name, owner, sensitivity and description, accepts the suggested key and clicks Create project. | The project is created with status Backlog and the owner as Owner member. It opens on its detail page. |
| UC-20.2-02 | A | The admin edits the suggested key. | The edited key is used. |
| UC-20.2-03 | V | The key duplicates an existing project. | "Key already in use" is shown and the project is not created. |
| UC-20.2-04 | V | The name is missing. | Create is disabled and the key stays blank. |
| UC-20.2-05 | P | A Member without project.create permission opens Projects. | New Project is hidden. |

### S-21 Project detail

#### UC-21.1 Review a project

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-21.1-01 | M | The user opens a project. | The page shows KPIs (open work items, work items, progress, rooms, requests), policies, members, the "In this project" links and recent decisions. |
| UC-21.1-02 | M | The user clicks an "In this project" link (e.g. Discussion rooms). | The list opens, filtered to this project. |
| UC-21.1-03 | M | The user clicks a recent decision. | The source opens: the approval or the room message. |

#### UC-21.2 Edit project and policies

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-21.2-01 | M | The owner changes the sensitivity from Internal to Confidential. | The policy is saved. Rooms, files and artifacts inherit the new sensitivity. The change is audited. |
| UC-21.2-02 | M | The owner limits the allowed connectors. | Agents working in the project can no longer call tools from other connectors. Running agents receive "connector not allowed in this project". |
| UC-21.2-03 | M | The owner adds "Human approval for: Send external email". | That action becomes at least T2 inside the project. |
| UC-21.2-04 | V | The owner tries to lower a tool below its connector tier. | This is not possible. The note says "Project policies can only raise tiers". |
| UC-21.2-05 | M | The owner turns on "Reviewer ≠ author on every item". | Work items in review cannot be approved by their author. |
| UC-21.2-06 | A | The owner changes the status to Paused. | Scheduled work items in the project stop creating items. Running agents finish their current work. |
| UC-21.2-07 | P | A Member opens Edit project. | Edit is hidden. |

#### UC-21.3 Manage members

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-21.3-01 | M | The owner adds a person as Member. | The person gains access to the project's content. |
| UC-21.3-02 | M | The owner adds an agent. | The agent can be assigned the project's work items and can join its rooms. |
| UC-21.3-03 | V | The owner adds an agent that is not in the allowed-agents policy. | The add is blocked with a link to the policy. |
| UC-21.3-04 | E | The owner removes the last Owner. | The change is blocked: a project must have an owner. |
| UC-21.3-05 | A | A member with open assigned work is removed. | A warning lists their open items. After confirmation they are removed, and their items stay assigned until reassigned. |

### S-22 Discussion Rooms — list

#### UC-22.1 Find rooms

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-22.1-01 | M | The user opens the list. | The default filter is Status = Active. KPIs show Total, Active, Archived and Messages. |
| UC-22.1-02 | M | The user filters by project, status (Any, Active, Idle, Paused, Closed, Archived) or searches by title or key. | The list filters. |
| UC-22.1-03 | M | The user clicks a room. | The room (S-23) opens. |
| UC-22.1-04 | N | No room matches. | "No discussion rooms match these filters." is shown. |
| UC-22.1-05 | P | A room is private and the user is not a participant. | It is not listed. |

#### S-22b UC-22.2 Create a room (New Discussion Room modal)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-22.2-01 | M | The user picks a project, enters a title, picks type and participants (people and agents), status Active and turn-taking Autonomous, then clicks Create room. | The room is created with the user as Owner and a participant, the other people as Members and the first agent picked as lead agent, and opens. The form shows the user first among the participants and does not let them be removed; a room may be created with nobody else picked (D167, D289, D345). |
| UC-22.2-02 | A | Turn-taking is Mention only. | Agents reply only when @mentioned. |
| UC-22.2-03 | V | No project is chosen. | Create is disabled. |
| UC-22.2-04 | B | A room is created under either turn-taking policy without any agent participant. | The room is created as a conversation between people: no agent answers and no note is added under people's messages (D213, D214, D289). |
| UC-22.2-05 | P | An agent not allowed in the project is selected. | The agent is not offered in the picker. |
| UC-22.2-06 | A | Status Paused is chosen. | The room is created but no agent runs until it is activated. |

### S-23 Discussion Room

#### UC-23.1 Converse with people and agents

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-23.1-01 | M | A member posts a message. | All participants see it live. |
| UC-23.1-02 | M | A member types @ and selects an agent, then sends. | The agent run starts with the room context. The participant shows "Working" and a working line appears ("… is working: drafting follow-up task…"). The reply streams to everyone. |
| UC-23.1-03 | M | The agent's reply includes a file it produced. | An artifact card shows name, size or rows, creator and Open. Open shows the artifact preview. |
| UC-23.1-04 | M | The user reads the meta of an agent message. | The meta shows the agent's version, Open trace (for authorised users) and feedback. Above the text, the run's tool calls are folded to their count ("3 steps done") and each opens onto its arguments and result (D352). It does not show the model or the estimated cost, and the room panel does not show the hop limit, room cap or estimated spend (D216). |
| UC-23.1-05 | M | The user marks an agent message Helpful or Not helpful. | The choice toggles, is stored and feeds the agent's evaluation. |
| UC-23.1-06 | A | A member mentions a person. | The person receives an Inbox mention and a notification according to their preferences. |
| UC-23.1-07 | A | Turn-taking is Autonomous and a member posts without naming anyone. | One agent answers: the room's only agent or, with several, the one the platform chooses (UC-23.3-02). A message that names a person gets no agent reply. An agent's post never starts another agent; agents work together only through delegation inside the mission (D66, D163, D213, D289). |
| UC-23.1-08 | B | The room's agents have posted its limit of agent messages for one human message (6 by default). | No further agent reply is posted, and the note "Agent hop limit reached; the next message from a person starts it again." is written once. A human message resets the count (D66). |
| UC-23.1-09 | B | The room's estimated spend reaches the cap (e.g. AED 25.00). | Agents stop responding. The owner sees "Room cost cap reached" and can raise the cap if permitted. |
| UC-23.1-10 | E | An agent run fails. | The message shows "… could not complete" with Retry and a link to the run. |
| UC-23.1-11 | P | An Observer tries to post. | The composer is disabled. |
| UC-23.1-12 | B | A user joins late or reconnects. | The full transcript is rebuilt, and an agent still streaming continues live. |
| UC-23.1-13 | A | The room is mirrored to Teams and a message arrives in Teams. | The message appears in the room and replies go back to Teams. |

#### UC-23.2 Approve inside the room

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-23.2-01 | M | An agent's T2 tool call pauses its run, the room shows "Approval required · <key>", and an eligible approver clicks Approve. | The card shows "Approved by you · applying", the call runs and the run carries on. |
| UC-23.2-02 | A | The approver clicks Request changes. | The call does not run; the agent receives the feedback and carries on with it. |
| UC-23.2-03 | M | The approver clicks Reject. | A reason is asked for. The card shows "Rejected by you". |
| UC-23.2-04 | P | A participant who is not an approver views the card. In a room the approver is the person who asked, except for a call that changes who may reach what (D105, D253). | The card is visible, reads "Awaiting approval from …", and its buttons are hidden. |
| UC-23.2-05 | B | The same approval is decided from the Inbox. | The room card updates to the decided state. |

#### UC-23.3 Manage the room

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-23.3-01 | M | The owner changes turn-taking between Mention only and Autonomous, the two policies a room has. | The policy is saved against the version the owner read, and agents answer by it from the next message (D289). |
| UC-23.3-02 | A | Turn-taking is Autonomous, the room has several agents, and a member posts without naming anyone. | The platform chooses one agent on the Decision route `agent-choice` from the message, the conversation so far and each agent's description. The lead agent answers when that route is unavailable, does not answer within 15 seconds or gives no valid choice (D289, D290). |
| UC-23.3-03 | P | A participant without the moderation right opens Turn-taking. | It is read-only for them, and the server refuses a change (D289). |
| UC-23.3-04 | M | The owner adds or removes a participant. | Participants update. A removed person loses access immediately. |
| UC-23.3-05 | M | The user clicks Fork and enters a new title and "What should change?". | A new room is created, linked to the original, with selected context carried over. |
| UC-23.3-06 | M | The owner clicks Close room. | The final context handoff is generated. Status becomes Closed, and running agent replies finish or are cancelled. |
| UC-23.3-07 | M | The user clicks Back. | The rooms list opens with the earlier filters kept. |

#### UC-23.4 Use the context handoff and linked items

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-23.4-01 | M | After an agent run ends. | The room's context handoff (goal, decisions, open questions, next step) is written and kept for agents and the record. The room's side panel does not show it (D236). |
| UC-23.4-02 | M | The user clicks a linked work item. | The work item drawer opens. |
| UC-23.4-03 | A | The user creates a work item from a message. | The item is created with origin = this message and appears under Linked work items. |

### S-24 Work Items — board, list and search

#### UC-24.1 View work

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-24.1-01 | M | The user opens Work Items. | The Hot items view is shown by default (high priority, blocked, or due ≤ 2 days) with an explanatory note. |
| UC-24.1-02 | M | The user switches to All work items. | All open items the user may see are shown. |
| UC-24.1-03 | M | The user switches between Board and List. | Board shows columns Backlog, To do, In progress, In review, Blocked and Done with counts. List shows key, title, project, type, status (coloured tag), priority, assignee and due. |
| UC-24.1-04 | M | The user clicks a card or row. | The work item drawer (S-25) opens. |
| UC-24.1-05 | B | A sub item appears in a filtered list. | It shows "This sub item is shown inside its parent work item" with a link to the parent. |
| UC-24.1-06 | N | There are no hot items. | An empty state is shown with a link to All work items. |
| UC-24.1-07 | A | The user drags a card to another column on the Board, or picks a status from the drawer's "Move to…". | The status changes if the transition is allowed. Otherwise the card returns with a message (D192). |

#### UC-24.2 Advanced search

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-24.2-01 | M | The user opens Advanced search and sets keyword, project, type, status, priority, assignee (Anyone, Unassigned, or a person or agent) and due from/to, then clicks Search all work items. | Matching items are listed. |
| UC-24.2-02 | M | The user clicks Save as view and gives it a name. | The view appears among the filters and can be reopened. |
| UC-24.2-03 | A | The user clicks Clear. | All criteria reset. |
| UC-24.2-04 | V | Due from is later than Due to. | A validation message is shown and the search is blocked. |
| UC-24.2-05 | N | Nothing matches. | An empty message is shown, with Clear. |

#### S-24b UC-24.3 Create a work item (New Work Item modal)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-24.3-01 | M | The user enters a title and project, keeps type Task, picks assignee, priority, due date and reviewer, writes a description and clicks Create work item. | The item is created with status To do (or Backlog when unassigned) and a key from the project prefix. |
| UC-24.3-02 | A | The assignee is an agent. | The agent run starts and the item moves to In progress. |
| UC-24.3-03 | A | The type is Sub item. | A parent must be chosen and the project is fixed to the parent's project. |
| UC-24.3-04 | A | The type is Bug. | Bug fields (severity, steps, expected vs actual) are offered as attributes. |
| UC-24.3-05 | B | A similar open item exists. | "Similar open item: TSK-2311 …" is shown with Open. The user may still create the item. |
| UC-24.3-06 | V | The title or project is missing. | Create is disabled. |
| UC-24.3-07 | V | The reviewer is the same as the assignee. | When the project requires reviewer ≠ author, "Reviewer must differ from assignee" is shown. |
| UC-24.3-08 | P | The selected agent is not allowed in the project. | The agent is not offered. |
| UC-24.3-09 | V | The due date is in the past. | A warning is shown; the item is allowed but marked overdue. |

### S-25 Work item drawer

#### UC-25.1 View a work item

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-25.1-01 | M | The drawer opens. | Header (key, title, type and status tags), main info (assignee, reviewer, project, request type, parent item, origin, due, description, attributes with schema, attachments and linked artifacts, each opening as what it is) and tabs (Sub items, Activity) (D347). |
| UC-25.1-02 | M | The user clicks the origin or parent link. | The request, room message, schedule or parent item opens. |
| UC-25.1-03 | M | The user adds an attachment from this computer, or a file or artifact they may read from Files or Artifacts. | The file uploads, or a copy of the held file is attached, and is listed (D229). |
| UC-25.1-04 | N | There are no attachments or no sub items. | "No attachments." and "No sub items yet." are shown. |
| UC-25.1-05 | V | An attachment is over the size limit or of a blocked type. | The upload is rejected with a message. |

#### UC-25.2 Act by status

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-25.2-01 | M | The item is To do or In progress and the user clicks Submit for review. | Status becomes In review and the reviewer is notified. |
| UC-25.2-02 | M | The item is In review and the reviewer clicks Approve. | Status becomes Done and the parent's progress updates. A linked request whose type decomposes completes when its last open work item is approved; any other request moves only by its steps (D312). |
| UC-25.2-03 | M | The item is In review and the reviewer clicks Request changes with a comment. | Status returns to In progress. If the assignee is an agent, the agent is re-triggered with the comment. |
| UC-25.2-04 | P | The author or assignee tries to Approve their own item. | Approve is hidden for them. |
| UC-25.2-05 | M | The item is Blocked and the user clicks Unblock. | Status returns to its previous state and the blocker is cleared. |
| UC-25.2-06 | M | The item is Blocked and the user picks an agent in Assign to, which lists people and agents. | The agent's run starts and the item moves to In progress. A person assignee moves a Backlog item to To do and may not be the item's reviewer (D150). |
| UC-25.2-07 | M | The item is Done and the user clicks Reopen with a reason. | Status becomes In progress and the reopen is counted in quality metrics. |
| UC-25.2-08 | V | The user moves a parent to Done while sub items are open. | The action is blocked: "Close or cancel sub items first". An authorised user may override with a reason. |
| UC-25.2-09 | E | An agent run fails while the item is In progress. | The item shows the failure. The user can Retry or Assign to agent/person. |

#### UC-25.3 Manage sub items

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-25.3-01 | M | The user clicks Add sub item and enters a title. | The sub item is created in the parent's project and listed. |
| UC-25.3-02 | M | The user toggles a sub item done. | It is marked Done and the parent's progress bar updates. |
| UC-25.3-03 | A | The user opens a sub item. | It opens in the same drawer layout, with the parent link. |
| UC-25.3-04 | B | All sub items are done. | The parent shows 100% and Submit for review is suggested. |
| UC-25.3-05 | V | The user attempts to move a sub item to another project. | This is not allowed. |

#### UC-25.4 Activity

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-25.4-01 | M | The user opens the Activity tab. | The chronological history shows the actor (person or agent) and the change. |
| UC-25.4-02 | A | The user adds a comment. | The comment appears in Activity, and @mentions notify the mentioned people. |

### S-27 Requests — list and request types

**Entry.** Requests and Request types are separate navigation entries, `/requests` and `/request-types` (D246).

#### UC-27.1 Find requests

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-27.1-01 | M | The user opens Requests. | Requests the user may see are listed with request, project, type, requester, submitted and status. |
| UC-27.1-02 | M | The user filters by title or key, project, requester (any, a person, or External contact), type, status and period. | The list filters; Clear resets it. |
| UC-27.1-03 | M | The user clicks a request. | The request detail (S-29) opens. |
| UC-27.1-04 | N | No request matches. | "No requests match these filters." is shown. |
| UC-27.1-05 | P | The user may not read requests in a request's project, did not raise it, is not an audience of its current step, and took no action on any of its steps. | The request is not listed. A person who acted on or returned one of its steps keeps it in their list, read-only, after it moves on (D166, D203, D330). |

#### UC-27.2 Manage request types

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-27.2-01 | M | An admin opens Request types. | One row per type, its published version or its draft before it is first published, with default project, category, intake channels, decomposition, SLA, status and open count. Filters: name or code, project, category, intake channel, decomposition and status, with Clear (D246, D302). |
| UC-27.2-02 | M | The admin clicks New request type, enters name and category, picks decomposition, accepts the suggested type code and clicks Create and configure steps. | A Draft version is created and the request type detail (S-30) opens. |
| UC-27.2-03 | V | The type code duplicates an existing one. | Creation is rejected. |
| UC-27.2-04 | M | The admin clicks Open on a type. | The type detail opens. |
| UC-27.2-05 | P | A Member opens Request types. | The screen is read-only or hidden. |

### S-28 New Request (modal)

#### UC-28.1 Submit with the template form

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-28.1-01 | M | The user picks a project and a request type (and Template form, when agentic entry is offered). The type's attributes asked on the request form appear (e.g. amount, expense date, category). The user fills them, adds attachments and clicks Submit request. | A request is created at the first transition step, the first step's audiences are notified, and the request detail opens. |
| UC-28.1-02 | A | The user picks another request type. | The attribute fields change to that type's fields (e.g. item, quantity, budget line; or from/to and leave type). |
| UC-28.1-03 | V | A required attribute is missing or has the wrong format. | A field message is shown and the request is not submitted. |
| UC-28.1-04 | V | An attachment has an unsupported type or exceeds the size limit. | The attachment is rejected with a message. |
| UC-28.1-05 | B | The type allows only the Agentic interactive entry mode. | While agentic entry is offered, the Template form option is disabled. While the "Agentic interactive request entry" flag is off, the type is raised through the form (D310). |
| UC-28.1-06 | P | The user is not allowed to submit this type. | The type is not offered. |

#### UC-28.2 Submit with Agentic interactive

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-28.2-01 | M | The user writes "Reimburse my taxi fares from 3 Oct, AED 186" and sends. | The triage agent proposes the type and values ("This looks like an Expense Claim… Shall I submit it to FIN?"). |
| UC-28.2-02 | M | The user confirms. | The request is created with the extracted attributes, and the history shows "Classified as Expense Claim" and "Submitted via Console · agentic". |
| UC-28.2-03 | A | The user corrects a value in conversation ("it was AED 168"). | The agent updates its proposal before submitting. |
| UC-28.2-04 | A | The agent is unsure of the type. | It asks the user to choose from the matching types. |
| UC-28.2-05 | V | Required information is missing. | The agent asks for it and does not submit until it is complete. |
| UC-28.2-06 | E | The classification route fails or returns invalid output. | The typesafe route retries, then falls back. If it still fails, or does not answer within 30 seconds, the modal switches to the Template form with whatever was understood so far, and the form shows why as a status line (D244). |
| UC-28.2-07 | P | The feature flag "Agentic interactive request entry" is off, as it is seeded (D310). | No entry mode is offered and every type is raised through the Template form. |
| UC-28.2-08 | A | The user attaches a receipt image. | The agent reads the receipt and pre-fills the amount and date for confirmation. |

### S-29 Request detail (and sub request)

#### UC-29.1 Follow a request

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-29.1-01 | M | The user opens a request. | Header (title, key, type, project and actions; the status is shown in the request list, D311) and main info: step tracker, description, key details (project, type, requester or external contact, submitted, channel and mode, current step, SLA due, parent), the attributes asked on the request form, and attachments. Tabs: History & audit, Sub requests, Work items. |
| UC-29.1-02 | M | The user opens the History & audit tab. | Events are listed latest first, each with its date and time, who and what, e.g. Request submitted, Took this step, Approve: <note>, Returned: <note>. An action that supplied a step's attributes offers "Attributes · n", which opens them (D314, D315, D318). |
| UC-29.1-03 | M | The user opens a sub request. | It opens with the same layout and breadcrumbs back to the parent. |
| UC-29.1-04 | M | The user opens the Work items tab and clicks an item. | The work item drawer opens. New work item raises one for the request, in the request's project (D312). |
| UC-29.1-05 | M | The user previews an attachment. | The preview opens. Selected attachments can be downloaded. |
| UC-29.1-06 | B | The SLA is close to its deadline. | The SLA value turns to a warning state, and the request appears in "SLA at risk". |
| UC-29.1-07 | B | The request is from an external contact (widget or WhatsApp). | "External contact" shows instead of a person, with the channel. |

#### UC-29.2 Act on a request

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-29.2-01 | M | A "Can act" audience of the current step clicks Take this step and, in the action window, uses a step action (e.g. Approve) with an optional note and attachments. | The request reads In progress while they hold the step, and other audiences are told who has taken it. The routing rule moves the request to the next step, whose audiences are notified. The tracker and history update (D147, D218, D219). |
| UC-29.2-02 | M | The user chooses Return in the action window with a note. | The request returns to the first step with status Submitted, the history reads "Returned: <note>", and the requester is emailed the update (D218, D247). |
| UC-29.2-03 | M | The user clicks Assign to agent in the action window. | An agent picker opens and the agent works the current step as a run; the history says whether it started. |
| UC-29.2-04 | A | A condition rule applies (`amount_aed >= 5000`), or an action rule guarded by one (`Approve if amount_aed >= 5000`, D262). | The request routes to "Finance + Work Lead" instead of "Finance approval". |
| UC-29.2-05 | A | A step has sequential audiences. | Each audience acts in order before the request moves on. |
| UC-29.2-06 | P | A "Notify only" or "View only" audience opens the request. | It can read the request but has no step actions. |
| UC-29.2-07 | P | The requester tries to approve their own request. | The approve action is not offered, with "You cannot approve your own request.", unless the step names the requester, as a person, among its "Can act" audiences (D217). An agent acting for the requester waits for a bound approval decided by somebody else (D141). |
| UC-29.2-08 | A | The request reaches a terminal step (Closed). | Actions are hidden and the status shows closed. Open work items stay linked. |
| UC-29.2-09 | E | No routing rule matches the current data. | The request stays in the step, flagged "No matching route", and the type owner is notified. |
| UC-29.2-10 | A | Decomposition is Agent or Hybrid. | The agent proposes sub requests and work items, which appear in the tabs. |

### S-30 Request type detail

#### UC-30.1 Configure general settings

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-30.1-01 | M | The admin sets category, decomposition, SLA, default project, "Embed on a website" and entry modes, then clicks Save draft. | The draft is saved. The published version is unchanged. An SLA is a count and an interval — minutes, hours, days or business days — on the type and on each step. |
| UC-30.1-02 | V | No entry mode is selected. | "Select at least one entry mode" is shown. |
| UC-30.1-03 | A | The version lists an intake channel other than the widget, such as WhatsApp. The designer does not show those channels. | Save draft keeps the channels the version has. Requests arriving on that channel's request intake binding can use this type (D303, D306). |
| UC-30.1-04 | A | A published type has "Embed on a website" on (the Widget intake channel, D306), and the admin copies its embed code onto an external site. | The site renders the type's own fields, and a submission raises a request from an external contact keyed by the email given. A draft offers no snippet. |

#### UC-30.2 Design transition steps

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-30.2-01 | M | The admin clicks Add step and sets the step name and step SLA, then moves it with Move up or Move down. | The step is added at the end of the ordered list and moves within it; the first step is where a new request starts (D146). |
| UC-30.2-02 | M | The admin clicks Add audience and picks the requester, a person or an agent with Can act, Notify only or View only. | The audience is listed on the step. A role or group audience is added through `request_type_audience_create`, by id, code or English name (D235). |
| UC-30.2-03 | M | The admin clicks Add rule and sets When (a condition, an action, or an action guarded by a condition) and Go to step. | The rule is listed under "Routing rules to next steps", in the order rules are tried, and can be edited in place without losing its place (D262, D309). |
| UC-30.2-04 | M | The admin marks a step Terminal. | Its audiences and rules are removed and it shows "Terminal step — no audience." |
| UC-30.2-05 | V | A non-terminal step has no outgoing transitions. | Publishing is blocked with "Step … has no outgoing transitions". |
| UC-30.2-06 | V | A step is unreachable from the first step. | Publishing is blocked with the step named. |
| UC-30.2-07 | V | A non-terminal step has no "Can act" audience. | Publishing is blocked. |
| UC-30.2-08 | V | A condition references an unknown attribute. | The rule is highlighted as invalid. |
| UC-30.2-09 | A | The admin edits or deletes a step that rules point to. | The admin is warned and the affected rules are listed. |
| UC-30.2-10 | B | There is a loop (Return → Submitted). | Allowed, since it is an explicit rule. |

#### UC-30.3 Define attributes

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-30.3-01 | M | The admin adds or edits an attribute in the popup form: English and Arabic labels, a type (Text, Long text, Number, Money, Date, Date and time, List with bilingual choices, or Checkbox), Required or Optional, and where it is asked (the request form or one step), and drags it into order. | It appears, in that order and with its type's control, on the request form or in that step's action window, and in the agentic extraction. One rule checks its values on the form, on the server, in the widget and at the step (D304, D305, D316). |
| UC-30.3-02 | V | The attribute key is a duplicate. | Rejected. |
| UC-30.3-03 | B | An attribute used by open requests is removed. | It is hidden for new requests; existing values are kept. |

#### UC-30.4 Publish

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-30.4-01 | M | The admin clicks Publish on a valid draft. | A new version (e.g. v6) becomes active. New requests use it; requests in progress keep their version's routing, and answer to the audiences of the same-named step in the new version, or their own step's where it has none (D217). |
| UC-30.4-02 | P | A user without publish permission opens the type. | Publish is hidden; Save draft is still available. |
| ~~UC-30.4-03~~ | A | Retired by D371: the change came from a Setup Director change set. | The Setup Director is removed; no change set publishes a request type. |

### S-31 Scheduled Work Items

#### UC-31.1 Manage schedules

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-31.1-01 | M | The user opens the list. | Each scheduled item is shown with project, assignee (agent, human or group), schedule, last run (Created, Failed, Skipped), next run and status. |
| UC-31.1-02 | M | The user filters the audience: All, Agents or Humans. | The list filters. |
| UC-31.1-03 | M | The user clicks Run now. | An item is created immediately and Last run updates. |
| UC-31.1-04 | M | The user clicks Edit. | The schedule modal opens prefilled. |
| UC-31.1-05 | M | An admin clicks Pause all and confirms. | All schedules show Paused and nothing fires until they are resumed. |
| UC-31.1-06 | A | The user pauses or resumes one schedule. | The schedule's status and next run update. |

#### UC-31.2 Create a schedule (New Scheduled Work Item modal)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-31.2-01 | M | The user enters title, project and type (Task), audience Agent with an agent, repeats Monthly, start date, time and time zone, and instructions, then clicks Create schedule. | The schedule is created and the next run is shown. |
| UC-31.2-02 | A | The type is a request type (e.g. Purchase Request). | Each firing creates a request instead of a work item. |
| UC-31.2-03 | A | Repeats is On event. | An event must be chosen; the item fires when the event occurs. |
| UC-31.2-04 | A | The audience is Group. | The created item is assigned to the group queue. |
| UC-31.2-05 | A | "Skip UAE public holidays and weekends" is on and the date falls on a holiday. | That firing is recorded as Skipped. |
| UC-31.2-06 | V | Instructions are empty for an agent audience. | Create is blocked: agents need instructions. |
| UC-31.2-07 | V | The start date is in the past for Once. | Rejected. |
| UC-31.2-08 | E | The assigned agent is paused or in error when the schedule fires. | The item is created and stays unstarted. Last run shows a warning and the owner is notified. |
| UC-31.2-09 | E | The project is Paused or Archived. | The firing is Skipped with the reason. |

### S-32 Artifacts and S-33 Files

#### UC-32.1 Browse artifacts

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-32.1-01 | M | The user opens Artifacts. | Artifacts are grouped by project, in Cards or List view. Each shows name, project, produced by, linked to, status and size. |
| UC-32.1-02 | M | The user clicks View. | The preview modal opens with the document preview and metadata, with Download, Activate or Deactivate, and Delete. |
| UC-32.1-03 | M | The user clicks the run link on an artifact. | The run viewer opens. |
| UC-32.1-04 | A | The user deactivates an artifact. | Its status becomes Inactive and agents no longer use it as context. |
| UC-32.1-05 | M | The user deletes an artifact and confirms ("Deleting removes it from the project. Audit records are kept."). | It is removed from the project; the audit record is kept. |
| UC-32.1-06 | B | The format cannot be previewed. | A file-type icon is shown with Download. A Word, Excel or PowerPoint file is previewed as its text with its tables (D237). |
| UC-32.1-07 | P | The user is not in the artifact's project. | It is not listed. |

#### UC-33.1 Upload and share files

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-33.1-01 | M | The user clicks Upload, picks a project and a file with scope "Only me", and clicks Upload. | The file is listed. Only the user, and agents acting for the user, can read it. |
| UC-33.1-02 | A | The scope is "Selected" and the user picks people and agents. | Only those people and agents can read it. The list shows "Selected: …". |
| UC-33.1-03 | A | The scope is "All project members & agents". | Everyone in the project can read it. |
| UC-33.1-04 | V | No file is chosen, or the file is too large or of a blocked type. | Upload is disabled or rejected. |
| UC-33.1-05 | E | A virus scan flags the file. | The file is quarantined, not listed as Active, and the user is told. |
| UC-33.1-06 | P | An agent outside the file's scope tries to read it. | Access is denied and the denial is audited. |
| UC-33.1-07 | M | The person who uploaded the file changes its scope later, from the file's preview. | Access updates immediately. Anybody else sees the scope read-only, and the server refuses them (D183, D188, D323). |
| UC-33.1-08 | M | The user switches between Cards and List, or uses View, Deactivate or Delete. | Behaves as for artifacts. |

---

## 6. Organisation

### S-40 Org chart

#### UC-40.1 Explore the organisation

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-40.1-01 | M | The user opens the Chart view. | People and agents are shown in one hierarchy, with agents in blue. |
| UC-40.1-02 | M | The user switches to List. | Columns: name, kind, role or version, org unit, reports to, direct reports. |
| UC-40.1-03 | M | The user searches by name or filters All, People or Agents. | The view filters. |
| UC-40.1-04 | M | The user selects a person. | The details panel shows email, org unit, reports to and direct reports. |
| UC-40.1-05 | M | The user selects an agent. | The details panel shows model, runs in the last 30 days, status, and Open agent and Agent run list. |
| UC-40.1-06 | N | The search finds no match. | "None" is shown. |

#### UC-40.2 Change a reporting line

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-40.2-01 | M | An admin clicks Change reporting line and picks a new manager. | The chart redraws and the change is audited. |
| UC-40.2-02 | V | The change would create a cycle. | Blocked with "This would create a reporting loop". |
| UC-40.2-03 | P | A Member selects someone. | Change reporting line is hidden. |

### S-41 People & roles

#### UC-41.1 Manage people

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-41.1-01 | M | An admin clicks Invite people, enters email addresses and a role, and clicks Send invites. | People are listed as Invited and are emailed a link to accept, valid once and for 7 days; the result says when no email was sent and why. Accepting asks the person to choose a password, makes them Active and signs them in (D248, D387). |
| UC-41.1-02 | V | An email address is invalid or already exists. | That address is flagged and the others are still invited. |
| UC-41.1-03 | M | The admin opens a person and changes their org unit or role. | The change applies at their next request and is audited. |
| UC-41.1-04 | M | The admin suspends a person. | Their sessions are revoked and their open assigned work is flagged for reassignment. |
| UC-41.1-05 | E | The admin tries to suspend the last Platform Owner. | Blocked. |

#### UC-41.2 Manage roles

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-41.2-01 | M | The admin opens the Roles tab. | Roles are listed with member count and scope. |
| UC-41.2-02 | M | The admin clicks Edit permissions, allows or denies permissions, and saves. | The permissions apply to all members. Explicit deny wins over allow. |
| UC-41.2-03 | A | The admin scopes a role assignment to an org unit or project. | The member's permissions apply only within that scope. |
| UC-41.2-04 | P | A non-admin tries to edit roles. | Not allowed. |
| UC-41.2-05 | B | The admin edits a system role (e.g. Platform Owner). | Core permissions are locked and cannot be removed. |

### S-42 Org units

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-42.1-01 | M | The user views the list. | Each unit shows lead, people, agents and projects. |
| UC-42.1-02 | M | An admin clicks New org unit, enters name, parent and lead, accepts the suggested code and creates it. | The unit appears in the list and the org chart. |
| UC-42.1-03 | V | The code is a duplicate or the parent creates a cycle. | Rejected. |
| UC-42.1-04 | E | The admin deletes a unit that still has people, agents or projects. | Blocked: "Move members and projects first". |
| ~~UC-42.1-05~~ | A | Retired by D371: the unit was created by the Setup Director. | The Setup Director is removed; no unit is created by a change set. |

---

## 7. AI Capabilities

### S-50 Agents — list

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-50.1-01 | M | The user opens Agents. | Agents are listed with avatar, name, org unit, version, model, execution profile, status (Idle, Running, Waiting, Paused, Error), runs and estimated cost. |
| UC-50.1-02 | M | The user filters by status or searches. | The list filters. |
| UC-50.1-03 | M | The user clicks an agent. | The agent detail (S-51) opens. |
| UC-50.2-01 | M | A designer clicks New Agent, enters name, org unit, execution profile, agent trust and model route (only chat routes, Standard or Typesafe, are offered, D337), and clicks Create agent. | A draft agent is created and its detail opens on Instructions. |
| UC-50.2-02 | V | The name is missing or the code is a duplicate. | Rejected. |
| UC-50.2-03 | P | A user without agent.create permission opens Agents. | New Agent is hidden. |
| UC-50.2-04 | V | Trust "System" is selected. | Not offered: System trust is not assignable to any agent. |
| UC-50.2-05 | B | An agent is in Error. | A red status is shown with the failure reason on hover, and the agent is counted in "Agents in error". |

### S-51 Agent detail

#### UC-51.1 Review the agent (Overview)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-51.1-01 | M | The user opens Overview. | The Configuration card shows execution profile, primary model, fallback route, reports to, agent trust, memory and run budget (soft/hard). Last 30 days shows runs, success rate, estimated cost and eval score. |
| UC-51.1-02 | M | The user clicks View runs. | The Agent run list tab opens. |
| UC-51.1-03 | M | A designer clicks Edit on Configuration, changes the primary model or fallback route, and saves. | Draft changes are saved and apply after the next publish. |
| UC-51.1-04 | M | An admin changes agent trust from Standard to Restricted. | From the next run, the agent may call only T0 tools autonomously and sees only its own items. The change is audited. |
| UC-51.1-05 | V | The run budget soft limit is greater than the hard limit. | Rejected. |
| UC-51.1-06 | A | The admin turns agent memory off. | Memory tools are removed from the agent's runs. Existing memory is kept. |

#### UC-51.2 Edit instructions, skills and tools

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-51.2-01 | M | A designer edits System instructions and saves. | A draft revision is saved. |
| UC-51.2-02 | M | A designer ticks and unticks skills, or connectors and their tools on Connector tools, in the grant popup and saves. | The additions and removals are saved as one change to the draft, and apply on the next version. A connector tool that reads (T0) is granted at Auto and any other at Approval (D228, D238, D264). |
| UC-51.2-03 | M | A designer sets a connector tool to Auto, Approval or Denied. | The mode is saved. It can never be looser than the connector's tier for that tool. |
| UC-51.2-04 | V | Auto is chosen for a T2 tool. | Not allowed; the minimum is Approval. |
| UC-51.2-05 | B | A skill declares a tool from a connector the agent's grant does not reach. | The skill is flagged, and Connector tools names the connector above the list. Connectors keep no list of allowed agents (D227, D238). |

#### UC-51.3 Test and publish

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-51.3-01 | M | A designer clicks Test in playground, enters a sample input ("Review claim EXP-4471") and clicks Run test. **D382: the console has no Test in playground; the Assistant's `agent_test_run_create` tool runs the test.** | The test runs in the sandbox and shows the result, duration ("Run completed in 9.2s") and estimated cost. No real side effects occur. |
| UC-51.3-02 | M | A publisher clicks Publish new version, writes release notes and publishes (e.g. v8). | The new version becomes active for new runs; running runs keep their version. The Versions tab updates. |
| UC-51.3-03 | V | Release notes are empty. | Publish is blocked. |
| UC-51.3-04 | E | The evaluation gate fails. | Publish is blocked with the failing scores. |
| UC-51.3-05 | P | The designer is not a publisher. | Publish is hidden, or requires a publisher's approval. |
| UC-51.3-06 | E | The playground test fails because a model or connector is unavailable. | The error is shown with the failing step. |

#### UC-51.4 Runs and versions

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-51.4-01 | M | The user opens Agent run list and filters by status, a search over run key and title, and a Started period. | Runs are listed newest first, 50 a page with the total, with run, status, started and duration (D300, D349). |
| UC-51.4-02 | N | No runs match the filters. | "No runs match these filters." is shown. |
| UC-51.4-03 | M | The user clicks a run. | The run viewer (S-52) opens. |
| UC-51.4-04 | M | A publisher clicks Roll back on an older version and confirms. | That version becomes Active for new runs, and the rollback is audited. |
| UC-51.4-05 | B | The user tries to roll back to the active version. | Not offered. |

### S-52 Run viewer

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-52.1-01 | M | The user opens a run. | KPIs: duration (+ waiting), tokens with cache hit %, tool calls (with how many approvals are pending; choosing it shows only the tool steps). Also the full-width timeline (a step per model response with text, per tool call, and the closing handoff) and the context composition when the run has one. No estimated cost is shown (D300). |
| UC-52.1-02 | M | The user selects a timeline step. | The step opens in place: a tool step shows its arguments and its result, any other step its text, with the hooks applied (D300). |
| UC-52.1-03 | M | The user selects a step that is waiting for approval. | The step shows "Open in Inbox", which opens the approval. |
| UC-52.1-04 | M | The run is live. | The timeline and KPIs update as steps complete. |
| UC-52.1-05 | M | The person who started the run, the owner of its room, or an administrator clicks Cancel run and confirms. Anybody else is refused (D295). | The run stops after its current step, status becomes Cancelled, and pending approvals are withdrawn. |
| UC-52.1-06 | M | An operator clicks Replay, or replays from a step with a reason. | A new linked run starts from that point, and the replay is audited. |
| UC-52.1-07 | M | The user clicks Open trace. | The Phoenix trace opens, if the user is authorised. |
| UC-52.1-08 | P | A Member without trace permission views the run. | Open trace and raw arguments are hidden. |
| UC-52.1-09 | B | The run exhausted an effort limit (steps or tool calls) it was given; runs are given none since D389. There is no money ceiling on a run (D73). | Status shows BudgetExceeded, never Succeeded, and the run says which limit stopped it (D93). |
| UC-52.1-10 | E | The agent service restarted during the run. | The timeline shows the run resuming with no duplicate steps. |
| UC-52.1-11 | B | Cancel is used on a finished run. | Not offered. Delete run is offered instead, to whoever may cancel the run, and removes it with its steps, approvals, questions and the Inbox items they raised (D300). |

### S-53 Skills

#### UC-53.1 Browse skills

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-53.1-01 | M | The user switches between the tabs Installed and My Skills. | Each tab shows the right skills with name, source, version, tags and agents using them. |
| UC-53.1-02 | M | The user opens a skill. | The skill detail shows every file of its package (a text file as text, an image as an image, anything else to download), Security scan, Where used, Download as .zip and Publish (D333). |

#### UC-53.2 Import a skill package

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-53.2-01 | M | An admin drops a .zip and clicks Validate package. | The checks list shows the files, "SKILL.md frontmatter valid" and "No embedded secrets". |
| UC-53.2-02 | M | The admin chooses agents to enable it for and clicks Import skill. | The skill is installed and enabled for those agents. |
| UC-53.2-03 | A | The admin imports from a Git URL. | The package is fetched and validated in the same way. |
| UC-53.2-04 | B | A script makes network calls. | The warning "Script makes network calls — will run in sandbox only" is shown and import is still allowed. |
| UC-53.2-05 | V | `SKILL.md` is missing or its front-matter is invalid. | Import is blocked with the reason. |
| UC-53.2-06 | E | Embedded secrets or prompt-injection patterns are found. | Import is blocked, or requires approval, per policy. |
| UC-53.2-07 | E | The Git URL is unreachable. | An error is shown. |
| UC-53.2-08 | A | The admin clicks Back. | Returns to the upload step. |

#### UC-53.3 Author and publish

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-53.3-01 | M | A designer clicks New skill, enters title and description, accepts the suggested skill name and creates it. | A draft skill opens with `SKILL.md`. |
| UC-53.3-03 | M | The designer clicks Publish. | A new version is created and agents pinned to an older version are listed in Where used. |
| UC-53.3-04 | V | The description is empty. | Rejected: agents need it to decide when to load the skill. |

### S-54 Connectors

#### UC-54.1 Add a connector

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-54.1-01 | M | An admin opens Connectors. | The connected connectors are listed, with Connector to add one. There is no catalogue to browse. |
| UC-54.1-02 | M | The admin enters credentials and clicks Test connection. | "Handshake OK · N tools listed" is shown and the tools appear with default tiers. A saved REST API is tested by reaching its server URL ("The API answered (HTTP 200) · N tools", D268). |
| UC-54.1-03 | M | The admin adjusts tiers per tool, sets the default tier for new tools and clicks Add connector. | The connector appears in the list, added Disabled; turning it on checks the server first. The connector keeps no list of allowed agents: each agent's own grant decides which of its tools the agent is offered (D227). |
| UC-54.1-04 | A | The admin clicks Connector, chooses the type MCP server, and enters a server URL and authentication (None, API key, Bearer, Basic, OAuth 2 client credentials or OAuth 2.1 sign-in). | Same flow as above. A secret is never shown back (D296). |
| UC-54.1-05 | E | The handshake fails (bad URL, auth or protocol). | The error is shown. Adding is allowed only as Disabled. |
| UC-54.1-06 | V | The server URL is empty or invalid. | Rejected. |
| UC-54.1-07 | B | A tool is annotated destructive. | Its default tier is T2. |
| UC-54.1-08 | B | A tool is annotated read-only. | Its default tier is T0. |
| UC-54.1-09 | M | The admin clicks Connector, chooses the type REST API (OpenAPI), uploads an OpenAPI or Swagger document, names the connector and chooses its authorisation (D296). | Every operation in the document is registered as a tool with its own parameters; a GET or HEAD starts at T0 and everything else at the connector's default tier. Operations the import skipped are named. |

#### UC-54.2 Maintain a connector

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-54.2-01 | M | The admin clicks a connector title in the list. | The drawer opens for editing. |
| UC-54.2-02 | M | The admin turns Connector enabled off. | Agents can no longer call its tools. Running agents get "connector disabled". |
| UC-54.2-03 | M | The admin raises a tool from T1 to T2. | New calls of that tool require approval. |
| UC-54.2-04 | M | An agent is to lose a connector's tools. | The designer removes them from the agent's Connector tools grant; the connector's drawer keeps no list of allowed agents (D227). |
| UC-54.2-05 | M | The admin clicks Remove and confirms. | The connector is removed and agents depending on it are listed in a warning beforehand. |
| UC-54.2-06 | E | The server's tool list changed since registration. | The changed tools are flagged and unavailable until the admin reviews them in the drawer. |
| UC-54.2-07 | E | The connector goes down at run time. | The connector's status shows Error, affected agents show in "Agents in error", and agents get a degraded-mode result. |
| UC-54.2-08 | P | A non-admin opens Connectors. | The page is read-only or hidden. |

### S-55 Memory

#### UC-55.1 Find and read memory

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-55.1-01 | M | The user opens Memory. | Cards show Total memories, Pending review, Active agents and Needs attention. The explorer tree and detail panel are shown. |
| UC-55.1-02 | M | The user searches across memories, policies, agents and keywords. | Results filter the tree. |
| UC-55.1-03 | M | The user clicks a scope chip (Organisation, Business unit, Agent, Session). | The tree filters to that scope. |
| UC-55.1-04 | M | The user opens Filters and sets owner, status, last reviewed and source. | Advanced filtering is applied. |
| UC-55.1-05 | M | The user selects a memory in the tree. | The detail shows title, path, status, version and History, entries with sources, and memory details (scope, owner, last reviewed, access, write policy). |
| UC-55.1-06 | A | The user expands or collapses tree nodes. | The tree state is kept during the session. Status dots mark pending and needs-attention items. |
| UC-55.1-07 | P | The user lacks access to a scope. | That scope does not appear in the tree. |

#### UC-55.2 Review agent-proposed memory

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-55.2-01 | M | A reviewer opens a pending memory ("Proposed by the agent. Approve before it is used in runs.") and clicks Approve. | It becomes Active, a new version is created, and it is used in later runs. |
| UC-55.2-02 | M | The reviewer clicks Reject. | It is not used, and the proposing agent is told. |
| UC-55.2-03 | M | A memory is overdue for review and the reviewer clicks Review now. | The review flow opens. After the review, "Last reviewed" updates and the warning clears. |
| UC-55.2-04 | P | The proposing agent's owner is the only reviewer and the policy requires someone else. | Approve is not offered to them. |

#### UC-55.3 Edit, compare and restore

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-55.3-01 | M | The user clicks Edit memory, changes the content, adds a change note and saves as a version. | A new version is created and audited. |
| UC-55.3-02 | V | The change note is empty. | Save is blocked. |
| UC-55.3-03 | V | The content contains PII and the PII filter is on. | The PII is masked or the save is blocked, per policy. |
| UC-55.3-04 | M | The user opens Version history and clicks Compare on version 12. | A side-by-side diff against the current version is shown. |
| UC-55.3-05 | M | The user clicks Restore and confirms ("Creates version 15 with this content. The change is audited."). | A new version with the old content is created. |
| UC-55.3-06 | M | The user clicks New memory and enters title, scope and content. | The memory is created. If the write policy requires review, it is Pending review. |
| UC-55.3-07 | E | Two users edit the same memory. | The second save is told to compare with the latest version (COM-10). |

### S-56 Knowledge — collections

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-56.1-01 | M | The user opens Knowledge. | KPIs show collections, documents, chunks and entities. Each collection shows project, index type, chunking, embedding route and status. |
| UC-56.1-02 | M | The user clicks a collection or Configure. | The collection page (S-57) opens. |
| UC-56.1-03 | M | The user clicks Test retrieval on a row. | The retrieval test opens, scoped to that collection. |
| UC-56.1-04 | M | The user clicks Test knowledge retrieval in the header. | The test opens with All collections. |
| UC-56.2-01 | M | An admin clicks New collection, enters name, project, index type, chunking technique, embedding route (only routes whose kind is Embedding are offered, D257) and visibility, accepts the collection ID and clicks Create and configure. | The collection is created empty and its page opens on Document sources. |
| UC-56.2-02 | V | The collection ID is a duplicate, or no embedding route is chosen. | Rejected. |
| UC-56.2-03 | B | A collection is ingesting. | Status shows progress (e.g. "Ingesting 62%"), updating live. |
| UC-56.2-04 | E | Ingestion failed. | Status shows Error with the reason and a re-index action. |

### S-57 Knowledge — collection page

#### UC-57.1 Manage document sources

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-57.1-01 | M | An admin clicks Add source, chooses Upload, drops PDF/DOCX/XLSX/HTML/MD files and clicks Add and index. | The source is listed as Indexing, then Indexed, with a document count. |
| UC-57.1-02 | A | The source type is URL crawl with start URL, max depth and include pattern. | Crawling and indexing run. |
| UC-57.1-03 | A | The source type is MCP resource with connector and resource path. | The resource is read through the connector and indexed. |
| UC-57.1-04 | M | The admin clicks Re-index on a source. | The source is re-processed. Unchanged documents are not duplicated. |
| UC-57.1-05 | M | The admin clicks Remove on a source and confirms. | Its documents, chunks and graph entities are removed from every store. |
| UC-57.1-06 | M | The admin clicks Re-index all. | The whole collection is re-processed and progress is shown. |
| UC-57.1-07 | V | An unsupported file type is dropped, or the URL is invalid. | Rejected. |
| UC-57.1-08 | E | The crawl is blocked, or the connector resource is unreachable. | The source status is Error with the reason. |
| UC-57.1-09 | B | A scanned PDF is uploaded and OCR is off. | A warning shows that text could not be extracted. |

#### UC-57.2 Configure the collection

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-57.2-01 | M | The admin changes chunk size, overlap or pre-processing (OCR, Arabic normalisation, strip headers/footers, PII masking) and clicks Save changes. | Saved. New and re-indexed documents use the new settings. |
| UC-57.2-02 | M | The admin changes the embedding route. | The warning "Changing the embedding route re-indexes the whole collection" is shown. After confirmation a full re-index starts. |
| UC-57.2-03 | M | The admin changes top-k, minimum score, sync schedule, visibility or maximum size. | Saved and applied to retrieval and the next sync. |
| UC-57.2-04 | V | Overlap is greater than or equal to the chunk size, or a value is out of range. | Rejected. |
| UC-57.2-05 | B | The collection reaches its maximum size. | New documents are rejected with a message. |
| UC-57.2-06 | P | A non-admin opens Configuration. | Read-only. |

### S-58 Test knowledge retrieval (popup)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-58.1-01 | M | The user types "What is the hotel per-diem in Riyadh?", chooses Hybrid and runs it. | Passages with scores and re-ranked markers are shown, plus graph facts and the retrieval time. |
| UC-58.1-02 | A | The user switches to Vector or Graph. | Results show only that mode's sources. |
| UC-58.1-03 | A | The user changes the collection (or All collections). | Results re-run on the new scope. |
| UC-58.1-04 | N | Nothing scores above the minimum score. | "No passages above the minimum score" is shown. |
| UC-58.1-05 | P | Some collections are not visible to the user. | Those collections are excluded from All collections. |
| UC-58.1-06 | E | The embedding route is down. | An error is shown; graph-only mode may still work. |

### S-59 Models & routes — providers

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-59.1-01 | M | The user opens the Providers tab and filters All, Active, Not active or Custom. | Each provider shows its kind, number of connections, models allowed, or "Not connected". |
| UC-59.1-02 | M | An admin opens a provider and clicks Add connection, entering name, region, endpoint, authentication, secret and allowed models, with Connection active on. | The connection is listed. Routes can use only its allowed models. |
| UC-59.1-03 | M | The admin clicks Test on a connection. | A short call is sent to each allowed model and the per-model result is shown. The result and its time are stored on the saved connection, whose health reads Not checked until tested, then Healthy or Failed; it never follows the switch (D196). |
| UC-59.1-04 | M | The admin turns Provider active off. | Every connection and route step using the provider is skipped. Routes fall back. |
| UC-59.1-05 | M | The admin clicks Add custom provider, picks an engine (e.g. vLLM), enters display name and base URL, clicks Discover models, picks models and adds it. | The custom provider appears with its allowed models. |
| UC-59.1-06 | E | Model discovery fails. | An error is shown. The admin may enter model names manually. |
| UC-59.1-07 | V | No models are allowed on a connection. | Warned: no route can use this connection. |
| UC-59.1-08 | E | A secret is wrong. | The test shows an authentication failure per model. |
| UC-59.1-09 | P | A non-admin views the page. | Read-only. Secrets are never shown. |
| UC-59.1-10 | B | The admin removes a connection that routes still use. | Blocked, with the routes listed. |

### S-60 Models & routes — routes

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-60.1-01 | M | The user opens the Routes tab. | Each route shows its alias, kind (Standard, Typesafe, Voice, Embedding, Decision), chain, fallback and the agents using it. A Decision route's steps use only Decision models, which no other route may use (D290). |
| UC-60.1-02 | M | An admin clicks New route, sets Use = Standard and builds the chain (primary, then Add fallback with provider, connection and model), accepts the suggested alias and saves. | The route is available to agents. |
| UC-60.1-03 | A | Use = Typesafe with an output schema, confidence threshold and max retries. | Invalid outputs are retried, then routed to the fallback. |
| UC-60.1-04 | A | Use = Voice, mode Pipeline with STT, LLM and TTS voice, languages, barge-in and max call length. | The route is available to voice deployments. |
| UC-60.1-05 | A | Use = Voice, mode Realtime speech-to-speech. | Only models that support realtime audio are offered. |
| UC-60.1-06 | V | The alias is a duplicate, the chain is empty, or the typesafe schema is invalid JSON Schema. | Rejected. |
| UC-60.1-07 | V | The selected model is not allowed on the chosen connection. | Not offered. |
| UC-60.1-08 | M | An admin edits a route used by agents. | Applies to new model calls; running calls finish. The change is audited. |
| UC-60.1-09 | E | The admin deletes a route used by agents or by knowledge collections. | Blocked, with the users listed. |

### S-61 Channels

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-61.1-01 | M | The user opens Channels. | Web widget, WhatsApp and Microsoft Teams are listed with toggle, status (Enabled, Degraded, Disabled), bound to and Configure. The other channels are listed as Coming soon. |
| UC-61.1-02 | M | An admin clicks Configure, enters credentials, sets Bind to (embedded deployment, discussion rooms mirror, or request intake), unknown senders (treat as external contact, or ignore), rate limit and business hours, and saves. | "Changes are hot-reloaded". The channel uses the new settings without a restart. |
| UC-61.1-03 | M | The admin opens Test channel, fills Send to and Message, and clicks Send test message. | The checks show credentials valid, outbound delivered, inbound webhook reachable, and the round-trip time. |
| UC-61.1-04 | M | The admin toggles a channel off. | Inbound messages are no longer processed. Senders get the configured offline behaviour. |
| UC-61.1-05 | E | A test fails (bad credentials, or an unreachable webhook). | The failing check is marked with the reason. |
| UC-61.1-06 | B | The channel is Degraded (e.g. provider latency or partial failures). | The status shows Degraded, and the dashboard and System page reflect it. |
| UC-61.1-07 | A | Business hours = working calendar, and a message arrives out of hours. | The offline message is sent, and the message is queued or turned into a request per the binding. |
| UC-61.1-08 | A | Unknown senders = ignore, and an unknown number writes. | The message is dropped and logged. |
| UC-61.1-09 | B | A sender exceeds the rate limit. | Extra messages are throttled with a polite notice. |
| UC-61.1-10 | P | The user clicks a Coming soon channel. | It cannot be enabled. |

### S-62 Embedded Deployment — list

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-62.1-01 | M | The user opens the list. | Each deployment shows default agent, surfaces, storyline (name, version, mode), status and rating ("No ratings yet" when empty). |
| UC-62.1-02 | M | A designer clicks New deployment, enters English and Arabic names and default agent, and creates it. | A Draft deployment opens on its detail page. |
| UC-62.1-03 | M | The user clicks a deployment. | The deployment detail (S-63) opens. |
| UC-62.1-04 | P | Feature flag "Embedded deployments" is off. | The page shows that the feature is disabled. |

### S-63 Embedded Deployment — detail

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-63.1-01 | M | A designer edits main details (names, default agent, status), surfaces, security and access (allowed origins, visitor identity, handoff queue, the person the agent acts as, rate limit per visitor; D221) and branding (widget title, accent colour, welcome message), then clicks Save changes. | Saved and applied to new conversations. |
| UC-63.1-02 | M | The designer clicks Copy embed code. | The script snippet is copied for the host website. |
| UC-63.1-03 | M | The designer clicks Publish, or sets the status to Enabled and saves (D263). | The widget becomes available on the allowed origins and the bound channels. |
| UC-63.1-04 | V | Status Enabled is set with no allowed origins for the Web widget. | Rejected. |
| UC-63.1-05 | V | The accent colour fails the contrast check. | A warning is shown with a suggested colour. |
| UC-63.1-06 | A | Visitor identity = Signed JWT from host site. | Visitors arrive identified. Without a valid JWT they are treated as anonymous, or refused, per configuration. |
| UC-63.1-07 | M | The user views Last 30 days. | Conversations and rating are shown. |
| UC-63.1-08 | M | The user opens the Storylines tab or the Preview tab. | The storyline editor (S-64) or the widget preview (S-65) is shown. |
| UC-63.1-09 | E | The default agent is paused or in error. | A warning is shown. Visitors are offered the handoff queue. |

### S-64 Storyline editor

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-64.1-01 | M | A designer chooses mode Strict. | The note "In strict mode the agent may only perform the current step" applies, and exact messages are sent verbatim. |
| UC-64.1-02 | A | The mode is Guided. | The agent may answer side questions and then return to the current step. |
| UC-64.1-03 | A | The mode is Guided and the visitor writes something the step does not offer. | The steps act as guidance: the agent answers, and the step's choices are offered again, with Back and Main menu. |
| UC-64.1-04 | M | The designer clicks Add step, picks a step type and configures it. Ask: message, slot, max attempts. Verify: method. Handoff: queue. Tool: tools. Skill: skills. Then sets next step and On error. | The step shows as configured. |
| UC-64.1-05 | M | The designer ticks "Send verbatim (exact)" on a Message step. | That message is sent exactly as written in each language. |
| UC-64.1-06 | M | The designer sets "Agent for this step" to another agent. | The step shows Override, and only that step uses the other agent. |
| UC-64.1-07 | M | The designer clicks Delete step and confirms. | Steps pointing to it are flagged to fix. |
| UC-64.1-08 | M | The designer clicks Simulate, enters test variables and clicks Start simulation. | The conversation is simulated step by step with a mock visitor. Variables and path are shown. |
| UC-64.1-09 | M | The designer clicks Publish. | A new version is created (e.g. Version 4). Conversations in progress keep their version. |
| UC-64.1-10 | V | The storyline has no steps, or a step is "Not configured yet", has no next step, or is unreachable at publish time. | Publish is blocked, listing the problems per step (D279). |
| UC-64.1-11 | V | An Arabic message is missing while Arabic is enabled. | Publish is blocked. |
| UC-64.1-12 | V | A Tool step uses a tool the agent is not allowed. | The step is flagged. |
| UC-64.1-13 | E | Simulation reaches a tool error. | The On error path is followed (e.g. Retry once) and shown. |

### S-65 Widget (visitor experience and preview)

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-65.1-01 | M | A visitor clicks "Need help?" on an allowed website. | The widget opens with its title, welcome message and quick actions. No step progress is drawn (D341). |
| UC-65.1-02 | M | The visitor taps a quick reply (Lost, Stolen or Damaged). | The slot is filled and the next step starts. |
| UC-65.1-03 | M | The Verify step uses OTP. | The visitor receives and enters the OTP, and "Identity verified by OTP" shows. |
| UC-65.1-04 | M | A Confirm step asks "Replace card ending 4821, deliver to …?" and the visitor taps Yes, confirm. | The next step runs. A Create work step creates a request and returns its reference. |
| UC-65.1-05 | A | The visitor taps Change on the confirmation. | The flow returns to the step that collects that value. |
| UC-65.1-06 | A | The visitor types free text instead of using the quick replies. | The agent extracts the value. If unsure, it re-asks within max attempts. |
| UC-65.1-07 | A | In strict mode the visitor asks something off-script. | A fixed redirect is sent and the step is asked again. After more than 2 off-script turns a person is offered, when the deployment has a handoff queue (D340). |
| UC-65.1-08 | M | The visitor taps "Talk to a person", which is offered only when the deployment has a handoff queue. | The conversation moves to a discussion room in the handoff queue's project with its transcript, and the visitor sees that a person will reply. Without a queue the server refuses the handoff (D340). |
| UC-65.1-09 | E | OTP fails or expires. | The visitor may resend within limits. After repeated failures, the conversation is handed off or ended per the step. |
| UC-65.1-10 | E | The widget is loaded on an origin that is not allowed. | The widget does not load and the attempt is logged. |
| UC-65.1-11 | B | The visitor switches the language to Arabic mid-chat. | The widget mirrors to RTL and continues in Arabic. |
| UC-65.1-12 | B | The visitor exceeds the rate limit. | Messages are throttled with a notice. |
| UC-65.1-13 | A | The visitor clicks Minimise. | The widget collapses to the launcher and the conversation is kept. |
| UC-65.1-14 | M | The conversation ends. | A rating is asked for (if enabled), and the outcome (Completed, Handed off, Abandoned, Request created) is recorded. |
| UC-65.1-15 | A | A designer opens the Preview tab. | The same widget is shown on a placeholder host page, with Copy embed code. |

---

## 8. Govern

### S-71 Budgets & estimated costs — list

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-71.1-01 | M | The user opens Budgets. | KPIs show estimated month to date, agents with a budget, over 90% and ending within 90 days. The list shows agent, period, effective dates, status, usage bar, estimated spend, limit and History / Edit. |
| UC-71.1-02 | M | The user filters by status: Active, Scheduled or Expired. | The list filters. |
| UC-71.1-03 | M | An admin clicks New agent budget, sets agent, limit, period (daily, weekly, monthly or quarterly), effective from/to, warn at %, and the action at 100%, then saves. | The budget is listed. Its status is derived from the dates. |
| UC-71.1-04 | A | "Keep forever (no end date)" is on. | Effective to is cleared and the budget shows "no end date". |
| UC-71.1-05 | A | The action at 100% is "switch to a cheaper alias". | A route must be chosen. |
| UC-71.1-06 | V | The limit is ≤ 0, warn at % is outside 1–99, or effective to is before effective from. | Rejected. |
| UC-71.1-07 | V | The new budget overlaps an existing budget for the same agent. | Rejected, with the conflicting budget named. A window that starts on the day another ends does not overlap it (D322). |
| UC-71.1-08 | M | The user clicks Export. | The file contains the estimated values, labelled as estimates. |
| UC-71.1-09 | P | A Member opens Budgets. | Read-only, or hidden. |

### S-72 Budget detail

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-72.1-01 | M | The user opens a budget. | Cards show limit, estimated spend, estimated forecast and the action at 100%. Also shown: the consumption history of every period of the window coloured by usage band, runs by period, the period history and the budget changes, all for this budget's window alone (D322). |
| UC-72.1-02 | M | The user clicks Edit budget and changes the limit. | Saved. "Limit set to …" is added to the budget changes. |
| UC-72.1-03 | M | The user clicks Open agent. | The agent detail opens. |
| UC-72.1-04 | B | Spend crosses the warning percentage. | The owner is notified and the period history shows "Warning sent". |
| UC-72.1-05 | B | Spend reaches 100% with "pause agent". | The agent is paused, the event "Hard limit reached" is logged, and the agent shows Paused. |
| UC-72.1-06 | B | Spend reaches 100% with "notify only". | Notification only; runs continue. |
| UC-72.1-07 | B | A new period starts. | Spend resets for the period, and the previous period moves to history. |
| UC-72.1-08 | N | The budget is newly created. | Charts show "No history yet". |

### S-73 Audit

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-73.1-01 | M | An auditor opens Audit. | Entries are listed with time, actor, action, object and detail, newest first. |
| UC-73.1-02 | M | The auditor filters by actor (All actors, People, Agents), period or action. | The list filters. |
| UC-73.1-03 | M | The auditor clicks Export. | The filtered entries are exported, and the export itself is audited. |
| UC-73.1-04 | B | An entry is a denied action (e.g. "Reveal denied (never returned)"). | It is shown with the Denied outcome. |
| UC-73.1-05 | P | Anyone tries to edit or delete an entry. | Not possible; the log is append-only. |
| UC-73.1-06 | M | The auditor clicks an entry's object. | The object's screen opens, if it still exists. |

### S-74 Logs

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-74.1-01 | M | An admin opens Logs. | Application and run logs are shown with time, level, service and message. |
| UC-74.1-02 | M | The admin filters by level (All levels, info, warn, error), service or run. | The list filters. |
| UC-74.1-03 | A | The admin clicks a run ID. | The run viewer opens. |
| UC-74.1-04 | P | A user without log permission opens Logs. | Hidden. |
| UC-74.1-05 | B | A log line contains PII or secrets. | The values are masked. |

### S-75 Settings

**Tabs.** General, Branding and Email (no Feature flags tab; flags are changed through the `feature_flag` agent tool). Email holds the platform's mail server and its email templates (Request created, Request updated, Request finished, Work item finished, User invitation), a test send and the latest 50 emails (D240, D247).

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-75.1-01 | M | An admin edits General (English and Arabic names, time zone, languages, working calendar, holidays) and clicks Save changes. | Validated against the schema and saved with history. Calendars affect SLAs and schedules. |
| UC-75.2-01 | M | The admin uploads light and dark logos and a favicon. | The new branding shows in the shell and the widget. |
| UC-75.2-02 | V | A logo is below 240×80, or the favicon is not 64×64 PNG. | Rejected with the required size. |
| UC-75.2-03 | M | The admin picks a primary brand colour. | The preview updates (primary button, secondary, links). The colour applies to buttons, links, active navigation and the embedded widget after saving. |
| UC-75.2-04 | V | The colour fails the WCAG 2.2 AA contrast check. | Saving is blocked, with a suggested accessible colour. |
| UC-75.3-01 | M | The admin toggles a feature flag (e.g. "Agentic interactive request entry"). | The dependent UI appears or disappears for all users, and the change is audited. |
| UC-75.3-02 | B | The admin turns off "Embedded deployments" while deployments are live. | A confirmation lists the deployments affected. After confirmation, widgets stop loading. |
| UC-75.3-03 | B | The admin turns off "Graph retrieval (Graphiti)". | Retrieval falls back to vector-only, and the Graph and Hybrid modes are disabled. |
| UC-75.4-01 | P | A non-admin opens Settings. | Read-only or hidden. |

### S-76 Integrations — clients

**Entry.** `/integrations`. The screen has no navigation entry (D226).

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-76.1-01 | M | An admin opens Integrations. | Clients are listed with owner, allowed permissions, agents, keys, MCP on/off, AG-UI on/off and status. |
| UC-76.1-02 | M | The admin clicks New client, enters client name in English and Arabic and owner, picks allowed permissions, accepts the client ID derived from the name and creates it. | The client is created Active with MCP and AG-UI exposure off, and its detail opens. The agents it may reach are chosen on its AG-UI tab. |
| UC-76.1-03 | V | No permission is selected, or the client ID is a duplicate. | Rejected. |

### S-77 Integration client detail

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-77.1-01 | M | The admin clicks Create key on Keys, entering key name and expiry. | The secret is shown once ("Store it in your secrets manager") and afterwards only the prefix is shown. |
| UC-77.1-02 | M | The admin clicks Rotate on a key. | A new secret is shown once. The old key stops working after the grace period. |
| UC-77.1-03 | M | The admin clicks Revoke. | The key stops working immediately. |
| UC-77.1-04 | B | A key passes its expiry. | Calls with it are rejected and the key shows Expired. |
| UC-77.2-01 | M | The admin turns on "Expose platform as MCP server" and selects the exposed tools. | The endpoint and auth are shown. |
| UC-77.2-02 | M | The admin pastes a key of the client and clicks Run test. | It calls tools/list with that key and shows, e.g., "Handshake OK · protocol <version the MCP SDK negotiates> · 3 tools listed" (D86). |
| UC-77.2-03 | N | MCP is off. | "MCP access is off for this client." is shown. |
| UC-77.3-01 | M | The admin turns on "Expose agents over AG-UI", picks agents, events and allowed origins. | The stream endpoint is shown, and only those agents and origins are accepted. |
| UC-77.3-02 | N | AG-UI is off. | "AG-UI streaming is off for this client." is shown. |
| UC-77.3-03 | E | A call comes from an origin that is not allowed. | Rejected by CORS and logged. |
| UC-77.4-01 | M | The admin edits Permissions. | The client's calls are limited to the new set at once. |
| UC-77.4-02 | E | The client calls an action it is not permitted. | The call is refused and audited. |
| UC-77.5-01 | M | The admin clicks Deactivate. | All keys stop working until the client is reactivated. |

### S-78 System

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-78.1-01 | M | An admin opens System. | KPIs show active runs, queue depth, active rooms and uptime (30d). The service list shows the version and health of each service. |
| UC-78.1-02 | M | The admin clicks Pause all agents and confirms. | Agent statuses show Paused and no new run starts. No run's status changes: runs already going drain and read Running until they finish, and the page says so (D182). |
| UC-78.1-03 | M | The admin clicks Resume all agents. | Each agent returns to the status it had and agents start runs again. No run's status changes (D182). |
| UC-78.1-04 | E | A service is unhealthy. | It is shown in an error state with its last check time. Affected screens show degraded messages. |
| UC-78.1-05 | P | A non-admin opens System. | Hidden. |

### S-79 Documentation

**Entry.** By its address. The screen has no navigation entry (D226).

| ID | Type | Scenario | Expected result |
| --- | --- | --- | --- |
| UC-79.1-01 | M | The user opens Documentation. | Guides are shown: Getting started, Discussion rooms, Approvals, Storylines, Connectors & tiers. |
| UC-79.1-02 | A | The user switches to Arabic. | Guides are shown in Arabic. |
| UC-79.1-03 | A | The user follows a link to a screen in a guide. | That screen opens, if the user has access. |

---

## 9. Traceability

| Screen | Spec section | Main data model entities |
| --- | --- | --- |
| S-01–S-05 Shell and account | §6, §7.6 | Person, Passkey, NotificationPreference |
| S-10–S-12 Home | §7.1 | Run, Approval, AgentQuestion, InboxItem, WorkItem, Request |
| S-20–S-21 Projects | §7.2.1 | Project, ProjectMember, ProjectAllowedAgent/Connector, ProjectApprovalRule, Decision |
| S-22–S-23 Discussion rooms | §7.2.2–7.2.3 | DiscussionRoom, RoomParticipant, RoomMessage, MessageFeedback, ContextHandoff |
| S-24–S-25 Work items | §7.2.4 | WorkItem, WorkItemActivity, Attachment, SavedView |
| S-27–S-30 Requests | §7.2.5 | RequestType, RequestTypeVersion, TransitionStep, StepAudience, RoutingRule, AttributeDefinition, Request, RequestEvent |
| S-31 Scheduled work items | §7.2.6 | ScheduledWorkItem, ScheduleRun |
| S-32–S-33 Artifacts and files | §7.2.7 | Artifact, ArtifactVersion, ProjectFile, FileAccessGrant |
| S-40–S-42 Organisation | §7.3 | OrgUnit, Person, Role, RolePermission, RoleAssignment |
| S-50–S-52 Agents and runs | §7.4.1–7.4.3 | Agent, AgentVersion, AgentSkill, AgentToolMode, Run, RunStep, PlaygroundTest |
| S-53 Skills | §7.4.4 | Skill, SkillVersion, SkillScanResult |
| S-54 Connectors | §7.4.5 | Connector, ConnectorTool |
| S-55 Memory | §7.4.6 | MemoryScope, Memory, MemoryVersion, MemoryEntry, MemoryReview |
| S-56–S-58 Knowledge | §7.4.7 | KnowledgeCollection, KnowledgeSource, KnowledgeDocument, IngestionJob |
| S-59–S-60 Models & routes | §7.4.8 | ModelProvider, ProviderConnection, ConnectionAllowedModel, Route, RouteStep |
| S-61 Channels | §7.4.9 | Channel |
| S-62–S-65 Embedded deployment | §7.4.10–7.4.12 | EmbeddedDeployment, DeploymentSurface, Storyline, StorylineVersion, StorylineStep, DeploymentConversation |
| S-71–S-72 Budgets | §7.5.2 | AgentBudget, BudgetPeriod, BudgetEvent, BudgetChange |
| S-73–S-79 Governance | §7.5.3–7.5.8 | AuditEntry, SettingsVersion, FeatureFlag, BrandingAsset, IntegrationClient, ClientKey, ClientMcpExposure, ClientAguiExposure, SystemState |

---
*End of document.*
