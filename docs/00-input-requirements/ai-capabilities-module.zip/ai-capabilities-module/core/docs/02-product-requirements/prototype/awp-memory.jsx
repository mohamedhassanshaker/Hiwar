const MEM_TREE = [
  { id: 'org', n: ['Organisation', 'الجهة'], ic: 'Bank', kids: [{ id: 'glossary', n: ['Glossary', 'المسرد'] }, { id: 'oprules', n: ['Operating rules', 'قواعد التشغيل'] }] },
  { id: 'fin', n: ['Finance', 'المالية'], ic: 'Invoice01', kids: [{ id: 'monthend', n: ['Month-end', 'نهاية الشهر'] }, { id: 'vendor', n: ['Vendor rules', 'قواعد الموردين'] }, { id: 'oldpd', n: ['2025 per-diem', 'بدل 2025'] }] },
  { id: 'exp', n: ['Expense Reviewer', 'مراجع المصروفات'], agent: 'exp', kids: [{ id: 'procedures', n: ['Procedures.md', 'Procedures.md'] }, { id: 'prefs', n: ['Preferences.md', 'Preferences.md'] }] },
  { id: 'ses', n: ['Sessions', 'الجلسات'], ic: 'Chat', kids: [{ id: 'handoff', n: ['SES-1042 handoff', 'تسليم SES-1042'] }] },
];
const MEM = {
  procedures: { title: ['Expense Reviewer', 'مراجع المصروفات'], path: ['Agent memory / Procedures', 'ذاكرة الوكيل / الإجراءات'], scope: 'Agent', st: 'Active', v: 14, owner: ['Finance Operations', 'العمليات المالية'], rev: '8 Oct 2026', access: ['Authorised agents', 'الوكلاء المصرح لهم'],
    items: [[['Learned procedures', 'الإجراءات المكتسبة'], ['Hotel per-diem rule: Riyadh AED 900 per night from 1 Oct 2026.', 'قاعدة البدل الفندقي: الرياض 900 د.إ لليلة من 1 أكتوبر 2026.'], ['Finance policy FIN-POL-007', 'السياسة المالية FIN-POL-007']], [['Receipt validation', 'التحقق من الإيصالات'], ['Validate VAT details and apply the approved exception rules. Taxi receipts without a VAT number are accepted up to AED 50.', 'التحقق من بيانات ضريبة القيمة المضافة وتطبيق قواعد الاستثناء المعتمدة. تُقبل إيصالات التاكسي بلا رقم ضريبي حتى 50 د.إ.'], ['Approved procedure · Fatima Noor, 8 Oct', 'إجراء معتمد · فاطمة نور، 8 أكتوبر']], [['Escalation', 'التصعيد'], ['Claims older than 90 days go to the Finance Approvers queue.', 'المطالبات الأقدم من 90 يوماً تذهب إلى طابور معتمدي المالية.'], ['Operating rules', 'قواعد التشغيل']]] },
  prefs: { title: ['Expense Reviewer', 'مراجع المصروفات'], path: ['Agent memory / Preferences', 'ذاكرة الوكيل / التفضيلات'], scope: 'Agent', st: 'Pending review', v: 3, owner: ['Finance Operations', 'العمليات المالية'], rev: '2 Oct 2026', access: ['Authorised agents', 'الوكلاء المصرح لهم'],
    items: [[['Reply style', 'أسلوب الرد'], ['Cite FIN-POL-007 clause numbers in every return reason.', 'ذكر أرقام بنود FIN-POL-007 في كل سبب إرجاع.'], ['Learned from RUN-88231', 'مكتسب من RUN-88231']]] },
  glossary: { title: ['Glossary', 'المسرد'], path: ['Organisation memory / Glossary', 'ذاكرة الجهة / المسرد'], scope: 'Organisation', st: 'Active', v: 22, owner: ['Platform team', 'فريق المنصة'], rev: '1 Oct 2026', access: ['All agents', 'كل الوكلاء'],
    items: [[['Terms', 'المصطلحات'], ['Tahseel card: prepaid government payment card. Per-diem: daily allowance under FIN-POL-007.', 'بطاقة تحصيل: بطاقة دفع حكومية مسبقة الدفع. البدل اليومي: حسب FIN-POL-007.'], ['Organisation glossary', 'مسرد الجهة']]] },
  oprules: { title: ['Operating rules', 'قواعد التشغيل'], path: ['Organisation memory / Rules', 'ذاكرة الجهة / القواعد'], scope: 'Organisation', st: 'Needs attention', v: 9, owner: ['Platform team', 'فريق المنصة'], rev: '12 Jul 2026', access: ['All agents', 'كل الوكلاء'],
    items: [[['Working hours', 'ساعات العمل'], ['Human approvals are routed only between 08:00 and 17:00 GST, Monday to Friday.', 'تُوجَّه الاعتمادات البشرية فقط بين 08:00 و17:00، من الاثنين إلى الجمعة.'], ['HR policy', 'سياسة الموارد البشرية']]], warn: ['Not reviewed for 89 days. Review cycle is 90 days.', 'لم تُراجع منذ 89 يوماً. دورة المراجعة 90 يوماً.'] },
  monthend: { title: ['Month-end', 'نهاية الشهر'], path: ['Business unit memory / Finance', 'ذاكرة وحدة العمل / المالية'], scope: 'Business unit', st: 'Active', v: 6, owner: ['Finance Operations', 'العمليات المالية'], rev: '5 Oct 2026', access: ['Finance agents', 'وكلاء المالية'],
    items: [[['Close calendar', 'تقويم الإقفال'], ['Bank reconciliation runs on day 1; exceptions must be cleared by day 3.', 'تجري المطابقة البنكية في اليوم 1؛ ويجب معالجة الاستثناءات بحلول اليوم 3.'], ['Reconciler routine', 'روتين المطابقة']]] },
  handoff: { title: ['SES-1042 handoff', 'تسليم SES-1042'], path: ['Session memory', 'ذاكرة الجلسة'], scope: 'Session', st: 'Active', v: 2, owner: ['Director', 'المدير'], rev: '9 Oct 2026', access: ['Room members', 'أعضاء الاجتماع'],
    items: [[['Context', 'السياق'], ['Q4 T&E policy change; CS-118 awaiting Work Lead approval.', 'تغيير سياسة السفر للربع الرابع؛ CS-118 بانتظار اعتماد قائد العمل.'], ['Discussion room', 'اجتماع العمل']]] },
};
MEM.vendor = { title: ['Vendor rules', 'قواعد الموردين'], path: ['Business unit memory / Finance', 'ذاكرة وحدة العمل / المالية'], scope: 'Business unit', st: 'Pending review', v: 1, owner: ['Finance Operations', 'العمليات المالية'], rev: '8 Oct 2026', access: ['Finance agents', 'وكلاء المالية'], by: 'u1', src: 'person', items: [[['Onboarding', 'التسجيل'], ['New vendors need a valid trade licence and IBAN letter before the first PO.', 'يحتاج الموردون الجدد إلى رخصة تجارية سارية وخطاب IBAN قبل أول أمر شراء.'], ['Proposed by Mariam Al Suwaidi', 'اقترحتها مريم السويدي']]] };
MEM.oldpd = { title: ['2025 per-diem', 'بدل 2025'], path: ['Business unit memory / Finance', 'ذاكرة وحدة العمل / المالية'], scope: 'Business unit', st: 'Archived', v: 4, owner: ['Finance Operations', 'العمليات المالية'], rev: '30 Sep 2026', access: ['Finance agents', 'وكلاء المالية'], src: 'person', items: [[['Limits', 'الحدود'], ['Riyadh AED 750 per night (replaced from 1 Oct 2026).', 'الرياض 750 د.إ لليلة (استُبدل من 1 أكتوبر 2026).'], ['FIN-POL-006', 'FIN-POL-006']]] };
MEM.prefs.by = 'exp'; MEM.procedures.src = 'agent'; MEM.prefs.src = 'agent'; MEM.glossary.src = 'person'; MEM.oprules.src = 'person'; MEM.monthend.src = 'agent'; MEM.handoff.src = 'agent';
const memTone = { Active: 'success', 'Pending review': 'warning', 'Needs attention': 'danger', Rejected: 'danger', Archived: 'neutral' };
const memAr = { Rejected: 'مرفوضة', Archived: 'مؤرشفة', Active: 'نشطة', 'Pending review': 'بانتظار المراجعة', 'Needs attention': 'تحتاج انتباهاً', Organisation: 'الجهة', 'Business unit': 'وحدة العمل', Agent: 'وكيل', Session: 'جلسة' };
const MEM_VER = [[14, '8 Oct 2026', 'exp', ['Added taxi VAT exception (approved by Fatima Noor)', 'أُضيف استثناء ضريبة التاكسي (اعتمدته فاطمة نور)']], [13, '1 Oct 2026', 'u3', ['Updated Riyadh per-diem to AED 900', 'تحديث بدل الرياض إلى 900 د.إ']], [12, '14 Sep 2026', 'exp', ['Added 90-day escalation rule', 'إضافة قاعدة تصعيد 90 يوماً']]];

function Memory() {
  const [ov, setOv] = React.useState({});
  const [del, setDel] = React.useState({});
  const M = (k) => ({ ...MEM[k], ...(ov[k] || {}) });
  const keys = Object.keys(MEM).filter((k) => !del[k]);
  const [sel, setSel] = React.useState('procedures');
  const [scope, setScope] = React.useState('all');
  const [q, setQ] = React.useState('');
  const [adv, setAdv] = React.useState(false);
  const blank = { owner: 'any', st: 'any', rev: 'any', src: 'any' };
  const [af, setAf] = React.useState(blank);
  const [open, setOpen] = React.useState({ org: true, fin: true, exp: true, ses: true });
  const [hist, setHist] = React.useState(false);
  const [edit, setEdit] = React.useState(false);
  const [nw, setNw] = React.useState(false);
  const [banner, setBanner] = useBanner();
  const [conf, setConf] = useConfirm();
  const revDays = (d) => Math.round((new Date(2026, 9, 8) - new Date(d)) / 864e5);
  const visible = (k) => { const m = M(k); return (scope === 'all' || m.scope === scope) && (af.owner === 'any' || m.owner[0] === af.owner) && (af.st === 'any' || m.st === af.st) && (af.src === 'any' || m.src === af.src) && (af.rev === 'any' || (af.rev === 'old' ? revDays(m.rev) > 60 : revDays(m.rev) <= 30)) && (!q || (T(m.title[0], m.title[1]) + m.items.map((i) => T(i[1][0], i[1][1])).join(' ')).toLowerCase().includes(q.toLowerCase())); };
  const vis = keys.filter(visible);
  const cur = vis.includes(sel) ? sel : vis[0];
  const m = cur ? M(cur) : null;
  const advN = Object.keys(blank).filter((k) => af[k] !== blank[k]).length;
  const setSt = (st, msg) => { setOv({ ...ov, [cur]: { ...(ov[cur] || {}), st, rev: '8 Oct 2026' } }); setBanner('success', msg); };
  const own = m && m.by === 'u1';
  const owners = [...new Set(Object.values(MEM).map((x) => x.owner[0]))];
  const statuses = ['Active', 'Pending review', 'Needs attention', 'Rejected', 'Archived'];
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Memory', 'الذاكرة')} sub={T('Manage persistent knowledge, agent context and governance.', 'إدارة المعرفة الدائمة وسياق الوكلاء والحوكمة.')}><Btn label={T('New memory', 'ذاكرة جديدة')} icon="AddCircle" onClick={() => setNw(true)} /></PageHead>
      {banner}
      <KpiRow items={[{ label: T('Total memories', 'إجمالي الذاكرات'), value: 128 }, { label: T('Pending review', 'بانتظار المراجعة'), value: keys.filter((k) => M(k).st === 'Pending review').length, tone: 'warning' }, { label: T('Active agents', 'الوكلاء النشطون'), value: 12 }, { label: T('Needs attention', 'تحتاج انتباهاً'), value: keys.filter((k) => M(k).st === 'Needs attention').length || T('None', 'لا شيء'), tone: keys.some((k) => M(k).st === 'Needs attention') ? 'danger' : undefined }]} />
      <Card>
        <div className="awp-col" style={{ gap: 12 }}>
          <div className="awp-row" style={{ gap: 10 }}><div style={{ flex: 1, position: 'relative' }}><span style={{ position: 'absolute', insetInlineStart: 12, top: '50%', transform: 'translateY(-50%)', display: 'flex' }}><Ic n="Search" s={18} c="var(--icon-tertiary)" /></span><input className="awp-input" style={{ paddingInlineStart: 38, width: '100%' }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={T('Search memories, policies, agents or keywords…', 'ابحث في الذاكرات أو السياسات أو الوكلاء أو الكلمات…')} /></div><Pill on={adv || advN > 0} onClick={() => setAdv(!adv)}>{T('Filters', 'عوامل التصفية')}{advN > 0 && ' · ' + advN}</Pill></div>
          <Chips value={scope} onChange={setScope} items={[{ id: 'all', label: T('All scopes', 'كل النطاقات') }, { id: 'Organisation', label: T('Organisation', 'الجهة') }, { id: 'Business unit', label: T('Business unit', 'وحدة العمل') }, { id: 'Agent', label: T('Agent', 'وكيل') }, { id: 'Session', label: T('Session', 'جلسة') }]} />
          {adv && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(180px,100%),1fr))', gap: 12, paddingTop: 4 }}>
            <Field label={T('Owner', 'المالك')}><Sel value={af.owner} onChange={(v) => setAf({ ...af, owner: v })} w={9999} opts={[['any', T('Any owner', 'أي مالك')], ...owners.map((o) => [o, T(o, (Object.values(MEM).find((x) => x.owner[0] === o) || {}).owner[1])])]} /></Field>
            <Field label={T('Status', 'الحالة')}><Sel value={af.st} onChange={(v) => setAf({ ...af, st: v })} w={9999} opts={[['any', T('Any status', 'أي حالة')], ...statuses.map((x) => [x, T(x, memAr[x])])]} /></Field>
            <Field label={T('Last reviewed', 'آخر مراجعة')}><Sel value={af.rev} onChange={(v) => setAf({ ...af, rev: v })} w={9999} opts={[['any', T('Any time', 'أي وقت')], ['recent', T('In the last 30 days', 'خلال آخر 30 يوماً')], ['old', T('More than 60 days ago', 'منذ أكثر من 60 يوماً')]]} /></Field>
            <Field label={T('Source', 'المصدر')}><Sel value={af.src} onChange={(v) => setAf({ ...af, src: v })} w={9999} opts={[['any', T('Any source', 'أي مصدر')], ['agent', T('Learned by an agent', 'اكتسبها وكيل')], ['person', T('Written by a person', 'كتبها شخص')]]} /></Field>
            <div style={{ alignSelf: 'end' }}><Lnk onClick={() => setAf(blank)}>{T('Clear filters', 'مسح عوامل التصفية')}</Lnk></div>
          </div>}
        </div>
      </Card>
      {!m ? <Card><Empty title={T('No memories match.', 'لا توجد ذاكرات مطابقة.')} text={T('Change the search or filters.', 'غيّر البحث أو عوامل التصفية.')}><Pill onClick={() => { setQ(''); setScope('all'); setAf(blank); }}>{T('Clear all', 'مسح الكل')}</Pill></Empty></Card> :
      <div className="awp-card awp-two" style={{ display: 'grid', gridTemplateColumns: 'minmax(220px,260px) minmax(0,1fr)', padding: 0, overflow: 'hidden' }}>
        <nav style={{ background: 'var(--surface-card)', padding: '16px 10px', borderInlineEnd: '1px solid var(--border-divider)' }} aria-label={T('Memory explorer', 'مستكشف الذاكرة')}>
          <div className="awp-small awp-muted" style={{ padding: '0 10px 10px', fontWeight: 900, letterSpacing: '.04em', textTransform: 'uppercase' }}>{T('Memory explorer', 'مستكشف الذاكرة')}</div>
          {MEM_TREE.map((g) => { const kids = g.kids.filter((k) => vis.includes(k.id)); if (!kids.length) return null; const on = g.kids.some((k) => k.id === cur); return (
            <div key={g.id} style={{ marginBottom: 6, borderRadius: 12, background: on && g.agent ? 'var(--surface-brand-subtle)' : 'transparent', padding: on && g.agent ? '4px 0' : 0 }}>
              <button onClick={() => setOpen({ ...open, [g.id]: !open[g.id] })} className="awp-row" style={{ width: '100%', gap: 8, border: 0, background: 'transparent', cursor: 'pointer', padding: '8px 10px', color: 'var(--text-primary)', fontWeight: 500, textAlign: 'start' }}>{g.agent ? <Who id={g.agent} s={20} /> : <Ic n={g.ic} s={18} />}<span style={{ flex: 1 }}>{T(g.n[0], g.n[1])}</span><Ic n={open[g.id] ? 'ChevronDown' : 'ChevronTight'} s={14} c="var(--icon-tertiary)" /></button>
              {open[g.id] && kids.map((k) => { const st = M(k.id).st; return <button key={k.id} onClick={() => setSel(k.id)} className="awp-row" style={{ width: '100%', border: 0, cursor: 'pointer', padding: '6px 10px 6px 38px', gap: 6, textAlign: 'start', borderRadius: 8, background: 'transparent', color: cur === k.id ? 'var(--text-brand)' : 'var(--text-secondary)', fontWeight: cur === k.id ? 900 : 400 }}><span style={{ flex: 1, textDecoration: st === 'Archived' ? 'line-through' : 'none' }}>{T(k.n[0], k.n[1])}</span>{['Pending review', 'Needs attention', 'Rejected'].includes(st) && <span className="awp-dot" style={{ background: st === 'Pending review' ? 'var(--icon-warning)' : 'var(--icon-danger)' }} />}</button>; })}
            </div>); })}
        </nav>
        <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20, minWidth: 0 }}>
          <div className="awp-row" style={{ alignItems: 'flex-start', gap: 12 }}><div style={{ flex: 1 }}><h2 style={{ margin: 0, fontSize: 20, fontWeight: 900 }}>{T(m.title[0], m.title[1])}</h2><div className="awp-small awp-muted">{T(m.path[0], m.path[1])}</div></div><Tg tone={memTone[m.st]} dot label={T(m.st, memAr[m.st])} /></div>
          {m.st === 'Needs attention' && m.warn && <Banner tone="danger"><span className="awp-row" style={{ gap: 12, flexWrap: 'wrap' }}><span style={{ flex: 1 }}>{T(m.warn[0], m.warn[1])}</span><Lnk onClick={() => setSt('Active', T('Review recorded for today. The next review is due in 90 days.', 'سُجّلت المراجعة اليوم. المراجعة التالية بعد 90 يوماً.'))}>{T('Review now', 'المراجعة الآن')}</Lnk></span></Banner>}
          {m.st === 'Pending review' && <Banner tone="warning"><div className="awp-col" style={{ gap: 10 }}><span>{own ? T('You proposed this memory. Someone else must approve or reject it before it is used.', 'أنت من اقترح هذه الذاكرة. يجب أن يعتمدها أو يرفضها شخص آخر قبل استخدامها.') : T('Proposed by ' + aName(m.by || 'exp') + '. Approve before it is used in runs.', 'مقترحة من ' + aName(m.by || 'exp') + '. اعتمدها قبل استخدامها في العمليات.')}</span>{!own && <span className="awp-row" style={{ gap: 10 }}><Btn type="secondary" label={T('Reject', 'رفض')} onClick={() => setSt('Rejected', T('Memory rejected. Agents will not use it.', 'رُفضت الذاكرة. لن تستخدمها الوكلاء.'))} /><Btn label={T('Approve', 'اعتماد')} onClick={() => setSt('Active', T('Memory approved. Agents can use it from their next run.', 'اعتُمدت الذاكرة. يمكن للوكلاء استخدامها من العملية التالية.'))} /></span>}</div></Banner>}
          {m.st === 'Rejected' && <Banner tone="danger">{T('Rejected. Agents do not use this memory. Edit it to propose a new version.', 'مرفوضة. لا تستخدم الوكلاء هذه الذاكرة. عدّلها لاقتراح إصدار جديد.')}</Banner>}
          {m.st === 'Archived' && <Banner tone="info"><span className="awp-row" style={{ gap: 12 }}><span style={{ flex: 1 }}>{T('Archived. Kept for audit; agents do not use it.', 'مؤرشفة. محفوظة للتدقيق ولا تستخدمها الوكلاء.')}</span><Lnk onClick={() => setSt('Active', T('Memory restored from the archive.', 'استُعيدت الذاكرة من الأرشيف.'))}>{T('Restore', 'استعادة')}</Lnk></span></Banner>}
          <div className="awp-row" style={{ borderTop: '1px solid var(--border-divider)', paddingTop: 14 }}><span className="awp-muted" style={{ flex: 1 }}>{T('Version', 'الإصدار')} {m.v}</span><button className="awp-row awp-lnk-t" style={{ gap: 6 }} onClick={() => setHist(true)}><Ic n="Calendar03" s={16} />{T('History', 'السجل')}</button></div>
          {m.items.map(([h, b, src], i) => <div key={i} style={{ paddingBottom: 16, borderBottom: '1px solid var(--border-divider)' }}><h4 style={{ margin: '0 0 6px', fontSize: 15, fontWeight: 900 }}>{T(h[0], h[1])}</h4><p style={{ margin: '0 0 6px' }}>{T(b[0], b[1])}</p><div className="awp-small awp-muted">{T('Source', 'المصدر')} · {T(src[0], src[1])}</div></div>)}
          <div><h4 style={{ margin: '0 0 10px', fontSize: 15, fontWeight: 900 }}>{T('Memory details', 'تفاصيل الذاكرة')}</h4>
            <dl className="awp-kv" style={{ margin: 0 }}><dt>{T('Scope', 'النطاق')}</dt><dd>{T(m.scope, memAr[m.scope])}</dd><dt>{T('Owner', 'المالك')}</dt><dd>{T(m.owner[0], m.owner[1])}</dd><dt>{T('Last reviewed', 'آخر مراجعة')}</dt><dd>{m.rev}</dd><dt>{T('Access', 'الوصول')}</dt><dd>{T(m.access[0], m.access[1])}</dd><dt>{T('Write policy', 'سياسة الكتابة')}</dt><dd>{T('PII filter · human approval for new rules', 'فلتر البيانات الشخصية · اعتماد بشري للقواعد الجديدة')}</dd></dl>
          </div>
          <div className="awp-row" style={{ gap: 10, flexWrap: 'wrap' }}>
            <Btn label={T('Edit memory', 'تعديل الذاكرة')} icon="PencilEdit01" onClick={() => setEdit(true)} />
            {m.st !== 'Archived' && <Btn type="secondary" label={T('Archive', 'أرشفة')} onClick={() => setSt('Archived', T('Memory archived.', 'أُرشفت الذاكرة.'))} />}
            <span style={{ flex: 1 }} />
            <Btn type="danger" label={T('Delete', 'حذف')} onClick={() => setConf({ title: T('Delete this memory?', 'حذف هذه الذاكرة؟'), intro: T('The memory and all ' + m.v + ' versions in its history are deleted. Agents lose it from their next run. This cannot be undone.', 'تُحذف الذاكرة وكل إصداراتها الـ ' + m.v + ' في السجل. تفقدها الوكلاء من العملية التالية. لا يمكن التراجع عن ذلك.'), confirm: T('Delete memory', 'حذف الذاكرة'), onConfirm: () => { setDel({ ...del, [cur]: 1 }); setBanner('success', T('Memory and its version history deleted.', 'حُذفت الذاكرة وسجل إصداراتها.')); } })} />
          </div>
        </div>
      </div>}
      {hist && m && <Modal w={640} title={T('Version history', 'سجل الإصدارات') + ' · ' + T(m.title[0], m.title[1])} onClose={() => setHist(false)}>
        {MEM_VER.map(([v, d, w, t]) => <div key={v} className="awp-row" style={{ gap: 12, padding: '12px 0', borderBottom: '1px solid var(--border-divider)', alignItems: 'flex-start' }}><Tg label={'v' + v} tone={v === 14 ? 'info' : 'neutral'} /><div style={{ flex: 1 }}><div>{T(t[0], t[1])}</div><div className="awp-small awp-muted">{aName(w)} · {d}</div></div><div className="awp-row" style={{ gap: 12 }}><Lnk onClick={() => window.__awpAct({ title: T('Compare', 'مقارنة') + ' v' + v, desc: T('Side-by-side diff against the current version.', 'مقارنة جنباً إلى جنب مع الإصدار الحالي.') })}>{T('Compare', 'مقارنة')}</Lnk>{v !== 14 && <Lnk onClick={() => window.__awpAct({ title: T('Restore', 'استعادة') + ' v' + v, desc: T('Creates version 15 with this content. The change is audited.', 'ينشئ الإصدار 15 بهذا المحتوى. التغيير مدقق.') })}>{T('Restore', 'استعادة')}</Lnk>}</div></div>)}
      </Modal>}
      {edit && m && <MemEdit m={m} onClose={() => setEdit(false)} onSave={(review) => { setOv({ ...ov, [cur]: { ...(ov[cur] || {}), v: m.v + 1, st: review ? 'Pending review' : 'Active', rev: '8 Oct 2026' } }); setEdit(false); setBanner('success', T('Saved as version ' + (m.v + 1) + '. 1 phone number was masked by the PII filter.', 'حُفظت كإصدار ' + (m.v + 1) + '. أخفى فلتر البيانات الشخصية رقم هاتف واحداً.') + (review ? T(' It needs review before it is used.', ' تحتاج إلى مراجعة قبل استخدامها.') : '')); }} />}
      {nw && <MemNew onClose={() => setNw(false)} onSave={() => { setNw(false); setBanner('success', T('Memory created and sent for review. Personal data was masked before saving.', 'أُنشئت الذاكرة وأُرسلت للمراجعة. أُخفيت البيانات الشخصية قبل الحفظ.')); }} />}
      {conf}
    </div>
  );
}

function MemEdit({ m, onClose, onSave }) {
  const [note, setNote] = React.useState('');
  const [review, setReview] = React.useState(m.scope === 'Organisation');
  return (
    <Modal w={720} title={T('Edit memory', 'تعديل الذاكرة') + ' · ' + T(m.title[0], m.title[1])} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Save as version', 'حفظ كإصدار') + ' ' + (m.v + 1)} disabled={!note.trim()} onClick={() => onSave(review)} /></>}>
      <Field label={T('Content', 'المحتوى')}><textarea className="awp-input awp-mono" rows={10} style={{ direction: 'ltr', textAlign: 'left' }} defaultValue={m.items.map(([h, b]) => '## ' + h[0] + '\n' + b[0]).join('\n\n')} /></Field>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}><Field label={T('Owner', 'المالك')}><input className="awp-input" defaultValue={m.owner[0]} /></Field><Field label={T('Access', 'الوصول')}><PopSelect className="awp-input" defaultValue={m.access[0]}><option>All agents</option><option>Finance agents</option><option>Authorised agents</option><option>Room members</option></PopSelect></Field></div>
      <Field label={T('Change note', 'ملاحظة التغيير')} hint={!note.trim() ? T('Required. It is kept in the version history.', 'مطلوبة. تُحفظ في سجل الإصدارات.') : null}><input className="awp-input" value={note} onChange={(e) => setNote(e.target.value)} placeholder={T('What changed and why', 'ما الذي تغير ولماذا')} /></Field>
      <label className="awp-row" style={{ gap: 12 }}><Toggle on={review} onChange={setReview} /><span>{T('Needs review before it is used', 'تحتاج إلى مراجعة قبل الاستخدام')}</span></label>
      <span className="awp-small awp-muted">{T('Personal data such as phone numbers and Emirates ID numbers is masked when you save.', 'تُخفى البيانات الشخصية مثل أرقام الهواتف والهوية الإماراتية عند الحفظ.')}</span>
    </Modal>
  );
}
function MemNew({ onClose, onSave }) {
  const [sc, setSc] = React.useState('Agent');
  const [t, setT] = React.useState('');
  const [c, setC] = React.useState('');
  const [close, guard] = useDirtyClose(!!(t || c), onClose);
  return (
    <Modal title={T('New memory', 'ذاكرة جديدة')} onClose={close} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={close} /><Btn label={T('Create', 'إنشاء')} disabled={!t.trim() || !c.trim()} onClick={onSave} /></>}>
      <Field label={T('Title', 'العنوان')}><input className="awp-input" value={t} onChange={(e) => setT(e.target.value)} placeholder={T('e.g. Vendor onboarding rules', 'مثال: قواعد تسجيل الموردين')} /></Field>
      <Field label={T('Scope', 'النطاق')}><Seg value={sc} onChange={setSc} items={[{ id: 'Organisation', label: T('Organisation', 'الجهة') }, { id: 'Business unit', label: T('Business unit', 'وحدة العمل') }, { id: 'Agent', label: T('Agent', 'وكيل') }]} /></Field>
      {sc === 'Agent' && <Field label={T('Agent', 'الوكيل')}><PopSelect className="awp-input">{AGENTS.map((a) => <option key={a.id}>{nm(a)}</option>)}</PopSelect></Field>}
      <Field label={T('Content', 'المحتوى')}><textarea className="awp-input" rows={5} value={c} onChange={(e) => setC(e.target.value)} /></Field>
      <span className="awp-small awp-muted">{T('New memories need review by someone else before agents use them. Personal data is masked when you save.', 'تحتاج الذاكرات الجديدة إلى مراجعة من شخص آخر قبل أن تستخدمها الوكلاء. تُخفى البيانات الشخصية عند الحفظ.')}</span>
      {guard}
    </Modal>
  );
}

Object.assign(window, { Memory });
