const CH_LIVE = [['Web widget', 'Embedded deployment: Tahseel website assistant', 'dep_7f3a9c'], ['WhatsApp', 'Embedded deployment: Tahseel website assistant', 'dep_7f3a9c'], ['Microsoft Teams', 'Discussion rooms (mirror)', 'dep_2b81e0']];
const CH_SOON = ['Slack', 'Email', 'SMS', 'Voice / IVR', 'Telegram', 'Webex', 'Google Chat', 'Instagram', 'Facebook Messenger'];
const CH_CHECKS = { 'Web widget': [['Embed script reachable', 'OK', 42], ['Allowed origin tahseel.ae', 'OK', 18], ['Visitor runtime', 'OK', 230]], WhatsApp: [['Webhook verified', 'OK', 120], ['Signing secret matches', 'OK', 8], ['Template awp_card_update', 'FAILED', 310, 'Rejected by Meta policy review']], 'Microsoft Teams': [['Bot registration', 'OK', 96], ['Graph permissions', 'OK', 140], ['Outbound endpoint', 'OK', 88]] };
const engageOn = () => !window.AWP_FLAGS || window.AWP_FLAGS['Embedded deployments'] !== false;

function Channels() {
  const [on, setOn] = React.useState({ 'Web widget': true, WhatsApp: true, 'Microsoft Teams': true });
  const [test, setTest] = React.useState(null);
  const [banner, setBanner] = useBanner();
  const cfg = (n) => window.__awpOpen('configChannel', { name: n });
  const st = (n) => !on[n] ? 'Disabled' : n === 'WhatsApp' ? 'Degraded' : 'Enabled';
  const toggle = (n, v) => { if (!v && n === 'Web widget') return setBanner('danger', T('Web widget cannot be turned off while the Tahseel website assistant is live. Disable that deployment first.', 'لا يمكن إيقاف ويدجت الويب ما دام مساعد موقع تحصيل منشوراً. عطّل ذلك النشر أولاً.')); setOn({ ...on, [n]: v }); setBanner('success', T(n + (v ? ' turned on.' : ' turned off.'), n + (v ? ' مفعّلة.' : ' معطّلة.'))); };
  const runTest = (n) => { setTest({ n, run: true }); setTimeout(() => setTest({ n, res: CH_CHECKS[n] }), 700); };
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Channels', 'القنوات')} sub={T('Enable or disable a channel and configure its credentials. Changes are hot-reloaded.', 'فعّل القناة أو عطّلها واضبط بيانات اعتمادها. تُطبق التغييرات دون إعادة تشغيل.')} />
      {banner}
      <Card pad={false}><DataTable rows={CH_LIVE} onRow={(r) => cfg(r[0])} cols={[
        { h: '', r: (r) => <Toggle on={on[r[0]]} onChange={(v) => toggle(r[0], v)} /> },
        { h: T('Channel', 'القناة'), r: (r) => <b>{r[0]}</b> },
        { h: T('Status', 'الحالة'), r: (r) => <StTag s={st(r[0])} /> },
        { h: T('Bound to', 'مرتبطة بـ'), r: (r) => r[1] },
        { h: '', end: true, r: (r) => <div className="awp-row" style={{ gap: 12, justifyContent: 'flex-end' }}><Lnk onClick={() => runTest(r[0])}>{T('Test', 'اختبار')}</Lnk><Lnk onClick={() => cfg(r[0])}>{T('Configure', 'إعداد')}</Lnk></div> },
      ]} /></Card>
      <Card title={T('Coming soon', 'قريباً')}>
        <div className="awp-row" style={{ flexWrap: 'wrap', gap: 8 }}>{CH_SOON.map((c) => <span key={c} className="awp-chip" style={{ cursor: 'default', opacity: 0.7 }}>{c}<Tg label={T('Coming soon', 'قريباً')} /></span>)}</div>
      </Card>
      {test && <Modal title={T('Test ' + test.n, 'اختبار ' + test.n)} onClose={() => setTest(null)} w={520} footer={<><Btn type="secondary" label={T('Close', 'إغلاق')} onClick={() => setTest(null)} /><Btn label={T('Run again', 'إعادة التشغيل')} disabled={test.run} onClick={() => runTest(test.n)} /></>}>
        {test.run ? <span className="awp-muted">{T('Running checks…', 'جارٍ تشغيل الفحوص…')}</span> : <div className="awp-col" style={{ gap: 10 }}>{test.res.map(([k, r, ms, why]) => <div key={k} className="awp-row" style={{ gap: 10, alignItems: 'flex-start' }}><Ic n={r === 'OK' ? 'TickCircle' : 'Alert02'} s={18} c={r === 'OK' ? 'var(--icon-success)' : 'var(--icon-danger)'} /><div style={{ flex: 1 }}><div>{k}</div>{why && <div className="awp-small" style={{ color: 'var(--text-danger)' }}>{why}</div>}</div><span className="awp-small awp-muted awp-mono">{ms} ms</span></div>)}</div>}
      </Modal>}
    </div>
  );
}

function ConfigChannelDrawer({ onClose, name }) {
  const [on, setOn] = React.useState(true);
  const [dep, setDep] = React.useState(name === 'Microsoft Teams' ? 'dep_2b81e0' : 'dep_7f3a9c');
  const [sec, setSec] = React.useState({});
  const [saved, setSaved] = React.useState(false);
  const wa = name === 'WhatsApp', tm = name === 'Microsoft Teams';
  const SecretF = ({ k, l }) => <Field label={l} hint={T('Saved. Enter a new value only to replace it. It cannot be shown again.', 'محفوظ. أدخل قيمة جديدة فقط لاستبداله. لا يمكن عرضه مرة أخرى.')}><input className="awp-input" type="password" autoComplete="new-password" value={sec[k] || ''} onChange={(e) => setSec({ ...sec, [k]: e.target.value })} placeholder={T('Saved · enter to replace', 'محفوظ · أدخل للاستبدال')} /></Field>;
  return (
    <Drawer title={name} sub={T('Channel configuration', 'إعداد القناة')} onClose={onClose} footer={<><Btn label={T('Save changes', 'حفظ التغييرات')} onClick={() => setSaved(true)} /><Btn type="secondary" label={T('Close', 'إغلاق')} onClick={onClose} /></>}>
      {saved && <Banner tone="success">{T('Saved. The channel reloaded without downtime.', 'حُفظ. أُعيد تحميل القناة دون توقف.')}</Banner>}
      <div className="awp-row" style={{ padding: 14, borderRadius: 16, background: 'var(--surface-card)' }}><div style={{ flex: 1 }}><b>{T('Channel enabled', 'القناة مفعّلة')}</b></div><Toggle on={on} onChange={setOn} /></div>
      <Field label={T('Bound to deployment', 'مرتبطة بالنشر')}><PopSelect className="awp-input" value={dep} onChange={(e) => setDep(e.target.value)}>{DEPS.map((d) => <option key={d.id} value={d.id}>{T(d.n, d.nAr)} · {d.id}</option>)}</PopSelect></Field>
      {wa && <><Field label={T('Phone number ID', 'معرّف رقم الهاتف')}><input className="awp-input awp-mono" defaultValue="104857362910" /></Field><SecretF k="tok" l={T('Access token', 'رمز الوصول')} /><SecretF k="sig" l={T('Webhook signing secret', 'سر توقيع الخطاف')} /></>}
      {tm && <><Field label={T('Bot app ID', 'معرّف تطبيق البوت')}><input className="awp-input awp-mono" defaultValue="7c1e0b4a-91f2-4a53-b0e1-2f6a8d1c3e70" /></Field><SecretF k="pw" l={T('Client secret', 'سر العميل')} /><Field label={T('Outbound endpoint URL', 'رابط نقطة الإرسال')}><input className="awp-input awp-mono" defaultValue="https://awp.tahseel.ae/api/channels/teams/messages" /></Field></>}
      {!wa && !tm && <><Field label={T('Allowed origins', 'المصادر المسموحة')}><input className="awp-input awp-mono" defaultValue="https://tahseel.ae" /></Field><SecretF k="sig" l={T('Webhook signing secret', 'سر توقيع الخطاف')} /></>}
      {wa && <Field label={T('Webhook URL (give this to Meta)', 'رابط الخطاف (قدّمه إلى Meta)')}><input className="awp-input awp-mono" readOnly value="https://awp.tahseel.ae/api/channels/whatsapp/hook" /></Field>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Offline message (English)', 'رسالة عدم التوفر (إنجليزي)')}><textarea className="awp-input" style={{ height: 72, padding: 12 }} defaultValue="We are offline right now. We will reply during working hours." /></Field>
        <Field label={T('Offline message (Arabic)', 'رسالة عدم التوفر (عربي)')}><textarea className="awp-input" dir="rtl" style={{ height: 72, padding: 12 }} defaultValue="نحن غير متاحين الآن. سنرد خلال ساعات العمل." /></Field>
      </div>
    </Drawer>
  );
}

const DEPS = [
  { id: 'dep_7f3a9c', n: 'Tahseel website assistant', nAr: 'مساعد موقع تحصيل', a: 'sup', surf: 'Widget · WhatsApp', sl: 'card-replacement v3 · strict', rate: 4.6, conv: 3120, st: 'Enabled' },
  { id: 'dep_2b81e0', n: 'Employee helpdesk', nAr: 'مكتب مساعدة الموظفين', a: 'kb', surf: 'Teams', sl: '—', rate: 4.3, conv: 842, st: 'Enabled' },
  { id: 'dep_91cd44', n: 'Vendor portal assistant', nAr: 'مساعد بوابة الموردين', a: 'prc', surf: 'Widget', sl: '', rate: 0, conv: 0, st: 'Draft' },
];
const DEP_SWATCH = ['#0677FF', '#0848CE', '#12034B', '#6538B5', '#2F784A'];

function DeploymentDetail({ d, back, go }) {
  const [tab, setTab] = React.useState('details');
  const [agent, setAgent] = React.useState(d.a);
  const [color, setColor] = React.useState('#0677FF');
  const [idm, setIdm] = React.useState('otp');
  const [origins, setOrigins] = React.useState('https://tahseel.ae, https://www.tahseel.ae');
  const [banner, setBanner] = useBanner();
  const [copied, setCopied] = React.useState(false);
  const chk = brCheck(color);
  const badOrigin = origins.split(',').map((o) => o.trim()).filter(Boolean).find((o) => !/^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(o));
  const snippet = '<script src="https://awp.tahseel.ae/api/widget/' + d.id + '/embed.js" data-lang="auto" defer></script>';
  const save = () => { if (!chk.ok) return setBanner('danger', T('Not saved. The accent colour is too light for white text. Use ' + chk.sug + ' instead.', 'لم يُحفظ. لون التمييز فاتح جداً للنص الأبيض. استخدم ' + chk.sug + ' بدلاً منه.')); if (badOrigin) return setBanner('danger', T('Not saved. "' + badOrigin + '" is not a valid origin. Use https:// and a host name only.', 'لم يُحفظ. "' + badOrigin + '" ليس مصدراً صالحاً. استخدم https:// واسم المضيف فقط.')); setBanner('success', T('Saved. The widget picks up the changes on the next page load.', 'حُفظ. يطبق الويدجت التغييرات عند تحميل الصفحة التالي.')); };
  return (
    <div className="awp-page" style={{ maxWidth: 'none' }}>
      <PageHead crumb={<Lnk onClick={() => back()}>{T('AI Capabilities / Embedded Deployment', 'قدرات الذكاء الاصطناعي / النشر المضمّن')}</Lnk>} title={T(d.n, d.nAr)} sub={<span className="awp-mono">{d.id}</span>}><StTag s={d.st} /><Btn type="secondary" label={copied ? T('Copied', 'تم النسخ') : T('Copy embed code', 'نسخ كود التضمين')} icon="Copy01" onClick={() => { try { navigator.clipboard.writeText(snippet); } catch (e) {} setCopied(true); setTimeout(() => setCopied(false), 2000); }} /><Btn label={T('Save changes', 'حفظ التغييرات')} onClick={save} /></PageHead>
      {banner}
      <Tabs value={tab} onChange={setTab} items={[{ id: 'details', label: T('Deployment details', 'تفاصيل النشر') }, { id: 'storylines', label: T('Storylines', 'السيناريوهات'), count: d.sl ? 1 : 0 }, { id: 'preview', label: T('Preview', 'معاينة') }]} />
      {tab === 'details' && <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card title={T('Main details', 'البيانات الرئيسية')}><div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Name (English)', 'الاسم (إنجليزي)')}><input className="awp-input" defaultValue={d.n} /></Field>
          <Field label={T('Name (Arabic)', 'الاسم (عربي)')}><input className="awp-input" defaultValue={d.nAr} dir="rtl" /></Field>
          <Field label={T('Default agent', 'الوكيل الافتراضي')}><div className="awp-row" style={{ gap: 10 }}><PopSelect className="awp-input" value={agent} onChange={(e) => setAgent(e.target.value)}>{AGENTS.filter((x) => x.id !== 'dir').map((x) => <option key={x.id} value={x.id}>{nm(x)}</option>)}</PopSelect><Btn type="secondary" label={T('Agent details', 'تفاصيل الوكيل')} onClick={() => go('agents', { agent })} /></div></Field>
          <Field label={T('Status', 'الحالة')}><PopSelect className="awp-input" defaultValue={d.st}><option value="Enabled">{T('Enabled', 'مفعّل')}</option><option value="Disabled">{T('Disabled', 'معطّل')}</option><option value="Draft">{T('Draft', 'مسودة')}</option></PopSelect></Field>
          <Field label={T('Surfaces', 'الواجهات')}><div className="awp-row" style={{ flexWrap: 'wrap', gap: 6 }}>{['Widget', 'WhatsApp', 'Teams'].map((c) => <button key={c} className={'awp-chip' + (d.surf.includes(c) ? ' on' : '')}>{c}</button>)}</div></Field>
          <Field label={T('Embed code', 'كود التضمين')} hint={T('Paste before the closing body tag of the host website.', 'الصقه قبل وسم body الختامي في الموقع المضيف.')}><pre className="awp-mono" style={{ margin: 0, padding: 12, borderRadius: 12, background: 'var(--surface-sunken)', whiteSpace: 'pre-wrap', direction: 'ltr', textAlign: 'left', overflowWrap: 'anywhere' }}>{snippet}</pre></Field>
        </div></Card>
        <Card title={T('Security & access', 'الأمان والوصول')}><div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Allowed origins', 'المصادر المسموحة')} hint={badOrigin ? <span style={{ color: 'var(--text-danger)' }}>{T('Each origin must be https:// plus a host name, with no path.', 'يجب أن يكون كل مصدر https:// مع اسم المضيف دون مسار.')}</span> : T('The widget only loads on these sites. Separate with commas.', 'يعمل الويدجت على هذه المواقع فقط. افصل بفواصل.')}><input className="awp-input awp-mono" value={origins} onChange={(e) => setOrigins(e.target.value)} /></Field>
          <Field label={T('Visitor identity', 'هوية الزائر')}><PopSelect className="awp-input" value={idm} onChange={(e) => setIdm(e.target.value)}><option value="otp">{T('Anonymous, step-up with OTP', 'مجهول مع تحقق برمز')}</option><option value="jwt">{T('Signed JWT from host site', 'JWT موقع من الموقع المضيف')}</option><option value="uaepass">UAE Pass</option></PopSelect></Field>
          {idm === 'jwt' && <><Field label={T('Visitor token signing secret', 'سر توقيع رمز الزائر')} hint={T('Shown once when created. Enter a new value only to replace it.', 'يُعرض مرة واحدة عند الإنشاء. أدخل قيمة جديدة فقط لاستبداله.')}><input className="awp-input" type="password" autoComplete="new-password" placeholder={T('Saved · enter to replace', 'محفوظ · أدخل للاستبدال')} /></Field><Field label={T('Token policy', 'سياسة الرمز')}><PopSelect className="awp-input"><option>{T('HS256 · expires within 10 minutes · audience awp-widget', 'HS256 · ينتهي خلال 10 دقائق · الجمهور awp-widget')}</option><option>{T('RS256 · JWKS from host · 10 minutes', 'RS256 · JWKS من المضيف · 10 دقائق')}</option></PopSelect></Field></>}
          <Field label={T('Human handoff queue', 'طابور التحويل البشري')}><PopSelect className="awp-input">{PROJECTS.map((p) => <option key={p.k}>{p.k} — {T(p.n, p.nAr)}</option>)}</PopSelect></Field>
          <Field label={T('Rate limit per visitor', 'حد المعدل لكل زائر')}><input className="awp-input" defaultValue="30 / min" /></Field>
        </div></Card>
        <Card title={T('Branding', 'الهوية')}><div className="awp-col" style={{ gap: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(180px,100%),1fr))', gap: 12 }}>
            <Field label={T('Widget title (English)', 'عنوان الويدجت (إنجليزي)')}><input className="awp-input" defaultValue="Tahseel Assistant" /></Field>
            <Field label={T('Widget title (Arabic)', 'عنوان الويدجت (عربي)')}><input className="awp-input" dir="rtl" defaultValue="مساعد تحصيل" /></Field>
          </div>
          <Field label={T('Accent colour', 'لون التمييز')}><div className="awp-row" style={{ gap: 8, flexWrap: 'wrap' }}>{DEP_SWATCH.map((c) => <button key={c} onClick={() => setColor(c)} aria-label={c} style={{ width: 32, height: 32, borderRadius: 999, border: color === c ? '3px solid var(--border-selected)' : '1px solid var(--border-divider)', background: c, cursor: 'pointer' }} />)}<input className="awp-input awp-mono" style={{ width: 120 }} value={color} onChange={(e) => setColor(e.target.value)} /></div></Field>
          {chk.bad ? <Banner tone="danger">{T('Enter a colour as #RRGGBB.', 'أدخل اللون بصيغة #RRGGBB.')}</Banner> : !chk.ok && <Banner tone="danger"><span className="awp-row" style={{ gap: 8, flexWrap: 'wrap' }}>{T('Too light for white text (' + chk.ratio.toFixed(1) + ':1).', 'فاتح جداً للنص الأبيض (' + chk.ratio.toFixed(1) + ':1).')}<span style={{ width: 16, height: 16, borderRadius: 999, background: chk.sug }} /><Lnk onClick={() => setColor(chk.sug)}>{T('Use ' + chk.sug, 'استخدام ' + chk.sug)}</Lnk></span></Banner>}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(180px,100%),1fr))', gap: 12 }}>
            <Field label={T('Welcome message (English)', 'رسالة الترحيب (إنجليزي)')}><input className="awp-input" defaultValue="Welcome. How can I help you today?" /></Field>
            <Field label={T('Welcome message (Arabic)', 'رسالة الترحيب (عربي)')}><input className="awp-input" dir="rtl" defaultValue="مرحباً. كيف يمكنني مساعدتك اليوم؟" /></Field>
          </div>
        </div></Card>
        <Card title={T('Last 30 days', 'آخر 30 يوماً')}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div><div className="awp-small awp-muted">{T('Conversations', 'المحادثات')}</div><div style={{ fontSize: 22, fontWeight: 500 }}>{d.conv.toLocaleString()}</div></div>
            <div><div className="awp-small awp-muted">{T('Rate', 'التقييم')}</div>{d.rate ? <Stars v={d.rate} /> : <span className="awp-muted">—</span>}</div>
          </div>
        </Card>
      </div>}
      {tab === 'storylines' && (d.sl ? <Storyline embedded defaultAgent={agent} /> : <Card><Empty title={T('No storylines yet.', 'لا توجد سيناريوهات بعد.')} text={T('Without a storyline the agent answers freely. Add one to guide visitors through a fixed flow.', 'دون سيناريو يجيب الوكيل بحرية. أضف سيناريو لتوجيه الزوار عبر مسار محدد.')} /></Card>)}
      {tab === 'preview' && <Widget dep={d} accent={chk.ok ? brHex(color) : null} />}
    </div>
  );
}

function NewDeploymentModal({ onClose, onAdd }) {
  const [x, setX] = React.useState({ n: '', nAr: '', a: 'sup' });
  const id = React.useMemo(() => 'dep_' + Math.random().toString(16).slice(2, 8), []);
  return (
    <Modal title={T('New deployment', 'نشر جديد')} onClose={onClose} w={520} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Create deployment', 'إنشاء النشر')} disabled={!x.n.trim() || !x.nAr.trim()} onClick={() => { onAdd({ id, n: x.n.trim(), nAr: x.nAr.trim(), a: x.a, surf: 'Widget', sl: '', rate: 0, conv: 0, st: 'Draft' }); onClose(); }} /></>}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Name (English)', 'الاسم (إنجليزي)')}><input className="awp-input" value={x.n} onChange={(e) => setX({ ...x, n: e.target.value })} /></Field>
        <Field label={T('Name (Arabic)', 'الاسم (عربي)')}><input className="awp-input" dir="rtl" value={x.nAr} onChange={(e) => setX({ ...x, nAr: e.target.value })} /></Field>
      </div>
      <Field label={T('Default agent', 'الوكيل الافتراضي')}><PopSelect className="awp-input" value={x.a} onChange={(e) => setX({ ...x, a: e.target.value })}>{AGENTS.filter((a) => a.id !== 'dir').map((a) => <option key={a.id} value={a.id}>{nm(a)}</option>)}</PopSelect></Field>
      <Field label={T('Deployment ID', 'معرّف النشر')} hint={T('Generated. Used in the embed code.', 'مُولّد. يُستخدم في كود التضمين.')}><input className="awp-input awp-mono" readOnly value={id} /></Field>
    </Modal>
  );
}

function Deployments({ go }) {
  const [rows, setRows] = React.useState(DEPS);
  const [sel, setSel] = React.useState(null);
  const [nw, setNw] = React.useState(false);
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  if (!engageOn()) return <div className="awp-page"><PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Embedded Deployment', 'النشر المضمّن')} /><Card><Empty title={T('Embedded deployments are turned off.', 'النشر المضمّن معطّل.')} text={T('Turn on "Embedded deployments" in Settings › Feature flags to publish agents to websites and channels.', 'فعّل "النشر المضمّن" في الإعدادات › خيارات الميزات لنشر الوكلاء على المواقع والقنوات.')}><Pill onClick={() => go('settings')}>{T('Open Settings', 'فتح الإعدادات')}</Pill></Empty></Card></div>;
  if (sel) return <DeploymentDetail d={sel} back={() => setSel(null)} go={go} />;
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Embedded Deployment', 'النشر المضمّن')} sub={T('Agents published to websites and channels, with branding, security and storylines.', 'وكلاء منشورون على المواقع والقنوات مع الهوية والأمان والسيناريوهات.')}><Btn label={T('New deployment', 'نشر جديد')} icon="AddCircle" onClick={() => setNw(true)} /></PageHead>
      {banner}
      <Card pad={false}>{rows.length ? <DataTable onRow={setSel} rows={rows} cols={[
        { h: T('Deployment', 'النشر'), r: (r) => <div><b>{T(r.n, r.nAr)}</b><div className="awp-small awp-muted awp-mono">{r.id}</div></div> },
        { h: T('Default agent', 'الوكيل الافتراضي'), r: (r) => <div className="awp-row" style={{ gap: 8 }}><Who id={r.a} s={24} />{aName(r.a)}</div> },
        { h: T('Surfaces', 'الواجهات'), r: (r) => r.surf },
        { h: T('Storyline', 'السيناريو'), r: (r) => <span className="awp-small">{r.sl || <span className="awp-muted">{T('None', 'لا يوجد')}</span>}</span> },
        { h: T('Status', 'الحالة'), r: (r) => <StTag s={r.st} /> },
        { h: T('Rate', 'التقييم'), r: (r) => r.rate ? <Stars v={r.rate} /> : <span className="awp-muted">{T('No ratings yet', 'لا تقييمات بعد')}</span> },
        { h: '', end: true, r: (r) => <Lnk danger onClick={() => setConf({ title: T('Delete ' + r.n + '?', 'حذف ' + r.nAr + '؟'), intro: r.conv ? T('The widget stops on every site and ' + r.conv.toLocaleString() + ' conversations are archived.', 'يتوقف الويدجت في كل المواقع وتُؤرشف ' + r.conv.toLocaleString() + ' محادثة.') : T('It has no conversations yet.', 'لا توجد محادثات بعد.'), confirm: T('Delete deployment', 'حذف النشر'), onConfirm: () => { setRows(rows.filter((y) => y !== r)); setBanner('success', T('Deployment deleted.', 'حُذف النشر.')); } })}>{T('Delete', 'حذف')}</Lnk> },
      ]} /> : <Empty title={T('No deployments yet.', 'لا توجد عمليات نشر بعد.')} />}</Card>
      {nw && <NewDeploymentModal onClose={() => setNw(false)} onAdd={(d) => { setRows([...rows, d]); setSel(d); }} />}
      {conf}
    </div>
  );
}

function Audit() {
  const [who, setWho] = React.useState('all');
  const [per, setPer] = React.useState('today');
  const [act, setAct] = React.useState('');
  const [out, setOut] = React.useState('all');
  const [banner, setBanner] = useBanner();
  const rows = [['10:41', 'u3', 'approval.approve', 'CS-118', T('Per-diem change set', 'مجموعة تغييرات البدل'), 'Allowed', ['inbox', { sel: 2 }]], ['10:40', 'dir', 'setup.apply_change_set', 'CS-118', T('Blueprint v13 → v14', 'المخطط v13 ← v14'), 'Allowed', ['setup']], ['10:12', 'u4', 'agent.publish', 'Expense Reviewer v7', '', 'Allowed', ['agents', { agent: 'exp' }]], ['09:58', 'exp', 'memory.write', '/memories/agents/expense-reviewer/procedures.md', 'v14', 'Allowed', ['memory']], ['09:30', 'u1', 'secret.read', 'erp/oauth_client', T('Reveal denied (never returned)', 'رُفض الكشف (لا يُعاد أبداً)'), 'Denied', ['connectors']], ['08:52', 'prc', 'approval.request', 'PO-7781', T('T2 tool erp/purchase_order.submit', 'أداة T2 erp/purchase_order.submit'), 'Allowed', ['inbox', { sel: 1 }]], ['08:01', 'u2', 'auth.login', 'SSO', 'WebAuthn', 'Allowed', null], ['Yesterday 17:20', 'u5', 'budgets.write', 'Customer Assistant', T('Missing permission', 'صلاحية غير متوفرة'), 'Denied', ['budgets']]];
  const list = rows.filter((r) => (per !== 'today' || !/Yesterday/.test(r[0])) && (who === 'all' || (who === 'agent' ? AGENTS.find((a) => a.id === r[1]) : !AGENTS.find((a) => a.id === r[1]))) && (!act || r[2].includes(act.toLowerCase())) && (out === 'all' || r[5] === out));
  return (
    <div className="awp-page">
      <PageHead crumb={T('Govern', 'الحوكمة')} title={T('Audit log', 'سجل الإجراءات')} sub={T('Append-only record of configuration, permissions, approvals, publishes, secret access, exports and logins.', 'سجل إلحاقي فقط للإعدادات والأذونات والاعتمادات والنشر والوصول للأسرار والتصدير وتسجيل الدخول.')}><Btn type="secondary" label={T('Export CSV', 'تصدير CSV')} icon="Download04" disabled={!list.length} onClick={() => setBanner('success', T(list.length + ' rows exported. The export itself is recorded in the audit log.', 'صُدّر ' + list.length + ' صفاً. يُسجّل التصدير نفسه في سجل التدقيق.'))} /></PageHead>
      {banner}
      <div className="awp-row" style={{ gap: 12, flexWrap: 'wrap' }}>
        <Chips value={per} onChange={setPer} items={[{ id: 'today', label: T('Today', 'اليوم') }, { id: '7d', label: T('Last 7 days', 'آخر 7 أيام') }, { id: '30d', label: T('Last 30 days', 'آخر 30 يوماً') }]} />
        <Chips value={who} onChange={setWho} items={[{ id: 'all', label: T('All actors', 'كل الفاعلين') }, { id: 'human', label: T('People', 'الأشخاص') }, { id: 'agent', label: T('Agents', 'الوكلاء') }]} />
        <Chips value={out} onChange={setOut} items={[{ id: 'all', label: T('Any outcome', 'أي نتيجة') }, { id: 'Allowed', label: T('Allowed', 'مسموح') }, { id: 'Denied', label: T('Denied', 'مرفوض') }]} />
        <input className="awp-input awp-mono" style={{ maxWidth: 220 }} value={act} onChange={(e) => setAct(e.target.value)} placeholder={T('Action, e.g. approval', 'الإجراء، مثل approval')} />
      </div>
      <Card pad={false}>{list.length ? <DataTable rows={list} cols={[
        { h: T('Time', 'الوقت'), r: (r) => <span className="awp-mono">{T(r[0], r[0].replace('Yesterday', 'أمس'))}</span> },
        { h: T('Actor', 'الفاعل'), r: (r) => <div className="awp-row"><Who id={r[1]} s={24} />{aName(r[1])}</div> },
        { h: T('Action', 'الإجراء'), r: (r) => <span className="awp-mono">{r[2]}</span> },
        { h: T('Object', 'الكائن'), r: (r) => r[6] ? <Lnk onClick={() => window.__awpGo(r[6][0], r[6][1])}><span className="awp-mono awp-small">{r[3]}</span></Lnk> : <span className="awp-mono awp-small">{r[3]}</span> },
        { h: T('Outcome', 'النتيجة'), r: (r) => <Tg tone={r[5] === 'Allowed' ? 'success' : 'danger'} dot label={r[5] === 'Allowed' ? T('Allowed', 'مسموح') : T('Denied', 'مرفوض')} /> },
        { h: T('Detail', 'التفاصيل'), r: (r) => <span className="awp-small awp-muted">{r[4]}</span> },
      ]} /> : <Empty title={T('No audit entries match.', 'لا توجد سجلات مطابقة.')}><Pill onClick={() => { setWho('all'); setAct(''); setOut('all'); setPer('30d'); }}>{T('Clear filters', 'مسح عوامل التصفية')}</Pill></Empty>}</Card>
    </div>
  );
}

function Logs() {
  const [lvl, setLvl] = React.useState('all');
  const [svc, setSvc] = React.useState('any');
  const [run, setRun] = React.useState('');
  const rows = [['10:42:11.204', 'WARN', 'model-gateway', 'RUN-88229', 'vllm/qwen3-32b timeout after 30s, falling back to claude-haiku-4.5'], ['10:41:58.090', 'INFO', 'agent-service', 'RUN-88231', 'workflow signal approval.decided received'], ['10:40:02.511', 'ERROR', 'connector:cards', 'RUN-88210', 'circuit open: 5 consecutive 503 from cards/block'], ['10:39:47.330', 'INFO', 'web', '—', 'change set CS-118 applied (14 objects)'], ['10:38:12.002', 'DEBUG', 'harness', 'RUN-88231', 'context blocks: sys 6.5k, skills 5.1k, work_item 7.9k'], ['10:37:00.871', 'WARN', 'channel:whatsapp', '—', 'template awp_card_update rejected (policy)']];
  const svcs = [...new Set(rows.map((r) => r[2]))];
  const list = rows.filter((r) => (lvl === 'all' || r[1] === lvl) && (svc === 'any' || r[2] === svc) && (!run || r[3].toLowerCase().includes(run.toLowerCase())));
  const tone = { INFO: 'info', WARN: 'warning', ERROR: 'danger', DEBUG: 'neutral' };
  return (
    <div className="awp-page">
      <PageHead crumb={T('Govern', 'الحوكمة')} title={T('Logs', 'السجلات')} sub={T('Application and run logs across services.', 'سجلات التطبيق والعمليات عبر الخدمات.')} />
      <div className="awp-row" style={{ gap: 12, flexWrap: 'wrap' }}>
        <Chips value={lvl} onChange={setLvl} items={[{ id: 'all', label: T('All levels', 'كل المستويات') }, ...['ERROR', 'WARN', 'INFO', 'DEBUG'].map((l) => ({ id: l, label: l }))]} />
        <Sel value={svc} onChange={setSvc} w={220} opts={[['any', T('All services', 'كل الخدمات')], ...svcs.map((s) => [s, s])]} />
        <input className="awp-input awp-mono" style={{ maxWidth: 180 }} value={run} onChange={(e) => setRun(e.target.value)} placeholder="RUN-…" />
      </div>
      <Card pad={false}>{list.length ? <div style={{ direction: 'ltr' }}><DataTable rows={list} cols={[
        { h: 'Time', r: (r) => <span className="awp-mono">{r[0]}</span> }, { h: 'Level', r: (r) => <Tg tone={tone[r[1]]} label={r[1]} /> }, { h: 'Service', r: (r) => <button className="awp-lnk-t awp-mono" onClick={() => setSvc(r[2])}>{r[2]}</button> }, { h: 'Run', r: (r) => r[3] === '—' ? <span className="awp-mono">—</span> : <Lnk onClick={() => window.__awpGo('run', { id: r[3] })}><span className="awp-mono">{r[3]}</span></Lnk> }, { h: 'Message', r: (r) => <span className="awp-mono">{r[4]}</span> },
      ]} /></div> : <Empty title={T('No log lines match.', 'لا توجد سطور سجل مطابقة.')}><Pill onClick={() => { setLvl('all'); setSvc('any'); setRun(''); }}>{T('Clear filters', 'مسح عوامل التصفية')}</Pill></Empty>}</Card>
    </div>
  );
}
window.AWP_MODALS.configChannel = ConfigChannelDrawer;
Object.assign(window, { Channels, Deployments, Audit, Logs, DEPS });
