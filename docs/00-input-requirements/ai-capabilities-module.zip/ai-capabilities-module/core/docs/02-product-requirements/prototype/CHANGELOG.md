## 2026-10-17 — Handoff gaps (D & E)
- Navigation: Setup Director removed from the menu; opens from the AI assistant ("Request a change to the setup", with documents) and from Inbox change-set items. Documentation moved to a new Help group.
- Branding: Settings saves a brand colour (WCAG check, suggested shade) that re-tints buttons, links and active nav; light/dark logos and favicon uploads replace the menu mark.
- Shared states: banners, empty states, impact/blocked delete dialogs, unsaved-changes guard (awp-states.jsx).
- Inbox, Discussion Rooms, Work Items, Setup Director, Projects, Requests (+ type designer, New Request), Scheduled Work Items, Artifacts/Files (preview, upload checks, quarantine), Connectors, Memory, Knowledge, Models & routes, Org chart, People & roles, Org units, Agents (config, instructions, skills/tools/knowledge/memory tabs), Run viewer, Skills (+ import review), Channels, Embedded Deployment, Storyline (simulate, publish checks), Widget (runtime states, OTP), Budgets, Audit, Logs, Integrations, System, Documentation, My profile, Search palette: controls, validation, refusal reasons and empty states from the implementation list.
- New files: awp-states, awp-brand, awp-work, awp-rooms, awp-setup, awp-projects, awp-requests, awp-newreq, awp-sched, awp-org, awp-agents, awp-engage, awp-govern. awp-screens-5.jsx removed (moved to awp-org.jsx).

# Tahseel AWP Console — Change Log

The interactive prototype is `AWP Console.html`. It is bilingual (English/Arabic RTL), supports light and dark themes, and is built on the Tahseel Design System.

This log lists every change requested in the chat, in order, ending with the current version.

---

## 1. Initial build
- Screens built from the platform specification: shell, Dashboard, Sessions, Session room, Tasks, Inbox, Setup Director, Agents, Run viewer, Storyline and Widget.
- **Shell:**
  - Sidebar navigation and top bar.
  - Theme toggle (light/dark) and language toggle (EN/AR, with RTL mirroring).
  - Global search (⌘K).

## 2. Full specification coverage
- Every screen listed in the specification was added:
  - **Work:** Projects, Requests, Routines, Artifacts and Files, plus the New Task and New Session modals.
  - **Organisation & capabilities:** Org chart, People & roles, Org units, Skills, Connectors, Memory, Knowledge and Models.
  - **Engage & govern:** Channels, Budgets, Audit, Logs, Settings, Keys, System and Docs.
- The navigation follows the full information architecture, and every page is wired up.

## 3. Review comments applied
- **Every action is interactive.** Every button and sub-button opens a modal or detail screen that shows what the function does. There is a fallback action modal for anything else.
- **Shell:**
  - A real Toggle component and a regrouped navigation.
  - A user menu with Profile and Log out.
  - Top-bar buttons for New Room, New Work Item and New Request.
  - The health indicator was removed.
- **Renamed:**
  - Sessions → **Discussion Rooms**. Rooms belong to a project, the default status filter is Active, and the room has no tabs.
  - Tasks → **Work Items**.
- **Requests** was rewritten:
  - Filters, a request detail page, and a request type detail page with steps, audiences and routing.
  - Submission in two modes: form and agentic.
- **Scheduled work items** (Routines), with a "New scheduled item" modal.
- **Agents:** a Runs list tab and a run detail page.
- **Artifacts and Files:**
  - Grouped by project, with list and card views.
  - View, activate and delete actions, and a file scope setting.
- **Org chart:** an interactive chart view and a list view.
- **AI Capabilities** contains Agents and Agent trust.
- **Skills:** a skills import.
- **Channels:** add, test and configure.
- **Embedded Deployment:** a list, a deployment detail page, and storylines with step customisation.
- **Removed:** Webhooks, Pairing and Approval policies.
- **Settings:** tabs, including a branding tab for logo and colour.
- **Integrations:** a clients section.

## 4. Channels
- Only **enable/disable** and **Configure** remain; "Add custom channel" was removed.
- Web, WhatsApp and MS Teams are available. All other channels are marked **Coming soon**.

## 5. Navigation
- **Channels** and **Embedded Deployment** moved to **AI Capabilities**.
- **Blueprint** was removed from Settings.

## 6. Dashboard and costs
- **Dashboard** is the default landing page.
- Every cost figure is labelled **Estimated cost**.

## 7. Work items and routes
- **Work Items** shows **Hot items** by default and has **Advanced search**.
- **Models & routes:** the routes list includes:
  - a **type-safe classification** route (`classifier-typed`);
  - a **voice** route.

## 8. Knowledge
- Each collection has its own page with two tabs:
  - **Details — document sources:** a list of sources (upload, URL crawl or MCP resource) with document count and status. Sources can be added, re-indexed or removed.
  - **Configuration**, in four groups:
    - Index: index type, distance metric, HNSW m / ef_construct, quantisation.
    - Chunking: technique, chunk size, overlap, pre-processing (OCR, Arabic normalisation, header/footer stripping, PII masking).
    - Models: embedding route and dimensions, entity-extraction route for the graph, re-ranker.
    - Retrieval & sync: top-k, minimum score, sync schedule, visibility, maximum collection size.
- **New collection** asks for name, project, index type, chunking, embedding route and visibility.
- **Explore graph** was replaced by **Test knowledge retrieval**, a popup with a query box, a Vector / Graph / Hybrid switch, passages with scores, and graph facts.
- The retrieval test opens from the page header (all collections), from each collection row, or from the collection page.

## 9. Agents and Connectors
- **Agent trust** is a single field in the agent's main data: Restricted, Standard, and so on.
- **Connectors (MCP)** was renamed to **Connectors**.
- **Tool tiers** are no longer a separate page; they are now a property of each MCP connector.
- The Review tab was removed.
- **Browse tab:** each connector has a **+** button to add and configure it.
- **Connected tab:** the connector title opens its configuration, so it can be updated at any time.

## 10. Codes and dashboard drill-down
- **Codes and keys:** users no longer type them in. The field is moved to the end of the form and the system suggests a value from the name or title, which the user can edit.
- **Dashboard cards** are clickable. For example, "SLA at risk" opens a list of the matching records, with search and navigation to each record's detail.

## 11. Sub items
- "Subtasks" was renamed **Sub items** everywhere: drawer, type tags, filters, the New Work Item form and the Skills description.
- Each work item has its own data:
  - project, reviewer and request type;
  - an origin link, attributes and activity;
  - a parent link (on sub items);
  - sub items that can be ticked done, with progress shown.
- Action buttons depend on status:
  - Blocked: Unblock and Assign to agent.
  - In review: Approve and Request changes.
  - Done: Reopen.
  - Anything else: Submit for review and Assign to agent.
- **Fixes:**
  - The Work Items list view shows the proper status labels as coloured tags.
  - TSK-2325 now has the same project as its parent.

## 12. Detail layout
- Requests, sub requests and work items all use the same order: **header → main info → tabs**.
- **Request detail:**
  - Header: title, key, type, project, status and actions.
  - Main info card:
    - a step tracker and the description;
    - a key details grid: project, type, requester, submitted, channel, current step, SLA, and parent request where there is one;
    - the request type's attributes;
    - attachments, with preview and add.
  - Tabs: History & audit, Sub requests and Work items.
  - Sub requests open on the same layout, with breadcrumbs back to the parent.
- **Work item drawer:**
  - Header and tags.
  - Main info: details, description, attributes and attachments.
  - Tabs: Sub items and Activity.

## 13. Budgets & estimated costs
- Budgets apply to **agents**.
- **Effective from / to** dates, with a **Keep forever (no end date)** switch.
- Budget status is Active, Scheduled or Expired, and the list can be filtered by status.
- Each budget has a limit, a period (daily, weekly, monthly or quarterly), a warning percentage, and an action at 100%: notify only, switch to a cheaper alias, or pause the agent.
- **Budget detail:**
  - Cards for limit, estimated spend, estimated forecast and the action at 100%.
  - A 6-month **consumption history** chart coloured by usage, and a daily chart for the current month.
  - A **period history** table with runs and events (warning sent or hard limit reached).
  - A log of budget changes, and an Open agent button.

## 14. Memory
- **Header:** title, subtitle and a New memory button.
- **Cards:** Total memories, Pending review, Active agents and Needs attention.
- **Search** across memories, policies, agents and keywords, with a filter button and scope chips: All scopes, Organisation, Business unit, Agent, Session.
- **Memory explorer:** a collapsible tree (Organisation, Finance, an agent such as Expense Reviewer, Sessions). Memories pending review or needing attention have a status dot.
- **Detail panel:**
  - Title, path and status.
  - Version number with History.
  - Each memory entry with its source.
  - Memory details: scope, owner, last reviewed, access, write policy.
  - An Edit memory button.
  - A warning for overdue reviews, and Approve / Reject for pending memories.
- **Modals:**
  - Version history, with Compare and Restore.
  - Edit, which saves as a new version and takes a change note.
  - New memory.

---

## 15. Responsive
- Mobile slide-out sidebar with hamburger; tablet icon rail; inline 2-column grids stack on phones; wide tables scroll inside cards; theme/language move into the user menu under 480px.

## 16. Arabic terminology (Tahseel)
- منصة العمل الوكيلي → منصة العمل بالوكلاء · مؤسسة تحصيل → تحصيل · المالك → المستخدم
- غرف النقاش → اجتماعات العمل (statuses in masculine: نشط، متوقف، مغلق…)
- Nav group العمل → إدارة الأعمال
- عناصر العمل → بنود العمل · العناصر الفرعية → البنود الفرعية
- البريد الوارد → صندوق الوارد · المؤسسة → الجهة · الأشخاص والوكلاء → الموظفين والوكلاء · غرفة عمليات → غرفة طوارئ
- الموصلات → التكامل · المعرفة → قاعدة المعرفة · الميزانيات والتكاليف التقديرية → تكاليف تشغيل الذكاء الاصطناعي · سجل التدقيق → سجل الإجراءات · التوثيق → المساعدة

## Files
- **Entry point:** `AWP Console.html`.
- **Shell and actions:** `awp-shell.jsx`, `awp-app.jsx`, `awp-actions.jsx`.
- **Screens:** `awp-screens-1.jsx` … `awp-screens-6.jsx`.
- **Feature modules:** `awp-knowledge.jsx`, `awp-memory.jsx`, `awp-budgets.jsx`, `awp-connectors.jsx`, `awp-models.jsx`, `awp-records.jsx`.
- **Design system:** `_ds/tahseel-design-system-…/`.

## Known limitations
- All data is illustrative sample data, including the KPIs, budget history and retrieval results.
- Several detail views reuse the same sample data: request attachments and work items, memory version history, and work item descriptions, which are built from the title and attributes.
