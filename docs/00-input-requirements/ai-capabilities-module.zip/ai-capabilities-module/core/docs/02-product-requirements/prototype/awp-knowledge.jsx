const KCOLS = [
  { id: 'pol', n: 'Policies', nAr: 'السياسات', st: 'Healthy', docs: 142, chunks: 9840, ents: 1210, sync: '2h', idx: 'Hybrid (vector + graph)', chunk: 'Semantic', size: 800, overlap: 120, emb: 'embedding-default', ext: 'classifier-typed', rr: true, k: 8, store: 'Qdrant · Neo4j', p: 'FIN', vis: 'Organisation' },
  { id: 'svc', n: 'Service catalogue', nAr: 'دليل الخدمات', st: 'Healthy', docs: 386, chunks: 18220, ents: 3104, sync: '6h', idx: 'Vector (HNSW)', chunk: 'Recursive by headings', size: 600, overlap: 80, emb: 'embedding-default', ext: '—', rr: true, k: 6, store: 'Qdrant', p: 'CS', vis: 'Organisation' },
  { id: 'faq', n: 'Customer FAQs', nAr: 'الأسئلة الشائعة', st: 'Healthy', docs: 64, chunks: 1120, ents: 0, sync: '1d', idx: 'Vector (HNSW)', chunk: 'Q&A pairs', size: 400, overlap: 0, emb: 'embedding-default', ext: '—', rr: false, k: 4, store: 'Qdrant', p: 'CS', vis: 'Public (widget)' },
  { id: 'run', n: 'IT runbooks', nAr: 'أدلة تشغيل التقنية', st: 'Degraded', docs: 210, chunks: 7400, ents: 2080, sync: '3d', idx: 'Hybrid (vector + graph)', chunk: 'Fixed size', size: 1000, overlap: 150, emb: 'embedding-default', ext: 'reasoning-default', rr: true, k: 8, store: 'Qdrant · Neo4j', p: 'IT', vis: 'Project' },
  { id: 'ven', n: 'Vendor contracts', nAr: 'عقود الموردين', st: 'Ingesting', docs: 482, chunks: 12400, ents: 1016, sync: T('now', 'الآن'), idx: 'Hybrid (vector + graph)', chunk: 'Semantic', size: 800, overlap: 120, emb: 'local-private', ext: 'local-private', rr: true, k: 10, store: 'Qdrant · Neo4j', p: 'PRC', vis: 'Project' },
];
const KSRC0 = [
  { n: 'FIN-POL-007 Travel & Expense Policy.pdf', kind: 'Upload', docs: 1, st: 'Indexed', at: '1 Oct' },
  { n: 'SharePoint · /sites/finance/policies', kind: 'MCP · m365', docs: 118, st: 'Indexed', at: '2h' },
  { n: 'https://tahseel.ae/en/policies', kind: 'URL crawl', docs: 21, st: 'Indexed', at: '6h' },
  { n: 'HR-POL-2026 Leave Policy.docx', kind: 'Upload', docs: 1, st: 'Failed', at: '3d', err: ['The file is password-protected, so its text could not be read.', 'الملف محمي بكلمة مرور، لذا تعذّرت قراءة نصه.'] },
  { n: 'Procurement handbook v4.pdf', kind: 'Upload', docs: 1, st: 'Queued', at: T('now', 'الآن') },
];
const srcTone = { Indexed: 'success', Failed: 'danger', Queued: 'info' };

function RetrievalTest({ c }) {
  const graphOn = !window.AWP_FLAGS || window.AWP_FLAGS['GraphRAG retrieval'] !== false;
  const graphIdx = !c || /graph/i.test(c.idx);
  const canGraph = graphOn && graphIdx;
  const [mode, setMode] = React.useState(canGraph ? 'hybrid' : 'vector');
  const [q, setQ] = React.useState(T('What is the hotel per-diem in Riyadh?', 'ما بدل الفندق اليومي في الرياض؟'));
  const [res, setRes] = React.useState(null);
  const run = () => { setRes('run'); setTimeout(() => setRes(c && c.st === 'Degraded' ? 'fail' : /per-?diem|hotel|riyadh|بدل|فندق|الرياض/i.test(q) ? 'ok' : 'none'), 700); };
  const pick = (m) => { if ((m === 'graph' || m === 'hybrid') && !canGraph) return; setMode(m); };
  return (
    <div className="awp-col" style={{ gap: 14 }}>
      <div className="awp-row" style={{ gap: 10, flexWrap: 'wrap' }}><input className="awp-input" style={{ flex: 1, minWidth: 220 }} value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && run()} /><Seg value={mode} onChange={pick} items={[{ id: 'vector', label: T('Vector', 'متجهي') }, { id: 'graph', label: T('Graph', 'رسومي') }, { id: 'hybrid', label: T('Hybrid', 'هجين') }]} /><Btn label={res === 'run' ? T('Searching…', 'جارٍ البحث…') : T('Run test', 'تشغيل الاختبار')} disabled={!q.trim() || res === 'run'} onClick={run} /></div>
      {!canGraph && <span className="awp-small awp-muted">{!graphOn ? T('Graph and Hybrid are unavailable because graph retrieval is turned off in Settings.', 'الوضعان الرسومي والهجين غير متاحين لأن الاسترجاع الرسومي معطّل في الإعدادات.') : T('Graph and Hybrid need a graph index. This collection uses ' + c.idx + '.', 'يحتاج الوضعان الرسومي والهجين إلى فهرس رسومي. تستخدم هذه المجموعة ' + c.idx + '.')}</span>}
      <div className="awp-small awp-muted">{T('Collection', 'المجموعة')}: <b>{c ? T(c.n, c.nAr) : T('All collections', 'كل المجموعات')}</b> · top-k {c ? c.k : 8}{(!c || c.rr) ? ' · ' + T('re-ranked', 'مُعاد ترتيبه') : ''}</div>
      {res === 'fail' && <Banner tone="danger">{T('The test failed: the vector store for this collection did not respond. Try again, or check System health.', 'فشل الاختبار: لم يستجب مخزن المتجهات لهذه المجموعة. أعد المحاولة أو راجع صحة النظام.')}</Banner>}
      {res === 'none' && <Empty title={T('No results above the minimum score.', 'لا توجد نتائج فوق الحد الأدنى للدرجة.')} text={T('Try other words, lower the minimum score, or add sources that cover this topic.', 'جرّب كلمات أخرى أو اخفض الحد الأدنى للدرجة أو أضف مصادر تغطي الموضوع.')} />}
      {res === 'ok' && <>
        {mode !== 'graph' && <div className="awp-card" style={{ padding: 12, background: 'var(--surface-card)' }}><div className="awp-small awp-muted awp-mono">FIN-POL-007#c14 · 0.89{(!c || c.rr) && <> · {T('re-ranked from #3', 'أُعيد ترتيبه من #3')}</>}</div>{T('Section 4.2: Hotel accommodation in Riyadh is reimbursed up to AED 900 per night effective 1 October 2026.', 'البند 4.2: يُعوَّض السكن الفندقي في الرياض حتى 900 د.إ لليلة اعتباراً من 1 أكتوبر 2026.')}</div>}
        {mode !== 'graph' && <div className="awp-card" style={{ padding: 12, background: 'var(--surface-card)' }}><div className="awp-small awp-muted awp-mono">FIN-POL-007#c15 · 0.81</div>{T('Section 4.3: Nights above the limit require Work Lead approval before travel.', 'البند 4.3: الليالي فوق الحد تتطلب اعتماد قائد العمل قبل السفر.')}</div>}
        {mode !== 'vector' && <div className="awp-card" style={{ padding: 12, background: 'var(--surface-card)' }}><div className="awp-small awp-muted awp-mono">{T('graph fact', 'حقيقة رسومية')}</div>(Riyadh) —[PER_DIEM_LIMIT]→ (AED 900) —[DEFINED_IN]→ (FIN-POL-007)</div>}
        <div className="awp-small awp-muted">{T('Retrieved in 182 ms', 'استُرجع خلال 182 م.ث')}</div>
      </>}
      {res === null && <span className="awp-small awp-muted">{T('Enter a question and run the test to see what agents would retrieve.', 'أدخل سؤالاً وشغّل الاختبار لترى ما ستسترجعه الوكلاء.')}</span>}
    </div>
  );
}

function useIngest(c) {
  const [p, setP] = React.useState(62);
  React.useEffect(() => { if (!c || c.st !== 'Ingesting') return; const t = setInterval(() => setP((x) => Math.min(100, x + 3)), 4000); return () => clearInterval(t); }, [c && c.st]);
  return p;
}
const K_OK = /\.(pdf|docx|xlsx|html?|md|txt|csv)$/i;

function CollectionDetail({ c, back }) {
  const [tab, setTab] = React.useState('details');
  const [src, setSrc] = React.useState(KSRC0);
  const [cfg, setCfg] = React.useState(c);
  const [test, setTest] = React.useState(false);
  const [add, setAdd] = React.useState(false);
  const [kind, setKind] = React.useState('Upload');
  const [ups, setUps] = React.useState([]);
  const [upErr, setUpErr] = React.useState('');
  const [ocr, setOcr] = React.useState(true);
  const [maxMb, setMaxMb] = React.useState('10240');
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  const prog = useIngest(c);
  const set = (k) => (e) => setCfg({ ...cfg, [k]: e.target ? e.target.value : e });
  const ovBad = +cfg.overlap >= +cfg.size;
  const failed = src.filter((x) => x.st === 'Failed');
  const save = () => { if (ovBad) return setBanner('danger', T('Not saved. Overlap must be smaller than the chunk size.', 'لم يُحفظ. يجب أن يكون التداخل أصغر من حجم المقطع.')); setBanner('success', cfg.emb !== c.emb ? T('Saved. The embedding route changed, so the whole collection is being re-indexed.', 'حُفظ. تغيّر مسار التضمين، لذا تُعاد فهرسة المجموعة كاملة.') : T('Configuration saved.', 'حُفظت الإعدادات.')); };
  const addFiles = (fs) => { const bad = fs.filter((f) => !K_OK.test(f.name) || f.size > 50 * 1048576); setUpErr(bad.length ? T(bad[0].name + ' was refused: ' + (!K_OK.test(bad[0].name) ? 'this file type is not supported.' : 'it is larger than 50 MB.'), 'رُفض ' + bad[0].name + ': ' + (!K_OK.test(bad[0].name) ? 'نوع الملف غير مدعوم.' : 'حجمه أكبر من 50 م.ب.')) : ''); setUps((u) => [...u, ...fs.filter((f) => !bad.includes(f)).map((f) => f.name)]); };
  const sel = (k, opts) => <PopSelect className="awp-input" value={cfg[k]} onChange={set(k)}>{opts.map((o) => <option key={o}>{o}</option>)}</PopSelect>;
  return (
    <div className="awp-page">
      <PageHead crumb={<Lnk onClick={back}>{T('AI Capabilities / Knowledge', 'قدرات الذكاء الاصطناعي / قاعدة المعرفة')}</Lnk>} title={T(c.n, c.nAr)} sub={<span className="awp-mono">{c.id} · {c.store}</span>}>
        <StTag s={c.st === 'Ingesting' ? 'In Progress' : c.st} />
        <Btn type="secondary" label={T('Test retrieval', 'اختبار الاسترجاع')} onClick={() => setTest(true)} />
        <Btn label={T('Save changes', 'حفظ التغييرات')} onClick={save} />
        <button className="awp-iconbtn" aria-label={T('Delete collection', 'حذف المجموعة')} title={T('Delete collection', 'حذف المجموعة')} onClick={() => setConf({ title: T('Delete ' + c.n + '?', 'حذف ' + c.nAr + '؟'), intro: T('Its ' + c.docs + ' documents, chunks and graph entities are removed from the stores. Agents with access lose it from their next run.', 'تُزال مستنداتها الـ ' + c.docs + ' ومقاطعها وكياناتها الرسومية من المخازن. تفقدها الوكلاء من العملية التالية.'), confirm: T('Delete collection', 'حذف المجموعة'), onConfirm: () => back(c.id) })}><Ic n="DeleteDS" s={18} /></button>
      </PageHead>
      {banner}
      {c.st === 'Ingesting' && <Card><div className="awp-col" style={{ gap: 8 }}><div className="awp-row"><b style={{ flex: 1 }}>{prog < 100 ? T('Ingesting documents', 'جارٍ إدخال المستندات') : T('Ingestion complete', 'اكتمل الإدخال')}</b><span className="awp-small awp-muted">{prog}% · {Math.round(c.docs * prog / 100)} / {c.docs}</span></div><Bar h={6} parts={[{ v: prog, c: 'var(--action-primary-bg)' }]} /><span className="awp-small awp-muted">{T('Updates every few seconds.', 'يتحدث كل بضع ثوانٍ.')}</span></div></Card>}
      {failed.length > 0 && <Banner tone="danger"><span className="awp-row" style={{ gap: 12, flexWrap: 'wrap' }}><span style={{ flex: 1 }}>{T(failed.length + ' source failed to ingest. Agents will not find its content.', 'فشل إدخال ' + failed.length + ' مصدر. لن تجد الوكلاء محتواه.')}</span><Lnk onClick={() => setSrc(src.map((x) => x.st === 'Failed' ? { ...x, st: 'Queued', err: null, at: T('now', 'الآن') } : x))}>{T('Re-index failed', 'إعادة فهرسة الفاشل')}</Lnk></span></Banner>}
      <KpiRow items={[{ label: T('Documents', 'المستندات'), value: c.docs.toLocaleString() }, { label: T('Chunks', 'المقاطع'), value: c.chunks.toLocaleString() }, { label: T('Entities', 'الكيانات'), value: c.ents.toLocaleString() }, { label: T('Last sync', 'آخر مزامنة'), value: c.sync }]} />
      <Tabs value={tab} onChange={setTab} items={[{ id: 'details', label: T('Details — document sources', 'التفاصيل — مصادر المستندات'), count: src.length }, { id: 'config', label: T('Configuration', 'الإعدادات') }]} />
      {tab === 'details' && <Card pad={false} title={T('Document sources', 'مصادر المستندات')} actions={<><Btn type="secondary" label={T('Re-index all', 'إعادة الفهرسة للكل')} onClick={() => { setSrc(src.map((x) => ({ ...x, st: 'Queued', err: null, at: T('now', 'الآن') }))); setBanner('success', T('All sources queued for re-indexing.', 'وُضعت كل المصادر في طابور إعادة الفهرسة.')); }} /><Btn label={T('Add source', 'إضافة مصدر')} icon="AddCircle" onClick={() => setAdd(true)} /></>}>
        {!src.length ? <Empty title={T('No document sources yet.', 'لا توجد مصادر مستندات بعد.')} text={T('Add files, a website or an MCP resource to fill this collection.', 'أضف ملفات أو موقعاً أو مورد MCP لملء هذه المجموعة.')}><Pill onClick={() => setAdd(true)}>{T('Add source', 'إضافة مصدر')}</Pill></Empty> : <DataTable rows={src} cols={[
          { h: T('Source', 'المصدر'), r: (s) => <div className="awp-col" style={{ gap: 2 }}><div className="awp-row"><Ic n="File01" s={18} /><b style={{ wordBreak: 'break-all' }}>{s.n}</b></div>{s.err && <span className="awp-small" style={{ color: 'var(--text-danger)' }}>{T(...s.err)}</span>}</div> },
          { h: T('Type', 'النوع'), r: (s) => s.kind },
          { h: T('Documents', 'المستندات'), end: true, r: (s) => s.docs },
          { h: T('Status', 'الحالة'), r: (s) => <Tg tone={srcTone[s.st]} dot label={T(s.st, { Indexed: 'مفهرس', Failed: 'فشل', Queued: 'في الطابور' }[s.st])} /> },
          { h: T('Updated', 'التحديث'), end: true, r: (s) => s.at },
          { h: '', end: true, r: (s) => <div className="awp-row" style={{ justifyContent: 'flex-end', gap: 12 }}><Lnk onClick={() => setSrc(src.map((x) => (x === s ? { ...x, st: 'Queued', at: T('now', 'الآن') } : x)))}>{T('Re-index', 'إعادة فهرسة')}</Lnk><Lnk danger onClick={() => setConf({ title: T('Remove this source?', 'إزالة هذا المصدر؟'), intro: T(s.n + ' and its ' + s.docs + ' documents are removed from the collection.', 'يُزال ' + s.n + ' ومستنداته الـ ' + s.docs + ' من المجموعة.'), confirm: T('Remove source', 'إزالة المصدر'), onConfirm: () => setSrc(src.filter((x) => x !== s)) })}>{T('Remove', 'إزالة')}</Lnk></div> },
        ]} />}
      </Card>}
      {tab === 'config' && <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card title={T('Index', 'الفهرس')}><div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Index type', 'نوع الفهرس')}>{sel('idx', ['Vector (HNSW)', 'Vector (IVF-PQ)', 'Keyword (BM25)', 'Hybrid (vector + BM25)', 'Hybrid (vector + graph)', 'Graph only'])}</Field>
          <Field label={T('Distance metric', 'مقياس المسافة')}><PopSelect className="awp-input"><option>Cosine</option><option>Dot product</option><option>Euclidean</option></PopSelect></Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="HNSW m"><input className="awp-input" defaultValue="16" /></Field>
            <Field label="ef_construct"><input className="awp-input" defaultValue="128" /></Field>
          </div>
          <Field label={T('Quantisation', 'التكميم')}><PopSelect className="awp-input"><option>{T('None', 'بدون')}</option><option>Scalar int8</option><option>Binary</option></PopSelect></Field>
        </div></Card>
        <Card title={T('Chunking', 'التقطيع')}><div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Chunking technique', 'أسلوب التقطيع')}>{sel('chunk', ['Fixed size', 'Recursive by headings', 'Semantic', 'Sentence window', 'Q&A pairs', 'Table-aware', 'Late chunking'])}</Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label={T('Chunk size (tokens)', 'حجم المقطع (رموز)')}><input className="awp-input" inputMode="numeric" value={cfg.size} onChange={set('size')} /></Field>
            <Field label={T('Overlap (tokens)', 'التداخل (رموز)')} hint={ovBad ? <span style={{ color: 'var(--text-danger)' }}>{T('Must be smaller than the chunk size.', 'يجب أن يكون أصغر من حجم المقطع.')}</span> : null}><input className="awp-input" inputMode="numeric" value={cfg.overlap} onChange={set('overlap')} /></Field>
          </div>
          <Field label={T('Pre-processing', 'المعالجة المسبقة')}><div className="awp-row" style={{ flexWrap: 'wrap', gap: 6 }}><Pill on={ocr} onClick={() => setOcr(!ocr)}>{T('OCR scanned PDFs', 'التعرف الضوئي لملفات PDF الممسوحة')}</Pill>{[[T('Arabic normalisation', 'توحيد النص العربي'), true], [T('Strip headers/footers', 'إزالة الترويسات والتذييلات'), true], [T('PII masking', 'إخفاء البيانات الشخصية'), false]].map(([l, on]) => <button key={l} className={'awp-chip' + (on ? ' on' : '')}>{l}</button>)}</div></Field>
          {!ocr && <Banner tone="warning">{T('With OCR off, scanned PDFs and images are indexed without text and cannot be found.', 'عند إيقاف التعرف الضوئي تُفهرس ملفات PDF الممسوحة والصور بلا نص ولا يمكن العثور عليها.')}</Banner>}
        </div></Card>
        <Card title={T('Models', 'النماذج')}><div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Embedding route', 'مسار التضمين')} hint={T('Changing the embedding route re-indexes the whole collection.', 'تغيير مسار التضمين يعيد فهرسة المجموعة كاملة.')}>{sel('emb', ['embedding-default', 'local-private'])}</Field>
          <Field label={T('Embedding dimensions', 'أبعاد التضمين')}><PopSelect className="awp-input"><option>3072</option><option>1536</option><option>1024</option></PopSelect></Field>
          <Field label={T('Entity extraction route (graph)', 'مسار استخراج الكيانات (الرسم)')}>{sel('ext', ['—', 'classifier-typed', 'reasoning-default', 'local-private'])}</Field>
          <Field label={T('Re-ranker', 'إعادة الترتيب')}><div className="awp-row" style={{ gap: 10 }}><Toggle on={cfg.rr} onChange={set('rr')} /><PopSelect className="awp-input" disabled={!cfg.rr}><option>rerank-v3.5 (Cohere)</option><option>bge-reranker-v2 (local)</option></PopSelect></div></Field>
        </div></Card>
        <Card title={T('Retrieval & sync', 'الاسترجاع والمزامنة')}><div className="awp-col" style={{ gap: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="top-k"><input className="awp-input" value={cfg.k} onChange={set('k')} /></Field>
            <Field label={T('Min score', 'أدنى درجة')}><input className="awp-input" defaultValue="0.55" /></Field>
          </div>
          <Field label={T('Sync schedule', 'جدول المزامنة')}><PopSelect className="awp-input"><option>{T('Every 6 hours', 'كل 6 ساعات')}</option><option>{T('Daily at 02:00', 'يومياً الساعة 02:00')}</option><option>{T('On change (webhook)', 'عند التغيير (خطاف)')}</option><option>{T('Manual', 'يدوي')}</option></PopSelect></Field>
          <Field label={T('Visibility', 'الظهور')}>{sel('vis', ['Project', 'Organisation', 'Public (widget)'])}</Field>
          <Field label={T('Max collection size (MB)', 'الحجم الأقصى للمجموعة (م.ب)')} hint={T('Ingestion stops when the collection reaches this size.', 'يتوقف الإدخال عند بلوغ المجموعة هذا الحجم.')}><input className="awp-input" inputMode="numeric" value={maxMb} onChange={(e) => setMaxMb(e.target.value.replace(/\D/g, ''))} /></Field>
        </div></Card>
      </div>}
      {test && <Modal w={760} title={T('Retrieval test', 'اختبار الاسترجاع')} onClose={() => setTest(false)}><RetrievalTest c={c} /></Modal>}
      {add && <Modal title={T('Add source', 'إضافة مصدر')} onClose={() => setAdd(false)} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={() => setAdd(false)} /><Btn label={T('Add and index', 'إضافة وفهرسة')} disabled={kind === 'Upload' && !ups.length} onClick={() => { if (kind === 'Upload') { setSrc([...src, ...ups.map((n) => ({ n, kind: 'Upload', docs: 1, st: 'Queued', at: T('now', 'الآن') }))]); setUps([]); setAdd(false); return; } setSrc([...src, { n: kind === 'Upload' ? 'new-document.pdf' : kind === 'URL crawl' ? 'https://tahseel.ae/en/services' : 'SharePoint · /sites/procurement', kind: kind === 'MCP resource' ? 'MCP · m365' : kind, docs: 1, st: 'Queued', at: T('now', 'الآن') }]); setAdd(false); }} /></>}>
        <Field label={T('Source type', 'نوع المصدر')}><Seg value={kind} onChange={setKind} items={[{ id: 'Upload', label: T('Upload', 'رفع') }, { id: 'URL crawl', label: T('URL crawl', 'زحف رابط') }, { id: 'MCP resource', label: T('MCP resource', 'مورد MCP') }]} /></Field>
        {kind === 'Upload' && <><label style={{ border: '1px dashed var(--border-divider)', borderRadius: 16, padding: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer', background: 'var(--surface-card)' }} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles([...e.dataTransfer.files]); }}><Ic n="Download04" s={24} c="var(--icon-brand)" /><b>{T('Drop files or browse', 'أفلت الملفات أو تصفح')}</b><span className="awp-small awp-muted">{T('PDF, DOCX, XLSX, HTML, MD, TXT, CSV · up to 50 MB each', 'PDF وDOCX وXLSX وHTML وMD وTXT وCSV · حتى 50 م.ب لكل ملف')}</span><input type="file" multiple style={{ display: 'none' }} onChange={(e) => { addFiles([...e.target.files]); e.target.value = ''; }} /></label>{upErr && <Banner tone="danger">{upErr}</Banner>}{ups.length > 0 && <div className="awp-col awp-small" style={{ gap: 4 }}>{ups.map((n, i) => <span key={i} className="awp-row" style={{ gap: 8 }}><Ic n="File01" s={14} />{n}</span>)}</div>}</>}
        {kind === 'URL crawl' && <><Field label={T('Start URL', 'رابط البدء')}><input className="awp-input" defaultValue="https://" /></Field><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><Field label={T('Max depth', 'أقصى عمق')}><input className="awp-input" defaultValue="3" /></Field><Field label={T('Include pattern', 'نمط التضمين')}><input className="awp-input" defaultValue="/en/*" /></Field></div></>}
        {kind === 'MCP resource' && <><Field label={T('Connector', 'الموصل')}><PopSelect className="awp-input"><option>m365</option><option>github</option><option>erp</option></PopSelect></Field><Field label={T('Resource path', 'مسار المورد')}><input className="awp-input" defaultValue="/sites/procurement/Shared Documents" /></Field></>}
      </Modal>}
      {conf}
    </div>
  );
}

function Knowledge() {
  const [sel, setSel] = React.useState(null);
  const [test, setTest] = React.useState(null);
  const [cols, setCols] = React.useState(KCOLS);
  const [nw, setNw] = React.useState(false);
  const [nn, setNn] = React.useState('');
  const [banner, setBanner] = useBanner();
  const ing = cols.find((c) => c.st === 'Ingesting');
  const prog = useIngest(ing);
  if (sel) return <CollectionDetail c={sel} back={(delId) => { setSel(null); if (typeof delId === 'string') { setCols(cols.filter((c) => c.id !== delId)); setBanner('success', T('Collection deleted.', 'حُذفت المجموعة.')); } }} />;
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Knowledge', 'قاعدة المعرفة')} sub={T('Collections ingested into vector and graph stores for cited retrieval. Each collection has its own configuration and document sources.', 'مجموعات مُدخلة في مخازن المتجهات والرسوم للاسترجاع مع الإسناد. لكل مجموعة إعداداتها ومصادر مستنداتها.')}><Btn type="secondary" label={T('Test knowledge retrieval', 'اختبار استرجاع المعرفة')} onClick={() => setTest('all')} /><Btn label={T('New collection', 'مجموعة جديدة')} icon="AddCircle" onClick={() => setNw(true)} /></PageHead>
      {banner}
      <KpiRow items={[{ label: T('Collections', 'المجموعات'), value: cols.length }, { label: T('Documents', 'المستندات'), value: cols.reduce((n, c) => n + c.docs, 0).toLocaleString() }, { label: T('Chunks', 'المقاطع'), value: (cols.reduce((n, c) => n + c.chunks, 0) / 1000).toFixed(1) + 'k' }, { label: T('Entities', 'الكيانات'), value: cols.reduce((n, c) => n + c.ents, 0).toLocaleString() }]} />
      <Card pad={false} title={T('Collections', 'المجموعات')}><DataTable onRow={setSel} rows={cols} cols={[
        { h: T('Collection', 'المجموعة'), r: (c) => <div><button className="awp-lnk-t" onClick={(e) => { e.stopPropagation(); setSel(c); }}>{T(c.n, c.nAr)}</button><div className="awp-small awp-muted awp-mono">{c.p} · {c.vis}</div></div> },
        { h: T('Index type', 'نوع الفهرس'), r: (c) => <span className="awp-small">{c.idx}</span> },
        { h: T('Chunking', 'التقطيع'), r: (c) => <span className="awp-small">{c.chunk} · {c.size}/{c.overlap}</span> },
        { h: T('Embedding route', 'مسار التضمين'), r: (c) => <span className="awp-mono awp-small">{c.emb}</span> },
        { h: T('Documents', 'المستندات'), end: true, r: (c) => c.docs },
        { h: T('Status', 'الحالة'), r: (c) => c.st === 'Ingesting' ? <Tg tone="info" dot label={T('Ingesting ' + prog + '%', 'جارٍ الإدخال ' + prog + '٪')} /> : <StTag s={c.st} /> },
        { h: '', end: true, r: (c) => <div className="awp-row" style={{ justifyContent: 'flex-end', gap: 12 }} onClick={(e) => e.stopPropagation()}><Lnk onClick={() => setTest(c)}>{T('Test retrieval', 'اختبار الاسترجاع')}</Lnk><Lnk onClick={() => setSel(c)}>{T('Configure', 'إعداد')}</Lnk></div> },
      ]} /></Card>
      {test && <Modal w={760} title={T('Retrieval test', 'اختبار الاسترجاع')} onClose={() => setTest(null)}><RetrievalTest c={test === 'all' ? null : test} /></Modal>}
      {nw && <Modal title={T('New collection', 'مجموعة جديدة')} onClose={() => setNw(false)} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={() => setNw(false)} /><Btn label={T('Create and configure', 'إنشاء وإعداد')} onClick={() => { const c = { ...KCOLS[0], id: 'new', n: 'New collection', nAr: 'مجموعة جديدة', docs: 0, chunks: 0, ents: 0, sync: '—', st: 'Healthy' }; setCols([...cols, c]); setNw(false); setSel(c); }} /></>}>
        <Field label={T('Name', 'الاسم')}><input className="awp-input" value={nn} onChange={(e) => setNn(e.target.value)} placeholder={T('e.g. HR policies', 'مثال: سياسات الموارد البشرية')} /></Field>
        <Field label={T('Project', 'المشروع')}><ProjectSelect /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label={T('Index type', 'نوع الفهرس')}><PopSelect className="awp-input"><option>Hybrid (vector + graph)</option><option>Vector (HNSW)</option><option>Hybrid (vector + BM25)</option></PopSelect></Field>
          <Field label={T('Chunking technique', 'أسلوب التقطيع')}><PopSelect className="awp-input"><option>Semantic</option><option>Recursive by headings</option><option>Fixed size</option></PopSelect></Field>
          <Field label={T('Embedding route', 'مسار التضمين')}><PopSelect className="awp-input"><option>embedding-default</option><option>local-private</option></PopSelect></Field>
          <Field label={T('Visibility', 'الظهور')}><PopSelect className="awp-input"><option>Project</option><option>Organisation</option><option>Public (widget)</option></PopSelect></Field>
        </div>
        <CodeField label={T('Collection ID', 'معرّف المجموعة')} from={nn} />
      </Modal>}
    </div>
  );
}

Object.assign(window, { Knowledge });
