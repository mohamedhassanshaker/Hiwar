const ORB_FS = `precision mediump float;
uniform vec2 uRes;uniform float uT;uniform float uE;uniform float uDark;
float sdC(vec2 p,vec2 c,float r){return length(p-c)-r;}
float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}
mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
void main(){
vec2 uv=(gl_FragCoord.xy*2.-uRes)/min(uRes.x,uRes.y);
const float S=.8;vec2 p=uv/S;float L=length(p);float px=2.4/min(uRes.x,uRes.y)/S;
float sm=1.-smoothstep(1.-px,1.+px,L);
float t=uT,e=uE;
vec2 b=rot(-.25+.35*sin(t*.21))*p;b/=1.+.035*sin(t*.85)+.02*e*sin(t*2.1);
float m=.035+.02*e;
vec2 c1=vec2(-.1,-.09)+m*vec2(sin(t*.7),cos(t*.9));
vec2 c2=vec2(.1,.11)+m*vec2(cos(t*.8+1.),sin(t*.6+2.));
vec2 c3=vec2(.03,.0)+m*1.3*vec2(sin(t*.5+3.),cos(t*.75));
float an=atan(b.y,b.x);
float d=smin(sdC(b,c1,.5),sdC(b,c2,.46),.42);d=smin(d,sdC(b,c3,.44),.36);
d+=(.012+.008*e)*sin(an*3.+t*1.1)+.007*sin(an*5.-t*.9);
vec2 b2=rot(.25*sin(t*.33))*(b-vec2(.07,.05)-.04*vec2(sin(t*.6),cos(t*.5)));
float d2=smin(sdC(b2,c1*.86,.41),sdC(b2,c2*1.04,.37),.36);
float aa=px*1.4;
float bm=1.-smoothstep(-aa,aa,d);
float bm2=(1.-smoothstep(-.05,.05,d2))*bm;
float g=clamp(dot(b,normalize(vec2(.75,.65)))*1.05+.5+.08*sin(t*.4),0.,1.);
vec3 cyan=vec3(.66,.9,1.),blue=vec3(.5,.74,1.),vio=vec3(.6,.72,1.),lav=vec3(.86,.9,.99),amb=vec3(.973,.71,0.);
vec3 bc=g<.5?mix(cyan,blue,g*2.):mix(blue,vio,(g-.5)*2.);
bc=mix(bc,mix(bc,lav,.6),smoothstep(-.16,0.,d)*.5);
bc=mix(bc,mix(bc,vec3(.42,.66,1.),.5),bm2*.5);
bc=mix(bc,lav,smoothstep(.05,0.,abs(d2))*bm*.18);bc+=amb*smoothstep(.12,0.,abs(d+.05))*bm*.07*(.7+.3*sin(t*.6));
bc=mix(bc,bc*.96,smoothstep(.0,-.3,d)*.3);
vec3 vc=vec3(.18,.86,1.),vb=vec3(.12,.52,1.),vv=vec3(.58,.4,1.);
vec3 vbc=g<.5?mix(vc,vb,g*2.):mix(vb,vv,(g-.5)*2.);
vbc=mix(vbc,vec3(.45,.8,1.),bm2*.35);
vbc+=vec3(.05,.12,.25)*smoothstep(-.18,0.,d)*.8;
vbc*=1.+.12*e+.04*sin(t*.7);
bc=mix(bc,vbc,uDark);
float hl=1.-.55*uDark;
vec3 glass=mix(vec3(.88,.94,1.),vec3(1.),.45);
glass=mix(glass,vec3(.635,.8,1.),clamp(dot(p,vec2(.62,-.62))*.55+.3,0.,1.)*.35);
glass=mix(glass,mix(vec3(.07,.1,.24),vec3(.14,.2,.48),clamp(dot(p,vec2(.62,-.62))*.55+.4,0.,1.)),uDark*.9);glass=mix(glass,amb,smoothstep(.5,0.,length(p-vec2(.55,-.6)))*.06);
float inner=1.-smoothstep(.8,.9,L);
vec3 col=mix(glass,bc,bm*.94*inner);
col=mix(col,mix(lav,vec3(1.),.6),smoothstep(.82,.93,L)*.5*hl);
col=mix(col,lav,smoothstep(.02,0.,abs(L-.865))*.3*hl);
float ang=atan(p.y,p.x);
vec3 iri=.5+.5*cos(vec3(0.,2.1,4.2)+ang+t*.15);
vec3 rimc=mix(mix(vec3(.82,.9,1.),vec3(.635,.8,1.),.5+.5*sin(ang+t*.15)),vio,.08);
rimc=mix(rimc,vec3(.36,.56,.98),uDark*.6);
col=mix(col,rimc,smoothstep(.86,1.,L)*.6);
vec2 np=p/max(L,.001);
col=mix(col,vec3(1.),smoothstep(.045,0.,abs(L-.91))*smoothstep(.25,.95,dot(np,normalize(vec2(-.72,.7))))*.8*(1.-.3*uDark));
col=mix(col,vec3(1.),smoothstep(.55,0.,length(p-vec2(-.42,.5)))*.3*hl);
col=min(col,vec3(1.));
float od=max(L-1.,0.);
float halo=exp(-od*14.)*(1.-sm)*(.1+.16*e+.03*sin(t*1.4))*smoothstep(1.24,1.02,L)*(1.+1.1*uDark);
vec3 hc=mix(vec3(.635,.8,1.),vec3(.55,.62,.95),.25+.15*sin(t*.5));hc=mix(hc,mix(vec3(.2,.7,1.),vec3(.5,.4,1.),.4+.2*sin(t*.5)),uDark*.8);
gl_FragColor=vec4(col*sm+hc*halo,sm+halo*(1.-sm));
}`;
const ORB_VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';

function AiOrb({ active, size = 60, still = false }) {
  const cv = React.useRef(null);
  const st = React.useRef({ e: 0.15, hover: false, active: false, t: 3.0 });
  const [fallback, setFallback] = React.useState(false);
  st.current.active = !!active; st.current.still = !!still;
  React.useEffect(() => {
    const c = cv.current; if (!c) return;
    const gl = c.getContext('webgl', { premultipliedAlpha: true, antialias: false, alpha: true });
    if (!gl) { setFallback(true); return; }
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
    const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, ORB_VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, ORB_FS)); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) { setFallback(true); return; }
    gl.useProgram(pr);
    const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const uRes = gl.getUniformLocation(pr, 'uRes'), uT = gl.getUniformLocation(pr, 'uT'), uE = gl.getUniformLocation(pr, 'uE'), uDark = gl.getUniformLocation(pr, 'uDark');
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    const css = size * 1.25, dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.width = Math.round(css * dpr); c.height = Math.round(css * dpr); gl.viewport(0, 0, c.width, c.height);
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const btn = c.closest('[data-orb-host]') || c.closest('button');
    const on = () => { st.current.hover = true; kick(); }, off = () => { st.current.hover = false; kick(); };
    if (btn) { btn.addEventListener('pointerenter', on); btn.addEventListener('pointerleave', off); btn.addEventListener('focus', on); btn.addEventListener('blur', off); }
    let raf = 0, last = performance.now();
    const draw = () => {
      const s = st.current;
      gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.uniform2f(uRes, c.width, c.height); gl.uniform1f(uT, s.t); gl.uniform1f(uE, s.e);
      gl.uniform1f(uDark, document.documentElement.dataset.theme === 'dark' ? 1 : 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    const frame = (now) => {
      const s = st.current, dt = Math.min((now - last) / 1000, 0.05); last = now;
      const target = s.active ? 1 : s.hover ? 0.6 : 0.15;
      s.e += (target - s.e) * Math.min(dt * 3, 1);
      s.t += dt * (0.55 + 0.9 * s.e);
      draw();
      raf = (document.hidden || (s.still && !s.hover && !s.active && Math.abs(s.e - target) < 0.01)) ? 0 : requestAnimationFrame(frame);
    };
    function kick() {
      if (mq.matches) { const s = st.current; s.e = s.active ? 0.7 : s.hover ? 0.45 : 0.2; draw(); return; }
      if (!raf && !document.hidden) { last = performance.now(); raf = requestAnimationFrame(frame); }
    }
    const vis = () => kick();
    const tmo = new MutationObserver(() => { if (raf) return; draw(); });
    tmo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    document.addEventListener('visibilitychange', vis); mq.addEventListener('change', kick);
    st.current.kick = kick; kick();
    return () => { tmo.disconnect(); cancelAnimationFrame(raf); raf = -1; document.removeEventListener('visibilitychange', vis); mq.removeEventListener('change', kick); if (btn) { btn.removeEventListener('pointerenter', on); btn.removeEventListener('pointerleave', off); btn.removeEventListener('focus', on); btn.removeEventListener('blur', off); } };
  }, [size]);
  React.useEffect(() => { st.current.kick && st.current.kick(); }, [active]);
  return (
    <span className="awp-orb" style={{ width: size, height: size }}>
      {fallback ? <span className="awp-orb-fb" /> : <canvas ref={cv} style={{ width: size * 1.25, height: size * 1.25 }} />}
    </span>
  );
}

Object.assign(window, { AiOrb });
