const RUNS = [
  { id: 'RUN-88231', st: 'Waiting', goal: 'Review claim EXP-4471 against T&E policy', goalAr: 'مراجعة المطالبة EXP-4471 وفق سياسة السفر', at: '2026-10-09 10:41', dur: '13.7s', cost: 0.30, by: 'TSK-2320' },
  { id: 'RUN-88218', st: 'Running', goal: 'Review claim EXP-4468', goalAr: 'مراجعة المطالبة EXP-4468', at: '2026-10-09 10:36', dur: '—', cost: 0.12, by: 'TSK-2316' },
  { id: 'RUN-88215', st: 'Queued', goal: 'Review claim EXP-4469', goalAr: 'مراجعة المطالبة EXP-4469', at: '2026-10-09 10:35', dur: '—', cost: 0, by: 'TSK-2317' },
  { id: 'RUN-88190', st: 'Completed', goal: 'Review claim EXP-4466', goalAr: 'مراجعة المطالبة EXP-4466', at: '2026-10-09 09:58', dur: '11.2s', cost: 0.27, by: 'TSK-2313' },
  { id: 'RUN-88164', st: 'Completed', goal: 'Per-diem impact analysis for September', goalAr: 'تحليل أثر البدل اليومي لشهر سبتمبر', at: '2026-10-09 09:14', dur: '48.0s', cost: 0.38, by: 'SES-1042' },
  { id: 'RUN-88120', st: 'BudgetExceeded', goal: 'Re-check 214 September claims', goalAr: 'إعادة فحص 214 مطالبة لشهر سبتمبر', at: '2026-10-08 17:05', dur: '2m 41s', cost: 5.00, by: 'SES-1042' },
  { id: 'RUN-88102', st: 'Failed', goal: 'Review claim EXP-4459', goalAr: 'مراجعة المطالبة EXP-4459', at: '2026-10-08 16:20', dur: '6.1s', cost: 0.05, by: 'TSK-2301' },
  { id: 'RUN-88077', st: 'Cancelled', goal: 'Review claim EXP-4455', goalAr: 'مراجعة المطالبة EXP-4455', at: '2026-10-08 14:02', dur: '3.4s', cost: 0.02, by: 'TSK-2298' },
  { id: 'RUN-88031', st: 'Completed', goal: 'Review claim EXP-4451', goalAr: 'مراجعة المطالبة EXP-4451', at: '2026-10-08 11:47', dur: '10.9s', cost: 0.26, by: 'TSK-2295' },
];
const runSt = { Queued: ['neutral', 'Queued', 'في الطابور'], Waiting: ['warning', 'Waiting · approval', 'بانتظار · اعتماد'], Running: ['info', 'Running', 'قيد التشغيل'], Completed: ['success', 'Completed', 'مكتملة'], Failed: ['danger', 'Failed', 'فشلت'], BudgetExceeded: ['danger', 'Budget exceeded', 'تجاوزت الميزانية'], Cancelled: ['neutral', 'Cancelled', 'ملغاة'] };
const RunTag = ({ s }) => <Tg tone={runSt[s][0]} dot label={T(runSt[s][1], runSt[s][2])} />;
const AG_ERR = { bug: ['Last run failed: cards/block circuit open after 3 timeouts.', 'فشلت آخر عملية: دائرة cards/block مفتوحة بعد 3 مهل.'] };
const AG_USED = { exp: ['Request type Expense Claim (Agent review step)', 'Scheduled: Weekly cost report', 'Project FIN'], sup: ['Embedded deployment: Tahseel website assistant', 'Channel: WhatsApp'], dir: ['Platform system agent'] };
const agStore = { made: [], del: {}, ov: {}, f: { q: '', st: 'all' }, ping() { dispatchEvent(new Event('ag-change')); } };
function useAG() { const [, f] = React.useReducer((x) => x + 1, 0); React.useEffect(() => { addEventListener('ag-change', f); return () => removeEventListener('ag-change', f); }, []); return agStore; }
const allAgents = () => [...AGENTS, ...agStore.made].filter((a) => !agStore.del[a.id]).map((a) => ({ ...a, ...(agStore.ov[a.id] || {}) }));
const ROUTE_ALIASES = ['reasoning-default', 'small-fast', 'vision', 'classifier-typed', 'local-private'];
const TRUSTS = [['Restricted', 'مقيد'], ['Standard', 'قياسي'], ['Elevated', 'مرتفع'], ['Coordinator', 'منسق']];

function AgentRuns({ a, go }) {
  const [f, setF] = React.useState('all');
  const [cx, setCx] = React.useState({});
  const [conf, setConf] = useConfirm();
  const rows = RUNS.map((r) => cx[r.id] ? { ...r, st: 'Cancelled' } : r).filter((r) => f === 'all' || r.st === f).sort((x, y) => (x.at < y.at ? 1 : -1));
  return (
    <Card pad={false}>
      <div className="awp-row" style={{ padding: '14px 20px', flexWrap: 'wrap', gap: 12, borderBottom: '1px solid var(--border-divider)' }}>
        <span className="awp-small awp-muted">{T('Status', 'الحالة')}</span>
        <Chips value={f} onChange={setF} items={[{ id: 'all', label: T('All', 'الكل') }, ...Object.keys(runSt).map((k) => ({ id: k, label: T(runSt[k][1], runSt[k][2]) }))]} />
        <span style={{ flex: 1 }} /><span className="awp-small awp-muted">{T('Newest first', 'الأحدث أولاً')}</span>
      </div>
      {rows.length ? <DataTable onRow={(r) => go('run', { agent: a.id, id: r.id })} rows={rows} cols={[
        { h: T('Run', 'العملية'), r: (r) => <div><div style={{ fontWeight: 500 }}>{T(r.goal, r.goalAr)}</div><div className="awp-small awp-muted awp-mono">{r.id} · {r.by}</div></div> },
        { h: T('Status', 'الحالة'), r: (r) => <RunTag s={r.st} /> },
        { h: T('Started', 'البدء'), r: (r) => <span className="awp-mono">{r.at}</span> },
        { h: T('Duration', 'المدة'), end: true, r: (r) => r.dur },
        { h: T('Estimated cost', 'التكلفة التقديرية'), end: true, r: (r) => AED(r.cost) },
        { h: '', end: true, r: (r) => ['Running', 'Waiting', 'Queued'].includes(r.st) ? <Lnk danger onClick={() => setConf({ title: T('Cancel ' + r.id + '?', 'إلغاء ' + r.id + '؟'), intro: T('The run stops and any pending approval is released. ' + r.by + ' returns to To do.', 'تتوقف العملية ويُحرر أي اعتماد معلق. يعود ' + r.by + ' إلى للتنفيذ.'), confirm: T('Cancel run', 'إلغاء العملية'), onConfirm: () => setCx({ ...cx, [r.id]: 1 }) })}>{T('Cancel', 'إلغاء')}</Lnk> : null },
      ]} /> : <Empty title={T('No runs with this status.', 'لا توجد عمليات بهذه الحالة.')}><Pill onClick={() => setF('all')}>{T('Show all', 'عرض الكل')}</Pill></Empty>}
      {conf}
    </Card>
  );
}

function AgentConfigModal({ a, onClose, onSave }) {
  const [x, setX] = React.useState({ profile: a.profile, route: a.route || 'reasoning-default', fb: a.fb || 'small-fast', trust: a.trust || (a.id === 'sup' ? 'Restricted' : ['prc', 'bug'].includes(a.id) ? 'Elevated' : 'Standard'), soft: a.soft || '2.00', hard: a.hard || '5.00', mem: a.mem !== false });
  const set = (k) => (e) => setX({ ...x, [k]: e && e.target ? e.target.value : e });
  const bad = !(+x.soft > 0) || !(+x.hard > 0) || +x.soft > +x.hard;
  return (
    <Modal w={600} title={T('Configuration', 'الإعدادات') + ' · ' + nm(a)} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Save', 'حفظ')} disabled={bad || x.route === x.fb} onClick={() => onSave(x)} /></>}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Execution profile', 'ملف التنفيذ')}><PopSelect className="awp-input" value={x.profile} onChange={set('profile')}>{[['task', 'Task', 'مهام'], ['conversational', 'Conversational', 'محادثة'], ['planner', 'Planner', 'تخطيط'], ['workbench', 'Workbench', 'بيئة عمل']].map(([k, e, ar]) => <option key={k} value={k}>{T(e, ar)}</option>)}</PopSelect></Field>
        <Field label={T('Agent trust', 'ثقة الوكيل')}><PopSelect className="awp-input" value={x.trust} onChange={set('trust')}>{TRUSTS.map(([v, l]) => <option key={v} value={v}>{T(v, l)}</option>)}</PopSelect></Field>
        <Field label={T('Primary route', 'المسار الأساسي')}><PopSelect className="awp-input" value={x.route} onChange={set('route')}>{ROUTE_ALIASES.map((r) => <option key={r}>{r}</option>)}</PopSelect></Field>
        <Field label={T('Fallback route', 'المسار البديل')} hint={x.route === x.fb ? <span style={{ color: 'var(--text-danger)' }}>{T('Choose a different route from the primary.', 'اختر مساراً مختلفاً عن الأساسي.')}</span> : null}><PopSelect className="awp-input" value={x.fb} onChange={set('fb')}>{ROUTE_ALIASES.map((r) => <option key={r}>{r}</option>)}</PopSelect></Field>
        <Field label={T('Soft run budget (AED)', 'ميزانية العملية المرنة (د.إ)')} hint={T('A warning is raised at this amount.', 'يظهر تنبيه عند هذا المبلغ.')}><input className="awp-input" inputMode="decimal" value={x.soft} onChange={set('soft')} /></Field>
        <Field label={T('Hard run budget (AED)', 'ميزانية العملية الصارمة (د.إ)')} hint={+x.soft > +x.hard ? <span style={{ color: 'var(--text-danger)' }}>{T('Must be at least the soft budget.', 'يجب ألا تقل عن الميزانية المرنة.')}</span> : T('The run stops at this amount.', 'تتوقف العملية عند هذا المبلغ.')}><input className="awp-input" inputMode="decimal" value={x.hard} onChange={set('hard')} /></Field>
      </div>
      <label className="awp-row" style={{ gap: 12 }}><Toggle on={x.mem} onChange={set('mem')} /><span>{T('Agent memory (learns procedures between runs)', 'ذاكرة الوكيل (يتعلم الإجراءات بين العمليات)')}</span></label>
    </Modal>
  );
}

function NewAgentModal({ onClose, onMade }) {
  const [x, setX] = React.useState({ n: '', nAr: '', unit: 'Finance', profile: 'task', trust: 'Standard', route: 'reasoning-default' });
  const set = (k) => (e) => setX({ ...x, [k]: e.target.value });
  const [close, guard] = useDirtyClose(!!(x.n || x.nAr), onClose);
  const code = slug(x.n);
  const ok = x.n.trim() && x.nAr.trim();
  return (
    <Modal w={600} title={T('New Agent', 'وكيل جديد')} onClose={close} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={close} /><Btn label={T('Create agent', 'إنشاء الوكيل')} disabled={!ok} onClick={() => { const id = 'ag' + Date.now(); agStore.made.push({ id, ini: keyOf(x.n).slice(0, 2) || 'AG', name: x.n.trim(), nameAr: x.nAr.trim(), unit: x.unit, unitAr: (PJ_UNITS.find((u) => u[0] === x.unit) || [])[1], ver: 'v1', model: 'claude-sonnet-4.5', status: 'Draft', profile: x.profile, runs: 0, cost: 0, trust: x.trust, route: x.route }); agStore.ping(); onClose(); onMade(id); }} /></>}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Name (English)', 'الاسم (إنجليزي)')}><input className="awp-input" value={x.n} onChange={set('n')} placeholder="Contract Reviewer" /></Field>
        <Field label={T('Name (Arabic)', 'الاسم (عربي)')}><input className="awp-input" dir="rtl" value={x.nAr} onChange={set('nAr')} placeholder="مراجع العقود" /></Field>
        <Field label={T('Org unit', 'الوحدة التنظيمية')}><PopSelect className="awp-input" value={x.unit} onChange={set('unit')}>{PJ_UNITS.map(([e, a]) => <option key={e} value={e}>{T(e, a)}</option>)}</PopSelect></Field>
        <Field label={T('Execution profile', 'ملف التنفيذ')}><PopSelect className="awp-input" value={x.profile} onChange={set('profile')}>{[['task', 'Task', 'مهام'], ['conversational', 'Conversational', 'محادثة'], ['planner', 'Planner', 'تخطيط'], ['workbench', 'Workbench', 'بيئة عمل']].map(([k, e, ar]) => <option key={k} value={k}>{T(e, ar)}</option>)}</PopSelect></Field>
        <Field label={T('Agent trust', 'ثقة الوكيل')} hint={T('System trust is reserved for platform agents.', 'ثقة النظام مخصصة لوكلاء المنصة.')}><PopSelect className="awp-input" value={x.trust} onChange={set('trust')}>{TRUSTS.map(([v, l]) => <option key={v} value={v}>{T(v, l)}</option>)}</PopSelect></Field>
        <Field label={T('Model route', 'مسار النموذج')}><PopSelect className="awp-input" value={x.route} onChange={set('route')}>{ROUTE_ALIASES.map((r) => <option key={r}>{r}</option>)}</PopSelect></Field>
      </div>
      <Field label={T('Agent code', 'رمز الوكيل')} hint={T('Made from the English name. Used in logs and APIs.', 'يُكوّن من الاسم الإنجليزي. يُستخدم في السجلات وواجهات API.')}><input className="awp-input awp-mono" readOnly value={code} placeholder={T('auto', 'تلقائي')} /></Field>
      {guard}
    </Modal>
  );
}

const AG_SKILLS = [['expense-claim-review', true, null], ['receipt-extraction', true, null], ['policy-lookup', false, null], ['vendor-check', false, 'sap']];
const AG_TOOLS = [['erp/claims.read', 'T0', 'auto'], ['erp/claims.update_status', 'T2', 'approval'], ['m365/mail.send', 'T2', 'approval'], ['knowledge/search', 'T0', 'auto'], ['erp/payments.release', 'T3', 'denied']];
const AG_KB = [['pol', 'Policies', 'السياسات', true], ['svc', 'Service catalogue', 'دليل الخدمات', false], ['faq', 'Customer FAQs', 'الأسئلة الشائعة', false], ['ven', 'Vendor contracts', 'عقود الموردين', false]];
const AG_MEM = [['org', 'Organisation', 'الجهة', 'read'], ['unit', 'Business unit · Finance', 'وحدة العمل · المالية', 'readwrite'], ['agent', 'Own agent memory', 'ذاكرة الوكيل الخاصة', 'readwrite'], ['session', 'Session', 'الجلسة', 'read']];

function AgentDetail({ id, go, back, tab0 }) {
  const ag = useAG();
  const a = allAgents().find((x) => x.id === id) || AGENTS[1];
  const [tab, setTab] = React.useState(tab0 || 'overview');
  React.useEffect(() => setTab(tab0 || 'overview'), [tab0]);
  const [cfg, setCfg] = React.useState(false);
  const [ins, setIns] = React.useState(`You review employee expense claims for Tahseel.\n\n1. Load the claim and its receipts.\n2. Check each line against the T&E policy (skill: expense-claim-review).\n3. Recommend Approve or Return with reasons per line.\n4. Never approve your own recommendation; route to the Finance Approver.`);
  const [insEd, setInsEd] = React.useState(null);
  const [rev, setRev] = React.useState(null);
  const [sk, setSk] = React.useState(AG_SKILLS);
  const [tools, setTools] = React.useState(AG_TOOLS);
  const [kb, setKb] = React.useState(AG_KB);
  const [mem, setMem] = React.useState(AG_MEM);
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  const trust = a.trust || (a.id === 'dir' ? 'System' : a.id === 'sup' ? 'Restricted' : ['prc', 'bug'].includes(a.id) ? 'Elevated' : 'Standard');
  const modeLbl = { auto: [T('Auto', 'تلقائي'), 'neutral'], approval: [T('Approval', 'اعتماد'), 'warning'], denied: [T('Denied', 'مرفوض'), 'danger'] };
  const del = () => { const u = AG_USED[a.id] || []; setConf(u.length ? { title: T('Cannot delete ' + nm(a), 'لا يمكن حذف ' + nm(a)), intro: T('This agent is in use. Remove it from these first:', 'هذا الوكيل قيد الاستخدام. أزله مما يلي أولاً:'), items: u, blocked: true } : { title: T('Delete ' + nm(a) + '?', 'حذف ' + nm(a) + '؟'), intro: T('All versions are deleted. Past runs stay in the audit log.', 'تُحذف كل الإصدارات. تبقى العمليات السابقة في سجل التدقيق.'), confirm: T('Delete agent', 'حذف الوكيل'), onConfirm: () => { ag.del[a.id] = 1; ag.ping(); back(T(nm(a) + ' was deleted.', 'حُذف ' + nm(a) + '.')); } }); };
  return (
    <div className="awp-page">
      <PageHead crumb={<Lnk onClick={() => back()}>{T('AI Capabilities / Agents', 'قدرات الذكاء الاصطناعي / الوكلاء')}</Lnk>} title={<span className="awp-row" style={{ gap: 14 }}><AgentAv a={a} s={48} />{nm(a)}</span>} sub={T(a.unit, a.unitAr) + ' · ' + a.ver + (rev ? T(' · draft ' + rev + ' saved', ' · المسودة ' + rev + ' محفوظة') : '')}>
        <AgentTag s={a.status} />
        <Btn type="secondary" label={T('Test in playground', 'اختبار في بيئة التجربة')} />
        <Btn label={T('Publish new version', 'نشر إصدار جديد')} onClick={() => setBanner('success', T('Published ' + a.ver.replace(/\d+/, (n) => +n + 1) + '. New runs use it; runs in progress finish on ' + a.ver + '.', 'نُشر ' + a.ver.replace(/\d+/, (n) => +n + 1) + '. تستخدمه العمليات الجديدة؛ وتكمل الجارية على ' + a.ver + '.'))} />
        {a.id !== 'dir' && <button className="awp-iconbtn" aria-label={T('Delete agent', 'حذف الوكيل')} title={T('Delete agent', 'حذف الوكيل')} onClick={del}><Ic n="DeleteDS" s={18} /></button>}
      </PageHead>
      {banner}
      {a.status === 'Error' && AG_ERR[a.id] && <Banner tone="danger">{T(...AG_ERR[a.id])} <Lnk onClick={() => setTab('runs')}>{T('View runs', 'عرض العمليات')}</Lnk></Banner>}
      <Tabs value={tab} onChange={setTab} items={[{ id: 'overview', label: T('Overview', 'نظرة عامة') }, { id: 'instr', label: T('Instructions', 'التعليمات') }, { id: 'skills', label: T('Skills', 'المهارات'), count: sk.filter((s) => s[1]).length }, { id: 'tools', label: T('Tools', 'الأدوات'), count: tools.length }, { id: 'kb', label: T('Knowledge', 'المعرفة'), count: kb.filter((k) => k[3]).length }, { id: 'mem', label: T('Memory', 'الذاكرة') }, { id: 'runs', label: T('Agent run list', 'قائمة عمليات الوكيل'), count: RUNS.length }, { id: 'versions', label: T('Versions', 'الإصدارات'), count: 7 }]} />
      {tab === 'overview' && <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card title={T('Configuration', 'الإعدادات')} actions={<Pill onClick={() => setCfg(true)}>{T('Edit', 'تعديل')}</Pill>}>
          <dl className="awp-kv" style={{ margin: 0 }}>
            <dt>{T('Execution profile', 'ملف التنفيذ')}</dt><dd className="awp-mono">{a.profile}</dd>
            <dt>{T('Primary route', 'المسار الأساسي')}</dt><dd className="awp-mono">{a.route || 'reasoning-default'} · {a.model}</dd>
            <dt>{T('Fallback route', 'المسار البديل')}</dt><dd className="awp-mono">{a.fb || 'small-fast'}</dd>
            <dt>{T('Reports to', 'يتبع')}</dt><dd>{aName('u2')}</dd>
            <dt>{T('Agent trust', 'ثقة الوكيل')}</dt><dd>{T(trust, (TRUSTS.find((t) => t[0] === trust) || [0, 'النظام'])[1])}</dd>
            <dt>{T('Memory', 'الذاكرة')}</dt><dd>{a.mem === false ? T('Off', 'معطّلة') : T('On · 1.2 MB', 'مفعّلة · 1.2 م.ب')}</dd>
            <dt>{T('Run budget', 'ميزانية العملية')}</dt><dd>{T('AED ' + (a.soft || '2.00') + ' soft · AED ' + (a.hard || '5.00') + ' hard', (a.soft || '2.00') + ' د.إ مرن · ' + (a.hard || '5.00') + ' د.إ صارم')}</dd>
          </dl>
        </Card>
        <Card title={T('Last 30 days', 'آخر 30 يوماً')} actions={<Lnk onClick={() => setTab('runs')}>{T('View runs', 'عرض العمليات')}</Lnk>}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[[T('Runs', 'العمليات'), a.runs.toLocaleString()], [T('Success rate', 'معدل النجاح'), a.runs ? '96.4%' : '—'], [T('Estimated cost', 'التكلفة التقديرية'), AED(a.cost)], [T('Eval score', 'درجة التقييم'), a.runs ? '0.91' : '—']].map(([k, v]) => <div key={k}><div className="awp-small awp-muted">{k}</div><div style={{ fontSize: 22, fontWeight: 500 }}>{v}</div></div>)}
          </div>
        </Card>
      </div>}
      {tab === 'instr' && <Card title={T('System instructions', 'تعليمات النظام')} actions={insEd === null ? <Pill onClick={() => setInsEd(ins)}>{T('Edit', 'تعديل')}</Pill> : null}>
        {insEd === null ? <pre className="awp-mono" style={{ margin: 0, whiteSpace: 'pre-wrap', direction: 'ltr', textAlign: 'left', lineHeight: 1.7 }}>{ins}</pre> : <div className="awp-col" style={{ gap: 12 }}>
          <textarea className="awp-input awp-mono" rows={10} style={{ direction: 'ltr', textAlign: 'left', padding: 12, lineHeight: 1.6 }} value={insEd} onChange={(e) => setInsEd(e.target.value)} />
          <div className="awp-row" style={{ gap: 10, flexWrap: 'wrap' }}><Btn label={T('Save as draft revision', 'حفظ كمراجعة مسودة')} disabled={insEd === ins || !insEd.trim()} onClick={() => { setIns(insEd); setInsEd(null); const r = 'r' + ((rev ? +rev.slice(1) : 3) + 1); setRev(r); setBanner('success', T('Saved as draft ' + r + '. Publish a new version to use it in runs.', 'حُفظت كمسودة ' + r + '. انشر إصداراً جديداً لاستخدامها في العمليات.')); }} /><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={() => setInsEd(null)} /></div>
        </div>}
      </Card>}
      {tab === 'skills' && <Card pad={false}>{sk.map(([s, on, need], i) => <div key={s} className="awp-col" style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-divider)', gap: 6 }}><div className="awp-row" style={{ gap: 10 }}><Ic n="SkillsDS" s={18} /><Lnk onClick={() => go('skills')}>{s}</Lnk><span style={{ flex: 1 }} /><Toggle on={on} onChange={(v) => setSk(sk.map((x, j) => j === i ? [x[0], v, x[2]] : x))} /></div>{need && on && <span className="awp-small" style={{ color: 'var(--text-warning)' }}>{T('Needs the ' + need + ' connector, which this agent cannot use yet. ', 'يحتاج إلى موصل ' + need + '، ولا يمكن لهذا الوكيل استخدامه بعد. ')}<Lnk onClick={() => go('connectors')}>{T('Open Connectors', 'فتح التكامل')}</Lnk></span>}</div>)}</Card>}
      {tab === 'tools' && <Card pad={false}>{tools.map(([t, tier, mode], i) => <div key={t} className="awp-row" style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-divider)', gap: 10, flexWrap: 'wrap' }}><span className="awp-mono" style={{ flex: 1, minWidth: 180 }}>{t}</span><TierTag t={tier} />{tier === 'T3' ? <Tg tone="danger" label={T('Denied by tier', 'مرفوض بحكم المستوى')} /> : <Seg value={mode} onChange={(v) => setTools(tools.map((x, j) => j === i ? [x[0], x[1], v] : x))} items={['auto', 'approval', 'denied'].filter((m) => !(tier === 'T2' && m === 'auto')).map((m) => ({ id: m, label: modeLbl[m][0] }))} />}</div>)}<p className="awp-small awp-muted" style={{ margin: 0, padding: '12px 20px' }}>{T('T2 tools always need approval or are denied. T3 tools are always denied.', 'أدوات T2 تحتاج دائماً إلى اعتماد أو تُرفض. أدوات T3 مرفوضة دائماً.')}</p></Card>}
      {tab === 'kb' && <Card pad={false}>{kb.map(([k, e, ar, on], i) => <div key={k} className="awp-row" style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-divider)', gap: 10 }}><Ic n="InformationDiamond" s={18} /><span style={{ flex: 1 }}>{T(e, ar)}</span>{on ? <Pill onClick={() => setKb(kb.map((x, j) => j === i ? [...x.slice(0, 3), false] : x))}>{T('Revoke', 'سحب')}</Pill> : <Pill onClick={() => setKb(kb.map((x, j) => j === i ? [...x.slice(0, 3), true] : x))}>{T('Grant', 'منح')}</Pill>}</div>)}</Card>}
      {tab === 'mem' && <Card pad={false}>{mem.map(([k, e, ar, v], i) => <div key={k} className="awp-row" style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-divider)', gap: 10, flexWrap: 'wrap' }}><span style={{ flex: 1, minWidth: 180 }}>{T(e, ar)}</span><Seg value={v} onChange={(x) => setMem(mem.map((y, j) => j === i ? [...y.slice(0, 3), x] : y))} items={[{ id: 'none', label: T('No access', 'بلا وصول') }, { id: 'read', label: T('Read', 'قراءة') }, { id: 'readwrite', label: T('Read and write', 'قراءة وكتابة') }]} /></div>)}</Card>}
      {tab === 'runs' && <AgentRuns a={a} go={go} />}
      {tab === 'versions' && <Card pad={false}><table className="awp-tbl"><thead><tr><th>{T('Version', 'الإصدار')}</th><th>{T('Published', 'تاريخ النشر')}</th><th>{T('By', 'بواسطة')}</th><th>{T('Eval', 'التقييم')}</th><th></th></tr></thead><tbody>{[['v7', '2 Oct 2026', 'u4', '0.91', true], ['v6', '18 Sep 2026', 'u4', '0.88'], ['v5', '1 Sep 2026', 'dir', '0.86']].map(([v, d, b, e, act]) => <tr key={v}><td className="awp-mono">{v}</td><td>{d}</td><td>{aName(b)}</td><td>{e}</td><td style={{ textAlign: 'end' }}>{act ? <Tg tone="success" dot label={T('Active', 'نشط')} /> : <Lnk>{T('Roll back', 'التراجع')}</Lnk>}</td></tr>)}</tbody></table></Card>}
      {cfg && <AgentConfigModal a={{ ...a, trust }} onClose={() => setCfg(false)} onSave={(x) => { ag.ov[a.id] = { ...(ag.ov[a.id] || {}), ...x }; ag.ping(); setCfg(false); setBanner('success', T('Configuration saved.', 'حُفظت الإعدادات.')); }} />}
      {conf}
    </div>
  );
}

function Agents({ go, p = {} }) {
  const ag = useAG();
  const [sel, setSel] = React.useState(p.agent || null);
  const [nw, setNw] = React.useState(false);
  const [banner, setBanner] = useBanner();
  React.useEffect(() => { setSel(p.agent || null); }, [p.agent, p.tab]);
  if (sel) return <AgentDetail id={sel} go={go} tab0={p.agent === sel ? p.tab : null} back={(msg) => { setSel(null); if (msg) setBanner('success', msg); }} />;
  const f = ag.f; const setF = (k, v) => { ag.f = { ...ag.f, [k]: v }; ag.ping(); };
  const all = allAgents();
  const errN = all.filter((a) => a.status === 'Error').length;
  const list = all.filter((a) => (f.st === 'all' || a.status === f.st) && (!f.q || (a.name + a.nameAr + a.unit).toLowerCase().includes(f.q.toLowerCase())));
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Agents', 'الوكلاء')} sub={T('Versioned workers with skills, tools, memory and an org position.', 'عاملون بإصدارات لهم مهارات وأدوات وذاكرة وموقع تنظيمي.')}>
        <Btn label={T('New Agent', 'وكيل جديد')} icon="AddCircle" onClick={() => setNw(true)} />
      </PageHead>
      {banner}
      {errN > 0 && f.st !== 'Error' && <Banner tone="danger"><span className="awp-row" style={{ gap: 12 }}><span style={{ flex: 1 }}>{T(errN + ' agent in error', errN + ' وكيل في حالة خطأ')}</span><Lnk onClick={() => setF('st', 'Error')}>{T('Show', 'عرض')}</Lnk></span></Banner>}
      <div className="awp-row" style={{ gap: 12, flexWrap: 'wrap' }}>
        <input className="awp-input" style={{ maxWidth: 260 }} value={f.q} onChange={(e) => setF('q', e.target.value)} placeholder={T('Search agents', 'ابحث في الوكلاء')} />
        <Chips value={f.st} onChange={(v) => setF('st', v)} items={[{ id: 'all', label: T('All', 'الكل') }, ...['Running', 'Idle', 'Waiting', 'Error', 'Paused', 'Draft'].map((s) => ({ id: s, label: T(agentStatus(s).en, agentStatus(s).ar) }))]} />
      </div>
      {list.length ? <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(280px,100%),1fr))', gap: 16 }}>
        {list.map((a) => (
          <button key={a.id} className="awp-card" onClick={() => setSel(a.id)} title={a.status === 'Error' && AG_ERR[a.id] ? T(...AG_ERR[a.id]) : undefined} style={{ padding: 20, textAlign: 'start', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="awp-row" style={{ gap: 12 }}><AgentAv a={a} s={44} /><div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 500, fontSize: 16 }}>{nm(a)}</div><div className="awp-small awp-muted">{T(a.unit, a.unitAr)} · {a.ver}</div></div></div>
            <div className="awp-row" style={{ flexWrap: 'wrap' }}><AgentTag s={a.status} /><Tg label={a.profile} /></div>
            {a.status === 'Error' && AG_ERR[a.id] && <span className="awp-small" style={{ color: 'var(--text-danger)' }}>{T(...AG_ERR[a.id])}</span>}
            <div className="awp-row awp-small awp-muted" style={{ justifyContent: 'space-between', borderTop: '1px solid var(--border-divider)', paddingTop: 12, gap: 8, flexWrap: 'wrap' }}><span>{a.runs.toLocaleString()} {T('runs', 'عملية')}</span><span>{T('Est. ', 'تقديري ')}{AED(a.cost)}</span></div>
          </button>
        ))}
      </div> : <Card><Empty title={T('No agents match.', 'لا يوجد وكلاء مطابقون.')}><Pill onClick={() => { ag.f = { q: '', st: 'all' }; ag.ping(); }}>{T('Clear', 'مسح')}</Pill></Empty></Card>}
      {nw && <NewAgentModal onClose={() => setNw(false)} onMade={(id) => setSel(id)} />}
    </div>
  );
}

const STEPS = [
  { k: 'run_start', t: 'Run started', tAr: 'بدء العملية', d: 'Expense Reviewer v7 · task profile', ms: 0, tok: 0, cost: 0, ic: 'TouchInteraction02' },
  { k: 'model', t: 'Plan', tAr: 'التخطيط', d: 'gpt-4.1-mini · 4 step plan', ms: 1840, tok: 6120, cost: 0.03, ic: 'Notebook' },
  { k: 'tool', t: 'erp/claims.read', tAr: 'erp/claims.read', d: 'EXP-4471 · 6 lines · 4 receipts', ms: 420, tok: 0, cost: 0, ic: 'Invoice01' },
  { k: 'skill', t: 'Skill: receipt-extraction', tAr: 'مهارة: receipt-extraction', d: '4 receipts parsed in sandbox', ms: 5210, tok: 11840, cost: 0.11, ic: 'File01' },
  { k: 'model', t: 'Policy check', tAr: 'فحص السياسة', d: '2 lines exceed per-diem', ms: 2960, tok: 14210, cost: 0.12, ic: 'Notebook' },
  { k: 'verify', t: 'Verifier', tAr: 'المُحقق', d: 'policy-compliance: pass · evidence complete', ms: 1310, tok: 3900, cost: 0.04, ic: 'TickCircle' },
  { k: 'approval', t: 'Waiting for approval', tAr: 'بانتظار الاعتماد', d: 'erp/claims.update_status → Fatima Noor', ms: null, tok: 0, cost: 0, ic: 'SecurityPassword', live: true },
];
const CTX = [['System + instructions', 'النظام والتعليمات', 18, 'var(--chart-series-1)'], ['Skills', 'المهارات', 14, 'var(--chart-series-2)'], ['Tools', 'الأدوات', 9, 'var(--chart-series-3)'], ['Work item', 'بند العمل', 22, 'var(--chart-series-4)'], ['Memory', 'الذاكرة', 7, 'var(--chart-series-5)'], ['Conversation', 'المحادثة', 30, 'var(--chart-series-6)']];

function ReplayModal({ run, step, onClose, onDone }) {
  const [from, setFrom] = React.useState(String(step));
  const [why, setWhy] = React.useState('');
  return (
    <Modal title={T('Replay ' + run.id, 'إعادة تشغيل ' + run.id)} onClose={onClose} w={520} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Start replay', 'بدء إعادة التشغيل')} disabled={!why.trim()} onClick={() => { onClose(); onDone(); }} /></>}>
      <p style={{ margin: 0 }}>{T('A new run starts from the chosen step with the same inputs. Earlier steps are reused; tools with side effects are mocked.', 'تبدأ عملية جديدة من الخطوة المختارة بنفس المدخلات. تُعاد استخدام الخطوات السابقة وتُحاكى الأدوات ذات الأثر.')}</p>
      <Field label={T('Replay from step', 'إعادة التشغيل من الخطوة')}><PopSelect className="awp-input" value={from} onChange={(e) => setFrom(e.target.value)}>{STEPS.map((s, i) => <option key={i} value={String(i)}>{i + 1}. {T(s.t, s.tAr)}</option>)}</PopSelect></Field>
      <Field label={T('Reason', 'السبب')} hint={T('Required. It is kept with both runs.', 'مطلوب. يُحفظ مع العمليتين.')}><textarea className="awp-input" style={{ height: 72, padding: 12 }} value={why} onChange={(e) => setWhy(e.target.value)} placeholder={T('e.g. Policy limits were updated', 'مثال: تم تحديث حدود السياسة')} /></Field>
    </Modal>
  );
}

function RunViewer({ go, p = {} }) {
  const [sel, setSel] = React.useState(4);
  const [rp, setRp] = React.useState(false);
  const [cx, setCx] = React.useState(false);
  const [conf, setConf] = useConfirm();
  const a = AGENTS.find((x) => x.id === (p.agent || 'exp')) || AGENTS[1];
  const run0 = RUNS.find((r) => r.id === p.id) || (p.id ? { ...RUNS[0], id: p.id } : RUNS[0]);
  const run = cx ? { ...run0, st: 'Cancelled' } : run0;
  const s = STEPS[sel];
  const over = run.st === 'BudgetExceeded';
  const total = over ? 5.0 : STEPS.reduce((x, y) => x + y.cost, 0);
  return (
    <div className="awp-page">
      <PageHead crumb={<span className="awp-row" style={{ gap: 6 }}><Lnk onClick={() => go('agents')}>{T('Agents', 'الوكلاء')}</Lnk>/<Lnk onClick={() => go('agents', { agent: a.id })}>{nm(a)}</Lnk>/<Lnk onClick={() => go('agents', { agent: a.id, tab: 'runs' })}>{T('Agent run list', 'قائمة عمليات الوكيل')}</Lnk></span>} title={<span className="awp-mono" style={{ fontSize: 26, fontFamily: 'inherit' }}>{run.id}</span>} sub={T(run.goal, run.goalAr) + ' · ' + nm(a) + ' ' + a.ver}>
        <RunTag s={run.st} />
        <Btn type="secondary" label={T('Open trace', 'فتح التتبع')} onClick={() => window.__awpAct({ title: T('Open trace in Phoenix', 'فتح التتبع في Phoenix'), desc: T('Opens the full trace for ' + run.id + ' in Phoenix in a new tab. You need the logs:read permission.', 'يفتح التتبع الكامل لـ ' + run.id + ' في Phoenix في علامة تبويب جديدة. تحتاج إلى صلاحية logs:read.'), confirm: T('Open trace', 'فتح التتبع') })} />
        <Btn type="secondary" label={T('Replay', 'إعادة التشغيل')} onClick={() => setRp(true)} />
        {['Running', 'Waiting', 'Queued'].includes(run.st) && <Btn type="danger" label={T('Cancel run', 'إلغاء العملية')} onClick={() => setConf({ title: T('Cancel ' + run.id + '?', 'إلغاء ' + run.id + '؟'), intro: T('The run stops and the pending approval is released.', 'تتوقف العملية ويُحرر الاعتماد المعلق.'), confirm: T('Cancel run', 'إلغاء العملية'), onConfirm: () => setCx(true) })} />}
      </PageHead>
      {over && <Banner tone="danger">{T('This run stopped at its hard budget of AED 5.00. Raise the run budget in the agent configuration, or replay with fewer items.', 'توقفت هذه العملية عند ميزانيتها الصارمة 5.00 د.إ. ارفع ميزانية العملية في إعدادات الوكيل أو أعد التشغيل بعناصر أقل.')}</Banner>}
      {run.st === 'Queued' && <Banner tone="info">{T('Queued behind 2 runs for this agent. It starts automatically.', 'في الطابور بعد عمليتين لهذا الوكيل. تبدأ تلقائياً.')}</Banner>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(180px,100%),1fr))', gap: 16 }}>
        <Kpi label={T('Duration', 'المدة')} value={over ? '2m 41s' : '13.7s'} note={over ? null : T('+ 6m waiting', '+ 6د انتظار')} />
        <Kpi label={T('Tokens', 'الرموز')} value={over ? '612k' : '36.1k'} note={T('42% cache hit', '42٪ من الذاكرة المؤقتة')} />
        <Kpi label={T('Estimated cost', 'التكلفة التقديرية')} value={AED(total)} tone={over ? 'danger' : undefined} note={over ? T('Hard budget AED 5.00 reached', 'بلغت الميزانية الصارمة 5.00 د.إ') : T('Budget AED 2.00', 'الميزانية 2.00 د.إ')} />
        <Kpi label={T('Tool calls', 'استدعاءات الأدوات')} value="3" note={T('1 needs approval', '1 يحتاج اعتماد')} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card title={T('Timeline', 'المخطط الزمني')} pad={false}>
          {STEPS.map((x, i) => (
            <button key={i} onClick={() => setSel(i)} style={{ width: '100%', border: 0, borderBottom: '1px solid var(--border-divider)', background: sel === i ? 'var(--surface-brand-subtle)' : 'transparent', padding: '12px 20px', display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer', textAlign: 'start' }}>
              <span style={{ width: 36, height: 36, borderRadius: 999, display: 'grid', placeItems: 'center', background: x.live ? 'var(--feedback-warning-bg)' : 'var(--surface-sunken)', flexShrink: 0 }}><Ic n={x.ic} c={x.live ? 'var(--icon-warning)' : 'var(--icon-secondary)'} /></span>
              <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 500 }}>{T(x.t, x.tAr)}</div><div className="awp-small awp-muted">{x.d}</div></div>
              <div className="awp-small awp-muted" style={{ textAlign: 'end', whiteSpace: 'nowrap' }}>{x.ms == null ? T('waiting', 'انتظار') : (x.ms / 1000).toFixed(2) + 's'}{x.cost > 0 && <div>{AED(x.cost)}</div>}</div>
            </button>
          ))}
        </Card>
        <div className="awp-col" style={{ gap: 16 }}>
          <Card title={T('Step detail', 'تفاصيل الخطوة') + ' · ' + T(s.t, s.tAr)}>
            <dl className="awp-kv" style={{ margin: 0 }}>
              <dt>{T('Type', 'النوع')}</dt><dd className="awp-mono">{s.k}</dd>
              <dt>{T('Result', 'النتيجة')}</dt><dd>{s.d}</dd>
              <dt>{T('Tokens', 'الرموز')}</dt><dd>{s.tok.toLocaleString()}</dd>
              <dt>{T('Hooks', 'الخطافات')}</dt><dd>{T('pii-mask (pre_model): 2 values masked', 'pii-mask (pre_model): إخفاء قيمتين')}</dd>
            </dl>
            <div className="awp-row" style={{ marginTop: 14, gap: 10, flexWrap: 'wrap' }}>{s.live && <Btn label={T('Open in Inbox', 'فتح في صندوق الوارد')} onClick={() => go('inbox', { sel: 1 })} />}{sel > 0 && <Pill onClick={() => setRp(true)}>{T('Replay from this step', 'إعادة التشغيل من هذه الخطوة')}</Pill>}</div>
          </Card>
          <Card title={T('Context composition', 'تكوين السياق')}>
            <Bar h={14} parts={CTX.map((c) => ({ v: c[2], c: c[3] }))} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 16px', marginTop: 14 }}>{CTX.map((c) => <div key={c[0]} className="awp-row" style={{ fontSize: 13 }}><span className="awp-dot" style={{ background: c[3] }} /><span style={{ flex: 1 }}>{T(c[0], c[1])}</span><span className="awp-muted">{c[2]}%</span></div>)}</div>
          </Card>
          <Card title={T('Estimated cost by step', 'التكلفة التقديرية حسب الخطوة')}>
            {STEPS.filter((x) => x.cost > 0).map((x) => <div key={x.t} style={{ display: 'grid', gridTemplateColumns: 'minmax(0,140px) minmax(0,1fr) auto', gap: 12, alignItems: 'center', padding: '5px 0', fontSize: 13 }}><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{T(x.t, x.tAr)}</span><Bar parts={[{ v: (x.cost / 0.12) * 100, c: 'var(--action-primary-bg)' }]} /><span className="awp-muted" style={{ textAlign: 'end' }}>{AED(x.cost)}</span></div>)}
          </Card>
        </div>
      </div>
      {rp && <ReplayModal run={run} step={sel} onClose={() => setRp(false)} onDone={() => go('run', { agent: a.id, id: 'RUN-' + (88240 + Math.floor(Math.random() * 50)) })} />}
      {conf}
    </div>
  );
}

Object.assign(window, { Agents, RunViewer, RUNS, runSt, RunTag, allAgents });
