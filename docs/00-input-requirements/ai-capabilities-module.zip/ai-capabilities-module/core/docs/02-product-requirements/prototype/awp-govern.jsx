const CLIENTS = [
  { id: 'cli_crm', n: 'CRM integration', nAr: 'تكامل CRM', own: 'u2', perms: ['agents:invoke', 'requests:write', 'webhooks:receive'], agents: ['sup', 'exp'], keys: 2, mcp: true, agui: true, last: '2m', st: 'Active' },
  { id: 'cli_erp', n: 'Oracle ERP', nAr: 'Oracle ERP', own: 'u3', perms: ['agents:invoke', 'work_items:read'], agents: ['exp', 'rec'], keys: 1, mcp: true, agui: false, last: '1h', st: 'Active' },
  { id: 'cli_portal', n: 'Customer portal', nAr: 'بوابة المتعاملين', own: 'u2', perms: ['agents:invoke', 'knowledge:search'], agents: ['sup'], keys: 1, mcp: false, agui: true, last: '4m', st: 'Active' },
  { id: 'cli_bi', n: 'Legacy reporting', nAr: 'التقارير القديمة', own: 'u4', perms: ['work_items:read', 'rooms:read'], agents: [], keys: 1, mcp: false, agui: false, last: '41d', st: 'Inactive' },
];
const CL_KEYS = (c) => [{ n: 'production', k: 'awp_live_…9f2c', last: c.last, exp: '2027-01-01', st: 'Active' }, ...(c.keys > 1 ? [{ n: 'staging', k: 'awp_test_…41ab', last: '3d', exp: '2026-12-01', st: 'Active' }] : []), ...(c.id === 'cli_crm' ? [{ n: 'old-prod', k: 'awp_live_…07de', last: '1d', exp: '2026-10-09 11:20', st: 'Rotating' }] : [])];
function ClientDetail({ c, back, onDelete }) {
  const [tab, setTab] = React.useState('keys');
  const [mcp, setMcp] = React.useState(c.mcp);
  const [agui, setAgui] = React.useState(c.agui);
  const [st, setSt] = React.useState(c.st);
  const [keys, setKeys] = React.useState(() => CL_KEYS(c));
  const [perms, setPerms] = React.useState(c.perms);
  const [secret, setSecret] = React.useState(null);
  const [mk, setMk] = React.useState(null);
  const [tk, setTk] = React.useState('');
  const [tr, setTr] = React.useState(null);
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  const gen = () => 'awp_live_' + c.id.slice(4) + '_' + Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10);
  const kTone = { Active: 'success', Rotating: 'warning', Revoked: 'neutral' };
  const kAr = { Active: 'نشط', Rotating: 'قيد التدوير', Revoked: 'ملغى' };
  return (
    <div className="awp-page">
      <PageHead crumb={<Lnk onClick={() => back()}>{T('Govern / Integrations', 'الحوكمة / التكاملات')}</Lnk>} title={T(c.n, c.nAr)} sub={<span className="awp-mono">{c.id}</span>}>
        <StTag s={st} />
        <Btn type="secondary" label={st === 'Active' ? T('Deactivate', 'تعطيل') : T('Activate', 'تفعيل')} onClick={() => st === 'Active' ? setConf({ title: T('Deactivate ' + c.n + '?', 'تعطيل ' + c.n + '؟'), intro: T('All its keys stop working right away. Calls return 401 until you activate it again. Keys are kept.', 'تتوقف كل مفاتيحه فوراً. تُعاد الاستدعاءات بالرمز 401 حتى تعيد تفعيله. تبقى المفاتيح محفوظة.'), danger: false, confirm: T('Deactivate', 'تعطيل'), onConfirm: () => { setSt('Inactive'); setBanner('success', T('Client deactivated.', 'عُطّل العميل.')); } }) : (setSt('Active'), setBanner('success', T('Client activated. Its keys work again.', 'فُعّل العميل. تعمل مفاتيحه مجدداً.')))} />
        <button className="awp-iconbtn" aria-label={T('Delete client', 'حذف العميل')} title={T('Delete client', 'حذف العميل')} onClick={() => setConf({ title: T('Delete ' + c.n + '?', 'حذف ' + c.n + '؟'), intro: T('Its ' + keys.length + ' keys are revoked and its MCP and AG-UI access ends. This cannot be undone.', 'تُلغى مفاتيحه الـ ' + keys.length + ' وينتهي وصوله عبر MCP وAG-UI. لا يمكن التراجع عن ذلك.'), confirm: T('Delete client', 'حذف العميل'), onConfirm: () => onDelete(c.id) })}><Ic n="DeleteDS" s={18} /></button>
      </PageHead>
      {banner}
      {secret && <Banner tone="warning"><div className="awp-col" style={{ gap: 8 }}><b>{T('Copy this secret now. It will not be shown again.', 'انسخ هذا السر الآن. لن يظهر مرة أخرى.')}</b><code className="awp-mono" style={{ padding: '8px 12px', borderRadius: 12, background: 'var(--surface-raised)', overflowWrap: 'anywhere', direction: 'ltr', textAlign: 'left' }}>{secret}</code><span className="awp-row" style={{ gap: 12 }}><Lnk onClick={() => { try { navigator.clipboard.writeText(secret); } catch (e) {} }}>{T('Copy', 'نسخ')}</Lnk><Lnk onClick={() => setSecret(null)}>{T('I have stored it', 'لقد حفظته')}</Lnk></span></div></Banner>}
      <Tabs value={tab} onChange={setTab} items={[{ id: 'keys', label: T('Keys', 'المفاتيح'), count: keys.filter((k) => k.st !== 'Revoked').length }, { id: 'mcp', label: T('MCP connection', 'اتصال MCP') }, { id: 'agui', label: T('AG-UI expose', 'إتاحة AG-UI') }, { id: 'perms', label: T('Permissions', 'الأذونات') }]} />
      {tab === 'keys' && <Card pad={false} title={T('API keys', 'مفاتيح API')} actions={<Pill onClick={() => setMk({ n: '', exp: '90 days' })}>{T('Create key', 'إنشاء مفتاح')}</Pill>}>
        {mk && <div className="awp-row" style={{ padding: '12px 20px', gap: 8, flexWrap: 'wrap', borderBottom: '1px solid var(--border-divider)' }}><input className="awp-input" style={{ flex: '1 1 180px' }} autoFocus value={mk.n} onChange={(e) => setMk({ ...mk, n: e.target.value })} placeholder={T('Key name', 'اسم المفتاح')} /><PopSelect className="awp-input" style={{ width: 150 }} value={mk.exp} onChange={(e) => setMk({ ...mk, exp: e.target.value })}>{['30 days', '90 days', '1 year'].map((x) => <option key={x}>{x}</option>)}</PopSelect><Pill disabled={!mk.n.trim()} onClick={() => { const s = gen(); setKeys([...keys, { n: mk.n.trim(), k: s.slice(0, 9) + '…' + s.slice(-4), last: null, exp: mk.exp === '1 year' ? '2027-10-08' : mk.exp === '30 days' ? '2026-11-07' : '2027-01-06', st: 'Active' }]); setSecret(s); setMk(null); }}>{T('Create', 'إنشاء')}</Pill></div>}
        <DataTable rows={keys} cols={[{ h: T('Name', 'الاسم'), r: (r) => <b>{r.n}</b> }, { h: T('Key', 'المفتاح'), r: (r) => <span className="awp-mono">{r.k}</span> }, { h: T('Status', 'الحالة'), r: (r) => <Tg tone={kTone[r.st]} dot label={T(r.st, kAr[r.st])} /> }, { h: T('Last used', 'آخر استخدام'), r: (r) => r.last ? T(r.last + ' ago', 'قبل ' + r.last) : <span className="awp-muted">{T('Never', 'لم يُستخدم')}</span> }, { h: T('Expires', 'الانتهاء'), r: (r) => r.exp }, { h: '', end: true, r: (r) => r.st === 'Revoked' ? null : <div className="awp-row" style={{ justifyContent: 'flex-end', gap: 12 }}>{r.st === 'Active' && <Lnk onClick={() => setConf({ title: T('Rotate ' + r.n + '?', 'تدوير ' + r.n + '؟'), intro: T('A new secret is created now. The old one keeps working for 24 hours so you can switch without downtime.', 'يُنشأ سر جديد الآن. يبقى القديم صالحاً لمدة 24 ساعة لتتمكن من التبديل دون توقف.'), danger: false, confirm: T('Rotate', 'تدوير'), onConfirm: () => { const s = gen(); setKeys([...keys.map((y) => y === r ? { ...y, st: 'Rotating', exp: T('in 24 h', 'خلال 24 ساعة') } : y), { ...r, k: s.slice(0, 9) + '…' + s.slice(-4), last: null }]); setSecret(s); } })}>{T('Rotate', 'تدوير')}</Lnk>}<Lnk danger onClick={() => setConf({ title: T('Revoke ' + r.n + '?', 'إلغاء ' + r.n + '؟'), intro: T('It stops working immediately. Anything using it gets 401 errors.', 'يتوقف فوراً. أي شيء يستخدمه سيتلقى أخطاء 401.'), confirm: T('Revoke', 'إلغاء'), onConfirm: () => setKeys(keys.map((y) => y === r ? { ...y, st: 'Revoked' } : y)) })}>{T('Revoke', 'إلغاء')}</Lnk></div> }]} />
      </Card>}
      {tab === 'mcp' && <Card title={T('Expose platform as MCP server', 'إتاحة المنصة كخادم MCP')} actions={<Toggle on={mcp} onChange={setMcp} />}>
        {mcp ? <div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Endpoint', 'نقطة النهاية')}><input className="awp-input awp-mono" readOnly value={'https://awp.tahseel.ae/mcp/' + c.id} /></Field>
          <Field label={T('Auth', 'المصادقة')}><PopSelect className="awp-input"><option>OAuth 2.1 (client credentials)</option><option>API key</option></PopSelect></Field>
          <Field label={T('Exposed tools', 'الأدوات المتاحة')}><div className="awp-col" style={{ gap: 8 }}>{['agents.invoke', 'requests.create', 'work_items.get', 'knowledge.search', 'rooms.post_message'].map((t, i) => <label key={t} className="awp-row"><input type="checkbox" defaultChecked={i < 3} /><span className="awp-mono">{t}</span></label>)}</div></Field>
          <Field label={T('Test with a key', 'اختبار بمفتاح')} hint={T('Paste one of this client\'s keys. It is used for this test only and not stored.', 'الصق أحد مفاتيح هذا العميل. يُستخدم لهذا الاختبار فقط ولا يُخزّن.')}><div className="awp-row" style={{ gap: 8 }}><input className="awp-input awp-mono" type="password" value={tk} onChange={(e) => { setTk(e.target.value); setTr(null); }} placeholder="awp_live_…" /><Pill disabled={!tk.trim()} onClick={() => setTr(/^awp_(live|test)_/.test(tk.trim()) ? 'ok' : 'fail')}>{T('Run test', 'تشغيل الاختبار')}</Pill></div></Field>
          {tr === 'ok' && <Banner tone="success">{T('Handshake OK · protocol 2025-06-18 · 3 tools listed.', 'المصافحة ناجحة · البروتوكول 2025-06-18 · سُردت 3 أدوات.')}</Banner>}
          {tr === 'fail' && <Banner tone="danger">{T('401 Unauthorized: this key does not belong to ' + c.n + ' or has been revoked.', '401 غير مصرح: هذا المفتاح لا يخص ' + c.n + ' أو أُلغي.')}</Banner>}
        </div> : <p className="awp-muted" style={{ margin: 0 }}>{T('MCP access is off for this client.', 'وصول MCP معطّل لهذا العميل.')}</p>}
      </Card>}
      {tab === 'agui' && <Card title={T('Expose agents over AG-UI', 'إتاحة الوكلاء عبر AG-UI')} actions={<Toggle on={agui} onChange={setAgui} />}>
        {agui ? <div className="awp-col" style={{ gap: 14 }}>
          <Field label={T('Stream endpoint', 'نقطة البث')}><input className="awp-input awp-mono" readOnly value={'https://awp.tahseel.ae/agui/' + c.id + '/run'} /></Field>
          <Field label={T('Agents available to this client', 'الوكلاء المتاحون لهذا العميل')}><div className="awp-row" style={{ flexWrap: 'wrap', gap: 6 }}>{AGENTS.map((a) => <button key={a.id} className={'awp-chip' + (c.agents.includes(a.id) ? ' on' : '')} style={{ paddingInlineStart: 4 }}><AgentAv a={a} s={22} />{nm(a)}</button>)}</div></Field>
          <Field label={T('Allowed origins (CORS)', 'المصادر المسموحة (CORS)')}><input className="awp-input" defaultValue="https://portal.tahseel.ae" /></Field>
        </div> : <p className="awp-muted" style={{ margin: 0 }}>{T('AG-UI streaming is off for this client.', 'بث AG-UI معطّل لهذا العميل.')}</p>}
      </Card>}
      {tab === 'perms' && <Card title={T('Allowed permissions', 'الأذونات المسموحة')} actions={<Pill disabled={perms.join() === c.perms.join()} onClick={() => setBanner('success', T('Permissions saved. They apply to new calls; tokens issued earlier keep their old scope until they expire (up to 1 hour).', 'حُفظت الأذونات. تُطبق على الاستدعاءات الجديدة؛ وتحتفظ الرموز السابقة بنطاقها القديم حتى تنتهي (حتى ساعة).'))}>{T('Save', 'حفظ')}</Pill>}><div className="awp-col" style={{ gap: 10 }}>{CLIENT_PERMS.map(([k, l]) => <label key={k} className="awp-row" style={{ gap: 10 }}><input type="checkbox" checked={perms.includes(k)} onChange={() => setPerms(perms.includes(k) ? perms.filter((p) => p !== k) : [...perms, k])} /><span className="awp-mono" style={{ width: 170 }}>{k}</span><span className="awp-muted">{l}</span></label>)}</div></Card>}
      {conf}
    </div>
  );
}
function Integrations() {
  const [rows, setRows] = React.useState(CLIENTS);
  const [sel, setSel] = React.useState(null);
  const [banner, setBanner] = useBanner();
  if (sel) return <ClientDetail c={sel} back={() => setSel(null)} onDelete={(id) => { setRows(rows.filter((r) => r.id !== id)); setSel(null); setBanner('success', T('Client deleted and its keys revoked.', 'حُذف العميل وأُلغيت مفاتيحه.')); }} />;
  return (
    <div className="awp-page">
      <PageHead crumb={T('Govern', 'الحوكمة')} title={T('Integrations', 'التكاملات')} sub={T('External clients and what they may do. Each client has its own keys, MCP connection and AG-UI exposure.', 'العملاء الخارجيون وما يمكنهم فعله. لكل عميل مفاتيحه واتصال MCP وإتاحة AG-UI.')}><Btn label={T('New client', 'عميل جديد')} icon="AddCircle" onClick={() => window.__awpOpen('client')} /></PageHead>
      {banner}
      <Card pad={false}>{rows.length ? <DataTable onRow={setSel} rows={rows} cols={[
        { h: T('Client', 'العميل'), r: (c) => <div><b>{T(c.n, c.nAr)}</b><div className="awp-small awp-muted awp-mono">{c.id}</div></div> },
        { h: T('Owner', 'المالك'), r: (c) => aName(c.own) },
        { h: T('Allowed permissions', 'الأذونات المسموحة'), r: (c) => <div className="awp-row" style={{ flexWrap: 'wrap', gap: 4 }}>{c.perms.map((p) => <Tg key={p} label={p} />)}</div> },
        { h: T('Keys', 'المفاتيح'), r: (c) => { const k = CL_KEYS(c); const r = k.filter((x) => x.st === 'Rotating').length; return <span>{k.length}{r > 0 && <span className="awp-small" style={{ color: 'var(--text-warning)' }}> · {T(r + ' rotating', r + ' قيد التدوير')}</span>}</span>; } },
        { h: 'MCP', r: (c) => <Tg tone={c.mcp ? 'success' : 'neutral'} label={c.mcp ? T('On', 'مفعّل') : T('Off', 'معطّل')} /> },
        { h: 'AG-UI', r: (c) => <Tg tone={c.agui ? 'success' : 'neutral'} label={c.agui ? T('On', 'مفعّل') : T('Off', 'معطّل')} /> },
        { h: T('Status', 'الحالة'), r: (c) => <StTag s={c.st} /> },
      ]} /> : <Empty title={T('No clients yet.', 'لا يوجد عملاء بعد.')} text={T('Create a client to let an external system call the platform.', 'أنشئ عميلاً للسماح لنظام خارجي باستدعاء المنصة.')} />}</Card>
    </div>
  );
}

function SystemPage() {
  const [paused, setPaused] = React.useState(false);
  const [checked, setChecked] = React.useState('10:42');
  const [conf, setConf] = useConfirm();
  const svc = [['Web app (Next.js)', '2.4.1', 'Healthy'], ['Agent service', '2.4.0', 'Healthy'], ['Temporal', '1.26', 'Healthy'], ['LiteLLM gateway', '1.61', 'Degraded', ['vllm-dc1 is timing out; requests fall back to cloud routes.', 'vllm-dc1 يتجاوز المهلة؛ تُحوّل الطلبات إلى المسارات السحابية.']], ['Langfuse', '3.12', 'Healthy'], ['SQL Server', '2022 CU16', 'Healthy'], ['Qdrant', '1.13', 'Healthy'], ['Neo4j', '5.26', 'Healthy'], ['MinIO', '2026-09', 'Healthy'], ['Redis', '7.4', 'Healthy']];
  const ok = svc.filter((s) => s[2] === 'Healthy').length;
  return (
    <div className="awp-page">
      <PageHead crumb={T('Govern', 'الحوكمة')} title={T('System', 'النظام')} sub={T('Versions and health of every platform service.', 'إصدارات وحالة كل خدمات المنصة.')}><Btn type="secondary" label={T('Check now', 'الفحص الآن')} onClick={() => setChecked(new Date().toTimeString().slice(0, 5))} />{paused ? <Btn label={T('Resume all agents', 'استئناف كل الوكلاء')} onClick={() => setPaused(false)} /> : <Btn type="danger" label={T('Pause all agents', 'إيقاف كل الوكلاء')} onClick={() => setConf({ title: T('Pause all agents?', 'إيقاف كل الوكلاء؟'), intro: T('14 running runs finish their current step and stop. New runs wait in the queue until you resume. Discussion rooms and the widget show agents as unavailable.', 'تُكمل 14 عملية جارية خطوتها الحالية ثم تتوقف. تنتظر العمليات الجديدة في الطابور حتى الاستئناف. تُظهر اجتماعات العمل والويدجت الوكلاء كغير متاحين.'), confirm: T('Pause all agents', 'إيقاف كل الوكلاء'), onConfirm: () => setPaused(true) })} />}</PageHead>
      {paused && <Banner tone="warning">{T('All agents are paused. Running workflows are drained; new runs are queued.', 'جميع الوكلاء متوقفون. تُستكمل العمليات الجارية وتُوضع العمليات الجديدة في الطابور.')}</Banner>}
      <KpiRow items={[{ label: T('Dependencies healthy', 'الخدمات السليمة'), value: ok + ' / ' + svc.length, tone: ok < svc.length ? 'warning' : 'success', note: T('Last checked ' + checked, 'آخر فحص ' + checked) }, { label: T('Active runs', 'العمليات النشطة'), value: paused ? '0' : '14' }, { label: T('Queue depth', 'عمق الطابور'), value: paused ? '22' : '3' }, { label: T('Uptime (30d)', 'وقت التشغيل (30ي)'), value: '99.94%' }]} />
      <Grid min={220}>{svc.map(([n, v, s, why]) => <div key={n} className="awp-card" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}><div className="awp-row"><b style={{ flex: 1 }}>{n}</b><StTag s={s} /></div><span className="awp-small awp-muted awp-mono">{v}</span>{why && <span className="awp-small" style={{ color: 'var(--text-warning)' }}>{T(...why)}</span>}</div>)}</Grid>
      {conf}
    </div>
  );
}

const DOC_TOC = () => [[T('Getting started', 'البدء'), T('A new installation starts empty. Open [Setup Director](setup) and describe your organisation: mission, departments, services, systems and policies. The Director proposes a blueprint as a change set; nothing is applied until an administrator approves it.', 'يبدأ التثبيت الجديد فارغاً. افتح [مدير الإعداد](setup) وصِف مؤسستك: الرسالة والأقسام والخدمات والأنظمة والسياسات. يقترح المدير مخططاً كمجموعة تغييرات، ولا يُطبق شيء حتى يعتمده المسؤول.')], [T('Discussion rooms', 'اجتماعات العمل'), T('[Discussion rooms](sessions) are topic-scoped rooms inside a project. Mention an agent with @ to start a run with the room context. The moderator sets the turn-taking policy.', '[اجتماعات العمل](sessions) مخصصة لموضوعات داخل مشروع. أشر إلى وكيل باستخدام @ لبدء عملية بسياق الاجتماع. يحدد المشرف سياسة تبادل الأدوار.')], [T('Approvals', 'الاعتمادات'), T('Agents never approve their own work. T2 tools pause the run until a person decides in the [Inbox](inbox) or from a channel.', 'لا يعتمد الوكلاء عملهم أبداً. توقف أدوات T2 العملية حتى يقرر شخص من [صندوق الوارد](inbox) أو القناة.')], [T('Storylines', 'السيناريوهات'), T('In strict mode the agent may only perform the current step. Messages marked exact are sent verbatim. Edit storylines in [Embedded Deployment](deployments).', 'في الوضع الصارم لا يؤدي الوكيل إلا الخطوة الحالية. تُرسل الرسائل المعلّمة exact حرفياً. عدّل السيناريوهات في [النشر المضمّن](deployments).')], [T('Connectors & tiers', 'التكاملات والمستويات'), T('Tool tiers default from MCP annotations: read-only is T0, destructive is T2. Project policies can only raise tiers. Manage them in [Connectors](connectors).', 'تُحدد المستويات افتراضياً من تعليقات MCP: القراءة فقط T0، والمدمّرة T2. يمكن لسياسات المشروع رفع المستويات فقط. أدرها في [التكامل](connectors).')]];
const DocText = ({ t }) => <>{t.split(/(\[[^\]]+\]\([a-z0-9]+\))/g).map((p, i) => { const m = /^\[([^\]]+)\]\(([a-z0-9]+)\)$/.exec(p); return m ? <Lnk key={i} onClick={() => window.__awpGo(m[2])}>{m[1]}</Lnk> : p; })}</>;
function Docs() {
  const [sel, setSel] = React.useState(0);
  const [q, setQ] = React.useState('');
  const toc = DOC_TOC();
  const list = toc.map((x, i) => [...x, i]).filter((x) => !q || (x[0] + x[1]).toLowerCase().includes(q.toLowerCase()));
  const cur = list.find((x) => x[2] === sel) || list[0];
  return (
    <div className="awp-page">
      <PageHead crumb={T('Help', 'الدعم')} title={T('Documentation', 'المساعدة')} />
      <input className="awp-input" style={{ maxWidth: 360 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={T('Search documentation', 'ابحث في المساعدة')} />
      {!list.length ? <Card><Empty title={T('No articles match "' + q + '".', 'لا توجد مقالات تطابق "' + q + '".')}><Pill onClick={() => setQ('')}>{T('Clear search', 'مسح البحث')}</Pill></Empty></Card> :
      <div style={{ display: 'grid', gridTemplateColumns: '240px minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card pad={false}>{list.map(([t, , i]) => <button key={i} className={'awp-nav-i' + (cur[2] === i ? ' on' : '')} style={{ borderRadius: 0 }} onClick={() => setSel(i)}>{t}</button>)}</Card>
        <Card title={cur[0]}><p style={{ margin: 0, lineHeight: 1.7, maxWidth: 680 }}><DocText t={cur[1]} /></p></Card>
      </div>}
    </div>
  );
}

Object.assign(window, { Integrations, SystemPage, Docs, CLIENTS });
