const PROV_SEED = [
  { id: 'anthropic', n: 'Anthropic', ini: 'A', c: 'var(--chart-series-5)', kind: 'Cloud', on: true, models: ['claude-opus-4.1', 'claude-sonnet-4.5', 'claude-haiku-4.5'], conns: [{ id: 'anth-prod', n: 'Production', ep: 'api.anthropic.com', auth: 'API key', region: 'Global', on: true, allow: ['claude-sonnet-4.5', 'claude-haiku-4.5'], st: 'Healthy' }, { id: 'anth-rnd', n: 'R&D sandbox', ep: 'api.anthropic.com', auth: 'API key', region: 'Global', on: false, allow: ['claude-opus-4.1'], st: 'Disabled' }] },
  { id: 'openai', n: 'OpenAI', ini: 'O', c: 'var(--chart-series-6)', kind: 'Cloud', on: true, models: ['gpt-4.1', 'gpt-4.1-mini', 'o4-mini', 'text-embedding-3-large', 'gpt-realtime', 'gpt-4o-transcribe', 'gpt-4o-mini-tts'], conns: [{ id: 'oai-main', n: 'Main', ep: 'api.openai.com', auth: 'API key', region: 'Global', on: true, allow: ['text-embedding-3-large', 'gpt-realtime', 'gpt-4o-transcribe', 'gpt-4o-mini-tts'], st: 'Healthy' }] },
  { id: 'azure', n: 'Azure OpenAI', ini: 'Az', c: 'var(--chart-series-1)', kind: 'Cloud', on: true, models: ['gpt-4.1', 'gpt-4.1-mini', 'o4-mini', 'gpt-realtime'], conns: [{ id: 'az-uaen', n: 'UAE North', ep: 'tahseel-uaen.openai.azure.com', auth: 'Entra ID', region: 'UAE North', on: true, allow: ['gpt-4.1', 'gpt-4.1-mini', 'gpt-realtime'], st: 'Healthy' }, { id: 'az-weu', n: 'West Europe (DR)', ep: 'tahseel-weu.openai.azure.com', auth: 'Entra ID', region: 'West Europe', on: true, allow: ['gpt-4.1-mini'], st: 'Healthy' }] },
  { id: 'gemini', n: 'Google Gemini', ini: 'G', c: 'var(--chart-series-4)', kind: 'Cloud', on: false, models: ['gemini-2.5-pro', 'gemini-2.5-flash'], conns: [] },
  { id: 'bedrock', n: 'AWS Bedrock', ini: 'B', c: 'var(--chart-series-3)', kind: 'Cloud', on: true, models: ['claude-sonnet-4.5', 'llama-3.3-70b', 'titan-embed-v2'], conns: [{ id: 'br-me', n: 'me-central-1', ep: 'bedrock-runtime.me-central-1', auth: 'IAM role', region: 'UAE', on: true, allow: ['claude-sonnet-4.5'], st: 'Healthy' }] },
  { id: 'mistral', n: 'Mistral AI', ini: 'M', c: 'var(--chart-series-2)', kind: 'Cloud', on: false, models: ['mistral-large', 'mistral-small'], conns: [] },
  { id: 'cohere', n: 'Cohere', ini: 'C', c: 'var(--chart-series-5)', kind: 'Cloud', on: false, models: ['command-r-plus', 'rerank-v3.5'], conns: [] },
  { id: 'groq', n: 'Groq', ini: 'Gq', c: 'var(--chart-series-3)', kind: 'Cloud', on: false, models: ['llama-3.3-70b', 'mixtral-8x7b'], conns: [] },
  { id: 'deepseek', n: 'DeepSeek', ini: 'DS', c: 'var(--chart-series-1)', kind: 'Cloud', on: false, models: ['deepseek-chat', 'deepseek-reasoner'], conns: [] },
  { id: 'vllm', n: 'vLLM (on-prem)', ini: 'vL', c: 'var(--chart-series-6)', kind: 'Custom', engine: 'vLLM', on: true, models: ['qwen3-32b', 'llama-3.3-70b'], conns: [{ id: 'vllm-dc1', n: 'Dubai DC1 GPU', ep: 'http://10.20.4.11:8000/v1', auth: 'Bearer token', region: 'UAE (on-prem)', on: true, allow: ['qwen3-32b'], st: 'Degraded' }] },
];
const ENGINES = [['Ollama', 'http://localhost:11434'], ['vLLM', 'http://host:8000/v1'], ['LM Studio', 'http://localhost:1234/v1'], ['Hugging Face TGI', 'http://host:8080'], ['llama.cpp server', 'http://host:8080/v1'], ['LocalAI', 'http://host:8080/v1'], ['NVIDIA Triton / NIM', 'http://host:8000/v1'], ['OpenAI-compatible (other)', 'https://']];
const ROUTES0 = [
  { a: 'reasoning-default', use: ['Main', 'رئيسي'], chain: [['anthropic', 'anth-prod', 'claude-sonnet-4.5'], ['azure', 'az-uaen', 'gpt-4.1']], agents: 3 },
  { a: 'small-fast', use: ['Main (interactive)', 'رئيسي (تفاعلي)'], chain: [['anthropic', 'anth-prod', 'claude-haiku-4.5'], ['azure', 'az-weu', 'gpt-4.1-mini']], agents: 2 },
  { a: 'vision', use: ['Auxiliary', 'مساعد'], chain: [['azure', 'az-uaen', 'gpt-4.1'], ['bedrock', 'br-me', 'claude-sonnet-4.5']], agents: 1 },
  { a: 'embedding-default', use: ['Auxiliary', 'مساعد'], chain: [['openai', 'oai-main', 'text-embedding-3-large']], agents: 0 },
  { a: 'classifier-typed', use: ['Classification (typed output)', 'التصنيف (مخرجات مضبوطة النوع)'], schema: 'RequestClassification v3', chain: [['anthropic', 'anth-prod', 'claude-haiku-4.5'], ['azure', 'az-uaen', 'gpt-4.1-mini']], agents: 2 },
  { a: 'voice-realtime', use: ['Voice (speech-to-speech)', 'الصوت (كلام إلى كلام)'], voice: 'STT gpt-4o-transcribe · TTS gpt-4o-mini-tts · AR/EN', chain: [['azure', 'az-uaen', 'gpt-realtime'], ['openai', 'oai-main', 'gpt-realtime']], agents: 1 },
  { a: 'local-private', use: ['Restricted data', 'بيانات مقيدة'], chain: [['vllm', 'vllm-dc1', 'qwen3-32b']], agents: 1 },
];

const ProvIcon = ({ p, s = 40 }) => <span style={{ width: s, height: s, borderRadius: 12, display: 'inline-grid', placeItems: 'center', background: p.c, color: 'var(--text-on-action)', fontWeight: 900, fontSize: s * 0.36, flexShrink: 0 }}>{p.ini}</span>;

const mKind = (m) => /embed/.test(m) ? 'Embedding' : /realtime/.test(m) ? 'Realtime' : /transcribe/.test(m) ? 'Speech-to-text' : /tts/.test(m) ? 'Text-to-speech' : /rerank/.test(m) ? 'Re-rank' : 'Chat';
const MK = [['Chat', 'محادثة'], ['Embedding', 'تضمين'], ['Realtime', 'لحظي'], ['Speech-to-text', 'كلام إلى نص'], ['Text-to-speech', 'نص إلى كلام'], ['Re-rank', 'إعادة ترتيب']];
const usesOf = (routes, pid, cid, m) => routes.filter((r) => r.chain.some((s) => s[0] === pid && (!cid || s[1] === cid) && (!m || s[2] === m)));
function ConnEditor({ p, conn, onSave, onClose }) {
  const [c, setC] = React.useState(conn || { id: 'new-' + Date.now(), n: '', ep: p.conns[0] ? p.conns[0].ep : '', auth: 'API key', region: '', on: true, allow: [], st: 'Healthy' });
  const [kinds, setKinds] = React.useState(() => Object.fromEntries(p.models.map((m) => [m, mKind(m)])));
  const [extra, setExtra] = React.useState([]);
  const [nm2, setNm2] = React.useState('');
  const [test, setTest] = React.useState(conn ? 'ok' : null);
  const [secret, setSecret] = React.useState('');
  const models = [...p.models, ...extra];
  const tog = (m) => { setC({ ...c, allow: c.allow.includes(m) ? c.allow.filter((x) => x !== m) : [...c.allow, m] }); setTest(null); };
  const run = () => { setTest('run'); setTimeout(() => setTest(c.allow.map((m) => [m, !/^qwen|custom/.test(m) || p.id !== 'vllm' ? 'OK' : 'FAILED'])), 800); };
  const passed = test === 'ok' || (Array.isArray(test) && test.every((r) => r[1] === 'OK'));
  return (
    <Modal w={640} title={(conn ? T('Edit connection', 'تعديل الاتصال') : T('Add connection', 'إضافة اتصال')) + ' · ' + p.n} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn type="secondary" label={test === 'run' ? T('Testing…', 'جارٍ الاختبار…') : T('Test', 'اختبار')} disabled={!c.allow.length || test === 'run'} onClick={run} /><Btn label={T('Save connection', 'حفظ الاتصال')} disabled={!c.n.trim() || !c.allow.length || !passed} onClick={() => onSave(c)} /></>}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Connection name', 'اسم الاتصال')}><input className="awp-input" value={c.n} onChange={(e) => setC({ ...c, n: e.target.value })} placeholder={T('e.g. Production', 'مثال: الإنتاج')} /></Field>
        <Field label={T('Region', 'المنطقة')}><input className="awp-input" value={c.region} onChange={(e) => setC({ ...c, region: e.target.value })} /></Field>
      </div>
      <Field label={T('Endpoint', 'نقطة النهاية')}><input className="awp-input awp-mono" value={c.ep} onChange={(e) => { setC({ ...c, ep: e.target.value }); setTest(null); }} /></Field>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Authentication', 'المصادقة')}><PopSelect className="awp-input" value={c.auth} onChange={(e) => setC({ ...c, auth: e.target.value })}>{['API key', 'Bearer token', 'Entra ID', 'IAM role', 'None'].map((x) => <option key={x}>{x}</option>)}</PopSelect></Field>
        {c.auth !== 'None' && <Field label={T('Secret', 'السر')} hint={conn ? T('Saved. Enter a new value only to replace it.', 'محفوظ. أدخل قيمة جديدة فقط لاستبداله.') : T('Stored encrypted and never shown again.', 'يُخزّن مشفراً ولا يظهر مرة أخرى.')}><input className="awp-input" type="password" autoComplete="new-password" value={secret} onChange={(e) => { setSecret(e.target.value); setTest(null); }} placeholder={conn ? T('Saved · enter to replace', 'محفوظ · أدخل للاستبدال') : ''} /></Field>}
      </div>
      <Field label={T('Allowed models on this connection', 'النماذج المسموحة على هذا الاتصال')} hint={T('Routes can only use models allowed here. Set what each model is for.', 'لا يمكن للمسارات استخدام إلا النماذج المسموحة هنا. حدد استخدام كل نموذج.')}>
        <div className="awp-col" style={{ gap: 8 }}>
          {models.map((m) => <div key={m} className="awp-row" style={{ gap: 10, flexWrap: 'wrap' }}><label className="awp-row" style={{ gap: 10, flex: 1, minWidth: 180 }}><input type="checkbox" checked={c.allow.includes(m)} onChange={() => tog(m)} /><span className="awp-mono">{m}</span></label><PopSelect className="awp-input" style={{ width: 170, height: 36 }} value={kinds[m] || 'Chat'} onChange={(e) => setKinds({ ...kinds, [m]: e.target.value })}>{MK.map(([k, a]) => <option key={k} value={k}>{T(k, a)}</option>)}</PopSelect>{Array.isArray(test) && test.find((r) => r[0] === m) && <Tg tone={test.find((r) => r[0] === m)[1] === 'OK' ? 'success' : 'danger'} label={test.find((r) => r[0] === m)[1] === 'OK' ? T('OK · ' + (300 + m.length * 37) + ' ms', 'ناجح · ' + (300 + m.length * 37) + ' م.ث') : T('FAILED · model not found', 'فشل · النموذج غير موجود')} />}</div>)}
          <div className="awp-row" style={{ gap: 8 }}><input className="awp-input awp-mono" style={{ flex: 1 }} value={nm2} onChange={(e) => setNm2(e.target.value.trim())} placeholder={T('Add a model name by hand', 'أضف اسم نموذج يدوياً')} /><Pill disabled={!nm2 || models.includes(nm2)} onClick={() => { setExtra([...extra, nm2]); setKinds({ ...kinds, [nm2]: mKind(nm2) }); setC({ ...c, allow: [...c.allow, nm2] }); setNm2(''); setTest(null); }}>{T('Add', 'إضافة')}</Pill></div>
          {!c.allow.length && <Banner tone="warning">{T('No models are allowed. Routes cannot use this connection until you allow at least one.', 'لا توجد نماذج مسموحة. لا يمكن للمسارات استخدام هذا الاتصال حتى تسمح بنموذج واحد على الأقل.')}</Banner>}
        </div>
      </Field>
      {Array.isArray(test) && !passed && <Banner tone="danger">{T('Some models failed the test. Remove them or fix the endpoint before saving.', 'فشلت بعض النماذج في الاختبار. أزلها أو صحّح نقطة النهاية قبل الحفظ.')}</Banner>}
      {passed && Array.isArray(test) && <Banner tone="success">{T('All allowed models answered. You can save.', 'استجابت كل النماذج المسموحة. يمكنك الحفظ.')}</Banner>}
      {test === null && c.allow.length > 0 && <span className="awp-small awp-muted">{T('Test the connection before saving.', 'اختبر الاتصال قبل الحفظ.')}</span>}
      <div className="awp-row" style={{ gap: 10 }}><Toggle on={c.on} onChange={(v) => setC({ ...c, on: v })} /><span>{T('Connection active', 'الاتصال نشط')}</span></div>
    </Modal>
  );
}

function ProviderDrawer({ p, onChange, onClose, routes, onDelete }) {
  const [edit, setEdit] = React.useState(null);
  const [conf, setConf] = useConfirm();
  const refuse = (what, list) => setConf({ title: T('Cannot remove ' + what, 'لا يمكن إزالة ' + what), intro: T('It is used by these routes. Change them first:', 'تستخدمه هذه المسارات. غيّرها أولاً:'), items: list.map((r) => r.a), blocked: true });
  const saveConn = (c) => { const exists = p.conns.find((x) => x.id === c.id); onChange({ ...p, conns: exists ? p.conns.map((x) => (x.id === c.id ? c : x)) : [...p.conns, c] }); setEdit(null); };
  return (
    <>
      <Drawer w={640} title={<span className="awp-row" style={{ gap: 12 }}><ProvIcon p={p} s={36} />{p.n}</span>} sub={(p.engine ? p.engine + ' · ' : '') + p.conns.length + ' ' + T('connections', 'اتصالات')} onClose={onClose} footer={<><Btn label={T('Add connection', 'إضافة اتصال')} icon="AddCircle" onClick={() => setEdit('new')} /><Btn type="secondary" label={T('Close', 'إغلاق')} onClick={onClose} /><span style={{ flex: 1 }} /><Btn type="danger" label={T('Delete provider', 'حذف المزود')} onClick={() => { const u = usesOf(routes, p.id); u.length ? refuse(p.n, u) : setConf({ title: T('Delete ' + p.n + '?', 'حذف ' + p.n + '؟'), intro: T('Its ' + p.conns.length + ' connections and saved secrets are removed.', 'تُزال اتصالاته الـ ' + p.conns.length + ' وأسراره المحفوظة.'), confirm: T('Delete provider', 'حذف المزود'), onConfirm: () => { onDelete(p.id); onClose(); } }); }} /></>}>
        <div className="awp-row" style={{ padding: 14, borderRadius: 12, background: 'var(--surface-card)' }}><div style={{ flex: 1 }}><b>{T('Provider active', 'المزود نشط')}</b><div className="awp-small awp-muted">{T('When off, every connection and route step using this provider is skipped.', 'عند الإيقاف، يُتخطى كل اتصال وخطوة مسار تستخدم هذا المزود.')}</div></div><Toggle on={p.on} onChange={(v) => onChange({ ...p, on: v })} /></div>
        <div className="awp-col" style={{ gap: 12 }}>
          <b>{T('Connections', 'الاتصالات')}</b>
          {p.conns.length === 0 && <p className="awp-muted" style={{ margin: 0 }}>{T('No connections yet. Add one to start using this provider.', 'لا توجد اتصالات بعد. أضف اتصالاً لبدء استخدام هذا المزود.')}</p>}
          {p.conns.map((c) => (
            <div key={c.id} className="awp-card" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10, opacity: c.on && p.on ? 1 : 0.7 }}>
              <div className="awp-row"><b style={{ flex: 1 }}>{c.n}</b><StTag s={c.on ? c.st : 'Disabled'} /><Toggle on={c.on} onChange={(v) => onChange({ ...p, conns: p.conns.map((x) => (x.id === c.id ? { ...x, on: v } : x)) })} /></div>
              <div className="awp-small awp-muted awp-mono">{c.ep} · {c.auth} · {c.region}</div>
              <div className="awp-row" style={{ flexWrap: 'wrap', gap: 6 }}><span className="awp-small awp-muted">{T('Allowed models', 'النماذج المسموحة')}:</span>{c.allow.length ? c.allow.map((m) => <Tg key={m} label={m} />) : <span className="awp-small awp-muted">{T('None', 'لا شيء')}</span>}</div>
              <div className="awp-row" style={{ gap: 12 }}><Lnk onClick={() => setEdit(c)}>{T('Configure', 'إعداد')}</Lnk><Lnk onClick={() => window.__awpAct({ title: T('Test connection', 'اختبار الاتصال') + ' · ' + c.n, desc: T('Sends a short completion to each allowed model.', 'يرسل طلباً قصيراً لكل نموذج مسموح.'), confirm: T('Run test', 'تشغيل الاختبار'), result: c.allow.map((m) => m + (c.st === 'Degraded' && m === c.allow[0] ? ' · FAILED · timeout after 30 s' : ' · OK · ' + (300 + m.length * 37) + ' ms')) })}>{T('Test', 'اختبار')}</Lnk><Lnk danger onClick={() => { const u = usesOf(routes, p.id, c.id); u.length ? refuse(c.n, u) : onChange({ ...p, conns: p.conns.filter((x) => x.id !== c.id) }); }}>{T('Remove', 'إزالة')}</Lnk></div>
            </div>
          ))}
        </div>
        <div><b>{T('Models offered by provider', 'النماذج التي يقدمها المزود')}</b><div className="awp-row" style={{ flexWrap: 'wrap', gap: 6, marginTop: 8 }}>{p.models.map((m) => <Tg key={m} label={m} />)}</div></div>
      </Drawer>
      {edit && <ConnEditor p={p} conn={edit === 'new' ? null : edit} onSave={saveConn} onClose={() => setEdit(null)} />}
      {conf}
    </>
  );
}

function CustomProviderModal({ onClose, onAdd }) {
  const [eng, setEng] = React.useState('Ollama');
  const [url, setUrl] = React.useState(ENGINES[0][1]);
  const [name, setName] = React.useState('');
  const [found, setFound] = React.useState(null);
  const [allow, setAllow] = React.useState([]);
  const [fail, setFail] = React.useState(false);
  const [man, setMan] = React.useState('');
  const discover = () => { if (eng === 'OpenAI-compatible (other)' || !/^https?:\/\/[^/]+/.test(url)) { setFail(true); setFound(found || []); return; } setFail(false); const m = eng === 'Ollama' ? ['llama3.3:70b', 'qwen3:32b', 'nomic-embed-text'] : ['qwen3-32b', 'llama-3.3-70b-instruct']; setFound(m); setAllow(m.slice(0, 1)); };
  return (
    <Modal w={620} title={T('Add custom provider', 'إضافة مزود مخصص')} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Add provider', 'إضافة المزود')} disabled={!found || !allow.length} onClick={() => { onAdd({ id: 'cus-' + Date.now(), n: name || eng, ini: eng.slice(0, 2), c: 'var(--chart-series-2)', kind: 'Custom', engine: eng, on: true, models: found, conns: [{ id: 'c1', n: T('Default', 'افتراضي'), ep: url, auth: 'None', region: T('On-prem', 'محلي'), on: true, allow, st: 'Healthy' }] }); onClose(); }} /></>}>
      <Field label={T('Inference engine', 'محرك الاستدلال')}><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(160px,100%),1fr))', gap: 8 }}>{ENGINES.map(([e, u]) => <button key={e} className={'awp-chip' + (eng === e ? ' on' : '')} style={{ height: 44, borderRadius: 12, justifyContent: 'center' }} onClick={() => { setEng(e); setUrl(u); setFound(null); }}>{e}</button>)}</div></Field>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Field label={T('Display name', 'الاسم المعروض')}><input className="awp-input" value={name} onChange={(e) => setName(e.target.value)} placeholder={eng + ' — DC1'} /></Field>
        <Field label={T('API key (optional)', 'مفتاح API (اختياري)')}><input className="awp-input" type="password" /></Field>
      </div>
      <Field label={T('Base URL', 'الرابط الأساسي')}><div className="awp-row" style={{ gap: 8 }}><input className="awp-input awp-mono" value={url} onChange={(e) => setUrl(e.target.value)} /><Btn type="secondary" label={T('Discover models', 'اكتشاف النماذج')} onClick={discover} /></div></Field>
      {fail && <Banner tone="warning">{T('The server did not list its models. Enter the model names it serves.', 'لم يسرد الخادم نماذجه. أدخل أسماء النماذج التي يقدمها.')}</Banner>}
      {fail && <div className="awp-row" style={{ gap: 8 }}><input className="awp-input awp-mono" style={{ flex: 1 }} value={man} onChange={(e) => setMan(e.target.value.trim())} placeholder="model-name" /><Pill disabled={!man || (found || []).includes(man)} onClick={() => { setFound([...(found || []), man]); setAllow([...allow, man]); setMan(''); }}>{T('Add model', 'إضافة نموذج')}</Pill></div>}
      {found && found.length > 0 && <Field label={fail ? T('Models to allow', 'النماذج المسموحة') : T('Models found — choose which to allow', 'النماذج المكتشفة — اختر المسموح منها')}><div className="awp-col" style={{ gap: 8 }}>{found.map((m) => <label key={m} className="awp-row" style={{ gap: 10 }}><input type="checkbox" checked={allow.includes(m)} onChange={() => setAllow(allow.includes(m) ? allow.filter((x) => x !== m) : [...allow, m])} /><span className="awp-mono">{m}</span></label>)}</div></Field>}
    </Modal>
  );
}

function RouteEditor({ r, provs, onSave, onClose }) {
  const [x, setX] = React.useState(r || { a: '', use: ['Main', 'رئيسي'], chain: [['', '', '']], agents: 0 });
  const [sch, setSch] = React.useState(r && r.schema ? r.schema : 'RequestClassification v3');
  const [json, setJson] = React.useState('{\n  "type": "object",\n  "properties": { "label": { "type": "string" } },\n  "required": ["label"]\n}');
  const jsonBad = sch === 'custom' && (() => { try { JSON.parse(json); return false; } catch (e) { return true; } })();
  const voice = x.use[0].startsWith('Voice'), emb = x.use[0] === 'Embedding';
  const okModel = (m) => voice ? /realtime/.test(m) : emb ? /embed/.test(m) : !/embed|realtime|transcribe|tts/.test(m);
  const complete = x.chain.some((s) => s[0] && s[1] && s[2]);
  const live = provs.filter((p) => p.on && p.conns.some((c) => c.on));
  const set = (i, j, v) => { const chain = x.chain.map((s, k) => { if (k !== i) return s; const n = [...s]; n[j] = v; if (j === 0) { n[1] = ''; n[2] = ''; } if (j === 1) n[2] = ''; return n; }); setX({ ...x, chain }); };
  return (
    <Modal w={720} title={r ? T('Edit route', 'تعديل المسار') + ' · ' + r.a : T('New route', 'مسار جديد')} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Save route', 'حفظ المسار')} disabled={!complete || jsonBad} onClick={() => onSave({ ...x, schema: x.use[0].startsWith('Classification') ? (sch === 'custom' ? T('Custom schema', 'مخطط مخصص') : sch) : x.schema, a: x.a || slug(x.use[0].split(' ')[0] + ' ' + x.chain[0][2].split('-').slice(0, 2).join(' ')) })} /></>}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 12 }}>
        <Field label={T('Use', 'الاستخدام')}><PopSelect className="awp-input" value={x.use[0]} onChange={(e) => setX({ ...x, use: [e.target.value, e.target.value] })}>{['Main', 'Main (interactive)', 'Auxiliary', 'Verifier', 'Embedding', 'Classification (typed output)', 'Voice (speech-to-speech)', 'Restricted data'].map((u) => <option key={u}>{u}</option>)}</PopSelect></Field>
      </div>
      {x.use[0].startsWith('Classification') && <div className="awp-card" style={{ padding: 14, background: 'var(--surface-card)', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="awp-row"><Tg tone="info" label={T('Typesafe', 'مضبوط النوع')} /><span className="awp-small awp-muted">{T('Responses must validate against the schema; invalid output is retried, then routed to the fallback.', 'يجب أن تطابق الاستجابات المخطط؛ تُعاد المخرجات غير الصالحة ثم تُحوّل إلى البديل.')}</span></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
          <Field label={T('Output schema', 'مخطط المخرجات')}><PopSelect className="awp-input" value={sch} onChange={(e) => setSch(e.target.value)}><option>RequestClassification v3</option><option>IntentLabel v1</option><option>SentimentLabel v2</option><option value="custom">{T('Custom JSON Schema', 'مخطط JSON مخصص')}</option></PopSelect></Field>
          <Field label={T('Confidence threshold', 'حد الثقة')}><input className="awp-input" defaultValue="0.80" /></Field>
          <Field label={T('Max retries on invalid', 'أقصى إعادة عند عدم الصلاحية')}><input className="awp-input" defaultValue="2" /></Field>
        </div>
        {sch === 'custom' ? <Field label={T('JSON Schema', 'مخطط JSON')} hint={jsonBad ? <span style={{ color: 'var(--text-danger)' }}>{T('This is not valid JSON.', 'هذا ليس JSON صالحاً.')}</span> : null}><textarea className="awp-input awp-mono" rows={7} style={{ direction: 'ltr', textAlign: 'left', padding: 12 }} value={json} onChange={(e) => setJson(e.target.value)} /></Field> : <pre className="awp-mono" style={{ margin: 0, padding: 12, borderRadius: 10, background: 'var(--surface-sunken)', whiteSpace: 'pre-wrap', direction: 'ltr', textAlign: 'left', fontSize: 12 }}>{'{ "request_type": enum[EXP,PUR,CRD,LEV,BUG,VEN],\n  "confidence": number 0..1,\n  "attributes": object,\n  "needs_human": boolean }'}</pre>}
      </div>}
      {x.use[0].startsWith('Voice') && <div className="awp-card" style={{ padding: 14, background: 'var(--surface-card)', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(180px,100%),1fr))', gap: 12 }}>
        <Field label={T('Mode', 'الوضع')}><PopSelect className="awp-input"><option>{T('Realtime speech-to-speech', 'كلام إلى كلام لحظي')}</option><option>{T('Pipeline: STT → LLM → TTS', 'تسلسل: نص ← نموذج ← صوت')}</option></PopSelect></Field>
        <Field label={T('Speech-to-text', 'تحويل الكلام إلى نص')}><PopSelect className="awp-input"><option>gpt-4o-transcribe</option></PopSelect></Field>
        <Field label={T('Text-to-speech voice', 'صوت تحويل النص إلى كلام')}><PopSelect className="awp-input"><option>gpt-4o-mini-tts · alloy</option><option>gpt-4o-mini-tts · verse</option></PopSelect></Field>
        <Field label={T('Languages', 'اللغات')}><input className="awp-input" defaultValue="ar-AE, en-US" /></Field>
        <Field label={T('Barge-in', 'المقاطعة')}><PopSelect className="awp-input"><option>{T('Allowed', 'مسموحة')}</option><option>{T('Off', 'معطّلة')}</option></PopSelect></Field>
        <Field label={T('Max call length', 'أقصى مدة للمكالمة')}><input className="awp-input" defaultValue="15 min" /></Field>
      </div>}
      <Field label={T('Chain — tried in order', 'السلسلة — تُجرب بالترتيب')}>
        <div className="awp-col" style={{ gap: 10 }}>
          {x.chain.map((s, i) => { const p = provs.find((q) => q.id === s[0]); const c = p && p.conns.find((q) => q.id === s[1]); return (
            <div key={i} className="awp-row" style={{ gap: 8, flexWrap: 'wrap' }}>
              <Tg tone={i ? 'neutral' : 'brand'} label={i ? T('Fallback ', 'بديل ') + i : T('Primary', 'أساسي')} />
              <PopSelect className="awp-input" style={{ flex: 1, minWidth: 140 }} value={s[0]} onChange={(e) => set(i, 0, e.target.value)}><option value="">{T('Provider', 'المزود')}</option>{live.map((q) => <option key={q.id} value={q.id}>{q.n}</option>)}</PopSelect>
              <PopSelect className="awp-input" style={{ flex: 1, minWidth: 140 }} value={s[1]} disabled={!p} onChange={(e) => set(i, 1, e.target.value)}><option value="">{T('Connection', 'الاتصال')}</option>{p && p.conns.filter((q) => q.on).map((q) => <option key={q.id} value={q.id}>{q.n}</option>)}</PopSelect>
              <select className="awp-input awp-mono" style={{ flex: 1, minWidth: 160 }} value={s[2]} disabled={!c} onChange={(e) => set(i, 2, e.target.value)}><option value="">{T('Model', 'النموذج')}</option>{c && c.allow.filter(okModel).map((m) => <option key={m}>{m}</option>)}</select>
              {x.chain.length > 1 && <button className="awp-iconbtn" style={{ width: 36, height: 36 }} aria-label={T('Remove', 'إزالة')} onClick={() => setX({ ...x, chain: x.chain.filter((_, k) => k !== i) })}><Ic n="X" s={16} /></button>}
            </div>); })}
          {(voice || emb) && <span className="awp-small awp-muted">{voice ? T('Only realtime models are listed for voice routes.', 'تظهر النماذج اللحظية فقط لمسارات الصوت.') : T('Only embedding models are listed for embedding routes.', 'تظهر نماذج التضمين فقط لمسارات التضمين.')}</span>}
          {!complete && <span className="awp-small" style={{ color: 'var(--text-danger)' }}>{T('Complete at least one step with provider, connection and model.', 'أكمل خطوة واحدة على الأقل بالمزود والاتصال والنموذج.')}</span>}
          <div><Btn type="secondary" label={T('Add fallback', 'إضافة بديل')} icon="AddCircle" onClick={() => setX({ ...x, chain: [...x.chain, ['', '', '']] })} /></div>
        </div>
      </Field>
      <Field label={T('Alias', 'الاسم المستعار')} hint={r ? T('Agents reference this alias.', 'يشير الوكلاء إلى هذا الاسم.') : T('Suggested from use and primary model. You can change it.', 'مقترح من الاستخدام والنموذج الأساسي. يمكنك تغييره.')}><input className="awp-input awp-mono" value={x.a || (x.chain[0][2] ? slug(x.use[0].split(' ')[0] + ' ' + x.chain[0][2].split('-').slice(0, 2).join(' ')) : '')} onChange={(e) => setX({ ...x, a: e.target.value })} placeholder={T('auto', 'تلقائي')} /></Field>
    </Modal>
  );
}

function Models() {
  const [tab, setTab] = React.useState('providers');
  const [provs, setProvs] = React.useState(PROV_SEED);
  const [routes, setRoutes] = React.useState(ROUTES0);
  const [open, setOpen] = React.useState(null);
  const [custom, setCustom] = React.useState(false);
  const [rEdit, setREdit] = React.useState(null);
  const [kind, setKind] = React.useState('all');
  const [cloud, setCloud] = React.useState(false);
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  const upd = (p) => setProvs(provs.map((x) => (x.id === p.id ? p : x)));
  const cur = open && provs.find((x) => x.id === open);
  const step = (s) => { const p = provs.find((q) => q.id === s[0]); const c = p && p.conns.find((q) => q.id === s[1]); const ok = p && p.on && c && c.on; return (
    <span className="awp-row" style={{ gap: 6, opacity: ok ? 1 : 0.55 }}>{p && <ProvIcon p={p} s={22} />}<button className="awp-lnk-t" onClick={() => p && setOpen(p.id)}>{p ? p.n : '—'}</button><span className="awp-muted">›</span><span>{c ? c.n : '—'}</span><span className="awp-muted">›</span><span className="awp-mono">{s[2]}</span>{!ok && <Tg tone="warning" label={T('Inactive', 'غير نشط')} />}</span>); };
  const list = provs.filter((p) => kind === 'all' || (kind === 'active' ? p.on : kind === 'custom' ? p.kind === 'Custom' : kind === 'cloud' ? p.kind === 'Cloud' : !p.on));
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Models & routes', 'النماذج والمسارات')} sub={T('Providers hold one or more connections; each connection allows specific models. Routes chain provider › connection › model.', 'يملك المزود اتصالاً أو أكثر، ويسمح كل اتصال بنماذج محددة. تربط المسارات المزود › الاتصال › النموذج.')}>
        {tab === 'providers' ? <><Btn type="secondary" label={T('Add custom provider', 'إضافة مزود مخصص')} onClick={() => setCustom(true)} /><Btn label={T('Add cloud provider', 'إضافة مزود سحابي')} icon="AddCircle" onClick={() => setCloud(true)} /></> : <Btn label={T('New route', 'مسار جديد')} icon="AddCircle" onClick={() => setREdit('new')} />}
      </PageHead>
      {banner}
      <Tabs value={tab} onChange={setTab} items={[{ id: 'providers', label: T('Providers', 'المزودون'), count: provs.length }, { id: 'routes', label: T('Routes', 'المسارات'), count: routes.length }]} />
      {tab === 'providers' && <>
        <Chips value={kind} onChange={setKind} items={[{ id: 'all', label: T('All', 'الكل') }, { id: 'active', label: T('Active', 'نشط') }, { id: 'inactive', label: T('Not active', 'غير نشط') }, { id: 'cloud', label: T('Cloud', 'سحابي') }, { id: 'custom', label: T('Custom', 'مخصص') }]} />
        <Grid min={260}>{list.map((p) => (
          <div key={p.id} className="awp-card" onClick={() => setOpen(p.id)} style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 12, cursor: 'pointer', opacity: p.on ? 1 : 0.75 }}>
            <div className="awp-row" style={{ gap: 12 }}><ProvIcon p={p} /><div style={{ flex: 1, minWidth: 0 }}><b>{p.n}</b><div className="awp-small awp-muted">{p.engine ? T('Custom · ', 'مخصص · ') + p.engine : T('Cloud provider', 'مزود سحابي')}</div></div><Toggle on={p.on} onChange={(v) => upd({ ...p, on: v })} /></div>
            <div className="awp-row awp-small awp-muted" style={{ justifyContent: 'space-between', borderTop: '1px solid var(--border-divider)', paddingTop: 10 }}>
              <span>{p.conns.length} {T('connections', 'اتصالات')} · {p.conns.reduce((n, c) => n + c.allow.length, 0)} {T('models allowed', 'نماذج مسموحة')}</span>
              {p.conns.length ? <StTag s={!p.on ? 'Disabled' : p.conns.some((c) => c.st === 'Degraded') ? 'Degraded' : 'Healthy'} /> : <Tg label={T('Not connected', 'غير متصل')} />}
            </div>
          </div>))}</Grid>
      </>}
      {tab === 'routes' && <Card pad={false}><DataTable rows={routes} cols={[
        { h: T('Alias', 'الاسم المستعار'), r: (r) => <div><b className="awp-mono">{r.a}</b><div className="awp-small awp-muted">{T(r.use[0], r.use[1])}</div>{r.schema && <div className="awp-row" style={{ gap: 6, marginTop: 4 }}><Tg tone="info" label={T('Typesafe', 'مضبوط النوع')} /><span className="awp-small awp-mono">{r.schema}</span></div>}{r.voice && <div className="awp-row" style={{ gap: 6, marginTop: 4 }}><Tg tone="brand" label={T('Voice', 'صوت')} /><span className="awp-small">{r.voice}</span></div>}</div> },
        { h: T('Chain (provider › connection › model)', 'السلسلة (المزود › الاتصال › النموذج)'), r: (r) => <div className="awp-col" style={{ gap: 6 }}>{r.chain.map((s, i) => <div key={i} className="awp-row" style={{ gap: 8 }}><span className="awp-small awp-muted" style={{ width: 56 }}>{i ? T('Fallback', 'بديل') : T('Primary', 'أساسي')}</span>{step(s)}</div>)}</div> },
        { h: T('Agents', 'الوكلاء'), end: true, r: (r) => r.agents },
        { h: '', end: true, r: (r) => <div className="awp-row" style={{ gap: 12, justifyContent: 'flex-end' }}><Lnk onClick={() => setREdit(r)}>{T('Edit', 'تعديل')}</Lnk><Lnk danger onClick={() => setConf(r.agents ? { title: T('Cannot delete ' + r.a, 'لا يمكن حذف ' + r.a), intro: T(r.agents + ' agents use this route. Move them to another route first.', 'يستخدم ' + r.agents + ' وكلاء هذا المسار. انقلهم إلى مسار آخر أولاً.'), items: AGENTS.filter((a) => a.id !== 'dir').slice(0, r.agents).map(nm), blocked: true } : { title: T('Delete ' + r.a + '?', 'حذف ' + r.a + '؟'), confirm: T('Delete route', 'حذف المسار'), onConfirm: () => { setRoutes(routes.filter((y) => y !== r)); setBanner('success', T('Route deleted.', 'حُذف المسار.')); } })}>{T('Delete', 'حذف')}</Lnk></div> },
      ]} /></Card>}
      {cur && <ProviderDrawer p={cur} routes={routes} onChange={upd} onDelete={(id) => { setProvs(provs.filter((x) => x.id !== id)); setBanner('success', T('Provider deleted.', 'حُذف المزود.')); }} onClose={() => setOpen(null)} />}
      {cloud && <CloudProviderModal provs={provs} onClose={() => setCloud(false)} onAdd={(p) => { setProvs(provs.some((x) => x.id === p.id) ? provs.map((x) => (x.id === p.id ? { ...x, on: true, conns: [...x.conns, ...p.conns] } : x)) : [...provs, p]); setBanner('success', T(p.n + ' connected.', 'تم ربط ' + p.n + '.')); }} />}
      {conf}
      {custom && <CustomProviderModal onClose={() => setCustom(false)} onAdd={(p) => setProvs([...provs, p])} />}
      {rEdit && <RouteEditor r={rEdit === 'new' ? null : rEdit} provs={provs} onClose={() => setREdit(null)} onSave={(x) => { setRoutes(rEdit === 'new' ? [...routes, x] : routes.map((y) => (y === rEdit ? x : y))); setREdit(null); }} />}
    </div>
  );
}

const CLOUD_T = [['azure', 'Azure OpenAI', 'Az', 'Entra ID', 'https://<resource>.openai.azure.com', ['gpt-4.1', 'gpt-4.1-mini', 'o4-mini']], ['bedrock', 'AWS Bedrock', 'B', 'IAM role', 'bedrock-runtime.<region>.amazonaws.com', ['claude-sonnet-4.5', 'llama-3.3-70b', 'titan-embed-v2']], ['vertex', 'Google Vertex AI', 'V', 'Service account', 'https://<region>-aiplatform.googleapis.com', ['gemini-2.5-pro', 'gemini-2.5-flash', 'text-embedding-005']], ['anthropic', 'Anthropic', 'A', 'API key', 'api.anthropic.com', ['claude-sonnet-4.5', 'claude-haiku-4.5']], ['openai', 'OpenAI', 'O', 'API key', 'api.openai.com', ['gpt-4.1', 'text-embedding-3-large']], ['mistral', 'Mistral AI', 'M', 'API key', 'api.mistral.ai', ['mistral-large', 'mistral-small']]];
function CloudProviderModal({ provs, onClose, onAdd }) {
  const [t, setT] = React.useState('vertex');
  const d = CLOUD_T.find((x) => x[0] === t);
  const needEp = ['azure', 'bedrock', 'vertex'].includes(t);
  const [ep, setEp] = React.useState('');
  const [region, setRegion] = React.useState('me-central1');
  const [proj, setProj] = React.useState('');
  const [sec, setSec] = React.useState('');
  const [test, setTest] = React.useState(null);
  React.useEffect(() => { setEp(''); setTest(null); }, [t]);
  const ok = (!needEp || ep.trim()) && sec.trim() && (t !== 'vertex' || proj.trim());
  return (
    <Modal w={620} title={T('Add cloud provider', 'إضافة مزود سحابي')} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn type="secondary" label={test === 'run' ? T('Testing…', 'جارٍ الاختبار…') : T('Test', 'اختبار')} disabled={!ok || test === 'run'} onClick={() => { setTest('run'); setTimeout(() => setTest('ok'), 800); }} /><Btn label={T('Add provider', 'إضافة المزود')} disabled={test !== 'ok'} onClick={() => { const base = provs.find((x) => x.id === d[0]); onAdd({ id: d[0], n: d[1], ini: d[2], c: 'var(--chart-series-4)', kind: 'Cloud', on: true, models: base ? base.models : d[5], conns: [{ id: d[0] + '-' + Date.now(), n: region || T('Default', 'افتراضي'), ep: ep || d[4], auth: d[3], region, on: true, allow: d[5].slice(0, 2), st: 'Healthy' }] }); onClose(); }} /></>}>
      <Field label={T('Provider', 'المزود')}><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(160px,100%),1fr))', gap: 8 }}>{CLOUD_T.map((x) => <button key={x[0]} className={'awp-chip' + (t === x[0] ? ' on' : '')} style={{ height: 44, justifyContent: 'center' }} onClick={() => setT(x[0])}>{x[1]}</button>)}</div></Field>
      {needEp && <Field label={T('Endpoint', 'نقطة النهاية')}><input className="awp-input awp-mono" value={ep} onChange={(e) => { setEp(e.target.value); setTest(null); }} placeholder={d[4]} /></Field>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        {t === 'vertex' && <Field label={T('Google Cloud project', 'مشروع Google Cloud')}><input className="awp-input awp-mono" value={proj} onChange={(e) => setProj(e.target.value)} placeholder="tahseel-ai-prod" /></Field>}
        <Field label={T('Region', 'المنطقة')}><input className="awp-input awp-mono" value={region} onChange={(e) => setRegion(e.target.value)} /></Field>
        <Field label={d[3]} hint={T('Stored encrypted and never shown again.', 'يُخزّن مشفراً ولا يظهر مرة أخرى.')}><input className="awp-input" type="password" autoComplete="new-password" value={sec} onChange={(e) => { setSec(e.target.value); setTest(null); }} /></Field>
      </div>
      {test === 'ok' && <Banner tone="success">{T('Connected. ' + d[5].length + ' models are available.', 'تم الاتصال. يتوفر ' + d[5].length + ' نماذج.')}</Banner>}
    </Modal>
  );
}

Object.assign(window, { Models });
