const BUDGETS0 = [
  { a: 'sup', lim: 450, per: 'Monthly', from: '2026-01-01', to: null, soft: 80, hard: 'Switch to cheaper alias', alt: 'small-fast', spent: 412.9 },
  { a: 'exp', lim: 250, per: 'Monthly', from: '2026-07-01', to: null, soft: 75, hard: 'Pause agent', spent: 186.4 },
  { a: 'bug', lim: 150, per: 'Monthly', from: '2026-09-01', to: '2026-12-31', soft: 80, hard: 'Pause agent', spent: 141 },
  { a: 'rec', lim: 120, per: 'Monthly', from: '2026-03-01', to: null, soft: 80, hard: 'Notify only', spent: 63.1 },
  { a: 'prc', lim: 200, per: 'Monthly', from: '2026-10-01', to: '2027-03-31', soft: 80, hard: 'Pause agent', spent: 58.7 },
  { a: 'dir', lim: 100, per: 'Monthly', from: '2026-01-01', to: null, soft: 90, hard: 'Notify only', spent: 41.2 },
  { a: 'kb', lim: 40, per: 'Monthly', from: '2026-05-01', to: '2026-09-30', soft: 80, hard: 'Pause agent', spent: 12.4 },
];
const MONTHS = [['May', 'مايو'], ['Jun', 'يونيو'], ['Jul', 'يوليو'], ['Aug', 'أغسطس'], ['Sep', 'سبتمبر'], ['Oct', 'أكتوبر']];
const histOf = (b) => MONTHS.map((m, i) => { const f = [0.62, 0.71, 0.84, 0.9, 1.02, 0][i]; return { m, lim: b.lim, v: i === 5 ? b.spent : Math.round(b.lim * f * (0.85 + ((b.a.charCodeAt(0) + i) % 5) * 0.05)) }; });
const budStatus = (b) => { const today = '2026-10-09'; if (b.from > today) return 'Planned'; if (b.to && b.to < today) return 'Expired'; return 'Active'; };
const bTone2 = { Active: 'success', Planned: 'info', Expired: 'neutral' };
const bLbl = { Active: ['Active', 'نشطة'], Planned: ['Scheduled', 'مجدولة'], Expired: ['Expired', 'منتهية'] };
const pctCol = (p) => (p > 90 ? 'var(--icon-danger)' : p > 75 ? 'var(--icon-warning)' : 'var(--action-primary-bg)');
const period = (b) => <span className="awp-mono awp-small">{b.from} → {b.to || T('no end date', 'بلا تاريخ انتهاء')}</span>;

function BudgetForm({ b, onSave, onClose }) {
  const [x, setX] = React.useState(b || { a: 'kb', lim: 100, per: 'Monthly', from: '2026-10-09', to: null, soft: 80, hard: 'Pause agent', spent: 0 });
  const forever = x.to === null;
  const [err, setErr] = React.useState('');
  const trySave = () => { if (!(x.lim > 0)) return setErr(T('Not saved. The limit must be more than zero.', 'لم يُحفظ. يجب أن يكون الحد أكبر من صفر.')); if (!(x.soft > 0 && x.soft < 100)) return setErr(T('Not saved. The warning level must be between 1 and 99%.', 'لم يُحفظ. يجب أن يكون مستوى التنبيه بين 1 و99٪.')); if (x.to && x.to < x.from) return setErr(T('Not saved. The end date is before the start date.', 'لم يُحفظ. تاريخ الانتهاء قبل تاريخ البدء.')); if (x.hard === 'Switch to cheaper alias' && !x.alt) return setErr(T('Not saved. Choose the route to switch to.', 'لم يُحفظ. اختر المسار البديل.')); if (!b && x.a === 'sup') return setErr(T('Not saved. Customer Assistant already has a budget for this period. Edit that one instead.', 'لم يُحفظ. لدى مساعد المتعاملين ميزانية لهذه الفترة. عدّلها بدلاً من ذلك.')); onSave(x); };
  return (
    <Modal title={b ? T('Edit budget', 'تعديل الميزانية') + ' · ' + aName(b.a) : T('New agent budget', 'ميزانية وكيل جديدة')} onClose={onClose} footer={<><Btn type="secondary" label={T('Cancel', 'إلغاء')} onClick={onClose} /><Btn label={T('Save budget', 'حفظ الميزانية')} onClick={trySave} /></>}>
      {err && <Banner tone="danger" onClose={() => setErr('')}>{err}</Banner>}
      <Field label={T('Agent', 'الوكيل')}><PopSelect className="awp-input" value={x.a} disabled={!!b} onChange={(e) => setX({ ...x, a: e.target.value })}>{AGENTS.map((a) => <option key={a.id} value={a.id}>{nm(a)}</option>)}</PopSelect></Field>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Field label={T('Limit (AED, estimated)', 'الحد (د.إ، تقديري)')}><input className="awp-input" type="number" value={x.lim} onChange={(e) => setX({ ...x, lim: +e.target.value })} /></Field>
        <Field label={T('Period', 'الفترة')}><PopSelect className="awp-input" value={x.per} onChange={(e) => setX({ ...x, per: e.target.value })}>{['Daily', 'Weekly', 'Monthly', 'Quarterly'].map((p) => <option key={p}>{p}</option>)}</PopSelect></Field>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Field label={T('Effective from', 'ساري من')}><PopDate className="awp-input" value={x.from} onChange={(e) => setX({ ...x, from: e.target.value })} /></Field>
        <Field label={T('Effective to', 'ساري حتى')}><PopDate className="awp-input" value={x.to || ''} disabled={forever} onChange={(e) => setX({ ...x, to: e.target.value })} /></Field>
      </div>
      <div className="awp-row" style={{ gap: 10 }}><Toggle on={forever} onChange={(v) => setX({ ...x, to: v ? null : '2026-12-31' })} /><span>{T('Keep forever (no end date)', 'الاحتفاظ دائماً (بلا تاريخ انتهاء)')}</span></div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Field label={T('Warn at (%)', 'تنبيه عند (٪)')}><input className="awp-input" type="number" value={x.soft} onChange={(e) => setX({ ...x, soft: +e.target.value })} /></Field>
        <Field label={T('At 100%', 'عند 100٪')}><PopSelect className="awp-input" value={x.hard} onChange={(e) => setX({ ...x, hard: e.target.value })}>{[['Notify only', 'إشعار فقط'], ['Switch to cheaper alias', 'التبديل إلى مسار أرخص'], ['Pause agent', 'إيقاف الوكيل']].map(([p, a]) => <option key={p} value={p}>{T(p, a)}</option>)}</PopSelect></Field>
      </div>
      {x.hard === 'Switch to cheaper alias' && <Field label={T('Switch to route', 'التبديل إلى المسار')} hint={T('New runs use this route once the limit is reached.', 'تستخدم العمليات الجديدة هذا المسار عند بلوغ الحد.')}><PopSelect className="awp-input" value={x.alt || ''} onChange={(e) => setX({ ...x, alt: e.target.value })}><option value="">{T('Choose a route', 'اختر مساراً')}</option>{['small-fast', 'local-private', 'classifier-typed'].map((r) => <option key={r} value={r}>{r}</option>)}</PopSelect></Field>}
    </Modal>
  );
}

function BudgetDetail({ b, back, onEdit }) {
  const a = AGENTS.find((x) => x.id === b.a);
  const h = histOf(b);
  const max = Math.max(...h.map((x) => Math.max(x.v, x.lim)));
  const pct = (b.spent / b.lim) * 100;
  const st = budStatus(b);
  const days = Array.from({ length: 9 }, (_, i) => ({ d: i + 1, v: +(b.spent / 9 * (0.6 + ((i * 7 + b.a.length) % 9) / 10)).toFixed(2) }));
  const dmax = Math.max(...days.map((x) => x.v));
  return (
    <div className="awp-page">
      <PageHead crumb={<Lnk onClick={back}>{T('Govern / Budgets & estimated costs', 'الحوكمة / تكاليف تشغيل الذكاء الاصطناعي')}</Lnk>} title={<span className="awp-row" style={{ gap: 14 }}><AgentAv a={a} s={44} />{nm(a)}</span>} sub={period(b)}><Tg tone={bTone2[st]} dot label={T(bLbl[st][0], bLbl[st][1])} /><Btn type="secondary" label={T('Open agent', 'فتح الوكيل')} onClick={() => window.__awpGo && window.__awpGo('agents', { agent: a.id })} /><Btn label={T('Edit budget', 'تعديل الميزانية')} onClick={onEdit} /></PageHead>
      <KpiRow items={[{ label: T('Limit', 'الحد'), value: AED(b.lim), note: T(b.per, { Monthly: 'شهري', Daily: 'يومي', Weekly: 'أسبوعي', Quarterly: 'فصلي' }[b.per]) }, { label: T('Estimated spend — October', 'الإنفاق التقديري — أكتوبر'), value: AED(b.spent), tone: pct > 90 ? 'danger' : pct > 75 ? 'warning' : undefined, note: Math.round(pct) + '%' }, { label: T('Estimated forecast', 'التوقع التقديري'), value: AED(b.spent / 9 * 31), tone: b.spent / 9 * 31 > b.lim ? 'danger' : undefined }, { label: T('At 100%', 'عند 100٪'), value: T(b.hard, { 'Notify only': 'إشعار فقط', 'Switch to cheaper alias': 'مسار أرخص', 'Pause agent': 'إيقاف الوكيل' }[b.hard]) }]} />
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)', gap: 16 }} className="awp-two">
        <Card title={T('Consumption history (estimated)', 'سجل الاستهلاك (تقديري)')}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 'clamp(4px,2vw,16px)', height: 200, paddingTop: 10 }}>
            {h.map((x, i) => { const p = (x.v / x.lim) * 100; return (
              <div key={i} className="awp-col" style={{ flex: 1, minWidth: 0, alignItems: 'center', gap: 6, height: '100%', justifyContent: 'flex-end', position: 'relative' }}>
                <span className="awp-small" style={{ fontWeight: 500 }}>{Math.round(x.v)}</span>
                <div style={{ width: '100%', maxWidth: 44, height: (x.v / max) * 150, borderRadius: '8px 8px 0 0', background: pctCol(p), opacity: i === 5 ? 1 : 0.75 }} title={AED(x.v)} />
                <span className="awp-small awp-muted">{T(x.m[0], x.m[1])}</span>
              </div>); })}
          </div>
          <div className="awp-row awp-small awp-muted" style={{ gap: 16, marginTop: 10 }}><span className="awp-row" style={{ gap: 6 }}><span className="awp-dot" style={{ background: 'var(--action-primary-bg)' }} />{T('Under 75%', 'أقل من 75٪')}</span><span className="awp-row" style={{ gap: 6 }}><span className="awp-dot" style={{ background: 'var(--icon-warning)' }} />75–90%</span><span className="awp-row" style={{ gap: 6 }}><span className="awp-dot" style={{ background: 'var(--icon-danger)' }} />{T('Over 90%', 'أكثر من 90٪')}</span></div>
        </Card>
        <Card title={T('Runs by period', 'العمليات حسب الفترة')}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 'clamp(4px,2vw,16px)', height: 160 }}>{h.map((x, i) => { const n = Math.round(x.v * 6.4); const mx = Math.max(...h.map((y) => y.v * 6.4)) || 1; return <div key={i} className="awp-col" style={{ flex: 1, alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end' }}><span className="awp-small">{n}</span><div style={{ width: '100%', maxWidth: 40, height: (n / mx) * 110, borderRadius: '8px 8px 0 0', background: 'var(--chart-series-2)' }} /><span className="awp-small awp-muted">{T(x.m[0], x.m[1])}</span></div>; })}</div>
        </Card>
        <Card title={T('This month by day (estimated)', 'هذا الشهر حسب اليوم (تقديري)')}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 200 }}>{days.map((x) => <div key={x.d} className="awp-col" style={{ flex: 1, alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end' }}><div style={{ width: '100%', height: (x.v / dmax) * 160, borderRadius: 6, background: 'var(--chart-series-1)' }} title={AED(x.v)} /><span className="awp-small awp-muted">{x.d}</span></div>)}</div>
        </Card>
      </div>
      <Card title={T('Period history', 'سجل الفترات')} pad={false}><DataTable rows={h.slice().reverse()} cols={[
        { h: T('Period', 'الفترة'), r: (x) => T(x.m[0], x.m[1]) + ' 2026' },
        { h: T('Limit', 'الحد'), end: true, r: (x) => AED(x.lim) },
        { h: T('Estimated spend', 'الإنفاق التقديري'), end: true, r: (x) => AED(x.v) },
        { h: T('Usage', 'الاستخدام'), r: (x) => { const p = (x.v / x.lim) * 100; return <div className="awp-row" style={{ minWidth: 160 }}><div style={{ flex: 1 }}><Bar h={6} parts={[{ v: Math.min(p, 100), c: pctCol(p) }]} /></div><span className="awp-small">{Math.round(p)}%</span></div>; } },
        { h: T('Runs', 'العمليات'), end: true, r: (x) => Math.round(x.v * 6.4) },
        { h: T('Events', 'الأحداث'), r: (x) => (x.v / x.lim) > 1 ? <span className="awp-row" style={{ gap: 6, flexWrap: 'wrap' }}><Tg tone="danger" label={T('Hard limit reached', 'بلغ الحد الصارم')} /><Tg label={T('Action applied: ' + b.hard + (b.alt ? ' → ' + b.alt : ''), 'طُبّق الإجراء: ' + ({ 'Notify only': 'إشعار فقط', 'Switch to cheaper alias': 'مسار أرخص', 'Pause agent': 'إيقاف الوكيل' }[b.hard]) + (b.alt ? ' ← ' + b.alt : ''))} /></span> : (x.v / x.lim) * 100 > b.soft ? <Tg tone="warning" label={T('Warning sent', 'أُرسل تنبيه')} /> : <span className="awp-muted">—</span> },
      ]} /></Card>
      <Card title={T('Budget changes', 'تغييرات الميزانية')}>{[['2026-10-01', 'u1', T('Limit set to ', 'تم تعيين الحد إلى ') + AED(b.lim)], [b.from, 'u3', T('Budget created, effective ', 'أُنشئت الميزانية، سارية ') + b.from + (b.to ? ' → ' + b.to : T(', no end date', '، بلا تاريخ انتهاء'))]].map(([d, w, t]) => <div key={d + t} className="awp-row" style={{ padding: '8px 0', borderBottom: '1px solid var(--border-divider)', gap: 10 }}><span className="awp-mono awp-muted" style={{ width: 92 }}>{d}</span><Who id={w} s={22} /><span><b>{aName(w)}</b> <span className="awp-muted">{t}</span></span></div>)}</Card>
    </div>
  );
}

function Budgets({ go }) {
  const [rows, setRows] = React.useState(BUDGETS0);
  const [sel, setSel] = React.useState(null);
  const [edit, setEdit] = React.useState(null);
  const [f, setF] = React.useState('all');
  const [banner, setBanner] = useBanner();
  const [busy, setBusy] = React.useState(false);
  const save = (x) => { setBanner('success', T('Budget saved.', 'حُفظت الميزانية.')); setRows(rows.some((r) => r.a === x.a) ? rows.map((r) => (r.a === x.a ? x : r)) : [...rows, x]); if (sel && sel.a === x.a) setSel(x); setEdit(null); };
  const tot = rows.filter((b) => budStatus(b) === 'Active').reduce((n, b) => n + b.spent, 0);
  const list = rows.filter((b) => f === 'all' || budStatus(b) === f);
  return (
    <>
      {sel ? <BudgetDetail b={sel} back={() => setSel(null)} onEdit={() => setEdit(sel)} /> : (
        <div className="awp-page">
          <PageHead crumb={T('Govern', 'الحوكمة')} title={T('Budgets & estimated costs', 'تكاليف تشغيل الذكاء الاصطناعي')} sub={T('Budgets apply to agents. All costs are estimates based on token usage and list prices.', 'تُطبق الميزانيات على الوكلاء. جميع التكاليف تقديرية بناءً على استخدام الرموز وأسعار القائمة.')}><Btn type="secondary" label={busy ? T('Exporting…', 'جارٍ التصدير…') : T('Export CSV', 'تصدير CSV')} icon="Download04" disabled={busy || !list.length} onClick={() => { setBusy(true); setTimeout(() => { setBusy(false); setBanner('success', T(list.length + ' budgets exported as CSV. The export is recorded in the audit log.', 'صُدّرت ' + list.length + ' ميزانيات بصيغة CSV. يُسجّل التصدير في سجل التدقيق.')); }, 700); }} /><Btn label={T('New agent budget', 'ميزانية وكيل جديدة')} icon="AddCircle" onClick={() => setEdit('new')} /></PageHead>
          {banner}
          <KpiRow items={[{ label: T('Estimated month to date', 'التقدير منذ بداية الشهر'), value: AED(tot) }, { label: T('Agents with a budget', 'وكلاء لديهم ميزانية'), value: rows.filter((b) => budStatus(b) === 'Active').length + ' / ' + AGENTS.length }, { label: T('Over 90%', 'أكثر من 90٪'), value: rows.filter((b) => budStatus(b) === 'Active' && b.spent / b.lim > 0.9).length || T('None', 'لا شيء'), tone: rows.some((b) => budStatus(b) === 'Active' && b.spent / b.lim > 0.9) ? 'danger' : undefined }, { label: T('Ending within 90 days', 'تنتهي خلال 90 يوماً'), value: rows.filter((b) => b.to && b.to >= '2026-10-09' && b.to <= '2027-01-07').length }]} />
          <Card pad={false}>
            <FilterBar><Chips value={f} onChange={setF} items={[{ id: 'all', label: T('All', 'الكل') }, { id: 'Active', label: T('Active', 'نشطة') }, { id: 'Planned', label: T('Scheduled', 'مجدولة') }, { id: 'Expired', label: T('Expired', 'منتهية') }]} /></FilterBar>
            {!list.length ? <Empty title={T('No budgets here.', 'لا توجد ميزانيات هنا.')}><Pill onClick={() => setF('all')}>{T('Show all', 'عرض الكل')}</Pill></Empty> : <DataTable onRow={setSel} rows={list} cols={[
              { h: T('Agent', 'الوكيل'), r: (b) => <button className="awp-row awp-lnk-t" style={{ gap: 8 }} onClick={(e) => { e.stopPropagation(); setSel(b); }}><Who id={b.a} s={26} />{aName(b.a)}</button> },
              { h: T('Effective', 'السريان'), r: period },
              { h: T('Status', 'الحالة'), r: (b) => { const s = budStatus(b); return <Tg tone={bTone2[s]} dot label={T(bLbl[s][0], bLbl[s][1])} />; } },
              { h: T('Usage this period', 'الاستخدام هذه الفترة'), r: (b) => { const p = (b.spent / b.lim) * 100; return budStatus(b) === 'Active' ? <div className="awp-row" style={{ minWidth: 180 }}><div style={{ flex: 1 }}><Bar h={6} parts={[{ v: Math.min(p, 100), c: pctCol(p) }]} /></div><span className="awp-small">{Math.round(p)}%</span></div> : <span className="awp-muted">—</span>; } },
              { h: T('Estimated spend', 'الإنفاق التقديري'), end: true, r: (b) => AED(b.spent) },
              { h: T('Limit', 'الحد'), end: true, r: (b) => AED(b.lim) + ' / ' + T(b.per === 'Monthly' ? 'mo' : b.per.toLowerCase(), b.per === 'Monthly' ? 'شهر' : b.per) },
              { h: '', end: true, r: (b) => <div className="awp-row" style={{ justifyContent: 'flex-end', gap: 12 }} onClick={(e) => e.stopPropagation()}><Lnk onClick={() => setSel(b)}>{T('History', 'السجل')}</Lnk><Lnk onClick={() => setEdit(b)}>{T('Edit', 'تعديل')}</Lnk></div> },
            ]} />}
          </Card>
        </div>
      )}
      {edit && <BudgetForm b={edit === 'new' ? null : edit} onClose={() => setEdit(null)} onSave={save} />}
    </>
  );
}

Object.assign(window, { Budgets });
