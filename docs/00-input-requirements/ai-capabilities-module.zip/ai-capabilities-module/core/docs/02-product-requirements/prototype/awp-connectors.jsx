const TIERS = [['T0', 'Autonomous', 'مستقل', 'neutral'], ['T1', 'Confirm', 'تأكيد', 'info'], ['T2', 'Human approval', 'اعتماد بشري', 'warning'], ['T3', 'Forbidden', 'محظور', 'danger']];
const CONNS0 = [
  { n: 'erp', d: 'Oracle ERP via OpenAPI bridge', dAr: 'نظام ERP عبر جسر OpenAPI', kind: 'REST/OpenAPI', url: 'https://erp.tahseel.ae/mcp', auth: 'OAuth 2.1', st: 'Healthy', on: true, def: 'T1', tools: [['claims.read', 'T0'], ['claims.update_status', 'T2'], ['purchase_order.submit', 'T2'], ['vendors.search', 'T0'], ['payments.release', 'T3']] },
  { n: 'm365', d: 'Microsoft 365 — mail, calendar, files', dAr: 'مايكروسوفت 365 — البريد والتقويم والملفات', kind: 'Remote MCP', url: 'https://mcp.m365.tahseel.ae', auth: 'OAuth 2.1', st: 'Healthy', on: true, def: 'T1', tools: [['mail.read', 'T0'], ['mail.send', 'T2'], ['calendar.create_event', 'T1'], ['files.search', 'T0']] },
  { n: 'knowledge', d: 'Platform knowledge (GraphRAG)', dAr: 'معرفة المنصة (GraphRAG)', kind: 'Platform MCP', url: 'internal://knowledge', auth: 'Run token', st: 'Healthy', on: true, def: 'T0', tools: [['search', 'T0'], ['graph.query', 'T0']] },
  { n: 'cards', d: 'Tahseel card management', dAr: 'إدارة بطاقات تحصيل', kind: 'Remote MCP', url: 'https://cards.tahseel.ae/mcp', auth: 'API key', st: 'Degraded', on: true, def: 'T1', tools: [['get_status', 'T0'], ['block', 'T1'], ['replace', 'T2']] },
  { n: 'sandbox-fs', d: 'Workbench file system', dAr: 'نظام ملفات بيئة العمل', kind: 'Local MCP (stdio)', url: 'stdio://sandbox-fs', auth: '—', st: 'Healthy', on: true, def: 'T0', tools: [['read_file', 'T0'], ['write_file', 'T1'], ['delete_file', 'T2']] },
];
const CATALOG = [
  ['github', 'GitHub — repositories, issues, pull requests', 'GitHub — المستودعات والبلاغات وطلبات الدمج', 'Remote MCP', 42],
  ['jira', 'Jira — issues and sprints', 'Jira — البلاغات والدورات', 'Remote MCP', 18],
  ['servicenow', 'ServiceNow — incidents and changes', 'ServiceNow — الحوادث والتغييرات', 'Remote MCP', 26],
  ['salesforce', 'Salesforce — accounts, cases', 'Salesforce — الحسابات والحالات', 'Remote MCP', 30],
  ['sap', 'SAP S/4HANA — finance, procurement', 'SAP S/4HANA — المالية والمشتريات', 'REST/OpenAPI', 54],
  ['postgres', 'PostgreSQL — read-only queries', 'PostgreSQL — استعلامات قراءة فقط', 'Local MCP (stdio)', 4],
  ['google-drive', 'Google Drive — files', 'Google Drive — الملفات', 'Remote MCP', 9],
  ['uaepass', 'UAE Pass — identity verification', 'UAE Pass — التحقق من الهوية', 'REST/OpenAPI', 5],
];
const TierTag = ({ t }) => { const x = TIERS.find((y) => y[0] === t); return x ? <Tg tone={x[3]} label={t + ' · ' + T(x[1], x[2])} /> : <Tg label={T('Off · set a tier', 'متوقفة · حدد مستوى')} />; };
const CONN_AGENTS = { erp: ['exp', 'prc', 'rec'], m365: ['exp', 'sup', 'prc'], knowledge: ['sup', 'kb', 'exp', 'bug'], cards: ['sup'], 'sandbox-fs': ['bug'] };
const CONN_NEW = { erp: ['invoices.match', 'vendors.create'], m365: ['teams.post_message'], cards: ['set_limit'] };

function ConnectorDrawer({ c, isNew, onSave, onRemove, onClose }) {
  const [x, setX] = React.useState({ ...c, ag: c.ag || CONN_AGENTS[c.n] || [], cmd: c.cmd || (c.kind === 'Local MCP (stdio)' ? 'npx -y @tahseel/' + c.n + '-mcp' : '') });
  const [test, setTest] = React.useState(isNew ? null : 'ok');
  const [cred, setCred] = React.useState('');
  const [note, setNote] = React.useState('');
  const set = (k) => (e) => setX({ ...x, [k]: e && e.target ? e.target.value : e });
  const setTier = (i, t) => setX({ ...x, tools: x.tools.map((tl, k) => (k === i ? [tl[0], t] : tl)) });
  const stdio = x.kind === 'Local MCP (stdio)';
  const runTest = () => { setTest('run'); setTimeout(() => { if (!stdio && !/^https?:\/\/[^/]+\.[^/]+/.test(x.url)) { setTest('fail'); return; } const keep = Object.fromEntries(x.tools.map(([n, t]) => [n, t])); const names = isNew ? ['list', 'get', 'create', 'update', 'delete'] : x.tools.map((t) => t[0]); setX((y) => ({ ...y, tools: names.map((n) => [n, keep[n] !== undefined ? keep[n] : (/^(list|get|read|search)/.test(n) ? 'T0' : /delete|release/.test(n) ? 'T2' : x.def)]) })); setTest('ok'); }, 800); };
  const refresh = () => { const add = (CONN_NEW[x.n] || ['new_tool']).filter((n) => !x.tools.some((t) => t[0] === n)); setX({ ...x, tools: [...x.tools, ...add.map((n) => [n, null])] }); setNote(add.length ? T(add.length + ' new tools found. They stay off until you set a tier.', 'وُجدت ' + add.length + ' أدوات جديدة. تبقى متوقفة حتى تحدد مستواها.') : T('No new tools. The list is up to date.', 'لا توجد أدوات جديدة. القائمة محدّثة.')); };
  const unset = x.tools.filter((t) => !t[1]).length;
  const canSave = test === 'ok' && (!stdio || x.cmd.trim());
  return (
    <Drawer w={640} title={<span className="awp-mono">{x.n}</span>} sub={T(x.d, x.dAr)} onClose={onClose} footer={<><Btn label={isNew ? T('Add connector', 'إضافة الموصل') : T('Save changes', 'حفظ التغييرات')} disabled={!canSave} onClick={() => onSave({ ...x, on: test === 'ok' ? x.on : false })} /><Btn type="secondary" label={test === 'run' ? T('Testing…', 'جارٍ الاختبار…') : T('Test connection', 'اختبار الاتصال')} disabled={test === 'run'} onClick={runTest} />{!isNew && <Btn type="danger" label={T('Remove', 'إزالة')} onClick={onRemove} />}</>}>
      {test === 'fail' && <Banner tone="danger">{T('Connection failed: the server did not answer the MCP handshake at ' + (x.url || 'this address') + '. Check the URL and credentials. The connector stays off until a test passes.', 'فشل الاتصال: لم يستجب الخادم لمصافحة MCP على ' + (x.url || 'هذا العنوان') + '. تحقق من الرابط وبيانات الاعتماد. يبقى الموصل متوقفاً حتى ينجح الاختبار.')}</Banner>}
      {test === 'ok' && isNew && <Banner tone="success">{T('Handshake OK. ' + x.tools.length + ' tools found. Review their tiers before adding.', 'المصافحة ناجحة. وُجدت ' + x.tools.length + ' أدوات. راجع مستوياتها قبل الإضافة.')}</Banner>}
      {isNew && test === null && <Banner tone="info">{T('Test the connection to load its tools. You can add the connector after a test passes.', 'اختبر الاتصال لتحميل أدواته. يمكنك إضافة الموصل بعد نجاح الاختبار.')}</Banner>}
      {!isNew && <div className="awp-row" style={{ padding: 14, borderRadius: 16, background: 'var(--surface-card)' }}><div style={{ flex: 1 }}><b>{T('Connector enabled', 'الموصل مفعّل')}</b><div className="awp-small awp-muted">{T('When off, agents cannot call any of its tools.', 'عند الإيقاف لا يمكن للوكلاء استدعاء أي من أدواته.')}</div></div><Toggle on={x.on} onChange={set('on')} /></div>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(200px,100%),1fr))', gap: 12 }}>
        <Field label={T('Transport', 'النقل')}><PopSelect className="awp-input" value={x.kind} onChange={set('kind')}>{['Remote MCP', 'Local MCP (stdio)', 'REST/OpenAPI', 'Platform MCP'].map((k) => <option key={k}>{k}</option>)}</PopSelect></Field>
        <Field label={T('Authentication', 'المصادقة')}><PopSelect className="awp-input" value={x.auth} onChange={set('auth')}>{['OAuth 2.1', 'API key', 'Run token', '—'].map((k) => <option key={k}>{k}</option>)}</PopSelect></Field>
      </div>
      {stdio ? <Field label={T('Command', 'الأمر')} hint={T('Runs inside the platform sandbox. Arguments are separated by spaces.', 'يُشغّل داخل بيئة المنصة المعزولة. تُفصل المعطيات بمسافات.')}><input className="awp-input awp-mono" value={x.cmd} onChange={set('cmd')} placeholder="npx -y @org/server" /></Field>
        : <Field label={T('Server URL', 'رابط الخادم')}><input className="awp-input awp-mono" value={x.url} onChange={(e) => { set('url')(e); setTest(null); }} /></Field>}
      {x.auth !== '—' && x.auth !== 'Run token' && <Field label={T('Credential', 'بيانات الاعتماد')} hint={isNew ? T('Stored encrypted. It cannot be read back after saving.', 'تُخزّن مشفرة. لا يمكن قراءتها بعد الحفظ.') : T('A credential is saved. Enter a new one only to replace it.', 'بيانات الاعتماد محفوظة. أدخل قيمة جديدة فقط لاستبدالها.')}><input className="awp-input" type="password" autoComplete="new-password" value={cred} onChange={(e) => setCred(e.target.value)} placeholder={isNew ? T('Enter credential', 'أدخل بيانات الاعتماد') : T('Saved · enter to replace', 'محفوظة · أدخل للاستبدال')} /></Field>}
      <Field label={T('Default tier for new tools', 'المستوى الافتراضي للأدوات الجديدة')} hint={T('Read-only tools default to T0 and destructive tools to T2 from MCP annotations. Project policies can only raise tiers.', 'تأخذ أدوات القراءة T0 والمدمّرة T2 افتراضياً من تعليقات MCP. يمكن لسياسات المشروع رفع المستويات فقط.')}><PopSelect className="awp-input" value={x.def} onChange={set('def')}>{TIERS.map(([t, en, a]) => <option key={t} value={t}>{t} · {T(en, a)}</option>)}</PopSelect></Field>
      <div className="awp-col" style={{ gap: 8 }}>
        <div className="awp-row"><b style={{ flex: 1 }}>{T('Tools and tiers', 'الأدوات والمستويات')} <span className="awp-small awp-muted" style={{ fontWeight: 400 }}>· {x.tools.length}</span></b>{!isNew && <Pill onClick={refresh}>{T('Refresh tools', 'تحديث الأدوات')}</Pill>}</div>
        {note && <Banner tone={unset ? 'warning' : 'info'} onClose={() => setNote('')}>{note}</Banner>}
        {x.tools.length ? x.tools.map(([tn, tier], i) => <div key={tn} className="awp-row" style={{ padding: '8px 0', borderBottom: '1px solid var(--border-divider)', gap: 10, flexWrap: 'wrap' }}><span className="awp-mono" style={{ flex: 1, minWidth: 160 }}>{x.n}/{tn}</span><TierTag t={tier} /><PopSelect className="awp-input" style={{ width: 170, height: 36 }} value={tier || ''} onChange={(e) => setTier(i, e.target.value)}>{!tier && <option value="">{T('Choose tier', 'اختر المستوى')}</option>}{TIERS.map(([t, en, a]) => <option key={t} value={t}>{t} · {T(en, a)}</option>)}</PopSelect></div>)
          : <span className="awp-small awp-muted">{test === 'ok' ? T('This server exposes no tools.', 'لا يتيح هذا الخادم أي أدوات.') : T('No tools yet. Test the connection to load them.', 'لا توجد أدوات بعد. اختبر الاتصال لتحميلها.')}</span>}
      </div>
      <Field label={T('Allowed agents', 'الوكلاء المسموحون')} hint={T('Only these agents can call this connector\'s tools.', 'يمكن لهؤلاء الوكلاء فقط استدعاء أدوات هذا الموصل.')}><div className="awp-row" style={{ flexWrap: 'wrap', gap: 6 }}>{AGENTS.filter((a) => a.id !== 'dir').map((a) => <button key={a.id} className={'awp-chip' + (x.ag.includes(a.id) ? ' on' : '')} style={{ paddingInlineStart: 4 }} onClick={() => setX({ ...x, ag: x.ag.includes(a.id) ? x.ag.filter((y) => y !== a.id) : [...x.ag, a.id] })}><AgentAv a={a} s={22} />{nm(a)}</button>)}</div></Field>
    </Drawer>
  );
}

function Connectors() {
  const [tab, setTab] = React.useState('connected');
  const [conns, setConns] = React.useState(CONNS0);
  const [open, setOpen] = React.useState(null);
  const [conf, setConf] = useConfirm();
  const [banner, setBanner] = useBanner();
  const tiersSum = (c) => TIERS.map(([t]) => [t, c.tools.filter((x) => x[1] === t).length]).filter((x) => x[1]);
  const addFrom = (r) => setOpen({ isNew: true, c: { n: r[0], d: r[1], dAr: r[2], kind: r[3], url: r[3] === 'Local MCP (stdio)' ? '' : 'https://', auth: r[3] === 'Local MCP (stdio)' ? '—' : 'OAuth 2.1', st: 'Healthy', on: true, def: 'T1', tools: [], ag: [] } });
  const remove = (c) => { const ag = c.ag || CONN_AGENTS[c.n] || []; setConf({ title: T('Remove ' + c.n + '?', 'إزالة ' + c.n + '؟'), intro: ag.length ? T('These agents lose access to its ' + c.tools.length + ' tools:', 'تفقد هذه الوكلاء الوصول إلى أدواته الـ ' + c.tools.length + ':') : T('No agents use this connector.', 'لا يستخدم أي وكيل هذا الموصل.'), items: ag.map((id) => aName(id) + ' · ' + c.tools.map((t) => t[0]).slice(0, 3).join(', ') + (c.tools.length > 3 ? '…' : '')), confirm: T('Remove connector', 'إزالة الموصل'), onConfirm: () => { setConns((cs) => cs.filter((y) => y.n !== c.n)); setOpen(null); setBanner('success', T(c.n + ' was removed.', 'أُزيل ' + c.n + '.')); } }); };
  return (
    <div className="awp-page">
      <PageHead crumb={T('AI Capabilities', 'قدرات الذكاء الاصطناعي')} title={T('Connectors', 'التكامل')} sub={T('MCP servers that give agents controlled access to systems. Each connector sets the tier of every tool it exposes.', 'خوادم MCP تمنح الوكلاء وصولاً مضبوطاً إلى الأنظمة. يحدد كل موصل مستوى كل أداة يتيحها.')}><Btn label={T('Connect your own', 'اربط خادمك')} icon="AddCircle" onClick={() => addFrom(['custom-server', 'Custom MCP server', 'خادم MCP مخصص', 'Remote MCP'])} /></PageHead>
      {banner}
      <Tabs value={tab} onChange={setTab} items={[{ id: 'connected', label: T('Connected', 'المتصلة'), count: conns.length }, { id: 'browse', label: T('Browse', 'تصفح'), count: CATALOG.length }]} />
      {tab === 'connected' && (conns.length ? <Card pad={false}><DataTable onRow={(c) => setOpen({ c })} rows={conns} cols={[
        { h: '', r: (c) => <Toggle on={c.on} onChange={(v) => setConns(conns.map((y) => (y === c ? { ...y, on: v } : y)))} /> },
        { h: T('Connector', 'الموصل'), r: (c) => <div><span className="awp-mono" style={{ fontWeight: 500 }}>{c.n}</span><div className="awp-small awp-muted">{T(c.d, c.dAr)}</div></div> },
        { h: T('Transport', 'النقل'), r: (c) => c.kind },
        { h: T('Auth', 'المصادقة'), r: (c) => c.auth },
        { h: T('Tool tiers', 'مستويات الأدوات'), r: (c) => <div className="awp-row" style={{ gap: 4, flexWrap: 'wrap' }}>{tiersSum(c).map(([t, n]) => <Tg key={t} tone={TIERS.find((y) => y[0] === t)[3]} label={t + ' × ' + n} />)}{c.tools.some((t) => !t[1]) && <Tg label={T(c.tools.filter((t) => !t[1]).length + ' off', c.tools.filter((t) => !t[1]).length + ' متوقفة')} />}</div> },
        { h: T('Status', 'الحالة'), r: (c) => <StTag s={c.on ? c.st : 'Disabled'} /> },
      ]} /></Card> : <Card><Empty title={T('No connectors yet.', 'لا توجد موصلات بعد.')} text={T('Browse the catalogue or connect your own MCP server.', 'تصفح الكتالوج أو اربط خادم MCP خاصاً بك.')}><Pill onClick={() => setTab('browse')}>{T('Browse', 'تصفح')}</Pill></Empty></Card>)}
      {tab === 'browse' && <Grid min={280}>{CATALOG.map((r) => { const added = conns.some((c) => c.n === r[0]); return (
        <div key={r[0]} className="awp-card" style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="awp-row"><Ic n="PlugDS" c="var(--icon-brand)" /><b className="awp-mono" style={{ flex: 1 }}>{r[0]}</b>{added ? <Tg tone="success" label={T('Connected', 'متصل')} /> : <button className="awp-iconbtn" style={{ width: 36, height: 36 }} aria-label={T('Add and configure', 'إضافة وإعداد')} title={T('Add and configure', 'إضافة وإعداد')} onClick={() => addFrom(r)}><Ic n="AddCircle" c="var(--icon-brand)" /></button>}</div>
          <div className="awp-small awp-muted">{T(r[1], r[2])}</div>
          <div className="awp-row awp-small awp-muted" style={{ borderTop: '1px solid var(--border-divider)', paddingTop: 10, justifyContent: 'space-between' }}><span>{r[3]}</span><span>{r[4]} {T('tools', 'أدوات')}</span></div>
        </div>); })}</Grid>}
      {open && <ConnectorDrawer c={open.c} isNew={open.isNew} onClose={() => setOpen(null)} onRemove={() => remove(conns.find((y) => y.n === open.c.n) || open.c)} onSave={(x) => { setConns(open.isNew ? [...conns, x] : conns.map((y) => (y.n === open.c.n ? x : y))); setOpen(null); setBanner('success', open.isNew ? T(x.n + ' was added.', 'أُضيف ' + x.n + '.') : T('Changes to ' + x.n + ' saved.', 'حُفظت تغييرات ' + x.n + '.')); if (open.isNew) setTab('connected'); }} />}
      {conf}
    </div>
  );
}

Object.assign(window, { Connectors, TIERS, TierTag });
