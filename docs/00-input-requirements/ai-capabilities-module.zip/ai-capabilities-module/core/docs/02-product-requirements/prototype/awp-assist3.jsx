const D3_PAGES = { dashboard: 'Main dashboard', dashboard3: 'Dashboard 3', inbox: 'Inbox', sessions: 'Discussion rooms list', tasks: 'Work items', agents: 'Agents', projects: 'Projects', requests: 'Requests', routines: 'Routines', artifacts: 'Artifacts', files: 'Files', orgchart: 'Org chart', people: 'People & roles', skills: 'Skills', connectors: 'Connectors', memory: 'Memory', knowledge: 'Knowledge', models: 'Models', channels: 'Channels', deployments: 'Embedded deployment', budgets: 'Budgets', audit: 'Audit', logs: 'Logs', settings: 'Settings', profile: 'My profile' };

function d3Context() {
  const rooms = (window.SESSIONS || []).slice(0, 6).map((s) => `- ${s.t} (${s.p}) · status ${s.st} · ${s.type} via ${s.src} · ${s.msgs} messages · AED ${s.cost} · last activity ${s.last} ago`).join('\n');
  return `User: Mariam (Tahseel organisation). Today: Wednesday 8 October 2026 (day 8 of 31).
DASHBOARD 3 DATA
- Automation rate: 68% of runs resolved without a human step, +5 pts (trend 41,46,44,52,55,58,63,68).
- Estimated cost this month: AED 4,912.40; AED 184.60 today. Split: Models 72%, Tools & connectors 28%.
- October budget: AED 12,000; 41% used (estimated) while 26% of month elapsed. Customer Assistant is the largest consumer.
- Work items: 27 in progress, 6 blocked; completed this week up 14 vs last week. Open by status: Backlog 42, To do 31, In progress 27, In review 14, Blocked 6.
- Runs in progress: 14 (3 waiting on humans).
  RUN-88231 Expense agent: review claim EXP-4471 against T&E policy, step 6/9, AED 0.42
  RUN-88229 Support agent: card replacement conversation (widget), step 4/7, AED 0.08
  RUN-88224 Procurement agent: compare 3 vendor quotes for laptops, waiting approval, AED 1.17
  RUN-88210 Bug Triage v5: reproduce BUG-311 in sandbox, FAILED, AED 2.31
- Needs attention: 1 agent in error (Bug Triage v5); 5 approvals waiting (2 high risk); 3 SLAs at risk (due within 4 hours).
- Discussion rooms:
${rooms}`;
}

function D3Assistant({ go, onClose, onDirector }) {
  const ar = window.__awpLang === 'ar';
  const KEY = 'awp.d3chats';
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; } };
  const [chats, setChats] = React.useState(load);
  const [cid, setCid] = React.useState(null);
  const [view, setView] = React.useState('chat');
  const [msgs, setMsgsRaw] = React.useState([]);
  const persist = (list) => { setChats(list); try { localStorage.setItem(KEY, JSON.stringify(list.slice(0, 30))); } catch (e) {} };
  const idRef = React.useRef(null);
  const setMsgs = (m) => {
    setMsgsRaw(m);
    if (!m.length) return;
    let id = idRef.current;
    if (!id) { id = 'c' + Date.now(); idRef.current = id; setCid(id); }
    const first = m.find((x) => x.role === 'user');
    const rec = { id, title: first ? first.content.slice(0, 60) : T('New chat', 'محادثة جديدة'), ts: Date.now(), msgs: m.filter((x) => !x.err) };
    persist([rec, ...load().filter((c) => c.id !== id)]);
  };
  const newChat = () => { idRef.current = null; setCid(null); setMsgsRaw([]); setView('chat'); };
  const openChat = (c) => { idRef.current = c.id; setCid(c.id); setMsgsRaw(c.msgs); setView('chat'); };
  const delChat = (id) => { persist(load().filter((c) => c.id !== id)); if (id === cid) newChat(); };
  const when = (ts) => { const d = Math.round((Date.now() - ts) / 60000); return d < 1 ? T('Just now', 'الآن') : d < 60 ? T(d + ' min ago', 'قبل ' + d + ' د') : d < 1440 ? T(Math.round(d / 60) + ' h ago', 'قبل ' + Math.round(d / 60) + ' س') : new Date(ts).toLocaleDateString(ar ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'short' }); };
  const [q, setQ] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const listRef = React.useRef(null);
  const inRef = React.useRef(null);
  React.useEffect(() => { inRef.current && inRef.current.focus(); }, []);
  React.useEffect(() => { const l = listRef.current; if (l) l.scrollTop = l.scrollHeight; }, [msgs, busy]);

  const tools = [
    { name: 'go_to_page', description: 'Navigate the console to a page. Use when the user asks to open, show or go to something.', input_schema: { type: 'object', properties: { page: { type: 'string', enum: Object.keys(D3_PAGES) } }, required: ['page'] },
      run: async ({ page }) => { setTimeout(() => go(page), 400); return 'Navigated to ' + D3_PAGES[page]; } },
    { name: 'open_run', description: 'Open the detail view of a specific agent run by id.', input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] },
      run: async ({ id }) => { setTimeout(() => go('run', { id }), 400); return 'Opened ' + id; } },
    { name: 'create', description: 'Open the creation form for a new work item, discussion room or request.', input_schema: { type: 'object', properties: { kind: { type: 'string', enum: ['workitem', 'room', 'request'] } }, required: ['kind'] },
      run: async ({ kind }) => { setTimeout(() => window.__awpOpen && window.__awpOpen(kind), 400); return 'Opened the new ' + kind + ' form'; } },
  ];

  const system = `You are the Tahseel Juman (Agentic Work Platform) assistant, embedded on Dashboard 3. You help Mariam understand her agents, runs, costs, budget, work items and discussion rooms, and you can take actions with tools.
Rules: answer from the data below; never invent numbers; if something isn't in the data say so and offer to open the relevant page. Be concise: 1–4 short sentences or a few "- " bullet lines. Plain text only, no markdown headings, no bold, no emoji. Formal, service-oriented tone. Currency is AED. Reply in ${ar ? 'Arabic' : 'English'} unless the user writes in another language.
${d3Context()}`;

  const send = async (text) => {
    const t = (text || '').trim();
    if (!t || busy) return;
    const next = [...msgs, { role: 'user', content: t }];
    setMsgs(next); setQ(''); setBusy(true);
    try {
      const out = await window.claude.complete({ system, max_tokens: 600, messages: next.slice(-12).map((m) => ({ role: m.role, content: m.content })), tools });
      setMsgs([...next, { role: 'assistant', content: (out || '').trim() || T('Done.', 'تم.') }]);
    } catch (e) {
      setMsgs([...next, { role: 'assistant', content: T('I could not reach the assistant service. Please try again.', 'تعذّر الوصول إلى خدمة المساعد. يرجى المحاولة مرة أخرى.'), err: true }]);
    }
    setBusy(false);
    setTimeout(() => inRef.current && inRef.current.focus(), 0);
  };

  const sugg = [T('What needs my attention today?', 'ما الذي يحتاج انتباهي اليوم؟'), T('Are we on track with the October budget?', 'هل نحن ضمن ميزانية أكتوبر؟'), T('Why did RUN-88210 fail?', 'لماذا فشلت العملية RUN-88210؟'), T('Open the blocked work items', 'افتح بنود العمل المعطّلة')];

  return (
    <div className="awp-card awp-assist is-d3 d3a" role="dialog" aria-label={T('AI Assistant', 'المساعد الذكي')}>
      <div className="awp-card-h">
        <div className="d3a-h"><AiOrb size={32} still /><div><h3>{T('AI Assistant', 'المساعد الذكي')}</h3><span className="d3a-hs">{busy ? T('Thinking…', 'يفكّر…') : T('Knows this dashboard', 'مطّلع على هذه اللوحة')}</span></div></div>
        <span className="d3a-ha">
          <button className={'awp-iconbtn' + (view === 'history' ? ' on' : '')} onClick={() => setView(view === 'history' ? 'chat' : 'history')} aria-pressed={view === 'history'} aria-label={T('Saved chats', 'المحادثات المحفوظة')} title={T('Saved chats', 'المحادثات المحفوظة')}><Ic n="Chat" s={16} c="currentColor" /></button>
          <button className="awp-iconbtn" onClick={newChat} aria-label={T('New chat', 'محادثة جديدة')} title={T('New chat', 'محادثة جديدة')}><Ic n="PencilEdit01" s={16} /></button>
          <button className="awp-iconbtn" onClick={onClose} aria-label={T('Close', 'إغلاق')}><Ic n="X" s={18} /></button>
        </span>
      </div>
      <div className="awp-card-b d3a-b">
        {view === 'history' ? (
          <div className="d3a-list d3a-hist">
            <span className="d3a-hist-h">{T('Saved chats', 'المحادثات المحفوظة')}</span>
            {chats.length === 0 && <p className="d3a-intro">{T('No saved chats yet. Conversations are saved automatically on this device.', 'لا توجد محادثات محفوظة بعد. تُحفظ المحادثات تلقائياً على هذا الجهاز.')}</p>}
            {chats.map((c) => (
              <div key={c.id} className={'d3a-hi' + (c.id === cid ? ' on' : '')}>
                <button className="d3a-hi-b" onClick={() => openChat(c)}><b>{c.title}</b><span>{when(c.ts)} · {c.msgs.length} {T('messages', 'رسائل')}</span></button>
                <button className="awp-iconbtn d3a-hi-x" onClick={() => delChat(c.id)} aria-label={T('Delete chat', 'حذف المحادثة')} title={T('Delete chat', 'حذف المحادثة')}><Ic n="X" s={14} /></button>
              </div>
            ))}
          </div>
        ) : <>
        <div className="d3a-list" ref={listRef} aria-live="polite">
          {msgs.length === 0 && <>
            <p className="d3a-intro">{T('Good morning, Mariam. Ask me about runs, costs, budget, work items or discussion rooms. I can also open pages for you.', 'صباح الخير، مريم. اسأليني عن العمليات والتكاليف والميزانية وبنود العمل واجتماعات العمل. يمكنني أيضاً فتح الصفحات لك.')}</p>
            <div className="d3a-sugg">{sugg.map((s) => <button key={s} className="awp-chip" onClick={() => send(s)}>{s}</button>)}{onDirector && <button className="awp-chip" onClick={onDirector}>{T('Request a change to the setup', 'طلب تغيير على الإعداد')}</button>}</div>
          </>}
          {msgs.map((m, i) => <div key={i} className={'d3a-m is-' + m.role + (m.err ? ' is-err' : '')}>{m.content}</div>)}
          {busy && <div className="d3a-m is-assistant d3a-typing" aria-label={T('Thinking', 'يفكّر')}><i /><i /><i /></div>}
        </div>
        <form className="d3a-form" onSubmit={(e) => { e.preventDefault(); send(q); }}>
          <input ref={inRef} className="awp-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={T('Ask about this dashboard', 'اسأل عن هذه اللوحة')} aria-label={T('Message', 'الرسالة')} />
          <button type="submit" className="d3a-send" disabled={!q.trim() || busy} aria-label={T('Send', 'إرسال')}><Ic n="ArrowUpRightL" s={16} c="currentColor" /></button>
        </form>
        </>}
      </div>
    </div>
  );
}

Object.assign(window, { D3Assistant });
