# Flows

| Item | Value |
| --- | --- |
| Purpose | The end-to-end business processes (ten in force, F-01 retired by D371), step by step, with the requirement and criteria each step exercises |
| Audience | Business analysts, testers, developers, stakeholders |
| Related | [Business overview](../01-business/overview.md) · [Business rules](../01-business/business-rules.md) · [Requirements](requirements.md) · [Acceptance document](../Tahseel_AWP_Screens_Use_Cases.md) · [Modules](../05-modules/README.md) |
| Last verified against code | 2026-10-29 |

The eleven end-to-end journeys of the handoff specification §8
([archived](../_reference/Tahseel_AWP_Specification.md)), written as numbered steps with the
requirement each step exercises. A flow crosses screens, so no single requirement proves one; the
flow is the integration case, and its last column names the criteria that qualify it. The diagrams
are the specification's own.

The in-product user guide (`/guide`, `apps/web/src/components/guide/scenarios.ts`) presents these
scenarios with screenshots of the product.

---

## F-01 First setup by prompt — retired

Specification §8.1 described a brand-new installation configured by prompt through the Setup
Director. The Setup Director is removed (D371), so this flow is retired and its number is not
reused. A fresh install starts from the shipped seed (organisation, system agents, one project,
seven request types, one knowledge collection); the Platform Owner lands on the Dashboard
(`UC-05.1-04`) and configures the platform on its screens, or through the Platform Assistant, whose
platform tools run under the person's permissions and approvals (D253, D254).

---

## F-02 Agentic request to closure

Specification §8.2. The Expense Claim example, which is the exit criterion of delivery phase 4.

```mermaid
flowchart LR
  A[Employee: New Request - Agentic interactive] --> B[Classifier proposes type and attributes]
  B --> C{Employee confirms?}
  C -- edit --> B
  C -- yes --> D[Request created at step Submitted]
  D --> E[Agent review step - agent audience acts]
  E -->|amount < 5000| F[Finance approval]
  E -->|amount >= 5000| G[Finance + Work Lead sequential]
  E -->|Return| D
  F -->|Approve| H[Payment step - payment agent]
  G -->|Approve| H
  F -->|Reject| Z[Closed]
  G -->|Reject| Z
  H -->|Paid| Z
```

At each step, "Can act" audiences receive the step in their Inbox (people) or as a run (agents).
"Notify only" audiences are notified. Work items created along the way appear in the request's Work
items tab.

As built: an agent audience gets a run when the request lands on its step. A person audience finds
the request in their request list, which includes requests at a step that names them (D166); no
Inbox item is raised for a step, and nothing notifies a "Notify only" audience
([open questions §8](open-questions.md#8-requirements-the-code-does-not-meet)). Agentic entry
(steps 1 to 3) is behind the `agentic-interactive-request-entry` flag, seeded off (D310); with it
off the request is raised through the template form.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | An employee opens New Request, chooses Agentic interactive and describes what they need. | FR-037 | `UC-28.2-01` |
| 2 | The agent service's classifier proposes the request type and extracts the attributes through a typesafe route, asking for anything missing. | FR-037 | `UC-28.2-04`, `-05`, `-06` |
| 3 | The employee corrects a value, then confirms. The request is created at the first step with the history showing how it was classified. | FR-037 | `UC-28.2-02`, `-03` |
| 4 | The first step's audiences are notified: people in their Inbox, agents as a run. | FR-036, FR-013 | `UC-28.1-01` |
| 5 | At "Agent review" an agent audience checks the claim and takes the step's action, or returns or rejects it with its findings as the comment; a routing rule sends it by amount to the right approval step (D215). | FR-039 | `UC-29.2-01`, `-04` |
| 6 | A "Can act" approver takes the step and approves. Sequential audiences act in order. The requester cannot approve their own request unless the step names them, as a person, among its "Can act" audiences; an agent acting for the requester waits for a bound approval decided by somebody else (D141, D147, D217). | FR-039 | `UC-29.2-05`, `-07` |
| 7 | A payment agent works the Payment step. Work items created along the way appear in the request's Work items tab. | FR-038, FR-039 | `UC-29.1-04`, `UC-29.2-03` |
| 8 | The request reaches a terminal step. Actions are hidden; open work items stay linked. A terminal step's own outcome (Completed or Rejected, set by the designer) decides which status this leaves the request at — the claim above is paid and Completed; a step an approver instead sent to a rejecting terminal leaves it Rejected. | FR-039 | `UC-29.2-08` |

Failure path: if no routing rule matches the data, the request stays in its step flagged "No matching
route" and the type owner is notified (`UC-29.2-09`). As built, the history line, a warning log and a
Denied audit entry are written and nobody is notified
([requests.md, Known gaps](../05-modules/requests.md#known-gaps)).

---

## F-03 Work item with agent and review

Specification §8.3.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | A work item is created — manually, from a request step, from a room message or by a schedule — and assigned to an agent. | FR-029 | `UC-24.3-01`, `-02` |
| 2 | The agent's run starts and the item moves to In progress. The run may create sub items and artifacts. | FR-029, FR-032 | `UC-24.3-02`, `UC-25.3-01` |
| 3 | A T2 tool call pauses the run and creates an approval. The approver decides in the Inbox and the run resumes. | FR-013 | `UC-12.1-01`, `-02` |
| 4 | The agent submits for review; a mission on the item that ends Succeeded submits it if the agent did not (D346). The reviewer, who is not the author, approves or requests changes. | FR-031 | `UC-25.2-01`, `-02`, `-03`, `-04` |
| 5 | On changes requested, the item returns to In progress and the agent is re-triggered with the comment. | FR-031 | `UC-25.2-03` |
| 6 | On approval the item is Done; the parent's progress, the linked request and the dashboard figures update. | FR-031, FR-032, FR-010 | `UC-25.2-02`, `UC-25.3-02`, `UC-10.1-02` |

Failure path: a run that fails leaves the item showing the failure with Retry and reassignment
(`UC-25.2-09`).

---

## F-04 Mention in a discussion room

Specification §8.4.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | A member posts a message mentioning an agent. | FR-023 | `UC-23.1-01`, `-02` |
| 2 | The agent's run starts with the room context. The participant shows Working and the reply streams to every participant. | FR-023 | `UC-23.1-02`, `-12` |
| 3 | The reply carries an artifact card, and shows the agent's version and Helpful / Not helpful feedback (D216). | FR-023 | `UC-23.1-03`, `-04` |
| 4 | Agent turns stop at the hop limit; the room stops answering at its cost cap. | FR-023 | `UC-23.1-08`, `-09` |
| 5 | The agent's call needs an approval. An approval card appears in the room; the person who asked decides it there, and a call that changes who may reach what goes to another holder of `approvals:decide` (D105, D253, D269). Setup tools are never offered in a room (D25). | FR-024 | `UC-23.2-01` … `-05` |
| 6 | The room's context handoff (goal, decisions, open questions, next step) updates when the run ends. It is kept for agents and the record and is not shown in the room's side panel (D236, D351). | FR-026 | `UC-23.4-01` |

Step 4 as built: only a person's message starts a mission, an agent's post never starts another
agent, and a room answers at most `agentHopLimit` agent messages per human message (D66, D106;
`apps/web/src/features/rooms/turns.ts`). D73 and D106 say a room's limit is agent turns, not money,
and that nothing sets a new cap; the code creates every console room with a 25 AED cap and enforces
it, while room spend stays 0 because missions report no cost
([discussion-rooms.md, Known gaps](../05-modules/discussion-rooms.md#known-gaps)).

Step 3 as built: no agent message shows Open trace, because the room sets each message's run key to
null ([discussion-rooms.md, Known gaps](../05-modules/discussion-rooms.md#known-gaps)).

---

## F-05 Embedded widget with a strict storyline and handoff

Specification §8.5.

```mermaid
sequenceDiagram
  actor V as Visitor
  participant W as Widget (platform frame)
  participant A as Agent (scripted)
  participant Q as Human handoff queue
  V->>W: Opens widget on allowed origin
  W->>A: Start storyline card-replacement v3 (strict)
  A->>V: Message (exact) → Ask reason (quick replies)
  A->>V: Verify (OTP) → Confirm address
  alt completed
    A->>A: Create work (request of type Card Replacement)
    A->>V: Reference number
  else Talk to a person / too many off-script turns
    A->>Q: Handoff with context
    Q->>V: Human continues the conversation
  end
```

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | A visitor opens the widget on an allowed origin. An origin that is not allowed does not load and the attempt is logged. As built, the loader draws nothing there and writes a browser console warning; the server log does not record it ([engage.md, Known gaps](../05-modules/engage.md#known-gaps)). | FR-077 | `UC-65.1-01`, `-10` |
| 2 | The storyline starts in Strict mode. Verbatim messages are sent exactly; quick replies fill slots. | FR-076, FR-077 | `UC-64.1-01`, `-05`, `UC-65.1-02` |
| 3 | A Verify step checks identity by OTP. As built, a widget conversation has no channel to send the code through, so the visitor is told it could not be sent ([engage.md, Known gaps](../05-modules/engage.md#known-gaps)). | FR-077 | `UC-65.1-03`, `-09` |
| 4 | A Confirm step is accepted, and a Create work step creates a request and returns its reference. | FR-077 | `UC-65.1-04` |
| 5 | Off-script turns get a fixed redirect and the step is asked again; after more than 2 the visitor is offered a person. | FR-077 | `UC-65.1-07` |
| 6 | "Talk to a person", offered only when the deployment has a handoff queue, moves the conversation into a discussion room in that queue's project with its transcript; a person's reply there reaches the widget (D231, D340). | FR-077 | `UC-65.1-08` |
| 7 | The conversation ends, the widget asks for a 1–5 rating, and its outcome is recorded. | FR-077 | `UC-65.1-14` |

---

## F-06 Scheduled work item

Specification §8.6.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | The schedule fires on its repeat rule, unless the date is a UAE public holiday or a weekend and skipping is on. | FR-045 | `UC-31.2-05` |
| 2 | A work item or a request is created in the project with the instructions and assigned to the agent, person or group. | FR-045 | `UC-31.2-01`, `-02`, `-04` |
| 3 | The last-run outcome — Created, Failed or Skipped — and the next run update. | FR-044 | `UC-31.1-01` |
| 4 | A paused or archived project, or a paused agent, is recorded as the reason rather than silently dropped. | FR-045 | `UC-31.2-08`, `-09` |

---

## F-07 Knowledge collection

Specification §8.7.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | An administrator creates a collection with its index, chunking, embedding route and visibility. | FR-067 | `UC-56.2-01` |
| 2 | Sources are added — upload, URL crawl or MCP resource — and ingestion runs with live progress. As built, only uploaded documents are ingested: a URL crawl or MCP resource source is stored and nothing fetches it ([knowledge.md, Known gaps](../05-modules/knowledge.md#known-gaps)). | FR-068, FR-067 | `UC-57.1-01` … `-03`, `UC-56.2-03` |
| 3 | Retrieval is tested in Vector, Graph or Hybrid mode and returns cited passages, graph facts and the time taken. | FR-070 | `UC-58.1-01`, `-02` |
| 4 | Changing the embedding route warns about a full re-index and, on confirmation, re-indexes. | FR-069 | `UC-57.2-02` |
| 5 | Agents with access to the collection retrieve cited passages and graph facts at run time through `knowledge_search`, limited to the collections their Knowledge tab grants that the person may read (D151, D291). | FR-055, FR-070 | `UC-58.1-05` |

---

## F-08 Memory review

Specification §8.8.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | An agent proposes a memory entry. It shows as Pending review and is not used in runs. | FR-065 | `UC-55.2-01` |
| 2 | A reviewer who is not the proposing agent's only owner approves or rejects it. | FR-065 | `UC-55.2-01`, `-02`, `-04` |
| 3 | An approved entry creates a new version and becomes available to runs in that scope. | FR-065, FR-066 | `UC-55.2-01`, `UC-55.3-01` |
| 4 | Edits and restores always create a new version with a change note, and are audited. | FR-066 | `UC-55.3-01`, `-05` |
| 5 | A memory past its review date shows Needs attention until reviewed. | FR-065 | `UC-55.2-03` |

Step 1 as built: a run's only memory write, `memory_write`, goes to its private (agent, person)
scope and is Active at once (D68, D116, D157). No agent proposes into a shared scope; a memory is
Pending review only when a person creates it with "Needs review before it is used"
([memory.md](../05-modules/memory.md#-unresolved-conflicts)).

---

## F-09 Budget enforcement

Specification §8.9.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | Each run adds its estimated cost to the agent's current budget period. | FR-081 | `UC-72.1-01` |
| 2 | At the warning percentage the owner is notified and the event is logged. | FR-081 | `UC-72.1-04` |
| 3 | At 100% the configured action runs: notify only, switch to a cheaper alias, or pause the agent. | FR-080, FR-081 | `UC-71.1-05`, `UC-72.1-05`, `-06` |
| 4 | A run that exhausts an effort limit it was given (model requests and tool calls across the mission) ends as BudgetExceeded. Runs are given none: a run carries on until it finishes (D389). A run has no money ceiling (D73, D93, D129). | FR-058 | `UC-52.1-09` |
| 5 | A new period resets spend and moves the previous one to history. | FR-081 | `UC-72.1-07` |

Steps 1–3 are implemented on the agent's budget period in `apps/web/src/features/budgets/spend-service.ts`
(`recordRunSpend`, called when a run finishes). Step 4 is implemented in the generic runtime, which
bounds each mission with `UsageLimits` from the run's `RunBudget` and ends it BudgetExceeded on
`UsageLimitExceeded` (`services/agent/src/awp_agent/mission/runtime.py`). The web app sends no
per-profile limits and, since D389 (owner, 2026-11-06), `RunBudget` has no default, so a run has no
limit on model requests or tool calls (agent runtime spec conflict 3).

### ⚠ Unresolved conflict: recorded cost

- **Requirement (steps 1–3):** each run adds its estimated cost to the agent's budget period.
- **Code:** the generic runtime finishes a mission without `estimated_cost_aed`, which `FinalizeInput`
  defaults to 0 (`_record_outcome` in `mission/runtime.py`, `harness/activities/finalize.py`), so
  live missions add 0 and never move a budget toward its warning or limit
  ([agent runtime spec, conflicts 4 and 10](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code)).
- **Needs:** the runtime to send the mission's estimated cost (D92), or an owner decision to amend D92.

---

## F-10 Connector and tool tiers

Specification §8.10.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | An administrator adds a connector by URL or from an OpenAPI document, from the one Connector button. | FR-062 | `UC-54.1-01`, `-04` |
| 2 | Test connection performs the MCP handshake and lists the tools; for a REST API it makes one authorised request to the server (D268). A failed handshake allows adding only as Disabled. | FR-062 | `UC-54.1-02`, `-05` |
| 3 | Tiers default from the MCP annotations: read-only to T0, destructive to T2; a REST operation's from its HTTP method. The administrator adjusts them. Agents are granted the tools on their own Connector tools tab, a read at Auto and any other at Approval (D227, D264). | FR-062 | `UC-54.1-03`, `-07`, `-08` |
| 4 | A project policy can raise a tool's tier but never lower it. | FR-019 | `UC-21.2-03`, `-04` |
| 5 | At run time an agent calls a tool only when its grant names it, within its tier and the project policy; T2 pauses for a human (D30, D49, D171). | FR-013, FR-055 | `UC-12.1-02`, `UC-51.2-04` |
| 6 | Disabling the connector or removing the tool from an agent's grant stops those calls with a clear result. | FR-063 | `UC-54.2-02`, `-04`, `-07` |

As built: agent trust is not read when a tool is called, and a project's human-approval rules are
stored but no run reads them ([open questions §8](open-questions.md#8-requirements-the-code-does-not-meet)).

---

## F-11 Integration client

Specification §8.11.

| # | Step | Requirement | Criteria |
| --- | --- | --- | --- |
| 1 | An administrator creates a client with allowed permissions and allowed agents. As built, New client takes no agents; they are set afterwards on the client's AG-UI tab ([integrations.md, Known gaps](../05-modules/integrations.md#known-gaps)). | FR-085 | `UC-76.1-02` |
| 2 | A key is created and its secret is shown once; afterwards only the prefix is shown. | FR-086 | `UC-77.1-01` |
| 3 | MCP exposure is enabled with a tool allowlist and tested with the client's own credentials. | FR-087 | `UC-77.2-01`, `-02` |
| 4 | AG-UI exposure is enabled with allowed agents, events and origins. A call from another origin is refused by CORS and logged. | FR-088 | `UC-77.3-01`, `-03` |
| 5 | Every call is limited to the client's permissions; a call outside them is refused and audited. As built, a T2 tool exposed to a client runs without an approval ([integrations.md, Known gaps](../05-modules/integrations.md#known-gaps)). | FR-089 | `UC-77.4-01`, `-02` |
| 6 | Rotating, revoking or deactivating stops the credential working, immediately or after the grace period. | FR-086, FR-090 | `UC-77.1-02`, `-03`, `UC-77.5-01` |
