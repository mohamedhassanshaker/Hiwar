# Configuration

| Item | Value |
| --- | --- |
| Purpose | Every environment variable the platform reads, who reads it, its default, and where its value comes from |
| Audience | Developers, operators |
| Related | [Operations](../operations.md) · [Deployment](deployment.md) · [Tech stack](../03-architecture/tech-stack.md) · [Governance module (feature flags)](../05-modules/governance.md) |
| Last verified against code | 2026-10-29 |

## How configuration reaches a workload

```mermaid
flowchart LR
  ENV[".env (local) or the organisation's secret store (Test, Live)"] -->|scripts/secrets-from-env.sh| SEC["Kubernetes Secrets: awp-app, agentgateway-providers, run-token, phoenix, minio-root, neo4j-auth"]
  CNPG["CloudNativePG generated passwords"] -->|scripts/db-credentials.sh| SEC
  VAL["infra/charts/awp values + values-ENV.yaml"] -->|_helpers.tpl awp.env| POD["web, agent-service, agent-worker pods"]
  SEC -->|envFrom secretRef awp-app| POD
```

- **Non-secret settings** come from the chart: `infra/charts/awp/values.yaml` `config.*`, rendered
  into one shared env block (`templates/_helpers.tpl`, `awp.env`) that `web`, `agent-service` and
  every `agent-worker` include. `values-local.yaml`, `values-test.yaml` and `values-live.yaml`
  override them per environment.
- **Secrets** come from the `awp-app` Secret through `envFrom`. Locally `scripts/secrets-from-env.sh`
  writes it from `.env`, copying only non-empty values and printing none; `scripts/db-credentials.sh`
  adds the four database URLs from the passwords CloudNativePG generated. In Test and Live the
  Secrets come from the organisation's secret store.
- **Validation.** The web application validates its environment once, with a Zod schema
  (`apps/web/src/lib/env.ts`). The Python services use `pydantic-settings` classes
  (`services/*/src/*/config.py`). An unknown variable is ignored by both.
- **Channel, connector, provider-connection and mail-server credentials are not environment
  variables.** They are entered on the Channels, Connectors, Models & routes and Settings → Email
  screens and stored encrypted with `APP_KEK` (see [Security](../03-architecture/security.md),
  [D240, D296](../harness-decisions.md)). The mail server's host, port and templates are settings
  rows too.

Feature flags are not environment variables either; they are rows the Settings screen edits. The
list and defaults are in the [Governance module](../05-modules/governance.md).

## Values that must be replaced before Test

`.env.example` marks these `DEV-ONLY`. They ship as working development values, so each of them
is a published key:

| Variable | What it protects |
| --- | --- |
| `APP_KEK` | Envelope encryption of every connector, channel, provider and mail-server credential, and of an invitation's token until it is emailed ([D248](../harness-decisions.md)). The example is 32 zero bytes. |
| `AUTH_SECRET` | Session integrity, and the key the widget's session tokens are derived from ([D231](../harness-decisions.md)). |
| `UAEPASS_CLIENT_SECRET` | The console's client at UAE PASS (D387); locally the public staging value `sandbox_stage`. |
| `RUN_TOKEN_SIGNING_KEY` | Agent identity. A forged token reaches the platform MCP server as any agent. |
| `MAINTENANCE_API_TOKEN` | Proves a scheduled work item's Temporal Schedule, not a person, is firing it. |
| `PHOENIX_SECRET`, `PHOENIX_API_KEY` | The trace store. |
| `S3_ACCESS_KEY`, `S3_SECRET_KEY` | The development object store's root credentials. |
| `NEO4J_AUTH`, `NEO4J_HEALTH_PASSWORD` | The graph store. |

With `NODE_ENV=production` (which the chart sets) the web application refuses to start while
`APP_KEK`, `AUTH_SECRET`, `RUN_TOKEN_SIGNING_KEY`, `PHOENIX_SECRET` or `MAINTENANCE_API_TOKEN` still
holds its `.env.example` value, naming each one (`apps/web/src/lib/env.ts`). The check is skipped
during `next build`.

⚠ **Code defect, logged:** `PHOENIX_SECRET` is in that list but is not a field of the schema, so its
comparison never matches and an example Phoenix secret does not stop start-up
(`apps/web/src/lib/env.ts:114`). The other four are enforced.

Generate real values with, for example, `openssl rand -base64 32` (`APP_KEK` must decode to exactly
32 bytes).

## Web application (`apps/web`)

Schema: `apps/web/src/lib/env.ts`. "ex" = present in `.env.example`.

| Variable | Default | Read by | Source in kind | ex |
| --- | --- | --- | --- | --- |
| `NODE_ENV` | `development` | env schema, Next.js | chart: `production` | no |
| `APP_URL` | `http://localhost:3000` | public links: the widget loader (`app/embed/v1/widget.js`), the request widget's `embed.js`, connector OAuth callbacks, email links, deployments, channels, integrations | chart `config.appUrl`; `.env` via `scripts/public-origin.sh` | yes |
| `AUTH_URL` | — (read by Auth.js, not the schema) | `next-auth` | chart: same as `APP_URL` | yes |
| `AUTH_SECRET` | none | `src/lib/auth.ts`, widget sessions (`features/engage/widget-session.ts`) | `awp-app` Secret | yes |
| `UAEPASS_BASE_URL` | `https://stg-id.uaepass.ae` | `features/auth/uae-pass.ts` | `awp-app` Secret | no |
| `UAEPASS_CLIENT_ID`, `UAEPASS_CLIENT_SECRET` | none; both or no UAE PASS button (D387) | `features/auth/uae-pass.ts` | `awp-app` Secret | yes |
| `UAEPASS_ACR_VALUES` | `urn:safelayer:tws:policies:authentication:level:low` | `features/auth/uae-pass.ts` | — | no |
| `WEBAUTHN_RP_ID` | `localhost` | passkeys (`features/organisation/profile-service.ts`) | chart `config.webauthnRpId` | yes |
| `DATABASE_URL` | required | `src/db/client.ts`, seed | `scripts/db-credentials.sh` (the PgBouncer pooler) | yes, empty |
| `DATABASE_RO_URL` | none | read-replica queries (`src/db/client.ts`) | `db-credentials.sh` (`awp-pg-r`) | yes, empty |
| `DATABASE_MIGRATE_URL` | falls back to `DATABASE_URL` | `src/db/migrate.ts` | `db-credentials.sh` (superuser, `awp-pg-rw`) | yes, empty |
| `APP_KEK` | none; must decode to 32 bytes | `src/lib/crypto.ts` | `awp-app` Secret | yes |
| `AGENT_SERVICE_URL` | none | run start, test runs, knowledge ingestion and retrieval, AG-UI proxy routes, health | chart `config.agentServiceUrl` | yes |
| `RUN_TOKEN_SIGNING_KEY` | none; minting a run token throws without it | `src/lib/run-token.ts` | `awp-app` Secret | yes |
| `MAINTENANCE_API_TOKEN` | none | `app/api/maintenance/schedules/[id]/fire/route.ts` | `awp-app` Secret | yes |
| `TEMPORAL_ADDRESS` | none | `src/lib/temporal.ts`, health | chart | yes |
| `TEMPORAL_NAMESPACE` | `awp` | `src/lib/temporal.ts` | chart | yes |
| `AGW_LLM_URL` | none | health (`src/lib/health.ts`) | chart | yes |
| `CONNECTOR_RUNTIME_URL` | none | `src/lib/connector-runtime.ts` | chart | no |
| `EGRESS_PROXY_URL` | none | every request to the internet: provider connection tests, OpenAPI connector calls, connector OAuth token and discovery requests, channel and room-mirror outbound, skill import by URL (`src/lib/egress.ts`) | chart (computed) | no |
| `AI_NAMESPACE` | `awp-ai` | agentgateway route rendering (`src/lib/kubernetes.ts`) | chart | no |
| `AI_GATEWAY_NAME` | `ai-gateway` | `src/agentgateway/render.ts` | chart | no |
| `SKILL_GIT_HOSTS` | empty = Git import off | `features/skills/import-service.ts` | **nothing sets it** | no |
| `PHOENIX_BASE_URL` | none | health | chart | yes |
| `PHOENIX_PUBLIC_ORIGIN` | none | "Open trace" links (`app/(console)/agents/runs/page.tsx`) | chart | no |
| `S3_ENDPOINT`, `S3_ACCESS_KEY`, `S3_SECRET_KEY` | none | `src/lib/objects.ts`, health | chart (endpoint), Secret (keys) | yes |
| `S3_REGION` | `us-east-1` | `src/lib/objects.ts` | chart | yes |
| `S3_FORCE_PATH_STYLE` | `true` | `src/lib/objects.ts` | chart: `"true"` | yes |
| `VALKEY_URL` | none; live updates off without it | `src/lib/valkey.ts`, health | chart | yes |
| `NEO4J_URI` | none | health (socket probe only) | chart | yes |
| `LOG_LEVEL` | `info` | `src/lib/logger.ts` | chart `config.logLevel` (`debug` in `values-local.yaml`) | yes |
| `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `AZURE_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY` | empty | the seed only: route fallback order follows which keys are present (`src/db/seed/models.ts`) | `scripts/seed.sh` reads them from the `agentgateway-providers` Secret | yes, except `GEMINI_API_KEY` |
| `AWP_MIGRATIONS_DIR`, `AWP_POSTGRES_SQL_DIR` | relative to the source tree | `src/db/migrate.ts` | `db-migrate` Job | no |
| `PORT` | `3000` | CopilotKit runtime (`src/agents/runtime.ts`), the integration MCP test (`features/integrations/service.ts`) | Dockerfile | no |
| `KUBERNETES_SERVICE_HOST` | set by Kubernetes | whether agentgateway routes can be applied (`src/lib/kubernetes.ts`) | the kubelet | no |

Declared in the web schema but not read by web code: `PLATFORM_MCP_URL`, `PHOENIX_API_KEY`,
`NEO4J_AUTH` (the agent service reads them) and `AGW_MCP_BASE_URL` (nothing reads it).

Test and tooling only: `BASE_URL`, `PORT`, `CI`, `AWP_AGENTIC_ENTRY`, `MAINTENANCE_API_TOKEN`, `E2E_ALLOW_REMOTE`, `E2E_MAIL_HOST`, `E2E_SIGN_IN_PASSWORD` (the Playwright suite in `tests/`, read in `tests/utils/env.ts` and the specs);
`TEST_DATABASE_URL`, `REQUIRE_DATABASE` (`tests/db/harness.ts`); `E2E_OWNER_USER`,
`E2E_MEMBER_USER`, `E2E_APPROVER_USER`, `E2E_DESIGNER_USER`, `E2E_WORK_LEAD_USER`,
`E2E_SIGN_IN_PASSWORD`.

## Agent service (`services/agent`)

Settings: `services/agent/src/awp_agent/config.py` (`pydantic-settings`, no prefix).

| Variable | Default | Read by | ex |
| --- | --- | --- | --- |
| `AWP_SERVICE_NAME`, `AWP_ENV` | `agent-service`, `local` | trace resource attributes (`tracing.py`) | no |
| `LOG_LEVEL` | `INFO` | API and worker logging | yes |
| `TEMPORAL_ADDRESS` | `temporal-frontend.awp-ai.svc:7233` | `worker.py` | yes |
| `TEMPORAL_NAMESPACE` | `awp` | `worker.py` | yes |
| `TEMPORAL_TASK_QUEUE` | `agent-runs` | run start (`api/runs.py`); the worker takes its queue from its first argument first | no |
| `TEMPORAL_CODEC_KEY` | unset = payload encryption off; base64 of 16, 24 or 32 bytes | `temporal/codec.py`: encrypts and decrypts (D81) | yes, empty |
| `TEMPORAL_CODEC_PREVIOUS_KEYS` | empty; comma-separated keys in the same form | `temporal/codec.py`: decrypts only, so history a rotated key wrote still opens (D204) | yes, empty |
| `AGW_LLM_URL` | `http://ai-gateway.awp-ai.svc:8080` | `clients/gateway_client.py` | yes |
| `AWP_RUN_TOKEN` | empty | bearer on gateway calls (`clients/gateway_client.py`, `ingestion/graph.py`) | no |
| `PLATFORM_MCP_URL` | `http://web.awp-app.svc:3000/api/mcp` | resolved in the API process into the mission's deps (`mission/runtime.py`), `clients/platform_mcp.py`, maintenance activities | yes |
| `PLATFORM_MCP_TOKEN` | empty | `clients/platform_mcp.py` | no |
| `MAINTENANCE_API_TOKEN` | empty | schedule firing (`maintenance/activities.py`) | yes |
| `SANDBOX_MANAGER_URL` | `http://sandbox-manager.awp-app.svc:8080` | resolved in the API process into the mission's deps; the skill-script tools (`mission/sandbox.py`) | no |
| `VALKEY_URL` | `valkey://valkey-primary.awp-data.svc:6379/0` | AG-UI event streams (`clients/events.py`), spend counter (`harness/spend.py`) | yes |
| `KB_DATABASE_URL` | empty = vector store off | `ingestion/vectors.py` | yes, empty |
| `NEO4J_URI` | `bolt://neo4j.awp-data.svc:7687` | `ingestion/graph.py` | yes |
| `NEO4J_AUTH` (`user/password`), or `NEO4J_USER` and `NEO4J_PASSWORD` | empty | `ingestion/graph.py` | `NEO4J_AUTH` only |
| `S3_ENDPOINT`, `S3_REGION`, `S3_ACCESS_KEY`, `S3_SECRET_KEY` | MinIO in-cluster URL, `us-east-1`, empty | uploaded skills (`mission/skills.py`), ingestion, Temporal external storage (`temporal/storage.py`) | yes |
| `S3_BUCKET_DOCUMENTS` | `raw-docs` | ingestion | no |
| `S3_BUCKET_RUN_PAYLOADS` | `run-payloads` | Temporal external storage of payloads of 32 KiB or more (`temporal/storage.py`, D287); off when `S3_ACCESS_KEY` is empty | no |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Phoenix OTLP URL; tracing is on when set | `tracing.py` | yes |
| `PHOENIX_BASE_URL`, `PHOENIX_API_KEY` | Phoenix URL, empty | `tracing.py` | yes |
| `AWP_SKILLS_PATH` | `/app/skills` (the Dockerfile sets the same) | bundled skills | no |
| `AWP_EMBEDDING_ROUTE` | `embedding-default` | knowledge API, gateway client | no |
| `AWP_WORKER_IN_PROCESS` | off; `1` serves the `agent-runs` queue inside the API process | `api/temporal.py` | no |
| `AWP_WORKER_HEALTH_PORT` | `8010`; the chart sets the same (`agentWorkerHealthPort`) | `worker.py` | no |
| `DOCLING_ARTIFACTS_PATH` | Dockerfile sets `/opt/docling-models` | `ingestion/parsing.py` | no |
| `GRAPHITI_TELEMETRY_ENABLED` | graphiti-core's own; the chart sets `false` on the agent service and every worker | graphiti-core, so it sends no usage telemetry (D255) | no |

Declared but read by nothing: `AGW_MCP_BASE_URL`, `S3_BUCKET_ARTIFACTS`.

## Connector runtime, sandbox manager, model engine

These read their own settings and get no `envFrom` from `awp-app`; the chart sets the values they
need (`templates/connector-runtime.yaml`, `templates/sandbox-manager.yaml`). The chart also gives
the connector runtime `HTTP_PROXY` and `HTTPS_PROXY` (the egress proxy) and a `NO_PROXY` of the
cluster's Services and the Kubernetes API's address, so its remote MCP sessions leave through the
proxy (D297).

| Service | Variable | Default |
| --- | --- | --- |
| `services/connectors` | `CONNECTOR_MODE` | `control` (or `bridge`, which each per-connector Pod runs) |
| | `CONNECTOR_ID`, `CONNECTOR_SPEC` | empty (bridge mode: which connector, and its spec as JSON) |
| | `CONNECTOR_IMAGE`, `CONNECTOR_IMAGE_PULL_POLICY` | `localhost:5001/awp/connector-runtime:dev`, `IfNotPresent` |
| | `CONNECTOR_NAMESPACE` | `awp-app` |
| | `CONNECTOR_SECRETS_PATH` | `/run/secrets/connectors` |
| | `EGRESS_PROXY_URL` | `http://egress-proxy.awp-app.svc:3128` |
| | `CONNECTOR_TIMEOUT_SECONDS`, `LOG_LEVEL` | `60`, `INFO` |
| `services/sandbox` | `SANDBOX_NAMESPACE`, `SANDBOX_IMAGE`, `SANDBOX_SERVICE_ACCOUNT` | `awp-sandbox`, `localhost:5001/awp/sandbox-workspace:dev` (chart: `images.sandboxWorkspace`), `awp-sandbox-workspace` |
| | `SANDBOX_RUNTIME_CLASS` | empty (plain `runc`); gVisor where configured |
| | `SANDBOX_CPU_LIMIT`, `SANDBOX_MEMORY_LIMIT`, `SANDBOX_STORAGE_LIMIT` | `1`, `1Gi`, `2Gi` |
| | `SANDBOX_MAX_SECONDS`, `SANDBOX_EXEC_TIMEOUT_SECONDS` | `900`, `120` |
| | `SANDBOX_WARM_POOL` | `2` (chart: 2, `values-local.yaml`: 1, Test 4, Live 8) |
| | `SANDBOX_NODE_POOL`, `EGRESS_PROXY_URL`, `LOG_LEVEL` | `awp/pool=sandbox`, the egress proxy, `INFO` |
| `services/modelstub` | none | — |

The egress proxy's allow-list is the chart value `egressProxy.allowedDomains`;
`egressProxy.allowAll` (default `false`, `true` in `values-local.yaml`) lets every destination
through and leaves the list unread (D297).

## Phoenix

Set by `infra/charts/phoenix/templates/phoenix.yaml`: `PHOENIX_SQL_DATABASE_URL` (from the
`awp-pg-phoenix` Secret that `db-credentials.sh` writes), `PHOENIX_ENABLE_AUTH="false"`,
`PHOENIX_SECRET` (from the `phoenix` Secret), `PHOENIX_WORKING_DIR`, `PHOENIX_HOST`, `PHOENIX_PORT`
(6006), `PHOENIX_GRPC_PORT` (4317) and `PHOENIX_TRACE_RETENTION_DAYS`.

## Secrets written from `.env`

| Secret | Keys | Written by |
| --- | --- | --- |
| `awp-app/awp-app` | `AUTH_SECRET`, `UAEPASS_BASE_URL`, `UAEPASS_CLIENT_ID`, `UAEPASS_CLIENT_SECRET`, `APP_KEK`, `RUN_TOKEN_SIGNING_KEY`, `TEMPORAL_CODEC_KEY`, `TEMPORAL_CODEC_PREVIOUS_KEYS`, `MAINTENANCE_API_TOKEN`, `PHOENIX_API_KEY`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `NEO4J_AUTH`; plus `DATABASE_URL`, `DATABASE_RO_URL`, `DATABASE_MIGRATE_URL`, `KB_DATABASE_URL` | `secrets-from-env.sh`; the database URLs by `db-credentials.sh` |
| `awp-ai/agentgateway-providers` | `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `AZURE_API_KEY`, `AZURE_API_BASE` | `secrets-from-env.sh` |
| `awp-ai/run-token` | `signing-key` | `secrets-from-env.sh` |
| `awp-ai/phoenix` | `secret`, `api-key` | `secrets-from-env.sh` |
| `awp-data/minio-root` | root user and password | `secrets-from-env.sh` |
| `awp-data/neo4j-auth` | `NEO4J_AUTH` (default `neo4j/please-change`) | `secrets-from-env.sh` |
| `awp-ai/awp-pg-temporal`, `awp-ai/awp-pg-phoenix` | Temporal and Phoenix database credentials | `db-credentials.sh` |

## Script, Makefile and CI variables

| Variable | Read by | Default |
| --- | --- | --- |
| `PROFILE` | `Makefile`, `bootstrap.sh` | `full` (or `core`) |
| `NO_ROOK` | `Makefile`, `bootstrap.sh` | `1` |
| `HTTP_PORT`, `HTTPS_PORT` | `Makefile`, `bootstrap.sh`, `public-origin.sh`, `render-infra.sh` | `8080`, `8443` |
| `CLUSTER` / `CLUSTER_NAME` | `Makefile` / `bootstrap.sh`, `build-images.sh` | `awp` |
| `REGISTRY_NAME`, `REGISTRY_PORT` | `bootstrap.sh`, `build-images.sh` | `kind-registry`, `5001` |
| `REGISTRY_UI_PORT` | `bootstrap.sh` (the registry browser) | `5080` |
| `REBUILD`, `ONLY` | `build-images.sh` | `0`, all images |
| `CACHE_CEILING_GB`, `IMAGE_CEILING_GB`, `PRUNE_NODES` | `build-images.sh` (disk housekeeping) | `20`, `20`, `1` |
| `ADMIN_ALLOWED_CIDRS` | `render-infra.sh` → the `admin-allowlist` middleware | loopback plus RFC 1918 ranges |
| `TEMPORAL_RETENTION` | `temporal-namespace.sh` | `7d` |
| `AWP_DB_PORT`, `AWP_MINIO_PORT`, `AWP_MINIO_ACCESS_KEY`, `AWP_MINIO_SECRET_KEY` | `dev-local.sh`, `verify.sh` | `55432`, `9000`, `awp-root`, the development value |
| `NAMESPACE`, `LOCAL_PORT` | `seed.sh` | `awp-data`, `55433` |
| `S3_LOCAL_PORT` | `seed.sh` | `55435` |
| `GREP`, `PROJECT` | `test-e2e.sh` | all cases, all default projects |
| `ENV_FILE`, `AWP_ROOT` | `secrets-from-env.sh`, `.env.example` | `<repo>/.env`, `.` |
| `DEV_DB_CONTAINER` | `verify.sh` | `awp-dev-db` |
| `SERVICE` | `make logs` | none |
| `ALLOW_IN_FLIGHT` | `deploy-cluster.sh`: deploy while workflows run | `0` |
| `GIT_BASH` | `deploy-cluster.bat` | found from `git.exe` |
| `HOST_GATEWAY_IP`, `HOST_NAME` | `cluster-host-access.sh` | the address `host.docker.internal` resolves to, `hostname` |

CI (`.github/workflows/verify.yml`, job `verify`) sets `DATABASE_URL`, `DATABASE_MIGRATE_URL`,
`APP_KEK` (the all-zero example), `S3_ENDPOINT`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_REGION` and
`S3_FORCE_PATH_STYLE` for its PostgreSQL and MinIO service containers.

## Mismatches between `.env.example` and the code

| Variable | Finding |
| --- | --- |
| `NEO4J_HEALTH_PASSWORD` | In `.env.example`; read by no code. |
| `AGW_MCP_BASE_URL` | In `.env.example` and the chart; read by neither service (the MCP listener has no caller). |
| `GEMINI_API_KEY` | Read by the seed; missing from `.env.example` and from `secrets-from-env.sh`. |
| `SKILL_GIT_HOSTS` | Read by the skills import; set nowhere, so importing a skill from a Git URL is refused in every environment. |
| `PHOENIX_SECRET` | In the production example-value check but not in the schema; never compared. |
| `CONNECTOR_RUNTIME_URL`, `EGRESS_PROXY_URL`, `PHOENIX_PUBLIC_ORIGIN`, `AI_NAMESPACE`, `AI_GATEWAY_NAME` | Read by the web app; set by the chart; absent from `.env.example` (only matters in host mode). |
