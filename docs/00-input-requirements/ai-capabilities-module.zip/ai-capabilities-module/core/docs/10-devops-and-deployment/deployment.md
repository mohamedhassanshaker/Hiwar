# Deployment

| Item | Value |
| --- | --- |
| Purpose | Environments, workload topology, how a change reaches a cluster, migrations and rollback, CI, and the version policy |
| Audience | Operators, architects, developers |
| Related | [Operations](../operations.md) · [Configuration](configuration.md) · [Runbook](runbook.md) · [Demo flows (deploy gate)](demo-flows.md) · [Architecture overview](../03-architecture/overview.md) · [Tech stack](../03-architecture/tech-stack.md) |
| Last verified against code | 2026-10-29 |

## Environments

One deployment model everywhere: container images and Helm charts on Kubernetes, with `kind`
locally. The charts are the same; only the values file differs.

| Environment | Cluster | Platform values (`infra/platform/values/`) | Application values (`infra/charts/values/`) | What differs |
| --- | --- | --- | --- | --- |
| Local | kind, created by `make kind-up` | `local.yaml.gotmpl` | `values-local.yaml` | PostgreSQL 1 instance; MinIO instead of Rook (`NO_ROOK=1`); `core` profile can drop Phoenix and Neo4j; registry `localhost:5001`, `pullPolicy: Always`; `logLevel: debug`; the deterministic model engine enabled; sandbox warm pool 1; the egress proxy lets every destination through (`egressProxy.allowAll`, D297), and its unread list is `.localtest.me`, `.tahseel.ae`, `.openrouter.ai`, `kontiki.com.fj`, `api.open-meteo.com` |
| Test | A conformant Kubernetes cluster | `test.yaml` | `values-test.yaml` | PostgreSQL 2 instances; registry `registry.tahseel.ae/awp`; console at `awp-test.tahseel.ae`; web 2 replicas, agent-service 2, `agent-runs` 2; sandbox warm pool 4; egress adds `.azure.com` |
| Live | A conformant Kubernetes cluster | `live.yaml` | `values-live.yaml` | PostgreSQL 3 instances; console at `awp.tahseel.ae`; web 3 replicas with an HPA (3 to 10 at 65% CPU), agent-service 3, `agent-runs` 4, `ingestion` 2; sandbox warm pool 8; egress proxy 2 replicas |

Only the local environment has been deployed from this repository. Nothing in it applies the
Test or Live values; per the stack specification, the organisation's CD applies the same charts
in order (operators → data → AI → app). TODO: needs input — the CD system and release process
for Test and Live.

⚠ **Code finding, logged:** `values-test.yaml` and `values-live.yaml` each replace the
`agentWorkers` list with `agent-runs` and `ingestion` only. A Helm list override replaces
the whole default list, so neither environment would run the `maintenance` worker, the only
worker that registers `ScheduleFireWorkflow` (`services/agent/src/awp_agent/worker.py`), and
scheduled work items would not fire there. Read from the values files; not deployed.

The cluster platform itself — CNI, storage class, certificates, the secret store, log collection,
metrics, the image registry, node hardening, volume backups and cluster upgrades — is a
prerequisite owned by the platform team, not by AWP. Locally the bootstrap provides stand-ins
(Cilium, cert-manager with a local CA, `.env`, the local registry).

## Topology

```mermaid
flowchart LR
  subgraph SYS["awp-system"]
    TR[Traefik - Gateway API]
    CNPGOP[CloudNativePG operator]
  end
  subgraph APP["awp-app"]
    WEB[web]
    AS[agent-service]
    AW["agent-worker x3: agent-runs, ingestion, maintenance"]
    CR[connector-runtime]
    SM[sandbox-manager]
    ME["model-engine (local only)"]
    EP[egress-proxy]
  end
  subgraph AI["awp-ai"]
    AGW[agentgateway ai-gateway]
    TMP[Temporal]
    PHX[Phoenix]
  end
  subgraph DATA["awp-data"]
    PG[(awp-pg: awp, awp_kb, temporal, temporal_visibility, phoenix)]
    VK[(Valkey)]
    NJ[(Neo4j)]
    S3[(MinIO locally / Rook Ceph RGW)]
  end
  subgraph SBX["awp-sandbox"]
    SP[sandbox pods]
  end
  TR --> WEB
  TR --> TMP & PHX & AGW
  WEB --> AS & PG & VK & S3 & TMP & AGW & CR
  AS --> TMP
  AW --> AGW & PG & NJ & VK & S3 & TMP & PHX & WEB
  AGW --> WEB
  AGW --> ME
  SM --> SP
  SP --> EP
  CR --> EP
```

### Namespaces

| Namespace | Workloads |
| --- | --- |
| `awp-system` | Traefik, the CloudNativePG operator, cert-manager, the local identity provider (local only) |
| `awp-data` | PostgreSQL `awp-pg` and its pooler, Valkey, Neo4j, the object store (MinIO locally), Adminer and RedisInsight (local only) |
| `awp-ai` | agentgateway, Temporal, Phoenix |
| `awp-app` | `web`, `agent-service`, the `agent-worker-*` Deployments, `connector-runtime` and its per-connector Pods, `sandbox-manager`, `model-engine`, `egress-proxy`, the Helm hook Jobs; Mailpit locally when applied by hand from `infra/kind/mailpit.yaml` (D240) |
| `awp-sandbox` | The sandbox workspace Pods, which `sandbox-manager` creates through a Role limited to this namespace |
| `rook-ceph` | Rook operator, Ceph daemons and RGW (only when `NO_ROOK=0`) |

### Workloads

| Workload | Kind | Source | Notes |
| --- | --- | --- | --- |
| `web` | Deployment (HPA optional) | `charts/awp` | Console, domain logic, CopilotKit runtime, platform MCP server, channel gateway; renders agentgateway model routes |
| `agent-service` | Deployment | `charts/awp` | AG-UI and run endpoints; init containers wait for Temporal and the agentgateway model list |
| `agent-worker-<queue>` | Deployment per queue | `charts/awp` | `python -m awp_agent.worker <queue>`; health on port 8010. `agent-runs`: `MissionWorkflow`; `ingestion`: `IngestionWorkflow`; `maintenance`: `ScheduleFireWorkflow` |
| `connector-runtime` | Deployment | `charts/awp` | Control mode; creates one Deployment and Service per stdio connector ([services/connectors](../../services/connectors/README.md)) |
| `sandbox-manager` | Deployment | `charts/awp` | Creates and deletes sandbox Pods ([services/sandbox](../../services/sandbox/README.md)) |
| `model-engine` | Deployment | `charts/awp` | The deterministic local engine (`services/modelstub`); disabled except in `values-local.yaml` |
| `egress-proxy` | Deployment | `charts/awp` | Squid on 3128, the only workload allowed to leave the cluster; holds the domain allow-list |
| `db-migrate` | Job, Helm `pre-install,pre-upgrade` hook | `charts/awp` | See [Migrations](#migrations) |
| `object-buckets` | Job, Helm `pre-install,pre-upgrade` hook | `charts/awp` | Creates `raw-docs`, `files`, `artifacts`, `attachments`, `skills`, `memory`, `run-payloads`, `branding`; versioning on `files`, `artifacts`, `memory`; `run-payloads` objects (Temporal payloads too large for the history, D287) expire after 30 days |
| agentgateway | Controller and Gateway `ai-gateway` | agentgateway chart 1.6.0 | Listeners `llm` :8080 and `mcp` :8081; admin Service :15000 published as `aigateway.<host>` |
| Temporal | Deployments and schema Job | `temporal/temporal` chart 0.68.0 | Server 1.29; databases on `awp-pg` |
| Phoenix | Deployment | `charts/phoenix` | Database `phoenix` on `awp-pg`; `full` profile only |
| PostgreSQL | CNPG `Cluster` and `Pooler` | `charts/cnpg-clusters` | Image `ghcr.io/cloudnative-pg/postgresql:18.6` |
| Valkey, Neo4j, MinIO | StatefulSets | Bitnami and Neo4j charts | Neo4j in the `full` profile; MinIO when `NO_ROOK=1` |
| Traefik | Deployment | Traefik chart | The only externally exposed workload |

Every application Pod runs as uid 10001, non-root, with a read-only root filesystem, all
capabilities dropped and the `RuntimeDefault` seccomp profile, on nodes labelled `awp/pool: app`.

### Start-up ordering

- Readiness probes on every workload. The `web` probes and the `agent-worker` liveness probe wait
  5 s for an answer ([D200, D255](../harness-decisions.md)).
- Init containers wait for dependencies: `agent-service` waits for the Temporal frontend and the
  agentgateway `/v1/models` route (`python -m awp_agent.wait_for`).
- Helm hook Jobs: `db-migrate`, `object-buckets`, and the Temporal schema Job. Phoenix migrates its
  own schema on start.
- Locally `make kind-up` installs everything in order with `--wait`
  ([Operations](../operations.md#bringing-the-platform-up)).

### Networking

| Concern | Implementation |
| --- | --- |
| North–south | Traefik is the Gateway API implementation. Gateway `awp` (listener `websecure`, wildcard certificate `awp-wildcard`). HTTPRoutes: the console host → `web:3000` with the `security-headers` middleware; `temporal.`, `phoenix.`, `aigateway.`, `adminer.`, `redisinsight.` and `neo4j.` hosts behind the `admin-allowlist` middleware (D225); the object-store routes (`s3.`, `minio.`) when `NO_ROOK=1`, behind the same middleware (`infra/gateway/`). |
| Admin hosts | The IP allowlist from `ADMIN_ALLOWED_CIDRS`. The AI gateway and RedisInsight have no login of their own, so the allowlist is their only control; the AI gateway's route publishes neither `/quitquitquit` nor the pprof endpoints. Traefik sees a cluster address for every client on kind, so the allowlist admits anyone who can reach the host's 8443 (D225). |
| AI traffic | agentgateway's internal Gateway, not exposed outside the cluster. Only the `llm` listener carries traffic; the `mcp` listener is provisioned and has no caller ([Tech stack](../03-architecture/tech-stack.md)). |
| NetworkPolicy | `infra/policies/network-policies.yaml`. `awp-app`, `awp-data`, `awp-ai` and `awp-sandbox` each start from default deny plus DNS. Egress: `awp-app` → `awp-data`, `awp-ai`, `awp-system` and itself; `awp-ai` → `awp-data` and itself; agentgateway's data plane → `awp-app` on 3000 (the platform MCP server) and 8080 (the model engine), and anywhere outside the cluster (providers); the egress proxy → anywhere; `awp-data` → only its own Pods; sandbox Pods → the egress proxy on 3128 only. Ingress: `web` accepts 3000 from `awp-system` (Traefik) and from `awp-ai`; `awp-app` Pods accept each other; `awp-data` accepts `awp-app`, `awp-ai`, `awp-system` and itself; `awp-ai` accepts `awp-app`, `awp-system` and itself; sandbox Pods accept `awp-app` (the manager). |
| Cilium | Three `CiliumNetworkPolicy` objects allow API-server egress for the workloads that create Kubernetes objects (`infra/policies/apiserver-egress.yaml`). Locally `scripts/cluster-host-access.sh` adds `connector-runtime-to-host`, which lets the connector runtime alone reach the Docker host's address (D222). |
| Quotas | ResourceQuotas and a LimitRange (`infra/policies/resourcequotas.yaml`); RuntimeClass `gvisor` with handler `runsc` (`runtimeclass.yaml`) for sandboxes where gVisor is installed. |

## Images and charts

| Image | Built from | Built by |
| --- | --- | --- |
| `awp/web` | `apps/web/Dockerfile` (repository root context) | `scripts/build-images.sh` |
| `awp/agent` | `services/agent/Dockerfile` (copies `packages/skills-bundled`) | same |
| `awp/sandbox-manager` | `services/sandbox/Dockerfile` | same |
| `awp/sandbox-workspace` | `services/sandbox/workspace/Dockerfile`; what a sandbox Pod runs (D209) | same |
| `awp/connector-runtime` | `services/connectors/Dockerfile` | same |
| `awp/model-engine` | `services/modelstub/Dockerfile` | same |

All six are tagged `0.1.0` in `infra/charts/awp/values.yaml`. Upstream chart and image versions
are declared in `infra/kind/versions.env` and `infra/platform/helmfile.yaml`; `versions.lock.md`
records each image with its resolved digest and licence; `make versions-lock` prints the current
registry digest of each one, and the file is updated by hand.

## Changing application code

`make deploy` installs the chart and does not build images, so a code change is a rebuild, a
push and a redeploy:

```bash
# 1. build the image and push it to the registry the bootstrap started
REBUILD=1 scripts/build-images.sh            # all six, or one: REBUILD=1 ONLY=awp/web scripts/build-images.sh

# 2. install the chart again
make deploy

# 3. the tag did not change, so tell the Deployment to pull it again
kubectl -n awp-app rollout restart deployment web
kubectl -n awp-app rollout status deployment web
```

Step 3 is needed only because the tag is the same: Kubernetes sees no change in the Pod spec
and leaves the running Pod alone. Giving the image a new tag (`--set images.web.tag=0.1.1`)
makes `make deploy` roll it out by itself. `make deploy-web` and `make deploy-agent` do steps 1
and 3 for one component.

`scripts/deploy-cluster.sh` (`scripts\deploy-cluster.bat` from Windows, which runs it in Git Bash)
does the same for the web and agent images, or for one of `web`, `agent` or `connectors`, and
checks each step: it refuses while the Temporal namespace `awp` has running workflows unless
`ALLOW_IN_FLIGHT=1`, compares the registry digest before and after the build, runs the chart's
`db-migrate` Job from the new web image before the web pods restart, and fails if a running pod
still carries the old image.

`make deploy` is idempotent: running it again with nothing changed succeeds and leaves the
release as it was. It installs the same chart for both profiles; the `core` difference is in the
platform underneath.

### Draining in-flight runs first

A run token carries what the run may reach: which tools it was granted, and which run it acts
on. A token minted before a claim existed carries nothing for it, and the server reads an absent
claim as "nothing" rather than "everything" ([D28, D51, D52](../harness-decisions.md)). A run
that is mid-flight when the new web image goes live therefore holds a token that can neither call
a tool nor finish itself: it stalls and then fails, rather than degrading.

So drain before deploying a change to the run token's claims:

```bash
# 1. what is still in flight
kubectl -n awp-data exec awp-pg-1 -- psql -U postgres -d awp -c \
  "select key, status, started_at from ai.run where status in ('Running','Waiting') order by started_at"

# 2. let them finish, or cancel them from the Runs screen (S-52)
# 3. re-run the query; deploy only once it returns no rows
```

A `Waiting` run is waiting on a person, so it can sit for hours: cancel it and tell the
requester, rather than deploying over it and leaving them a run that never answers.
`scripts/deploy-cluster.sh` makes the same check against Temporal's count of running workflows.

### The deploy gate

No deploy is complete until the [demo flows](demo-flows.md) pass against the deployed image
(D54).

## Migrations

The `db-migrate` Job is a `pre-install,pre-upgrade` hook of `charts/awp`, so it runs and
completes before `web` starts, on every `make kind-up` and every `make deploy`. It runs
`node apps/web/db-migrate/db/migrate.js` (compiled from `apps/web/src/db/migrate.ts`), which
applies `infra/postgres/01-extensions.sql`, checks that the Drizzle journal's timestamps increase,
applies the Drizzle migrations in `apps/web/src/db/migrations/`, then the partitioning,
audit-guard, integrity and role SQL (`03-partitions.sql`, `04-audit-guard.sql`, `05-integrity.sql`,
`06-roles.sql`), then, on an installation that has been seeded, syncs the permission catalogue and
its grants, and ends with `Migrations complete.`

```bash
kubectl -n awp-app logs job/db-migrate
kubectl -n awp-app get job db-migrate -o jsonpath='{.status.succeeded}'
```

Running it again on an already-migrated database succeeds and changes nothing. Outside the
cluster, `npm --prefix apps/web run db:migrate` runs the same entry point against
`DATABASE_MIGRATE_URL`. A new migration is generated with `npm --prefix apps/web run db:generate`
(drizzle-kit).

The Drizzle migrations are numbered `0000` to `0074`; `0036` does not exist, so there are 74.

### Rolling one back

Drizzle has no down-migrations, so a rollback is written by hand and checked before the deploy
that needs it, not after. Take a backup first regardless: a rollback undoes a schema change,
never a data change. Roll the image back first: rolling back the schema without rolling back the
image leaves the application reading columns that no longer exist.

The rollbacks written below cover `0031` to `0040` only; none is written for `0041` to `0074`.
The journal `DELETE` at the end removes the newest journal rows, so it is correct only when the
migrations rolled back are the newest applied: on a database at `0074`, `0041` to `0074` have to be
rolled back before `0031` to `0040`.

`0031` to `0038` are additive — nullable columns, one new table, foreign keys, indexes and one
widened check constraint — so each reverses cleanly and loses only what was written into the new
columns after the deploy. The exception is `0038`, whose data is private memory that exists
nowhere else; see its note below. `0039` only fills `default_version` for the built-in agent and
disappears with `0035`'s column. `0040` inserts the widened default grant into every agent
version's `agent_platform_tool` rows; those rows cannot be told apart from rows an administrator
added since, so it has no clean reversal. TODO: needs input — whether a rollback past `0040`
should remove the 63 names it added, and from which agent versions.

```sql
-- 0033: the delegation tree
DROP INDEX IF EXISTS "ai"."run_parent_idx";
ALTER TABLE "ai"."run" DROP CONSTRAINT IF EXISTS "run_parent_run_id_run_id_fk";
ALTER TABLE "ai"."run" DROP COLUMN IF EXISTS "parent_run_id";

-- 0032: the run-row grant. Dropping it makes every in-flight run's grant unknown,
-- which reads as "the child's own configuration" (childGrant), never as "everything".
ALTER TABLE "ai"."run" DROP COLUMN IF EXISTS "granted_tools";

-- 0031: the approval binding. Dropping it makes every pending approval unbindable, so
-- the server refuses the T2 calls waiting on them — the fail-closed direction.
DROP INDEX IF EXISTS "ai"."approval_binding_idx";
ALTER TABLE "ai"."approval"
  DROP COLUMN IF EXISTS "consumed_at",
  DROP COLUMN IF EXISTS "expires_at",
  DROP COLUMN IF EXISTS "target_version",
  DROP COLUMN IF EXISTS "arguments_hash";

-- 0038: memory scoped per person. The two DELETEs destroy private memory, so they are
-- not part of a routine rollback: dropping the column alone is the non-destructive half,
-- and it leaves agent-scoped rows that every user of that agent can read. Decide before
-- running them.
DROP INDEX IF EXISTS "ai"."memory_scope_person_idx";
DROP INDEX IF EXISTS "ai"."memory_scope_agent_person_key";
ALTER TABLE "ai"."memory_scope" DROP CONSTRAINT IF EXISTS "memory_scope_person_id_person_id_fk";
-- DELETE FROM "ai"."memory" WHERE "scope_id" IN (SELECT "id" FROM "ai"."memory_scope" WHERE "person_id" IS NOT NULL);
-- DELETE FROM "ai"."memory_scope" WHERE "person_id" IS NOT NULL;
ALTER TABLE "ai"."memory_scope" DROP COLUMN IF EXISTS "person_id";

-- 0037: the Blocked outcome
ALTER TABLE "ai"."run" DROP CONSTRAINT IF EXISTS "run_status_check";
ALTER TABLE "ai"."run" ADD CONSTRAINT "run_status_check" CHECK ("status" in ('Queued', 'Running', 'Waiting', 'Succeeded', 'Failed', 'Cancelled', 'BudgetExceeded'));

-- 0035 (and 0039): the built-in assistant
ALTER TABLE "ai"."agent" DROP COLUMN IF EXISTS "default_version";
ALTER TABLE "ai"."agent" DROP COLUMN IF EXISTS "is_builtin";

-- 0034: the per-agent grant. Dropping it leaves every agent with no stored grant, which
-- reads as "nothing" — fail closed, and agents stop working until the code is rolled
-- back too. Dropping the table also removes the rows 0040 inserted.
DROP TABLE IF EXISTS "ai"."agent_platform_tool";

-- then remove the journal rows so the migrator does not think they are applied.
-- LIMIT is the number of migrations rolled back: 9 for all of 0031 to 0040 (0036 does not exist).
DELETE FROM "drizzle"."__drizzle_migrations"
 WHERE "hash" IN (SELECT "hash" FROM "drizzle"."__drizzle_migrations" ORDER BY "created_at" DESC LIMIT 9);
```

## Continuous integration

One workflow, `.github/workflows/verify.yml`, on every push, every pull request and on demand,
one run per ref (a newer push cancels the older run), with read-only repository permissions.

| Job | What it runs | Entry point |
| --- | --- | --- |
| `verify` (45 min) | PostgreSQL 18 and MinIO service containers; `npm --prefix apps/web ci`; creates the eight buckets with `apps/web/scripts/ensure-buckets.mjs`; then the gate | `bash scripts/verify.sh`, the same script `make verify` runs locally ([Conventions](../08-development/conventions.md#the-verification-gate)) |
| `scan` (20 min) | `npm audit --audit-level=high` for `apps/web`; `pip-audit` on `services/agent`'s exported requirements; gitleaks; semgrep (`p/default`); trivy filesystem scan for CRITICAL and HIGH | the tools directly |

Node comes from `actions/setup-node` reading `engines.node` in `apps/web/package.json`; uv from
`astral-sh/setup-uv`.

Gaps, logged:

- `pip-audit` covers `services/agent` only, not `services/connectors`, `services/sandbox` or
  `services/modelstub`.
- The Playwright suite does not run in CI; it needs the kind deployment and is run with
  `make test-e2e`.
- CI resolves Node from the range `>=20.9.0`, while the web image runs Node 24.11.0, so CI and the
  image can run different Node majors.

There is no release or publish job: images are built and pushed only by `scripts/build-images.sh`
to the local registry. TODO: needs input — how images reach `registry.tahseel.ae/awp` for Test and
Live.

## Sizing

Reference Live capacity from the stack specification (about 300 concurrent agent runs and 2,000
concurrent room users), not measured on this platform:

- 20 vCPU and 80 GB RAM in total for application, AI and data workloads;
- storage nodes for Ceph with raw SSD or NVMe;
- GPUs only when hosting models, on a separate pool behind agentgateway.

Scaling: an HPA on `web` (enabled in `values-live.yaml`); `agent-worker` replicas set per queue
in the values files; agentgateway proxies scale horizontally; PostgreSQL scales reads with CNPG
replicas and can be split by database by changing connection strings; Ceph adds OSD nodes.

Unverified: the reference capacity figures (no load test exists in the repository).

## Version and upgrade policy

The stack specification's policy, checked against the project's dependency rules in
[CLAUDE.md](../../CLAUDE.md):

| Rule | Stack specification | Current code | Status |
| --- | --- | --- | --- |
| Pinning | Image digests in Helm values; lock files; `versions.lock.md` | Lock files (`package-lock.json`, `uv.lock`) and `versions.lock.md` are used. Images are pinned by tag in values; the base images of the web and service Dockerfiles are pinned by exact version **and digest**, while `services/sandbox/workspace/Dockerfile` uses `node:24-bookworm-slim` and `python:3.12-slim-bookworm` | ⚠ Conflict: CLAUDE.md forbids exact `X.Y.Z`, digest or commit-SHA pins in declarations; the stack specification asks for digests. The digest-pinned Dockerfiles and `react`, `react-dom` in `apps/web/package.json` use exact pins. Unresolved — owner's call. |
| `latest` tags | — | `adminer:latest` and `redis/redisinsight:latest` in `infra/platform/admin-tools.yaml` (local only) | Neither rule is met for these two. |
| CopilotKit | `@copilotkit/react-core`, `@copilotkit/runtime` and `@ag-ui/client` upgraded together | Declared as `^1.78.0`, `^1.78.0`, `^1.0.2` | Process rule; not enforced by tooling. |
| Pydantic AI | Track the latest v2 minor; deprecation warnings fail CI | `pydantic-ai-slim` 2.57.0 and `pydantic-ai-harness` 0.57.0 resolved in `uv.lock` | Unverified: no CI setting that fails on deprecation warnings was found. |
| Freshness | Adopt versions after at least two weeks public, with changelog and security review | — | Process rule. |
| Cadence | Monthly patches, quarterly minors, majors planned | — | Process rule. |
| Gateways | agentgateway, Traefik and the Gateway API CRDs upgraded together with smoke tests | Declared together in `infra/kind/versions.env` | Process rule. |
| Storage | Rook and Ceph along Rook's supported path, one minor at a time | Rook 1.21.0 | Process rule. |
| Harness, standards, database | Replay plus evaluations for the harness; MCP, AG-UI and Agent Skills conformance tests; expand/migrate/contract migrations through `db-migrate` | Migrations through `db-migrate` | Unverified: no replay, evaluation or conformance suite was found in the repository. |
| Runtimes | Node.js Active LTS ≥ 20; Python 3.12 | `engines.node >=20.9.0`, image Node 24.11.0; `requires-python ==3.12.*`, image 3.12.12 | Consistent, with the CI/image Node gap above. |
