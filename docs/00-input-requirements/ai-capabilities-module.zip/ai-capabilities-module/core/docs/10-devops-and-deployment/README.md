# 10 — DevOps & Deployment

> CI/CD, environments, configuration, release and rollback.
> Owner: DevOps lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Deployment](deployment.md) | draft | 1.0 | 2026-10-30 |
| [Configuration](configuration.md) | draft | 1.0 | 2026-10-30 |

`deployment.md` describes the local `kind` platform, Test and Live, the Helm charts and the NetworkPolicies;
`configuration.md` lists every environment variable with its reader. Bringing the local platform up from a
clean machine is in [local-platform.md](../12-user-and-developer-guides/local-platform.md).
