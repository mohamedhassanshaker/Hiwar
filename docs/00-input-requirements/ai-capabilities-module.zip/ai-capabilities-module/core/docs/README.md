# Documentation

> Index of the project documentation. Rules: `docs/AGENTS.md`.

## Folders

| Folder | Contents |
|--------|----------|
| [01-business-requirements](01-business-requirements/README.md) | Business context, scope, business rules, handoff source documents |
| [02-product-requirements](02-product-requirements/README.md) | Requirements, use cases, flows, module specs, glossary, open questions, prototype |
| [03-architecture](03-architecture/README.md) | Tech stack, HLD, LLD, C4 diagrams, runtime specifications |
| [04-decisions](04-decisions/README.md) | ADRs and the decision register |
| [05-api-and-integrations](05-api-and-integrations/README.md) | API contracts and integration specs |
| [06-data](06-data/README.md) | ERDs, schemas, data flows, data dictionary |
| [08-security](08-security/README.md) | Threat models, permissions, security requirements and reports |
| [09-testing](09-testing/README.md) | Test plans, cases and reports |
| [10-devops-and-deployment](10-devops-and-deployment/README.md) | CI/CD, environments, configuration, release and rollback |
| [11-operations](11-operations/README.md) | Runbooks, monitoring, incident response |
| [12-user-and-developer-guides](12-user-and-developer-guides/README.md) | Setup, build/lint/test/run commands, development conventions, user manuals, demo flows |
| [13-releases-and-changelog](13-releases-and-changelog/README.md) | Release notes, migration guides, changelog |
| [14-project-management](14-project-management/README.md) | Roadmap, risks, milestones, delivery tracker, progress log |

## Reading paths

| Reader | Read in this order |
|--------|--------------------|
| <Audience> | <document → document → …> |
