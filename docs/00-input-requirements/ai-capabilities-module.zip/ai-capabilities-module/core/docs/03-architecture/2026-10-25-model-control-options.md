# Model control: three approaches compared

| Item | Value |
| --- | --- |
| Purpose | Where model providers, keys and routes are controlled: the current design, standalone agentgateway, and the console editing Kubernetes resources only. Compared, with a recommendation for production |
| Date | 2026-10-25 |
| Audience | The owner, architects, operations |
| Evidence | The code on branch `review-8`; the kind cluster (`awp-ai`); `cr.agentgateway.dev/agentgateway:v1.6.0` run standalone in Docker on 2026-10-24 |
| Related | [Models and routes](../05-modules/models-and-routes.md) · [AI platform](../03-architecture/ai-platform.md#agentgateway) · [Model providers](../06-integrations/model-providers.md) · [Stack decisions](../03-architecture/decisions/stack.md) (SD-3, SD-7) |

## Recommendation

Keep approach 1, the current design, and fix the defects listed in [section 3](#3-approach-1-current-console-and-postgres-rendered-into-agentgateway).
It is the most maintainable option for production:

- The record keeps typed columns, foreign keys and migrations.
- Postgres backups already cover the configuration.
- The gateway can be rebuilt from the database after a cluster loss.
- It needs the fewest changes.

Approach 3 is the alternative if Kubernetes should hold the record. Approach 2 is not suitable for
production.

## 1. What "model control" covers

| Item | Example |
| --- | --- |
| Providers and connections | OpenRouter › Main, Azure OpenAI › UAE North |
| Keys | The API key of each connection |
| Allowed models per connection | `nvidia/nemotron-3.5-super-vl:free` |
| Routes | The alias agents call (`reasoning-default`), its primary model and fallbacks in order |
| Settings the gateway has no field for | English and Arabic names, model kind, price per 1000 tokens (D92), typesafe output schema and confidence, voice settings, connection health (D196) |
| Who may change it | `models:write`, recorded in the platform audit log |

Every caller (agent service, knowledge ingestion, request classification, skill test bench) calls
agentgateway's OpenAI-compatible listener with the route alias. None of the three approaches
changes the callers.

## 2. agentgateway's two modes

| | Controller mode (installed today) | Standalone mode |
| --- | --- | --- |
| Configuration source | Kubernetes resources (`Gateway`, `AgentgatewayModel`, Secrets). The controller translates them and pushes them to the data plane over xDS. | A YAML file the process reads and watches |
| Admin UI | Read-only ("Configuration is managed by XDS") | Edits the file through `POST /api/config` when `config.storage.mode` is `file` or `hybrid` |
| Replicas | Several, all fed by the controller | One per file; `hybrid` (database-backed) not verified |
| Status | Each resource reports `Accepted` / `ResolvedRefs` | None |

## 3. Approach 1: current, console and Postgres rendered into agentgateway

```mermaid
flowchart LR
  A[Models & routes screen] -->|models:write, audited| B[(Postgres ai.route*, ai.provider*)]
  A -->|key on save| S[Secret provider-conn-id]
  B -->|render.ts, publish.ts| C[AgentgatewayModel resources]
  C --> D[agentgateway controller]
  S --> D
  D -->|xDS| E[ai-gateway data plane]
  E --> F[Model providers]
```

How it works:

- The console saves the record in Postgres, then applies one internal `AgentgatewayModel` per
  route step and one public alias with `virtualModel.failover`.
- The key is stored encrypted in Postgres (`APP_KEK`) and in plain form in a Kubernetes Secret
  that the gateway reads.
- `republishRoutes` re-applies all routes when the web server starts.

Strengths:

- A typed record with foreign keys. An agent cannot point at a route that does not exist, and a
  route in use cannot be deleted.
- The console enforces `models:write` and writes the platform audit log.
- Connection tests and their stored health work.
- Typesafe and voice settings have a home.
- Local development works without a cluster.
- Postgres backups already cover the configuration.

Defects found (2026-10-24):

| # | Defect | Evidence |
| --- | --- | --- |
| 1 | A route whose steps are all on switched-off providers keeps its old gateway resources | `vision` is Inactive on every step in the console; the gateway still routes it to Azure `gpt-4.1`. `readRouteForGateway` returns `null` and nothing is published. |
| 2 | Deleting a route leaves it served | 8 `e2e-route-*` aliases still accepted; `removeRoute` (`route-service.ts:86`) deletes rows only |
| 3 | Shortened chains leave step resources | `classifier-typed-step-1..3`; unreferenced and internal, so clutter |
| 4 | The gateway's `Accepted` status is never read back | `publish.ts` applies and returns |
| 5 | Reconciliation runs only on save and at web start | `instrumentation.ts`; no drift detection |
| 6 | Rebuilding the gateway does not rebuild the key Secrets | `republishRoutes` renders models only; Secrets are written only when a key is typed on screen (`provider-service.ts:158/205/271`). The seed stores no key (`seed/models.ts`, `secretRef: null`). So a new cluster, or a restored database, has routes whose keys are missing until someone re-enters every key. Inferred from the code, not reproduced. |
| 7 | The web app can read every Secret in `awp-ai` | Role in `infra/charts/awp/templates/web.yaml`: `secrets: [get, create, update, patch]`; no code reads one |
| 8 | Gateway keys are not encrypted at rest on kind | No `--encryption-provider-config` on the API server; SD-3 open |

Fixes that make it production ready:

1. **One reconcile function.**
   - It builds the full desired set from Postgres: models, aliases, and Secrets decrypted from the
     Postgres copy.
   - It applies that set, then deletes every `app.kubernetes.io/managed-by=awp-console` resource
     outside it.
   - A route with no active step gets no alias, so callers get "route not found" (fail closed).
   - It reads each alias's `Accepted` condition back onto the route.
   - It runs on every models write, at start and on a timer.

   This fixes defects 1 to 6.
2. Remove `get` from the Secrets rule (7).
3. etcd encryption with a KMS, or keys supplied through External Secrets, on Test and Live (8, SD-3).
4. Set `config.storage.mode: readOnly` in `AgentgatewayParameters`. The admin `/api/config`
   endpoint is published at `aigateway.awp.localtest.me`, and the cluster reports
   `configStoreMode: file`.
5. Optional: test a saved connection through the gateway as well, so Healthy means a real call
   worked.

## 4. Approach 2: standalone agentgateway, model controls removed from the console

```mermaid
flowchart LR
  O[Operator] -->|agentgateway UI| G[ai-gateway standalone]
  G -->|reads, writes| Y[(config.yaml on a volume)]
  K[Secret env vars] --> G
  G --> F[Model providers]
  A[Console] -.->|read-only GET /api/config, or nothing| G
```

How it works:

- The controller and the `Gateway` resource are removed.
- A Deployment runs `agentgateway -f /config/config.yaml` with the file on a writable volume.
- Routes are edited in agentgateway's UI, which rewrites the file; the process reloads it.
- Keys come from environment variables (`$OPENROUTER_API_KEY`), or are typed into the UI and saved
  literally in the file.
- Models & routes in the console becomes a read-only view or is removed.

Measured on 1.6.0:

| Fact | Evidence |
| --- | --- |
| Failover is supported in the file format | `llm.models[].visibility: internal` and `llm.virtualModels[].routing.failover.targets[{model, priority}]` pass `--validate-only` |
| **The admin port has no authentication** | Unauthenticated `GET /api/config` returned a literal key; unauthenticated `POST /api/config` rewrote the file |
| The UI can require a login only on a separate gateway listener | `gateways.admin` + `ui.gateways: admin` + `ui.policies` (`oidc`, `basicAuth`, `jwtAuth`, `apiKey`, `extAuthz`). `basicAuth` blocked only with `mode: strict`. The admin port stayed open regardless, so `adminAddr` must remain on loopback. |
| OIDC login needs `OIDC_COOKIE_SECRET` (64 hex characters) and the issuer reachable at startup | Validation fails without either |
| A ConfigMap cannot hold the file | ConfigMaps mount read-only, so UI edits fail or are lost on restart |

Changes:

- `infra/platform/helmfile.yaml` and `infra/kind/bootstrap.sh`: stop installing the controller.
- `infra/gateway/gateway.yaml`: remove the `Gateway` and `AgentgatewayParameters`.
- New: a Deployment and Service named `ai-gateway`, ports 8080/8081, one replica, a PVC, keys from
  Secrets as environment variables.
- `httproutes.yaml`: point the UI host at the protected listener.
- `network-policies.yaml`: keep or replace the selector.
- Console: remove the renderer, the Secret writer, the Role and the model tables; Models & routes
  becomes a viewer.
- Agents and budgets keep the alias as text.
- Tests and docs change accordingly, and so does stack specification 6.1.

Strengths:

- Operators edit routing in the gateway's own UI.
- No custom rendering code.

Weaknesses:

- One replica, so the gateway is a single point of failure for every model call.
- The admin API is unauthenticated. Anyone who reaches it reads and replaces the whole
  configuration, keys included.
- Keys typed into the UI are stored in plain text in the file and shown by `GET /api/config`.
- Adding a key through Secrets means a Pod restart.
- No platform permission check, no platform audit log, no "route in use" refusal and no
  connection health on the console.
- No typesafe or voice settings.
- No Gateway API status.
- The record is a file on one volume, which needs its own backup.
- It departs from the stack specification's single path: the web app renders agentgateway
  resources (6.1).

## 5. Approach 3: console edits Kubernetes resources only, no Postgres storage

```mermaid
flowchart LR
  A[Models & routes screen] -->|models:write, audited| K[AgentgatewayModel resources + annotations]
  A -->|key on save, write-only| S[Secret per connection]
  K --> D[agentgateway controller]
  S --> D
  D -->|xDS| E[ai-gateway data plane]
  E --> F[Model providers]
```

How it works:

- The controller stays.
- The console reads and writes `AgentgatewayModel` resources and Secrets through the Kubernetes
  API; Postgres holds no model data and no keys.

| Console concept | Stored as |
| --- | --- |
| Connection key | One Secret per connection, written on save, never read back. The only copy. |
| Allowed model | One internal `AgentgatewayModel` (provider, model, URL, `secretRef`) |
| Route | One public `AgentgatewayModel` whose `virtualModel.failover` targets allowed models |
| Provider, connection | Labels |
| Names, kind, prices, typesafe schema, voice settings, last test | Annotations under one prefix (256 KB per resource) |

Changes:

- `features/models/repository.ts` switches from SQL to the Kubernetes API (list by label,
  server-side apply, delete by label).
- The renderer becomes its write side, and `republishRoutes` is removed.
- `ai.agent_version.primary_route_id`, `fallback_route_id` and `gov.*.cheaper_route_id` become
  alias text checked against the cluster.
- Prices move to annotations, which the cost estimate reads.
- The seed becomes a create-only manifest.
- Migration: export, switch, then drop `ai.model_provider`, `ai.provider_connection`,
  `ai.connection_allowed_model`, `ai.route`, `ai.route_step` (irreversible).
- The Role becomes `get/list/watch/create/patch/delete` on models and
  `create/patch/delete` on Secrets.
- Docs and stack specification 6.1 change.

Strengths:

- One record, so no drift between a database and the gateway.
- Keys exist only where the gateway reads them, and the console cannot read them back.
- `Accepted` status is native.
- The console keeps the permission check and audit log for its own edits.

Weaknesses:

- **Testing a saved connection.** The console cannot read the key, and internal models cannot be
  called through the gateway. You test on save only, create a temporary public alias per test, or
  rely on gateway health checking (not verified on the CRD).
- **No foreign keys.** A `kubectl delete` of a route breaks the agents using it with
  "route not found", and nothing refuses it.
- **Metadata in annotations is untyped.** No schema validation or migrations when a setting
  changes shape.
- **Kubernetes write access is a second way in.** Anyone with write RBAC on `awp-ai` edits routes
  outside the console's permission check and audit.
- **Backup moves to Kubernetes.** Model configuration is backed up with Velero or etcd snapshots,
  separately from the Postgres backup that covers everything else.
- **Local development needs the kind cluster** for Models & routes and the agents' route picker.
- **The keys still need etcd encryption or External Secrets** (SD-3).

## 6. Comparison

| Criterion | 1. Current, fixed | 2. Standalone | 3. Kubernetes only |
| --- | --- | --- | --- |
| Source of truth | Postgres; gateway resources derived and rebuilt from it | Gateway's YAML file | Kubernetes resources |
| Where keys live | Postgres (encrypted, `APP_KEK`) and Secret (derived) | Pod env vars or plain text in the file | Secret only |
| Console can read a key back | No (screen is write-only); the server decrypts for tests | n/a | No |
| Who edits | Console (`models:write`) | Anyone past the gateway UI login; anyone reaching the admin port | Console (`models:write`) and anyone with Kubernetes write access |
| Platform audit of changes | Yes | No | Console edits only |
| High availability | Yes, several data-plane replicas | No, one replica | Yes |
| Drift between record and gateway | Removed by the reconcile fix | None (one file) | None |
| Agent ↔ route integrity | Foreign keys | None | Checked by the console only |
| Saved-connection test | Yes | No | Limited |
| Typesafe, voice, prices, Arabic names | Typed columns | Lost | Annotations, untyped |
| Rebuild after cluster loss | From the Postgres backup | From the file backup | From a Kubernetes backup |
| Local development without a cluster | Yes | No | No |
| Admin UI exposure | Read-only viewer | Must be behind OIDC on a separate listener; admin port must stay internal | Read-only viewer |
| Code to change | Reconcile function, Role, gateway parameters | Install, gateway manifests, console module removed, docs | Models repository rewrite, table drop, seed, foreign keys, docs |
| Reversible | Yes | Hard: data leaves the platform | Hard: tables dropped |
| Fits the stack specification (6.1) and design rules | Yes | No | Deviates from 6.1; needs an amendment |

## 7. Why approach 1 for production

1. **One record, rebuildable projection.** Once the reconcile function prunes and re-creates
   Secrets, the gateway is a pure function of Postgres. Losing the cluster loses nothing that the
   existing CloudNativePG backup does not restore. Approaches 2 and 3 add a second backup system
   for the platform's configuration.
2. **Typed, migrated, referentially sound.** Route and connection settings change shape over time
   (typesafe, voice, prices). Columns with migrations and foreign keys are easier to evolve than
   annotations or a YAML file.
3. **One authorisation path.** Every change passes `models:write` and the platform audit log.
   Approach 3 adds Kubernetes RBAC as a parallel way in; approach 2 adds an unauthenticated admin
   API.
4. **High availability is kept.** The controller feeds several gateway replicas. Approach 2 makes
   every model call depend on one Pod.
5. **Smallest change, reversible.** The fixes touch the models feature, one Role and one gateway
   parameter. Approaches 2 and 3 drop tables or move data out of the platform.

The key exists twice in approach 1: encrypted in Postgres as the record, and in a Secret the
gateway reads. That copy is what lets the gateway be rebuilt and saved connections be tested. The
Secret's exposure is closed by fixes 2 and 3 above, not by removing the record.

Choose approach 3 instead if the organisation requires that provider keys never be stored by the
application, and accepts weaker connection testing, no foreign keys and a Kubernetes backup of
model configuration.

## 8. Decisions needed

| Decision | Recommendation |
| --- | --- |
| Which approach | 1, with fixes 1 to 4 of section 3 |
| How keys are protected at rest on Test and Live (SD-3) | etcd encryption with the organisation's KMS; External Secrets if a vault is the organisation's standard |
| Whether saved connections are also tested through the gateway | Yes, after the reconcile fix |
