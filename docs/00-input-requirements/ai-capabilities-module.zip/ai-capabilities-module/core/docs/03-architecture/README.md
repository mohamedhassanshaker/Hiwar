# 03 — Architecture

> Tech stack (languages, frameworks, tools, versions), ownership map (which component owns each concern),
> HLD, LLD, C4 diagrams, runtime specifications.
> Owner: Tech lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Enterprise tech stack and solution design guide](enterprise-tech-stack-solution-design.md) | draft | 1.1 | 2026-11-03 |
| [Architecture overview](overview.md) | draft | 1.0 | 2026-10-30 |
| [Tech stack](tech-stack.md) | draft | 1.0 | 2026-10-30 |
| [Solution design](solution-design.md) | draft | 1.0 | 2026-10-30 |
| [AI platform components](ai-platform.md) | draft | 1.0 | 2026-10-30 |
| [Agent communication](agent-communication.md) | draft | 1.0 | 2026-10-30 |
| [Agent runtime specification](agent-runtime-spec.md) | draft | 1.0 | 2026-10-30 |

## Dated reports

Evidence of what was true on one date. Never edited afterwards; current facts are in the maintained documents above.

| Date | Report | Records |
|------|--------|---------|
| 2026-10-19 | [Refactor report](2026-10-19-refactor-report.md) | The behaviour-preserving code restructure: baseline, contracts, what moved, final gate |
| 2026-10-25 | [Model control: three approaches compared](2026-10-25-model-control-options.md) | Three ways to control model providers, keys and routes (current, standalone agentgateway, Kubernetes only), compared, with a recommendation |

## Related

- Security architecture is in [08-security](../08-security/README.md).
- Decision registers (platform, stack, code structure, agent runtime) are in [04-decisions](../04-decisions/README.md).
- Data model and ERDs are in [06-data](../06-data/README.md).
