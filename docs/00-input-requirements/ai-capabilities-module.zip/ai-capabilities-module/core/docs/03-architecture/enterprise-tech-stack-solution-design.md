---
title: Enterprise Tech Stack and Solution Design Guide
status: draft
owner: Enterprise Architecture
related: [03-architecture/overview.md, 04-decisions/README.md, 08-security/security.md, 09-testing/README.md, 10-devops-and-deployment/deployment.md, 12-user-and-developer-guides/conventions.md]
version: 1.1
last-updated: 2026-11-03
---

# Enterprise tech stack and solution design guide

| Item | Value |
| --- | --- |
| Purpose | A reusable reference for product teams: stack principles, reference architecture, solution patterns, and where to record project-specific choices |
| Audience | Developers, architects, tech leads, security, operations |
| Scope | Organization-wide; **not** tied to a single product name or repository |
| How to use | Copy sections into a new product’s `03-architecture/` folder, replace placeholders, and link decisions in `04-decisions/` |

---

## 1. How this guide relates to a product repository

Every product should maintain its own architecture folder (numbered `03-architecture/` or equivalent) with:

| Artifact | Content |
| --- | --- |
| **Tech stack inventory** | Resolved versions from lock files, images, and charts—not wish lists |
| **Solution design** | Request paths, async/agent paths, and key business flows for *that* product |
| **Runtime specifications** | Behaviour of long-running processes (agents, jobs, workflows) |
| **ADRs** | One record per significant technical choice |

This document is the **template and rationale**. Product documents cite ADRs and evidence; they do not duplicate the full org policy unless the product deviates.

---

## 2. Design principles

These principles apply to new platforms and major releases. A product may document an exception in an ADR with owner approval.

| ID | Principle | Rationale | Typical effect |
| --- | --- | --- | --- |
| **P-1** | **Clear runtime boundaries** | Different workloads have different scaling, security, and release cadence | Often: one **primary application runtime** (e.g. TypeScript web stack) for UI and domain logic, plus **specialized runtimes** (e.g. Python) for AI workers, ingestion, or heavy compute—not one language for everything |
| **P-2** | **One system of record per domain** | Split brains cause inconsistent authorisation and audit | One **relational database** (or strictly bounded schemas) owns transactional domain data; search/graph/vector stores are **indexes** rebuildable from source |
| **P-3** | **Open standards over proprietary glue** | Portability and vendor optionality | Prefer OIDC, OAuth 2, OpenTelemetry, S3 API, Gateway API, OpenAI-compatible model APIs, MCP, and documented HTTP/JSON contracts |
| **P-4** | **Single controlled path for AI traffic** | Keys, routing, policy, and observability in one place | All model and (where adopted) MCP/A2A traffic passes through an **AI gateway**; ad-hoc provider calls from UI or untrusted sandboxes are forbidden |
| **P-5** | **Durable by default for long work** | Restarts and human-in-the-loop must not lose state | Agent runs, schedules, ingestion, and multi-step approvals use a **workflow engine** (e.g. Temporal), not in-memory-only orchestration |
| **P-6** | **Minimum moving parts** | Operational cost and attack surface | Add a component only when nothing already in the stack can fulfill the requirement; platform teams own cluster networking, certs, baseline logging |
| **P-7** | **Pin and prove versions** | Reproducible builds and incident response | Lock files, image digests (or immutable tags), and a central **version register** updated by automation—not manual drift |
| **P-8** | **One orchestration model per environment class** | Dev/prod parity | Same container orchestrator locally (e.g. kind/minikube) and in shared environments; configuration differs, topology does not |
| **P-9** | **Authorise on the server** | UI is not a security boundary | Every protected read and mutation checks permissions in server code; agents use the same rules via server-mediated tools |
| **P-10** | **Vertical slices in code** | Team ownership and safe evolution | Features live in folders with explicit layers (repository → service → actions/API); shared code only when **three or more** features need it |

---

## 3. Reference architecture (C4-style)

### 3.1 System context

```mermaid
flowchart LR
  user([Human user - console])
  visitor([External visitor - widget or channel])
  integrator([Integration client - API or MCP])
  subgraph platform["Product installation - one tenant or org unit"]
    core[Console, domain services, AI orchestration]
  end
  idp[[Identity provider - OIDC]]
  models[[Model providers - cloud or on-prem]]
  channels[[Messaging channels - e.g. chat, SMS]]
  external[[External systems - REST, MCP, SaaS]]
  mail[[Corporate SMTP]]
  user -->|HTTPS, session or token| core
  visitor -->|public or scoped channel| core
  integrator -->|API key or mTLS| core
  core --> idp
  core -->|via AI gateway| models
  core <--> channels
  core -->|controlled egress| external
  core --> mail
```

**Reading guide:** Replace “product installation” with deployment boundary (single tenant, cell, or region). External systems must be listed in integration specs with data classification and retention.

### 3.2 Container diagram (logical)

```mermaid
flowchart TB
  subgraph edge["Ingress / edge"]
    GW[API gateway or ingress controller]
  end
  subgraph app["Application tier"]
    WEB["Web application - UI, domain API, tool server, channel gateway"]
    AS["Agent / worker API - run control, ingestion, classification"]
    W["Workflow workers - mission, batch, maintenance queues"]
    CON["Connector runtime - optional isolated integrations"]
    SBX["Sandbox manager - optional script isolation"]
    EGR["Egress proxy - allow-listed outbound"]
  end
  subgraph ai["AI platform tier"]
    AGW[AI gateway - models and future MCP/A2A]
    WF[Workflow service]
    OBS[LLM trace / eval store - optional]
  end
  subgraph data["Data tier"]
    PG[("PostgreSQL - domain + optional vector extension")]
    CACHE[(Redis-compatible cache / streams)]
    GRAPH[(Graph DB - optional knowledge graph)]
    OBJ[(Object storage - S3 API)]
  end
  GW --> WEB
  WEB --> PG
  WEB --> CACHE
  WEB --> OBJ
  WEB --> AS
  WEB --> WF
  AS --> WF
  W --> WF
  W --> AGW
  W --> WEB
  W --> OBJ
  AS --> AGW
  CON --> EGR
  SBX --> EGR
  W --> OBS
  WF --> PG
```

Not every product needs every box. **Omit** graph DB, sandbox, or separate agent API when requirements do not justify them (document the omission in an ADR).

### 3.3 Responsibility matrix

| Container | Owns | Must not own |
| --- | --- | --- |
| Web application | Domain schema, authorisation, audit, human UX, starting runs/jobs, platform tool endpoints | Long-running model loops without workflow backing |
| Agent / worker API | Run lifecycle HTTP, streaming relay, ingestion/retrieval endpoints | Direct unauthenticated domain DB writes bypassing web tools |
| Workflow workers | Durable steps, timers, signals (approve/cancel), idempotent activities | Session state for humans |
| AI gateway | Provider credentials, route aliases, failover chains, model observability hooks | Business permission rules (those stay in web) |
| Connector runtime | Third-party MCP/stdio bridges, credential injection | Domain transactions |
| Object storage | Blobs: files, artifacts, large workflow payloads | Relational integrity |

---

## 4. Technology stack (categories and selection criteria)

Pin exact versions in the **product** tech-stack document. Below: **what to choose and why**.

### 4.1 Client and primary application

| Concern | Recommended direction | Selection notes |
| --- | --- | --- |
| Framework | Modern full-stack web framework with SSR/API routes (e.g. **Next.js App Router**, or equivalent) | Single deployable for console + BFF; avoid splitting auth across many SPAs unless required |
| Language | **TypeScript** strict mode | Shared types with API contracts and form validation |
| UI | Organisation design system + accessible primitives | WCAG 2.2 AA; RTL if required by locale policy |
| Forms and validation | Schema-first validation at boundaries (e.g. **Zod**) | Same schemas for API and UI where possible |
| Data access | Type-safe SQL layer (e.g. **Drizzle**, Prisma, or Kysely) | Migrations in repo; no manual prod DDL |
| AuthN | **OIDC** via established library; sessions in DB or secure cookies | WebAuthn/passkeys where policy requires |
| AuthZ | Central evaluator; checks in **service layer** | Never “button hidden = secure” |
| Real-time | SSE or WebSocket backed by pub/sub (e.g. Redis/Valkey) | Prefer replayable streams for agent UIs |
| Logging | Structured JSON (e.g. pino, structlog on other runtimes) | No PII/secrets in logs |

### 4.2 Specialized services (AI, ingestion, connectors)

| Concern | Recommended direction | Selection notes |
| --- | --- | --- |
| HTTP API | **FastAPI** or equivalent async framework | OpenAPI published; health endpoints |
| Agent framework | **Pydantic AI** (or org-standard) with explicit tool boundaries | Tools call back into web/MCP, not raw DB |
| Workflow | **Temporal** (or org-standard durable execution) | One namespace per product; encrypted payloads if required |
| MCP | Official SDK for client and server | Streamable HTTP for platform server; stdio in isolated pods for connectors |
| Document AI | Parser chosen after **language/locale proof** (e.g. docling vs alternatives) | Record evidence in ADR |
| Vector search | **pgvector** in PostgreSQL when sufficient; dedicated vector DB only at scale | Treat as index |
| Knowledge graph | Optional **Neo4j** (or FalkorDB) behind graph library | Rebuildable from source documents |

### 4.3 Platform and data services

| Component | Role | HA notes |
| --- | --- | --- |
| PostgreSQL | System of record; optional pgvector DB for passages | CloudNativePG or managed RDS; 3-node in production |
| Cache / streams | Fan-out, rate limits, mail/job queues | Redis-compatible; persistence policy documented |
| Object storage | S3 API (MinIO dev, Ceph/Rook or cloud S3 prod) | Lifecycle rules for temp payloads |
| Workflow backend | Same PostgreSQL or dedicated store per vendor | Backup and retention aligned with compliance |
| Ingress | Gateway API–capable controller (e.g. Traefik, Envoy) | TLS termination, WAF at edge where mandated |
| Secrets | Kubernetes secrets + external KMS/Vault for master keys | App-level envelope encryption only when KMS unavailable (ADR) |
| Observability | OpenTelemetry → collector → backend; LLM traces optional (e.g. Phoenix) | Trace id correlates to business run id |

### 4.4 AI gateway

| Capability | Requirement |
| --- | --- |
| Routing | Named routes (aliases), provider failover chains, embedding vs chat vs “decision” route kinds |
| Credentials | Provider keys only on gateway; runtime uses short-lived run tokens |
| Observability | OTel spans for model calls; join to mission trace where possible |
| Future | MCP and A2A termination at gateway—adopt when connectors scale |

Verify **license and feature set** (OSS vs enterprise) before committing to voice, structured output passthrough, or budget enforcement at the gateway.

### 4.5 Developer toolchain

| Area | Standard |
| --- | --- |
| Package managers | One per runtime (e.g. npm/pnpm for Node; uv/poetry for Python)—document in product README |
| Lint / format | ESLint + ruff (or org equivalents); CI must fail on violations |
| Type checking | `tsc --noEmit` (strict) for TypeScript; mypy strict for Python |
| Unit tests | Vitest/Jest (TS); pytest (Python); ≥80% on business logic |
| Live tests | Playwright in dedicated repository-root `tests/` tree (see §9) |
| CI | One verification script, identical locally and in pipeline—see §9.3 |

Full testing guidance is in **§9**. Product commands belong in `12-user-and-developer-guides/`.

### 4.6 Web application — layered components

Typical full-stack console built on Next.js (or equivalent). Map each row to your product `tech-stack.md` with pinned versions.

| Layer | Components | Responsibility |
| --- | --- | --- |
| **Edge / middleware** | Reverse proxy, CSP middleware, locale headers | TLS termination at cluster edge; per-request CSP nonce; security headers; no business auth here unless org standard requires |
| **Routing** | App Router route groups `(console)`, `(auth)`, `api/`, optional `embed/` | Thin composition only; no repository imports in pages |
| **Presentation** | Design system wrapper, shared UI primitives, feature `components/` | Accessible UI; Server Components by default; `"use client"` only for interactivity |
| **Mutations** | Server actions (`"use server"`), route handlers | Zod-validated input; call feature services; return domain outcomes (not thrown messages for expected refusals) |
| **Domain** | Feature `service.ts`, permission evaluator (`authz/`) | Business rules, optimistic concurrency, audit writes, authorisation |
| **Persistence** | Feature `repository.ts`, ORM schema, migrations | Sole database client access from repositories; forward-only migrations |
| **Real-time** | SSE routes, pub/sub client | Live channels, agent event replay; namespaced stream keys |
| **Agent UI (optional)** | CopilotKit or AG-UI client, runtime route | Browser talks only to web app; runtime forwards cookies/tokens server-side |
| **Tool surface (optional)** | Platform MCP server (Streamable HTTP), tool catalogue | Agents invoke governed capabilities; same authz as humans |
| **Integrations in web** | Channel webhooks, widget API, SMTP consumer | Idempotent handlers; outbound via egress proxy |
| **Cross-cutting `lib/`** | Session, audit, crypto, object store client, workflow client, logger, env validation | Shared by ≥2 features; never imports features |
| **i18n** | Translation helper or library, RTL layout | Every user string and refusal in supported locales |

**Supporting libraries (common choices):**

| Concern | Typical libraries | Notes |
| --- | --- | --- |
| Validation | Zod (+ Ajv for dynamic schemas if needed) | Validate env at startup |
| AuthN | Auth.js / OIDC client, WebAuthn | Sessions in PostgreSQL |
| ORM | Drizzle, Prisma, Kysely | One migration toolchain |
| HTTP to internet | Fetch via egress proxy wrapper | Timeouts, no secrets in URLs |
| Object storage | AWS SDK S3 client | Path-style for MinIO-compatible stores |
| Workflow scheduling | Temporal TypeScript client | Schedules created from domain entities |
| Rich text / mail | TipTap, sanitize-html, nodemailer | Sanitise on save and send |
| Markdown / diagrams | react-markdown, flow library | Read-only views unless editing is required |

### 4.7 Agent and worker services — components

Python (or org-standard) services behind the web BFF. One container image often runs as **API** and **worker** processes.

| Component | Technology pattern | Role |
| --- | --- | --- |
| **HTTP API** | FastAPI + Uvicorn | Start runs, stream relay, signals (approve/cancel/answer), ingestion/retrieval HTTP |
| **Agent runtime** | Pydantic AI (or equivalent) + harness plugins | Model loop, toolsets, compaction, deferred tools |
| **Workflow worker** | Temporal worker per task queue | `MissionWorkflow`, ingestion, maintenance; encrypted payload codec optional |
| **Model client** | OpenAI-compatible SDK | Base URL = AI gateway; API key = run token |
| **MCP client** | Official MCP SDK | Calls platform tool server with run-scoped credential |
| **Streaming** | Valkey/Redis streams | AG-UI or custom events keyed by run id |
| **Ingestion** | Document parser, chunker, embedder, optional graph extractor | PII hooks; writes index stores only |
| **Retrieval** | pgvector queries, optional Graphiti | Hybrid search policies in product spec |
| **Tracing** | OpenTelemetry + Phoenix (or org backend) | Trace id aligned with business run id |
| **Temporal storage** | S3 external storage driver | Large workflow payloads offloaded with TTL lifecycle |

**Task queues (pattern):**

| Queue | Workflows | Isolation reason |
| --- | --- | --- |
| `agent-runs` | Interactive and scheduled missions | Latency-sensitive; scales with concurrent runs |
| `ingestion` | Document indexing | CPU/IO heavy; scale independently |
| `maintenance` | Schedule firing, housekeeping | Low rate; protects interactive queues |

### 4.8 Connector, sandbox, and stub components

| Component | Purpose | Stack notes |
| --- | --- | --- |
| **Connector runtime** | Host MCP connectors (stdio or remote) | Kubernetes client to spawn bridge pods; credentials in memory only |
| **Connector bridge pod** | Per-connector stdio MCP | No cluster SA token; egress via proxy only |
| **Sandbox manager** | Create/destroy isolated execution pods | Optional gVisor/Kata runtime class |
| **Sandbox workspace image** | Python + Node toolchains for skill scripts | Minimal packages; no provider keys in image |
| **Egress proxy** | Squid or org standard | Domain allow-list; separate policies for web, gateway, sandbox |
| **Model stub** | Deterministic OpenAI-compatible server | Local/CI only; backs gateway routes in dev |

### 4.9 Data plane — components in depth

| Component | Implementation options | Configuration highlights |
| --- | --- | --- |
| **PostgreSQL (domain)** | CloudNativePG, RDS, Azure Database | 3 instances HA in prod; separate DB role per service; connection pooling at app |
| **PostgreSQL (vectors)** | Same cluster, database `*_kb`, pgvector extension | Rebuild from object store + ingestion jobs |
| **Temporal persistence** | PostgreSQL databases `temporal`, `temporal_visibility` | Namespace retention (e.g. 7 days) documented |
| **Valkey / Redis** | Bitnami Valkey, Elasticache | Persistence off for pure cache; AOF/RDB if job durability required |
| **Neo4j (optional)** | Community + operator | One graph group per knowledge collection |
| **Object storage** | MinIO (dev), Rook-Ceph or cloud S3 (prod) | Buckets: files, artifacts, raw-docs, run-payloads, skills; lifecycle on temp buckets |
| **Phoenix (optional)** | Self-hosted chart | Trace retention (e.g. 60 days); licence ADR |

**Hook jobs (Kubernetes):** database migrate, bucket ensure, gateway route sync—run as Helm pre/post hooks or init jobs, idempotent.

### 4.10 AI gateway — components in depth

| Sub-component | Function |
| --- | --- |
| **LLM listener** | OpenAI-compatible `/v1` for chat, embeddings, decisions |
| **Route CRD / config renderer** | Web app or GitOps renders routes from domain “model route” entities |
| **Provider secret store** | K8s Secret mounted only on gateway |
| **Admin UI** | Route testing, provider health—admin network only |
| **OTel exporter** | Model span attributes for cost and latency dashboards |

Route kinds to model in domain data: **Standard chat**, **Typesafe** (structured output), **Embedding**, **Decision** (custom provider path), **Voice** (verify gateway support before adoption).

### 4.11 Cluster platform components

Owned by platform team; product charts consume as dependencies.

| Component | Role |
| --- | --- |
| **Ingress / Gateway API** | Traefik, Envoy Gateway, NGINX |
| **cert-manager** | TLS certificates (public CA or internal CA locally) |
| **CNI + NetworkPolicy** | Default-deny between namespaces; explicit egress rules |
| **Sealed Secrets / ESO** | Git-safe secret references |
| **Local registry (dev)** | kind cluster image load |
| **Mock OIDC (dev only)** | Never in production |
| **Mail sink (dev only)** | Mailpit or equivalent |

### 4.12 Shared contracts and packages

| Package | Contents | Consumers |
| --- | --- | --- |
| **API contracts** | JSON Schema or OpenAPI in `packages/contracts/` | Web, services, live tests |
| **Bundled skills / prompts** | Versioned artifact package | Agent runtime import |
| **Design system (vendored)** | Tokens, components, fonts | Web app code generation step |

Any change to a shared contract requires coordinated version bump and contract tests (§9.6).

---

## 5. Application solution design

### 5.1 Feature folder structure (vertical slice)

```
src/
├── app/                    # Routes only; compose features
├── features/<feature>/
│   ├── repository.ts       # Data access only
│   ├── service.ts          # Rules, permissions, audit
│   ├── actions.ts          # Server mutations (validated)
│   ├── schema.ts           # Zod/types
│   ├── tools.ts            # Optional MCP tools for this feature
│   └── components/         # Feature UI
├── lib/                    # Cross-cutting, no feature imports
├── authz/                  # Permission engine
└── components/             # Shared UI
```

**Rules:**

- Repository is the only layer that talks to the database client.
- Service is the only layer that enforces permissions and writes audit records.
- Routes and components call services—not repositories directly.
- Architecture tests enforce forbidden imports (recommended).

### 5.2 Synchronous request path (human operations)

```mermaid
sequenceDiagram
  actor U as User
  participant Edge as Ingress
  participant App as Web app
  participant Svc as Feature service
  participant Repo as Repository
  participant DB as PostgreSQL
  U->>Edge: HTTPS + session
  Edge->>App: forward
  App->>Svc: validated input
  Svc->>Svc: authorisation + invariants
  Svc->>Repo: query / command
  Repo->>DB: SQL
  Svc->>DB: audit event
  Svc-->>App: result or domain error
  App-->>U: UI / API response
```

**Cross-cutting on this path:** CSP and security headers at edge or middleware; optimistic concurrency (version columns) on updates; domain errors mapped to safe client messages.

### 5.3 Agent / long-running path

```mermaid
sequenceDiagram
  actor U as User
  participant Web as Web app
  participant API as Agent API
  participant WF as Workflow worker
  participant GW as AI gateway
  participant Tools as Platform tool server
  participant Stream as Event stream
  U->>Web: send message (session only)
  Web->>Web: permission check, create run, mint short-lived tokens
  Web->>API: start run
  API->>WF: start workflow
  Web->>API: subscribe to stream
  loop each step
    WF->>GW: model call (run token)
    WF->>Tools: tool call (scoped token)
    Tools->>Tools: same authz as human
    WF->>Stream: progress events
  end
  Stream-->>Web: SSE / relay
  Web-->>U: streamed UI
  WF->>Tools: finalize run (outcome, audit)
```

**Non-negotiables:**

- Browser never holds provider keys or unconstrained run tokens.
- Browser never connects directly to agent API in production (network policy + BFF).
- Tool calls that mutate data go through the same authorisation path as server actions.
- Human-in-the-loop (approvals) pauses workflow without holding worker threads (workflow timers).

### 5.4 Key cross-cutting flows (patterns)

| Pattern | Description | Design checkpoints |
| --- | --- | --- |
| **Approval gate** | Sensitive tool tier requires human decision | Bind approval to tool name + args hash + record version; single use; timeout → deny |
| **Outbox / mail** | Reliable async notifications | Stream or table + idempotent consumer; audit failures |
| **Schedule → workflow** | Cron-like business schedules | One schedule entity maps to one workflow schedule id |
| **File upload** | Metadata in DB, bytes in object store | Virus scan / MIME validation; no direct browser-to-storage for privileged buckets |
| **Knowledge ingestion** | Parse → chunk → embed → optional graph | PII masking hooks; rebuild indexes from raw docs |
| **Embedded widget** | Third-party site embed | Separate origin policy; `frame-ancestors`; visitor identity model documented |

Product `solution-design.md` should sequence-diagram **only** flows that are unique to that product.

---

## 6. Data architecture

### 6.1 Ownership

| Store | Typical owner | Content |
| --- | --- | --- |
| Primary PostgreSQL | Web application | All transactional domain entities, audit, sessions |
| Secondary PostgreSQL DB / schema | Worker service | Vectors, workflow-adjacent indexes |
| Graph database | Worker service | Derived entities and relationships |
| Object storage | Web + workers | Files, artifacts, large encrypted workflow payloads |
| Cache | Web + workers | Ephemeral channels, rate counters, job streams |

**Rule:** Only one service role may write authoritative domain rows. Workers extend domain through **tool APIs**, not shared DB credentials—unless explicitly ADR-approved (strong exception).

### 6.2 Migration and compatibility

- Forward-only SQL migrations in repo.
- Expand–contract for zero-downtime releases when traffic is continuous.
- Document retention and erasure per entity class in `06-data/` and security docs.

---

## 7. Security architecture (summary)

Detail lives in `08-security/` per product. Org minimum:

| Topic | Requirement |
| --- | --- |
| Authentication | OIDC SSO; MFA/passkeys per policy |
| Authorisation | Server-side on every path; attribute-based or RBAC documented in matrix |
| Secrets | Never in code/logs; reveal-once UX; KMS where available |
| Network | Default-deny between tiers; egress allow-list for sandboxes and connectors |
| Agents | Run-scoped tokens; tool tiering; no self-approval except documented exceptions |
| Audit | Append-only audit for security-relevant events |
| Supply chain | Dependency scanning; pinned base images |
| Compliance | Map to OWASP ASVS L2 (or org baseline) with evidence links |

---

## 8. Non-functional requirements (template)

Product NFR docs should assign IDs and **how measured**. Starter set:

| Category | Example criteria |
| --- | --- |
| Performance | p95 screen API < 300 ms; first agent token < 1.5 s excluding provider |
| Durability | Workflow survives worker restart; waiting runs consume no worker slot |
| Availability | 99.9% target; min replicas and HA DB in production |
| Security | ASVS L2; no agent bypass of authorisation |
| Privacy | PII masking in ingestion and logs; documented retention |
| Accessibility | WCAG 2.2 AA for console and public widget |
| Observability | Health aggregation; run id = trace id where applicable |
| Operability | Runbooks for gateway, workflow, and database failover |

---

## 9. Testing strategy and suites

Testing is **layered**: fast feedback near code, a **single CI verification gate**, and **live tests** against a local full stack. Products document exact commands in `12-user-and-developer-guides/` and maintain `tests/AGENTS.md` (or equivalent) for live-test rules.

### 9.1 Test pyramid and ownership

```mermaid
flowchart TB
  subgraph ci["CI gate — every PR"]
    U[Unit tests]
    C[Component / interaction]
    A[Architecture tests]
    D[Database integration]
    P[Python unit + workflow tests]
  end
  subgraph live["Live gate — release / nightly"]
    E2E[Browser E2E]
    API[Live API tests]
    LV[Live / smoke scenarios]
  end
  U --> C --> A
  D --> P
  E2E --> API --> LV
```

| Layer | Location (convention) | Runner | In CI gate? | Mocks |
| --- | --- | --- | --- | --- |
| **Unit** — services, validators, pure logic | `apps/<app>/tests/**/*.test.ts`, `services/<svc>/tests/unit/` | Vitest, pytest | Yes | External HTTP/queue only |
| **Database integration** — repositories, SQL | `apps/<app>/tests/db/` | Vitest + real PostgreSQL | Yes | No mock DB |
| **Component render** — first paint, no I/O | `apps/<app>/tests/*-render.test.tsx` | Vitest | Yes | Stub server actions |
| **Component interaction** — click, form | `apps/<app>/tests/*-interaction.test.tsx` | Vitest + happy-dom (or jsdom) | Yes | Stub actions |
| **Route handlers** — HTTP in/out | `apps/<app>/tests/` | Vitest + `Request` | Yes | Auth/session test doubles |
| **Architecture** — import rules, module set | `apps/<app>/tests/architecture.test.ts` | Vitest | Yes | N/A |
| **Traceability** — reqs ↔ test titles | `apps/<app>/tests/traceability.test.ts` | Vitest | Yes | N/A |
| **NFR measurements** — latency budgets | `apps/<app>/tests/measure/` | Vitest separate config | Optional / scheduled | Real DB or staging-like |
| **Service integration** | `services/<svc>/tests/integration/` | pytest + containers | Yes (if in verify script) | Real DB; Temporal test server for workflows |
| **Contract** | `services/<svc>/tests/contract/` or shared package tests | pytest / schemathesis | Yes | Against `docs/05` schemas |
| **Browser E2E** | `tests/e2e/<feature>/*.spec.ts` | Playwright | No* | Real local stack |
| **Live API** | `tests/api/<feature>/*.spec.ts` | Playwright `request` | No* | Real local stack |
| **Live / AI smoke** | `tests/live/*.spec.ts` | Playwright dedicated project | No* | Real agent + gateway |

\*Live suites run in pipeline stages that start the full stack (Kubernetes locally or docker-compose), not in the fast unit stage.

**Rules:**

- Unit tests sit **next to the application code**; live tests live **only** under repository-root `tests/`.
- Mock **external** systems (payment gateways, third-party APIs), not your own business services.
- Every bug fix starts with a **failing test** at the lowest layer that can express the bug.
- Never skip, delete, or weaken a test to green the build.

### 9.2 CI verification gate (how to)

Define one script (e.g. `scripts/verify.sh` or `make verify`) that **local developers and CI run identically**, stopping at the first failure:

| Step | Typical command | Purpose |
| --- | --- | --- |
| 1 | Database migrate | Schema matches code under test |
| 2 | Test seed (optional) | Deterministic fixtures for suites |
| 3 | Lint | ESLint, ruff |
| 4 | Typecheck | `tsc --noEmit`, `mypy --strict` |
| 5 | Unit + DB + architecture tests | `npm test`, per-service `pytest -q` |
| 6 | Build | Production build catches import/env errors |
| 7 | (Optional) Security scan | SCA, container scan |

Set `REQUIRE_DATABASE=1` (or equivalent) so missing PostgreSQL **fails loudly** instead of skipping DB suites. Document host choice (e.g. `127.0.0.1` vs `localhost`) if OS networking affects connection latency.

### 9.3 Live test suite layout (`tests/`)

```
tests/
├── AGENTS.md              # Live-test rules for the product (required)
├── package.json           # Playwright dependency isolated from web app
├── playwright.config.ts
├── fixtures/              # Auth, failure guard, shared helpers
├── pages/<feature>/       # Page objects (optional, no cross-feature imports)
├── e2e/<feature>/         # Browser journeys
├── api/<feature>/         # HTTP contract tests against running stack
├── live/                  # Long-running or AI smoke scenarios
├── .auth/                 # storageState — gitignored
├── reports/               # html + json — gitignored
└── test-results/          # traces — gitignored
```

**Environment variables:** `BASE_URL`, `API_URL` from env—no hard-coded hosts except `localhost` policy per org.

**Playwright config minimums:**

| Setting | Recommended | Why |
| --- | --- | --- |
| `fullyParallel` | `true` | Independent tests |
| `forbidOnly` | `true` | `test.only` hides failures |
| `failOnFlakyTests` | `true` | Retry is for diagnostics, not pass |
| `retries` | CI: 2, local: 0 | |
| `reporter` | list + html + json | Agents read JSON, not interactive HTML |
| `trace` / `screenshot` / `video` | retain on failure | Evidence |
| `webServer` | Start stack + health URL | Reuse local stack when not CI |

### 9.4 Browser matrix and run modes

Define Playwright **projects** for each supported browser, viewport, and locale (especially **RTL** if applicable). Example matrix:

| Project | Engine | Viewport / notes |
| --- | --- | --- |
| `desktop-chromium` | Chromium | Desktop |
| `desktop-firefox` | Firefox | Full gate only |
| `desktop-webkit` | WebKit | Full gate only |
| `mobile-chromium` | Chromium | Phone profile |
| `tablet-*` | WebKit | Portrait / landscape |
| `rtl-desktop`, `rtl-mobile` | Chromium | RTL locale + `dir=rtl` assertions |
| `api` | — | Single project for `tests/api/` |
| `setup` | — | Writes `.auth/` storage per role/locale |
| `live` | — | Agent/workflow smoke |

**Run modes** (npm scripts `test:fast`, `test:normal`, `test:full`):

| Mode | Projects | When |
| --- | --- | --- |
| **fast** | Desktop Chromium only | Feature development |
| **normal** | All Chromium (+ RTL if supported) | Default iteration |
| **full** | Entire matrix | Release gate, baseline evidence |

Release and baseline runs always use **full**. Reports must state the mode and must not claim coverage outside it.

One spec file serves all viewport projects—branch on `isMobile` / `hasTouch` instead of duplicating files or using `test.skip` per project.

### 9.5 Failure guard (browser tests)

Attach a shared **failure-guard** fixture to every E2E test. The run fails if any of the following occur unless explicitly declared:

| Signal | Treatment |
| --- | --- |
| Browser `console.error`, uncaught `pageerror` | Fail |
| `requestfailed` or HTTP ≥400 | Fail unless `expectFailure({ status, reason: 'STORY-id' })` |
| Response body violates `docs/05` contract | Fail |
| Accessibility violations (axe, WCAG level per product) | Fail |
| Horizontal overflow or clipped primary control | Fail |
| RTL project but page not `dir=rtl` | Fail |

API tests assert status codes directly; browser-only checks do not apply.

**Also fails the gate:** flaky pass-on-retry, any `test.skip` / `test.fixme`, zero tests matched, running release gate in non-`full` mode.

### 9.6 Coverage matrix (`docs/09-testing/`)

Maintain `coverage-matrix.md` mapping requirements to tests. Every row needs at least one test whose **title contains the story ID** (e.g. `[STORY-123]`).

| Dimension | Minimum coverage |
| --- | --- |
| Stories | Positive, negative, boundary per acceptance criterion |
| Routes / screens | Every route from router inventory |
| API endpoints | 200/201, 400, 401, 403, 404, 409, 422 as applicable |
| UI states | Loading, empty, error, success (intercept only when backend cannot produce state) |
| Authorisation | Each role × protected route; cross-tenant denial |
| Forms | Valid, empty, invalid, boundary; errors match Problem Details |
| Locales | Main journeys per language + RTL |
| Navigation | No dead links |

A matrix row without a test is a **coverage gap**—treat as a failed gate, not a footnote.

Optional **traceability test** parses requirement IDs from `docs/02` and test titles; fails on orphan IDs in either direction.

### 9.7 Writing good tests

| Topic | Standard |
| --- | --- |
| **Naming** | `should_<behaviour>_when_<condition> [STORY-id]` |
| **Locators** | `getByRole`, `getByLabel`, `getByText`, then `getByTestId`—not CSS/XPath |
| **Assertions** | User-visible outcomes and API effects; web-first `expect` |
| **Waiting** | Wait for response, URL, or locator—no fixed sleeps |
| **Data** | Create via API with unique ids; delete in teardown; parallel-safe |
| **Auth** | `setup` project → `storageState`; one file per role |
| **Page objects** | Actions and locators only—not assertions |
| **Permissions** | Include a valid **foreign** identity when testing denials |

### 9.8 Run and investigate loop (live tests)

1. Start stack until `/health/ready` (or documented ready probe).
2. Run `npm run test:<mode>` from `tests/`.
3. Read `reports/results.json`—do not trust truncated console output.
4. Classify each failure: **app defect** (fix product), **test defect** (fix test without weakening), **environment** (fix setup; record blocker).
5. Rerun failed specs, then the same scope; green = 0 failed, 0 flaky, 0 skipped in mode projects.
6. Do not modify application behaviour to hide a failing test.

For **AI/workflow** failures: run a **smoke test** that completes one minimal agent run first. If smoke fails, treat downstream run-dependent failures as platform/worker defects, not missing test data.

### 9.9 Live test reporting

For each full live run, add a dated report `docs/09-testing/YYYY-MM-DD-live-test-report.md` (immutable afterward). Include:

- Coverage summary vs matrix (gaps listed)
- Run mode and projects executed
- Pass/fail/flaky/skipped counts (skipped must be 0)
- Defects with reproduction and trace paths
- Recommendations for runtime and coverage

### 9.10 Python / workflow testing notes

| Area | Approach |
| --- | --- |
| Handlers / validators | pytest unit tests, no I/O |
| Repositories | pytest against PostgreSQL test container |
| Temporal workflows | Temporal Python test environment or time-skipping test server |
| Activities | Mock external calls; assert idempotency |
| Agent missions | Golden tests on tool selection where deterministic; integration for full loop |

Run `ruff`, `mypy --strict`, and `pytest` in the same gate as the web app.

### 9.11 Product testing checklist

- [ ] `tests/AGENTS.md` documents failure guard, matrix, and modes
- [ ] `docs/09-testing/coverage-matrix.md` linked to `docs/02`
- [ ] CI runs verify script; live stage runs Playwright `full` on release branch
- [ ] Architecture and traceability tests enforce layering and req IDs
- [ ] Contract tests validate `docs/05` samples
- [ ] Developer guide lists all commands (`verify`, `test:e2e`, `test:live`)

---

## 10. Environments and DevOps

| Environment | Purpose | Parity rule |
| --- | --- | --- |
| Local | Developer laptop / kind cluster | Same charts as test; lighter resources |
| Test | Integration and QA | Production-like network policies |
| Staging | Pre-prod validation | Optional prod-anonymized data |
| Production | Live traffic | HA, backups, alerting |

**Pipeline expectations:** lint → unit test → build images → deploy to test → live/E2E gate → promote with rollback documented in `10-devops-and-deployment/`.

Configuration: environment variables and sealed secrets; **no** environment-specific code branches.

---

## 11. Integration standards

| Integration | Pattern |
| --- | --- |
| Identity | OIDC authorization code; session or token per client type |
| External REST | Egress proxy + credential vault; timeouts and retries with idempotency keys |
| MCP connectors | Isolated runtime; stdio or remote MCP over TLS; no flat network |
| Webhooks inbound | Signature verification, replay protection, rate limits |
| Model providers | OpenAI-compatible API via gateway only |

Document each external system in `05-api-and-integrations/` with data flow, classification, and owner.

---

## 12. Decision process (ADRs)

When a team chooses a library, pattern, or boundary change:

1. Copy ADR template from `04-decisions/0000-adr-template.md`.
2. Record **context**, **options**, **decision**, **consequences**, **status**.
3. Link from tech stack and solution design.
4. Never edit accepted ADRs—supersede with a new number.

Stack-level decisions (database, gateway, workflow engine) should be **organizationally aligned** before individual products fork.

---

## 13. Product onboarding checklist

Use this when starting or auditing a product:

- [ ] `03-architecture/overview.md` — context and container diagram for *this* product
- [ ] `03-architecture/tech-stack.md` — pinned versions and lock-file evidence
- [ ] `03-architecture/solution-design.md` — request path, agent path, unique flows
- [ ] `04-decisions/` — ADRs for every non-default choice
- [ ] `05-api-and-integrations/` — contracts and external systems
- [ ] `06-data/` — ERD, dictionary, retention
- [ ] `08-security/` — threat model and permission matrix
- [ ] `09-testing/` — coverage matrix, NFR measurement plan, live-test reports
- [ ] `tests/AGENTS.md` — live suite layout, failure guard, browser matrix
- [ ] `10-devops-and-deployment/` — environments, rollback
- [ ] `12-user-and-developer-guides/` — build, lint, test commands

---

## 14. Glossary (architecture)

| Term | Meaning |
| --- | --- |
| **BFF** | Backend-for-frontend: web app aggregates APIs for the browser |
| **Tool server** | MCP or internal HTTP surface where agents invoke governed capabilities |
| **Run token** | Short-lived credential scoped to one workflow run and tool grant |
| **Route alias** | Gateway name mapping to provider + model + policy |
| **Index store** | Vector or graph data rebuildable from authoritative sources |
| **Vertical slice** | Feature folder owning UI through persistence |

---

## 15. Document maintenance

| Trigger | Action |
| --- | --- |
| Org changes baseline stack | Bump this guide’s version; notify product teams |
| Product adopts new component | Update product docs + ADR; no need to change this guide unless policy changes |
| Principle exception | ADR in product repo; optional summary in org architecture council minutes |

**Status:** `draft` until enterprise architecture review marks `approved`.
