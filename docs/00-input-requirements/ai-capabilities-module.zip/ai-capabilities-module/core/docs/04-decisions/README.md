# 04 — Decisions

> ADRs and technical decisions. Copy `0000-adr-template.md` for each new ADR.
> The index below is the decision register; list unresolved conflicts between decisions under it.
> Owner: Tech lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Decision registers](decision-registers.md) | draft | 1.0 | 2026-10-30 |
| [Platform architecture decisions (AD-01 … AD-20)](platform-decisions.md) | draft | 1.0 | 2026-10-30 |
| [Stack decisions (SD-1 … SD-13)](stack-decisions.md) | draft | 1.0 | 2026-10-30 |
| [Code-structure decisions](code-structure-decisions.md) | draft | 1.0 | 2026-10-30 |
| [Agent runtime decision register](harness-decisions.md) | draft | 1.0 | 2026-10-30 |

## How decisions are kept

Existing decisions are kept as registers, one table per subject and one row per decision, amended rather
than superseded file by file. [decision-registers.md](decision-registers.md) says which register holds which
kind of decision. New decisions that are not an amendment of a register row are written as ADRs from
`0000-adr-template.md`, numbered `0001`, `0002`, … in the order of their dates.

## Open items

- No decision has been split out into an individual ADR yet. The registers were moved whole; splitting them is
  a decision for the owner, because it is a large change that adds no information.
- Unresolved conflicts between decisions: none recorded in the source registers; the conflicts between the
  handoff documents are in [open-questions.md](../02-product-requirements/open-questions.md).

- [ADR-0001: Live test tooling, Playwright in tests/](0001-live-test-tooling.md) (proposed, 2026-10-31)
- [ADR-0002: Read legacy Excel (.xls) attachments with xlrd](0002-read-legacy-excel-with-xlrd.md) (accepted, 2026-11-02)
- [ADR-0003: Deploy TAWP to Railway beside the kind cluster](0003-railway-deployment.md) (accepted, 2026-11-07)
