# Stack decisions (SD-1 … SD-13)

| Item | Value |
| --- | --- |
| Purpose | The register of technology-stack decisions: the options, the recommendation, and what the code has settled |
| Audience | Architects, developers, the owner |
| Related | [Decision registers](README.md) · [Tech stack](../tech-stack.md) · [Open questions](../../specs/open-questions.md) · [Platform decisions](platform.md) |
| Last verified against code | 2026-10-29 |

The Decision, Options and Recommendation columns are the stack specification's §16 text (archived at
[`_reference/Tahseel_AWP_Stack_Specification.md`](../../_reference/Tahseel_AWP_Stack_Specification.md)).
The Status column is the code's current state together with what
[open-questions.md §3](../../specs/open-questions.md) records. Questions that still need the owner
are listed in open-questions.md, which links here for the options.

## Register

| # | Decision | Options | Recommendation | Status |
| --- | --- | --- | --- | --- |
| SD-1 | PostgreSQL data access | Drizzle · Prisma · Kysely | Drizzle | **Settled**: Drizzle ORM 0.45.4 with `pg` 8.17.0 (`apps/web/package-lock.json`). |
| SD-2 | PostgreSQL version | 17 · 18 | 18, after compatibility checks with Temporal, Phoenix and pgvector | **Settled**: 18 (`ghcr.io/cloudnative-pg/postgresql:18.6`; `postgres:18` in CI and `make dev-local`). |
| SD-3 | Secrets encryption key | App KEK · organisation KMS/Vault | Organisation KMS where available | **Open.** Application-level envelope encryption with `APP_KEK` is implemented (`apps/web/src/lib/crypto.ts`). A KMS needs the organisation's key service. |
| SD-4 | Document parser | docling · unstructured | docling, after verifying Arabic output | **Open pending evidence**: docling 2.137.0 is installed in the agent image (`--extra parsers`, `services/agent/Dockerfile`); its Arabic output has not been verified. |
| SD-5 | Teams integration | In Next.js · separate bot service | In Next.js | **Settled**: in Next.js (`apps/web/src/features/engage/`). A room mirrors to a Teams conversation and back through the same channel inbound and outbound path the other live channels use. |
| SD-6 | Allowed model providers and regions | Organisation policy | Decide before the first Live install | **Open** for Test and Live. Locally `OPENROUTER_API_KEY` is used; OpenRouter is on the egress allow-list only in `infra/charts/values/values-local.yaml`. |
| SD-7 | agentgateway feature coverage | Open-source only · vendor edition | Verify failover priority groups, budgets, voice/realtime and structured-output passthrough | **Open.** Affects FR-072 (voice and typesafe routes). Evidence so far: open-questions.md U-5. |
| SD-8 | Passage retrieval | pgvector · Graphiti episode search only | pgvector (maps the Knowledge screen's index settings per collection) | **Settled**: pgvector, table `passage` in `awp_kb` (`services/agent/src/awp_agent/ingestion/vectors.py`). |
| SD-9 | Graphiti graph backend | Neo4j · FalkorDB | Neo4j | **Settled**: Neo4j 5.26 Community, `graphiti-core` 0.30.2. |
| SD-10 | CopilotKit API surface | v2 entry points only | v2 entry points (`/v2` imports) | **Settled**: `@copilotkit/runtime/v2` in `apps/web/src/agents/runtime.ts`. |
| SD-11 | Phoenix trace retention | 30 · 60 · 90 days | 60 days; datasets, experiments and prompts are kept | **Implemented at the recommendation, not confirmed by the owner**: `traceRetentionDays: 60` (`infra/platform/values/phoenix.yaml`), passed to Phoenix as `PHOENIX_TRACE_RETENTION_DAYS`. |
| SD-12 | Phoenix licence | Elastic License 2.0 (to confirm) | Confirm acceptable for internal self-hosting | **Open.** A licence question; see [versions.lock.md](../../../versions.lock.md#licence-sign-off). |
| SD-13 | Pydantic AI Harness capabilities | Not used · adopt selected (e.g. code mode on Monty for light calculations instead of a sandbox pod) | Not used in v1 of AWP; evaluate code mode and context management per capability | **Changed by D83–D96**: `pydantic-ai-harness` 0.57.0 is a dependency. The generic runtime composes the harness's compaction (`ClearToolResults`, `SummarizingCompaction`) beside Pydantic AI's own `ToolSearch` (D137) and reads granted skills with `Skills(...).load()` (D127); `SubAgents` is not composed (D142); spend and guardrail modules exist but are not on the mission path (see [agent-runtime-spec conflicts](../../agent-runtime-spec.md#-unresolved-conflicts-with-the-code)). |

## Open decisions carried from the product specification

Specification §11.2 listed seven open decisions. Four are SD-1, SD-2, SD-3 and SD-6 above. The other
three:

| # | Decision | Status |
| --- | --- | --- |
| SPEC-11.2-a | One long-lived Temporal workflow per discussion room, or one short workflow per turn | **Settled, by what is built**: one per turn. Each message a run answers opens a fresh `ai.run` row and a fresh `run-{run_id}` workflow; nothing keeps a room's workflow alive between turns. This keeps a run's budget, cost and cancellation (`UC-52.1-05`) per turn. |
| SPEC-11.2-b | The sandbox technology for skill scripts | **Settled by D209**: one Pod per run in `awp-sandbox`, created by `services/sandbox`, from the image `awp/sandbox-workspace` (Python 3.12 and Node 24). The Pod has no service-account token and reaches the network only through the egress proxy. A `gvisor` RuntimeClass (`infra/policies/runtimeclass.yaml`) is used when `SANDBOX_RUNTIME_CLASS` is set. |
| SPEC-11.2-c | The order in which the Coming soon channels are released | **Open.** Out of scope for this delivery. |

## Deviations from the stack specification

| # | Deviation | Reason | Status |
| --- | --- | --- | --- |
| D-1 | The stack specification §4.2 names **next-intl** for localisation. The application uses its own `translate(lang)` helper (`apps/web/src/i18n/index.ts`), applied across every screen and enforced by tests. | Replacing it would touch every component for no behaviour the screens need. | Recommendation recorded in open-questions.md: accept. No owner decision recorded. |
| D-2 | The local cluster runs a development object store (MinIO) in place of Rook Ceph, selected by `NO_ROOK=1`. | A kind node on Windows or macOS has no raw block device. Both speak the S3 API, so no code differs. | Accepted. Rook is used where a Linux host with a loop device is available. |
| D-3 | The stack specification lists React Hook Form, TanStack Query, Recharts, React Flow, MDXEditor, `@date-fns/tz`, Testing Library, pnpm, Prettier and oxlint. None but React Flow, which draws the request type workflow view (D317), is in `apps/web/package.json` or its lock file; the repository uses npm. | The screens and tests are built without them; component interaction tests use `happy-dom` with `react-dom/client` (R13, D198). | Recorded. See [tech-stack.md](../tech-stack.md#named-in-the-stack-specification-but-not-used). |
