# Code-structure decisions

| Item | Value |
| --- | --- |
| Purpose | The code layout and testing conventions in force (R01 … R17) |
| Audience | Developers |
| Related | [Decision registers](README.md) · [Development conventions](../../08-development/conventions.md) |
| Last verified against code | 2026-10-29 |

Agent-runtime decisions are in [docs/harness-decisions.md](../../harness-decisions.md); this file
cites them by ID where they constrain the layout. IDs missing from the sequence are retired and are
not reused.

## R01 Feature layout

- **Decision:** every feature is `apps/web/src/features/<feature>/` with `actions.ts`,
  `service.ts`, `repository.ts`, `schema.ts`, `types.ts` and `components/`. A Python service is
  `services/<service>/src/awp_<service>/`.
- **Why:** `tests/architecture.test.ts` asserts these six entries in every feature, that only
  `features/<feature>/repository.ts` imports the database client, and that only a feature's own
  service or actions call its repository. The Python package paths are contracts:
  `awp_agent.main:app` (Dockerfile), `awp_agent.wait_for` (Helm init containers) and the
  `awp-agent-worker` entry point (`pyproject.toml`).

## R02 One agent definition

- **Decision:** the single `awp-mission` agent in `services/agent/src/awp_agent/mission/runtime.py` runs
  every agent. There is no file per agent.
- **Why:** D64 and D87: one runtime for every agent; agents differ only by configuration.

## R03 One repository file per feature

- **Decision:** `features/<feature>/repository.ts` is not split, whatever its length. Pure helpers
  that do not touch the database client may live elsewhere.
- **Why:** the architecture test allows the database client only in a file named exactly
  `features/<feature>/repository.ts`, and `@/features/<feature>/repository` as the only repository
  import.

## R04 Service splits are named `<topic>-service.ts`

- **Decision:** a feature service that outgrows the size limit is split by responsibility into
  `features/<feature>/<topic>-service.ts` files beside `service.ts` (for example
  `features/agents/run-service.ts`).
- **Why:** the architecture test lets a file ending in `service.ts` call its feature's repository.

## R05 No `server-only` guard

- **Decision:** server modules do not import `server-only`.
- **Why:** the package is not installed. Next.js aliases it only inside its own bundler, so `tsc`
  and Vitest cannot resolve it. The architecture test enforces the boundary that matters in
  practice: no server action in a client module.

## R08 Harness modules outside the mission path

- **Decision:** `harness/activities/{model_step,tool_call,compact,delegation}.py`,
  `harness/context/`, `harness/tools/pool.py`, `harness/hooks/base.py` and `harness/storyline/`
  are deleted under D96, with their tests (`test_tool_call.py`, `test_context_engine.py`,
  `test_storyline.py` and the parts of `test_contracts.py` that cover them).
- **Status:** done. The functions they left without a caller are listed in conflict 7 of
  [agent-runtime-spec.md](../../agent-runtime-spec.md#-unresolved-conflicts-with-the-code).

## R12 A split service keeps `service.ts` as its public module

- **Decision:** when `features/<feature>/service.ts` is split, the moved functions live in
  `<topic>-service.ts` files and `service.ts` re-exports them. Shared refusal classes live in
  `errors.ts`, so no topic module imports `service.ts`.
- **Why:** callers reach a service as `import * as service from "./service"` and check
  `error instanceof service.AgentRejected`, and tests load it with
  `await import("@/features/<feature>/service")`. The no-barrel rule applies to client bundles;
  these are server modules.

## R13 How screens are tested

- **Decision:** a screen has a `react-dom/server` first-render test with fixed props in
  `tests/<feature>-render.test.tsx`, with the server actions it imports stubbed by `vi.mock`.
  Behaviour that needs a re-render or a click is tested in `happy-dom`, switched on per file
  (`// @vitest-environment happy-dom`), rendering with `react-dom/client` and `act` through
  `tests/dom.tsx` (D198). The suite's default environment is `node`. Testing Library is not used.
- **Why:** a server action is a network call from the client, so stubbing it mocks a boundary,
  not the code under test. A per-file DOM keeps every other suite on `node`.

## R14 Client code imports UI primitives from their own files

- **Decision:** there is no `src/components/ui/index.ts`. Each primitive is imported from the file
  that defines it (`@/components/ui/button`, `@/components/ui/tabs`, ...). `src/ds/index.ts` and
  `src/i18n/index.ts` hold code, not re-exports, and stay.
- **Why:** barrel files are not used in client code, and every importer of a UI primitive is a
  client component.

## R15 Files allowed above 250 lines

- **Decision:** the 250-line guideline does not apply to:
  - a feature's `repository.ts` (R03);
  - a server-action module (`actions.ts`), because a server action's module path is part of its
    identity;
  - a file that is one component or function of 200 lines or more plus small helpers;
  - `services/agent/src/awp_agent/mission/runtime.py`, the one agent and the workflow that runs it (D87);
  - `services/agent/src/awp_agent/harness/types.py`, the wire contract with the web app (D97).
- **Why:** splitting these would mean separating functions that call each other or rewriting a
  long component body, which changes React's component boundaries and can reset state.

## R16 Route handlers are tested as shipped

- **Decision:**
  - Every route handler is called directly from Vitest with a real `Request`.
  - `vitest.config.ts` inlines `next-auth` (`server.deps.inline`). Auth.js imports
    `next/server` without a file extension, which Node's ESM resolver refuses; inlining lets Vite
    resolve it, so the Auth.js route loads unmocked.
  - `tests/db/harness.ts` provides `restoreColumns`, which puts a row's columns back exactly after
    a suite changes it.
- **Why:** mocking `@/lib/auth` in the route tests would mock the code under test of the auth
  route. The inline setting changes only how the test runner loads one package. Every other suite
  mocks `@/lib/auth`.

## R17 The agent service is grouped by responsibility

- **Decision:** `services/agent/src/awp_agent/` keeps only its entry points and cross-cutting
  modules at the top (`main.py`, `worker.py`, `wait_for.py`, `config.py`, `logging.py`,
  `tracing.py`, `classify.py`). The mission runtime is `mission/` (`runtime.py` and its deps,
  tools, sandbox, skills, approvals, questions, delegation, stream and timeline), the clients of
  other services are `clients/` (`platform_mcp.py`, `gateway_client.py`, `object_store.py`,
  `events.py`), and the Temporal codec and payload storage are `temporal/`. `tests/` has one
  folder per package.
- **Why:** the top of the package held 24 modules, ten of them the mission under a `runtime_`
  prefix. Temporal names workflows and activities by class and function, not by module, so moving
  a module changes no workflow or activity name and a mission in flight replays unchanged; the
  three entry points of R01 stay where they are.

