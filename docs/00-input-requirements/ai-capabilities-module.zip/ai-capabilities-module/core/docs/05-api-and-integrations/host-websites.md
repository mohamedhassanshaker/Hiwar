# Host websites (embedded widget and intake form)

| Item | Value |
| --- | --- |
| Purpose | The contract with external websites that embed the platform: the embedded-deployment widget and a request type's intake form, their scripts, endpoints, origin rules and refusals |
| Audience | Developers, integrators, operators |
| Related | [External systems](README.md) · [Embedded widget specification](embedded-widget-spec.md) · [Engage module](../05-modules/engage.md) · [Requests module](../05-modules/requests.md) · [Flow F-05](../specs/flows.md#f-05-embedded-widget-with-a-strict-storyline-and-handoff) · [Security](../03-architecture/security.md) |
| Last verified against code | 2026-10-29 |

## What it is

Two public surfaces let a page on another site talk to the platform without a console session. Each
is a script the site loads; neither script carries a credential, and the platform decides what a
visitor may do. The intake form's script calls its endpoint from the host page; the widget's script
opens a frame served by the platform, which calls the session API itself.

| Surface | Script | Endpoint | Configured on |
| --- | --- | --- | --- |
| Embedded-deployment widget | `GET /embed/v1/widget.js` | `GET /embed/v1/config/<deployment>`, the frame `/embed/v1/frame/<deployment>`, and `/embed/v1/sessions/…` called from the frame | [Embedded Deployment](../05-modules/engage.md) ("Copy embed code") |
| Request intake form | `GET /api/request-widget/<request type>/embed.js` | `GET, OPTIONS, POST /api/request-widget/<request type>` | [Request type](../05-modules/requests.md), "Embed on a website" on the General tab, which is the intake channel `Widget` (D306) |

## Embedded-deployment widget

The widget follows the [embedded widget specification](embedded-widget-spec.md) (D231). The host page
loads one script and the conversation runs in a frame the platform serves, so the host page holds no
token and sees no transcript.

```html
<script
  src="https://<console host>/embed/v1/widget.js"
  data-deployment="<deployment code>"
  data-lang="auto"
  data-position="bottom-right"
  defer></script>
```

| Attribute | Values |
| --- | --- |
| `data-deployment` | The deployment's code (required) |
| `data-lang` | `auto` (the page's `<html lang>`, then the browser), `en`, `ar` |
| `data-position` | `bottom-right`, `bottom-left`; flipped in Arabic |
| `data-open` | `true` opens the panel on load |
| `data-context` | JSON, `{"page": "…"}`: the quick actions offered on that page come first, and one limited to other pages is left out |

The loader (`app/embed/v1/widget.js/route.ts`) is served on each request with the platform's own
`APP_URL` as its origin (D272). It asks `GET /embed/v1/config/<deployment>?host=<page origin>`
first; a page opened as a file, or in a sandboxed frame, is named `null`, the origin browsers send
for it (D273). A deployment that is not Enabled, the Embedded deployments feature flag being off,
or a page origin the deployment does not list, answers 403 (`DEPLOYMENT_DISABLED`,
`ORIGIN_NOT_ALLOWED`) and the loader draws nothing. Otherwise it draws the launcher and an `iframe`
of `/embed/v1/frame/<deployment>?lang=…&host=…&page=…`. The loader and the frame talk only through
`postMessage`, checked by origin on both sides. Expand in the frame makes the loader size the frame
to the whole page and hide the launcher until Restore, Minimise or Escape (D340). The page drives
the widget through `window.AnyPlatformAssistant`:

| Call | Effect |
| --- | --- |
| `open()`, `close()` | Opens or closes the panel |
| `startAction(id)` | Opens the panel and starts the quick action with that id, or the storyline with that code |
| `setLanguage("en" \| "ar")` | Switches the widget's language |
| `on(name, handler)` | Calls `handler` on `open`, `close` and `conversation:end` |

The frame's response carries `frame-ancestors` built per request from the deployment's allowed
origins and the console's own origin (`frameAncestorsFor` in `proxy.ts`); a deployment that lists
`null` gets `frame-ancestors * file:`, so every page, a page opened as a file included, may frame it
(D220, D278).

### Session API

The frame calls these on the platform's own origin, so no cross-origin call is allowed or needed. Every
call but the first presents the session token as `Authorization: Bearer` (the stream takes it as
`?token=`), and every answer that returns the session carries a fresh token. The token is HS256 under a
key derived from `AUTH_SECRET`, lasts 30 minutes, and names the conversation, the deployment, the
visitor key, the language, the page and whether it is a console preview
(`features/engage/widget-session.ts`).

| Method and path | Body | Answer |
| --- | --- | --- |
| `POST /embed/v1/sessions` | `deployment`, `lang`, `context.page`, `host`, `visitorKey`, `preview` | 201, the session: `sessionId`, `sessionToken`, `identityLevel`, `config`, `messages`, `state` |
| `GET /embed/v1/sessions/{id}` | — | The session as it stands |
| `DELETE /embed/v1/sessions/{id}` | — | 204; the conversation ends as Abandoned |
| `POST /embed/v1/sessions/{id}/messages` | `text` (≤ 4000), `clientMessageId` (a repeated id is taken once) | The session |
| `POST /embed/v1/sessions/{id}/actions` | An action: `postback`, `start_scenario`, `field_submit`, `edit_field`, `confirm`, `cancel`, `handoff`, `load_more`, `restart`, `back`, `main_menu`, `show_example`, each but `restart` with the `step` it belongs to | The session |
| `GET /embed/v1/sessions/{id}/stream` | — | Server-sent events: `message.start`, `message.delta`, `message.end`, `typing`, `handoff.update`, `session.update`, `error` |
| `POST /embed/v1/sessions/{id}/files` | `name`, `dataUrl` | 201, `fileId` and the session |
| `POST /embed/v1/sessions/{id}/otp/send` | — | The session with a new code sent |
| `POST /embed/v1/sessions/{id}/otp/verify` | `code` (6 digits) | The session, `identityLevel` `otp_verified` |
| `POST /embed/v1/sessions/{id}/resume` | `choice`: `continue`, `start_over` | The session |
| `POST /embed/v1/sessions/{id}/feedback` | `messageId` and `value` (`up`, `down`), or `rating` (1–5) | The session |
| `POST /embed/v1/sessions/{id}/events` | `name` (`widget.opened`, `widget.closed`, `widget.minimized`, `widget.language`), `props` | 204 |
| `POST /embed/v1/sessions/{id}/language` | `lang` | The session in that language |

| Rule | Result |
| --- | --- |
| A session starts only while the Embedded deployments feature flag is on, for an Enabled deployment published on the Widget surface, for a `host` the deployment allows | 403 `DEPLOYMENT_DISABLED` or `ORIGIN_NOT_ALLOWED` |
| `preview: true` needs a console session with `channels:write`; it skips the origin and surface checks and shows the one-time code | 403 `ORIGIN_NOT_ALLOWED` without it |
| A missing, expired or foreign token, a conversation that is not the visitor's, or one that no longer exists | 401, 403 or 404 `SESSION_EXPIRED` |
| A quick action whose storyline is not published | 404 `NOT_FOUND` |
| The deployment's per-visitor rate limit, per minute | 429 `RATE_LIMITED`, `retryAfter` 60 |
| An action for a step the conversation has left | 409 `STALE_ACTION` |
| A field, file or feedback value the server refuses | 400 `VALIDATION_FAILED` with the reason |
| A wrong, expired or exhausted one-time code | `OTP_INVALID`, `OTP_EXPIRED`, `OTP_LOCKED` |
| A quick action that needs a verified visitor, or a Signed JWT deployment that refuses visitors without a token | 403 `IDENTITY_REQUIRED` |
| A body that cannot be read, or a `handoff` action on a deployment with no handoff queue (D340) | 400 `BAD_REQUEST` |
| Any other failure | 503 `TOOL_UNAVAILABLE`, "The assistant is not responding. Please try again." (logged) |

Every refusal is `{ "error": { "code", "message", "messageAr", "retryAfter" } }`, with a
`retry-after` header when `retryAfter` is set (`features/engage/widget-http.ts`). The
`embedded-deployments` feature flag hides the console's deployment list and turns every widget off:
with it off, `GET /embed/v1/config/<deployment>` and a new session answer `DEPLOYMENT_DISABLED`. One
deployment is taken off the web by setting it Disabled or removing its Widget surface.

## Request intake form

The form is open to any origin by design (`access-control-allow-origin: *`): it shows only a
published request type's name and field labels and accepts a submission
(`app/api/request-widget/[requestTypeCode]/route.ts`).

| Call | Purpose |
| --- | --- |
| `GET` | The form's fields: `{ code, nameEn, nameAr, fields: [{ key, labelEn, labelAr, dataType, required, enumValues }] }`, a list attribute's choices as `{ value, labelEn, labelAr }` (D304). 404 unless the type's published version lists `Widget` intake and names a project. |
| `POST` | `{ name, email, summary, attributes }`. A name, a valid email and a summary are required, else 400; they are trimmed and cut to 120, 200 and 2000 characters, and each attribute key and value to 60 and 2000. The request is raised from an external contact keyed by the email, and the attributes are validated by the requests service (`UC-30.1-04`). Answers `{ key }`; a refusal is 400 `{ reason }`, any other failure 503. |

## Known gaps

| Gap | Evidence |
| --- | --- |
| The stack specification describes the widget as a CopilotKit `CopilotPopup` inside a web component using the CopilotKit runtime with a deployment token. The code serves its own loader and frame over the `/embed/v1` session API of the widget specification (D231). | `app/embed/v1/`; [stack decisions](../03-architecture/decisions/stack.md) |
| A refused origin is not written to the server log (`UC-65.1-10`); the loader writes a console warning and the browser refuses to frame the widget. | `app/embed/v1/config/[code]/route.ts`; `logRefusal` in `features/engage/widget-session.ts` |
| A host cannot pass a signed visitor token to the widget, so a Signed JWT deployment treats every widget visitor as unidentified (anonymous, or refused, per its fallback). | `startSession` in `features/engage/widget-session.ts` |
| The intake form endpoint applies no rate limit; neither the route nor the intake service has one. | `app/api/request-widget/[requestTypeCode]/route.ts`; `features/requests/intake-service.ts` |
