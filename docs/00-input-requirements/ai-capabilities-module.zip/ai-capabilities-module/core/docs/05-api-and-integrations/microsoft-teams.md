# Microsoft Teams

| Item | Value |
| --- | --- |
| Purpose | How the platform exchanges messages with Microsoft Teams: the shared channel-gateway contract, room mirroring, and what is unproven |
| Audience | Developers, integrators, operators |
| Related | [External systems](README.md) · [WhatsApp](whatsapp.md) · [Discussion rooms](../05-modules/discussion-rooms.md) · [Engage module: channels](../05-modules/engage.md) · [Data dictionary: engage](../04-data-model/data-dictionary/engage.md) |
| Last verified against code | 2026-10-29 |

## What it is

Microsoft Teams is a live channel (`MicrosoftTeams` in `LIVE_CHANNEL_TYPES`). It is handled by the
same channel gateway as WhatsApp, inside the Next.js app; there is no separate bot service (SD-5,
settled — see [stack decisions](../03-architecture/decisions/stack.md)). A Teams channel can be
bound to an embedded deployment, to request intake, or to discussion rooms for mirroring.

## Contract

Teams uses exactly the inbound and outbound contract described for WhatsApp: the same webhook
(`POST /api/channels/MicrosoftTeams/inbound`), the same `x-awp-signature` HMAC over the raw body,
the same `{ from, name, text, conversation }` body and answer, the same decision order and the same
outbound `{ to, text }` POST to the configured endpoint URL. See
[WhatsApp: inbound](whatsapp.md#inbound) and [WhatsApp: outbound](whatsapp.md#outbound); only the
differences are written here.

The gateway does not speak the Bot Framework or Microsoft Graph protocols. A relay that turns
Teams activities into the platform's shape, and the platform's outbound POST into Teams messages,
is required and is not in this repository (TODO: needs input — which relay or bot registration
carries Teams traffic in Test and Live).

For request intake, the request type must take `Teams` intake (the gateway maps `MicrosoftTeams` to
the surface `Teams`, `SURFACE` in `features/engage/gateway.ts`).

## Room mirroring

Mirroring links one discussion room to one conversation on the channel, both ways
(SC-ROOM-06, SC-CH-02, `UC-23.1-13`).

```mermaid
sequenceDiagram
  participant T as Teams (through a relay)
  participant G as Channel gateway (web)
  participant R as Discussion room
  Note over G,R: Requires the flag mirror-rooms-to-microsoft-teams and a channel bound to RoomMirror
  T->>G: POST /api/channels/MicrosoftTeams/inbound {from, text, conversation}
  G->>G: verify signature, decide (enabled, sender, rate limit, hours)
  G->>R: post as the person (matched by email) or as an external contact
  R-->>G: a reply is posted in the room
  G->>T: POST endpointUrl {to: conversation, text: "author: reply"}
```

| Rule | Source |
| --- | --- |
| A room is linked with `mirrorRoom` (server action), which needs `rooms:moderate` in the room's project, the flag `mirror-rooms-to-microsoft-teams` (seeded on), and the channel bound to `RoomMirror`. The link is audited. | `mirrorRoom` in `features/engage/service.ts` |
| An inbound message must name the provider conversation (`conversation`); a message with none, or for a conversation no room mirrors, is not routed. | `roomBinding` in `features/engage/gateway.ts` |
| A reply posted in a mirrored room is sent out as `"<author>: <text>"` through the egress proxy (D234). Sending never fails the room: a refusal or timeout (5 s) is logged as a warning. | `mirrorOutbound` in `features/engage/gateway.ts` |

## Not proven

Teams end to end has not been exercised: no real channel credentials exist
([open questions U-4](../specs/open-questions.md#5-unmeasured-claims)).

## Known gaps

| Gap | Evidence |
| --- | --- |
| The Teams app and tenant IDs from the handoff design are not configurable; the channel holds only an endpoint URL, a secret and an inbound secret. | `configureChannelInput` in `features/engage/schema.ts`; handoff v2 §10 |
| The UTC business-hours, email-only sender matching and unproxied Test channel gaps of [WhatsApp](whatsapp.md#known-gaps) apply here too. | `handleInbound` in `features/engage/gateway.ts`; `features/engage/channel-test.ts` |
