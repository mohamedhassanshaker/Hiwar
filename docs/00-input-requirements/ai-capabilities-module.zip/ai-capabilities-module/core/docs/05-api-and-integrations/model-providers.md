# Model providers

| Item | Value |
| --- | --- |
| Purpose | How agents reach external model providers (OpenRouter, Anthropic, OpenAI, Azure OpenAI, Gemini, on-prem engines): protocol, credentials, fallbacks, identifying headers and failure handling |
| Audience | Developers, architects, operators |
| Related | [External systems](README.md) · [AI platform: agentgateway](../03-architecture/ai-platform.md) · [Models and routes module](../05-modules/models-and-routes.md) · [Configuration](../07-operations/configuration.md) · [Agent runtime conflicts](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code) |
| Last verified against code | 2026-10-29 |

## What it is

Every model and embedding call leaves the platform through **agentgateway**, which speaks the
OpenAI-compatible API to the agent service and the provider's own API to the provider. No
application code holds a provider SDK or a provider key: the agent service uses Pydantic AI's
`OpenAIProvider` and the `openai` client against the gateway, and the gateway holds the
credentials (AD-11 in [platform decisions](../03-architecture/decisions/platform.md)).

```mermaid
flowchart LR
  A[agent service: MissionWorkflow, ingestion, Graphiti] -->|OpenAI-compatible /v1, Bearer run token| G[agentgateway LLM listener :8080]
  G -->|alias = route, failover by priority| P1[Primary provider step]
  G -.->|on failure| P2[Fallback step]
  G --> L[local engine services/modelstub, kind only]
  W[web: Models screen] -->|renders AgentgatewayModel resources| G
```

## Protocol and endpoints

| Item | Value | Source |
| --- | --- | --- |
| Caller protocol | OpenAI Chat Completions and Embeddings, base URL `AGW_LLM_URL` + `/v1` | `services/agent/src/awp_agent/clients/gateway_client.py` (`openai_base_url`) |
| Model name sent | The route alias from Models & routes (e.g. `reasoning-default`); the gateway maps it to a chain of concrete models | `clients/gateway_client.py` (`model_for_route`); `mission/runtime.py` (`_model_for`) |
| Caller credential | `Authorization: Bearer <run token>` (the mission's model token in the generic runtime; `AWP_RUN_TOKEN` or `anonymous` elsewhere) | `mission/runtime.py` (`_model_for`); `clients/gateway_client.py` (`_api_key`) |
| Provider credential | Set by the gateway as `Authorization: Bearer …` from the connection's own Secret, `awp-ai/provider-conn-<connection id>`, key `credential`, only for connections whose auth type travels in a header (`ApiKey`, `BearerToken`, `OAuth`); `IamRole`, `EntraId` and `None` carry no header | `apps/web/src/agentgateway/render.ts` (`carriesHeaderCredential`, `renderStep`); `agentgateway/secrets.ts` |
| Provider-specific blocks | `Custom` (OpenAI-compatible engines: completions and embeddings, at the connection's base URL, which ends in `/v1`, as the engine presets do (D337)), `Azure` (resource name from the endpoint host), `Bedrock` (region), `VertexAI` (project id) | `render.ts` (`providerBlock`); `features/models/types.ts` |
| Decision routes | A route of kind Decision renders each step as a `Custom` provider at the connection's origin whose Completions format is sent to the provider's decisions path. The caller posts the decisions request, with the empty `messages` the gateway's parser requires, to the alias at `/v1/chat/completions` (`gateway_client.decide`). Used by the `agent-choice` route, on which a discussion room chooses its answering agent (D290) | `render.ts` (`decisionBlock`); `services/agent/src/awp_agent/classify.py` |
| Fallback | Each alias renders as an `AgentgatewayModel` with `virtualModel.failover.targets`, priority 0 for the primary and one higher per fallback. Steps are `Internal`, so a caller cannot skip the chain by naming a step. A step whose provider or connection is switched off is left out of the chain | `render.ts` (`renderStep`, `renderAlias`); `features/models/repository.ts` (`readRouteForGateway`) |
| Rendering | The web app applies the resources through the Kubernetes API with a narrow service account, and republishes all routes at start-up | `apps/web/src/instrumentation.ts`; `apps/web/src/features/models/service.ts` |

## Providers and keys

The gateway reads a provider credential only from the Secret of the connection it belongs to.
A credential entered on a connection on the Models screen is stored encrypted with `APP_KEK` and
written to `awp-ai/provider-conn-<connection id>` (key `credential`), which the connection's
rendered steps reference; it is never returned by an API
([Models and routes](../05-modules/models-and-routes.md)). The seed stores no connection
credential, so a seeded connection reaches its provider only after a credential is entered on it.

| Provider | Environment variable | Where it goes |
| --- | --- | --- |
| Anthropic | `ANTHROPIC_API_KEY` | Secret `awp-ai/agentgateway-providers` |
| OpenAI | `OPENAI_API_KEY` | same |
| OpenRouter | `OPENROUTER_API_KEY` | same |
| Azure OpenAI | `AZURE_API_KEY`, `AZURE_API_BASE` | same |
| Gemini | `GEMINI_API_KEY` | not written to a Secret |

Source: `scripts/secrets-from-env.sh`; `scripts/seed.sh`; `apps/web/src/db/seed/models.ts`. No
rendered resource references `agentgateway-providers`: `scripts/seed.sh` reads the four keys back
from it, and the seed uses them only to order each route chain by what the installation can reach.
Steps whose provider key is present lead, the local engine follows, and the rest stay last. A
provider with no key answers 401, which agentgateway correctly does not treat as a reason to fail
over, so a chain led by one would fail end to end (`orderedChain` in `seed/models.ts`).

## Identifying the caller

| Field | Specified | In the running code |
| --- | --- | --- |
| `user` (OpenAI body field) | The real platform person, never the agent ([D45](../harness-decisions.md)) | Set only by `gateway_client.call_settings`, which nothing calls. The generic runtime's model (`_model_for` in `mission/runtime.py`) sets no `user`. |
| `x-awp-mission-id`, `x-awp-run-id`, `x-awp-person-id`, `x-awp-parent-run-id` headers | On every model call ([D75](../harness-decisions.md)) | Same: defined in `clients/gateway_client.py` (`call_settings`) and sent by nothing. Missions on the generic runtime send none of them. |

This is conflict 4 in [the agent runtime specification](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code).
Whether OpenRouter groups requests by the header is unverified ([D75](../harness-decisions.md)).

## Network path

agentgateway's pods may reach any address (`infra/policies/network-policies.yaml`,
`agentgateway-egress`: `0.0.0.0/0`), so providers are reached directly. The squid **egress proxy**
allow-list (`.tahseel.ae`, `.anthropic.com`, `.openai.com` in `infra/charts/awp/values.yaml`,
`egressProxy.allowedDomains`) applies to application workloads that use `EGRESS_PROXY_URL`: the
Models screen's connection test (`apps/web/src/lib/model-probe.ts`), voice input's transcription call
(`apps/web/src/lib/transcription.ts`, D386: agentgateway has no transcription format, so the first
Transcription model on an active OpenAI-compatible connection with a header credential is called at
its `/audio/transcriptions`), the web app's other outbound
calls (`lib/egress.ts`), the connector runtime and sandboxes. The test calls the provider directly,
not through the gateway, and stores each model's result on the connection (D196). In Test and Live,
a "Test connection" to OpenRouter from the Models screen is therefore refused by the proxy unless
the domain is added, while agent calls through the gateway still work. The local kind values set
`egressProxy.allowAll`, so there every destination passes (D297).

## Error handling

| Situation | What happens |
| --- | --- |
| A provider step fails | agentgateway tries the next target by priority. A 401 from a missing key does not fail over. |
| A provider is switched off on the Models screen | Its steps are skipped and the fallbacks are used (SC-MDL-03). |
| A typesafe route returns output that does not validate | Pydantic AI asks the same route again, twice (`classify.py`); after that the agent service answers 503 and the console offers the template form (`UC-28.2-06`). Invalid output is not a reason for the gateway to fail over, so the fallback steps are not tried for it. With only `OPENROUTER_API_KEY`, the `classifier-typed` chain lands on a free model (D245) that does not reliably produce structured output. Agentic request entry is hidden behind its feature flag, off in the seed (D310). See [open questions U-5](../specs/open-questions.md#5-unmeasured-claims). |
| The gateway is unreachable | The model call fails inside the mission's durable activity, which Temporal tries 4 times, each bounded at 10 minutes (D137); the System screen probes `/v1/models` and shows `agentgateway` down (`apps/web/src/lib/health.ts`). |
| No provider key at all | The platform installs and runs, but no run reaches a real model. In kind, the deterministic local engine (`services/modelstub`, enabled in `values-local.yaml`) answers instead. |

## Open decisions

Allowed providers and regions (SD-6) and which agentgateway features are open source (SD-7) are in
[stack decisions](../03-architecture/decisions/stack.md).
