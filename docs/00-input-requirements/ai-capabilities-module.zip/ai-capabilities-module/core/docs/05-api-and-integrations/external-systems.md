# External systems

| Item | Value |
| --- | --- |
| Purpose | Index of the systems outside the platform that it exchanges data with, the protocol of each, and which side starts the exchange |
| Audience | Developers, architects, integrators, operators |
| Related | [Architecture overview](../03-architecture/overview.md) · [AI platform](../03-architecture/ai-platform.md) · [Security](../03-architecture/security.md) · [Integration clients module](../05-modules/integrations.md) · [Configuration](../07-operations/configuration.md) |
| Last verified against code | 2026-10-29 |

The platform's own components — PostgreSQL, Temporal, Valkey, Neo4j, Phoenix, object storage,
agentgateway, the connector runtime and the sandbox manager — are internal and are described in
[the architecture documents](../03-architecture/overview.md). This folder covers what lies outside
the installation.

| System | What for | Protocol | Direction | Status | Document |
| --- | --- | --- | --- | --- | --- |
| Model providers (OpenRouter, Anthropic, OpenAI, Azure OpenAI, Gemini, on-prem engines) | Every model and embedding call | OpenAI-compatible API to agentgateway; the gateway speaks each provider's API | Platform → provider | In use; OpenRouter verified with a real key | [model-providers.md](model-providers.md) |
| External MCP servers and REST APIs | Tools agents and storylines call | MCP (Streamable HTTP, stdio through a bridge pod) through the connector runtime; HTTP for OpenAPI operations from the web app; both through the egress proxy (D234, D297) | Platform → system | MCP and OpenAPI connector tools reachable from storylines and, through the platform MCP server, from agent missions (D223) | [mcp-connectors.md](mcp-connectors.md) |
| WhatsApp | A live messaging channel | Platform-defined JSON webhook with an HMAC signature, through a relay | Both | Built; unproven without credentials | [whatsapp.md](whatsapp.md) |
| Microsoft Teams | A live channel and room mirroring | Same contract as WhatsApp | Both | Built; unproven without credentials | [microsoft-teams.md](microsoft-teams.md) |
| Organisation identity provider | Single sign-on | OIDC (authorization code with PKCE) through Auth.js | Platform ↔ provider | In use against a mock provider locally | [identity-provider.md](identity-provider.md) |
| Mail server | System notifications, invitations and the agent's `email_create` | SMTP through nodemailer, not through the egress proxy | Platform → server | Built; a Mailpit sink in kind (`infra/kind/mailpit.yaml`) (D240, D242, D248) | [Governance module: Settings](../05-modules/governance.md#settings-s-75) |
| Host websites | The embedded widget and request intake forms | Widget: a loader script and a frame served by the platform, framable only by allowed origins, with the `/embed/v1` session API (D231, [embedded-widget-spec.md](embedded-widget-spec.md)). Request intake: a generated script plus a JSON endpoint, CORS | Visitor's browser → platform | In use | [host-websites.md](host-websites.md) |
| Integration clients (CRM and other systems) | External systems calling the platform | MCP over `POST /api/mcp`; AG-UI over SSE | Client → platform | In use | [Integration clients module](../05-modules/integrations.md) |

Not present in the code: SMS sending, LiveKit or voice providers, and any second identity
server. The Coming soon channels (Slack, Email, SMS, Voice/IVR, Telegram, Webex, Google Chat,
Instagram, Facebook Messenger) have no integration code; an inbound message for one is dropped
(`apps/web/src/features/engage/inbound.ts`).
