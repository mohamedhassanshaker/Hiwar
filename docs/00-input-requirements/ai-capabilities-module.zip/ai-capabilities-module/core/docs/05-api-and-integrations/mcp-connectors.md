# External MCP servers (connectors)

| Item | Value |
| --- | --- |
| Purpose | How the platform connects to external systems through connectors: transports, credentials, tool tiers, the connector runtime, and which callers can reach a connector tool today |
| Audience | Developers, architects, operators, integrators |
| Related | [External systems](README.md) · [Connectors module](../05-modules/connectors.md) · [Connector runtime README](../../services/connectors/README.md) · [AI platform](../03-architecture/ai-platform.md) · [Security](../03-architecture/security.md) · [Data dictionary: connectors](../04-data-model/data-dictionary/connectors.md) |
| Last verified against code | 2026-10-29 |

## What it is

A connector is an MCP server (or an OpenAPI description) that gives agents controlled access to an
external system. Each connector sets the tier of every tool it exposes. The screens and tiers are
in the [Connectors module](../05-modules/connectors.md); this page covers the connection itself.
A connector has no list of allowed agents: a run reaches every enabled connector, narrowed by its
project's allowed connectors, and is offered the tools its agent version grants (D227). The
built-in Platform connector (`platform`, `internal://platform`) is the platform's own tool
catalogue, served by the platform MCP server itself; it has no stored tool rows, so no call to it
goes to the connector runtime (D228). An agent granted the connector tools of the catalogue can
create, import, edit and test connectors; no tool takes a credential, which a person enters in the
console (D277).

## Transports

| Transport | How it is reached | Source |
| --- | --- | --- |
| `StreamableHttp` | A remote MCP server at the configured URL, called by the connector runtime with the MCP Python SDK's Streamable HTTP client | `apps/web/src/db/schema/enums.ts` (`CONNECTOR_TRANSPORTS`); `services/connectors/src/awp_connectors/runtime.py` |
| `Stdio` | A local MCP server (usually an `npx` package). The connector runtime in **control** mode creates one Deployment and Service per stdio connector, running the same image in **bridge** mode, which runs that one server and exposes it over Streamable HTTP | [services/connectors/README.md](../../services/connectors/README.md); `pods.py` |
| `OpenApi` | An HTTP API described by OpenAPI (a REST API connector). Each operation becomes a tool named `<connector>/<operation>`, served by the platform MCP server rather than the connector runtime, because the credential is stored against the connector row in the web app; such a connector is never sent to the runtime. Test connection makes one authorised GET of its server URL through the egress proxy and records Connected or Error; Refresh tools is not offered for it and the server refuses it (D268) | `callConnectorOperation` in `apps/web/src/mcp/server.ts`; `apps/web/src/features/connectors/openapi-call.ts` (`probeServer`) |

Auth types are `OAuth` (authorization code, MCP servers only), `ClientCredentials`, `Bearer`,
`ApiKey`, `Basic` and `None` (`CONNECTOR_AUTH_TYPES`, migration 0064, D296).

## Connector runtime API

The web app talks to `services/connectors` at `CONNECTOR_RUNTIME_URL`
(`apps/web/src/lib/connector-runtime.ts`).

| Call | Purpose | Timeout |
| --- | --- | --- |
| `PUT /connectors` `{ "connectors": [...] }` | Replace the whole connector set: every enabled MCP connector, never an `OpenApi` one or the Platform connector. The runtime stops sessions of changed connectors, removes workloads of removed ones and creates new ones; a `failed` map in the answer is reported as an error. This is what "saving a connector takes effect without a restart" means (S-54). Each HTTP connector carries `headers` and `query` for its credential and `needs_credential` (D296). | 20 s |
| `GET /mcp/<code>/tools` | The MCP handshake: list the tools with their `readOnlyHint` and `destructiveHint` annotations and the `inputSchema` the server declares (`UC-54.1-02`, D223). A failure means the connector can be added only as Disabled (`UC-54.1-05`). 409 when the connector needs a credential the runtime does not hold. | 20 s |
| `POST /mcp/<code>` `{ "name", "arguments" }` | Call one tool. Answers `{ content, structured, raw }`; 400 with the server's text when the tool reports an error, 502 when the server cannot be reached, 409 as above. | 30 s |
| `GET /connectors` | The configured set, with environment values redacted | — |

## Credentials

A connector's credential is stored encrypted by the console (envelope encryption with
`APP_KEK`) as one typed object, and is never returned by an API (D296). For a remote MCP server the
web app turns it into request headers (`apps/web/src/features/connectors/credential-auth.ts`),
getting and refreshing OAuth tokens with the MCP SDK's `auth()`, and sends them with
`PUT /connectors`. The runtime holds them in memory only: they are excluded from the ConfigMap it
keeps for a restart and from a bridge's spec, never logged (`httpx` and `httpcore` log at WARNING,
and a connection error is redacted), and never returned. After a restart it answers 409 for a
connector that needs them, and the web app sends the set again and retries (`viaRuntime`); it also
sends it again before a token lapses. A stdio server's secrets are a Kubernetes Secret mounted as
files under `CONNECTOR_SECRETS_PATH` (one file per key) and put in the server process's
environment; `/connectors` shows which variables are set, never their values
([services/connectors/README.md](../../services/connectors/README.md)). Outbound traffic from the
runtime and bridge pods (the runtime's remote MCP sessions by `HTTP_PROXY`/`HTTPS_PROXY`, with the
cluster's own Services and the Kubernetes API in `NO_PROXY`, D297), and the web app's calls to an
OpenAPI connector's API, a token endpoint or an authorization server (`egressFetch`,
`apps/web/src/lib/egress.ts`), go through the egress proxy and its domain allow-list
(`EGRESS_PROXY_URL`, `egressProxy.allowedDomains`): an API whose host is not on the list cannot be
reached from the cluster (D234). The local kind values set `egressProxy.allowAll`, so there any
destination passes: an external host, an address on the network, or this machine, which
`scripts/cluster-host-access.sh` makes resolvable as `host.docker.internal` and by its own name
(D222, D297).

## Tiers

Tiers default from MCP annotations: read-only tools to T0 and destructive tools to T2; a tool
with neither gets the connector's default tier (`tierForTool`). An administrator adjusts them per
tool; a project policy can raise a tier but never lower it
(Spec §7.4.5, `UC-54.1-03`, `UC-21.2-04`). The rules are in the
[Connectors module](../05-modules/connectors.md).

## Who can call a connector tool today

| Caller | Path | Status |
| --- | --- | --- |
| A storyline **Tool** step | `features/engage/conversation-effects.ts`: an `OpenApi` connector's operation is issued in the web app with the stored credential (`callOperation`); any other goes through `callConnectorTool` to the connector runtime `POST /mcp/<id>`. Publishing the storyline checks each Tool step against the tools its agent's active version grants (`toolsAllowedTo`, D227) | Implemented. The step runs the call itself, which keeps a Strict storyline deterministic (D231). |
| An agent mission, `OpenApi` connector | Platform MCP server, listed to the model as `<connector>__<operation>` and read back as `<connector>/<operation>`, agent callers only, checked against the run's grant; a T2 operation needs a bound approval of the exact call (D171, D223) | Implemented. |
| An agent mission, `StreamableHttp` or `Stdio` connector | Platform MCP server: `tools/list` names the granted tools `<connector>__<tool>` with the schemas the server declares (read from the connector runtime), and `tools/call` checks the grant and the T2 backstop, then forwards to the connector runtime `POST /mcp/<code>` and audits the call (`apps/web/src/mcp/server.ts`, D223) | Implemented. |
| agentgateway as MCP gateway | Listener `AGW_MCP_BASE_URL` (:8081) is provisioned in every environment; the agent service and the web app declare the variable but no code uses it, and nothing renders an MCP route to it | Target design, not implemented ([stack decisions](../03-architecture/decisions/stack.md)). |

## Error handling

| Situation | Result |
| --- | --- |
| An OpenAPI connector that is disabled, has no server URL, or lacks the operation | The call is refused with a sentence the model can repeat, e.g. "`<connector>` is disabled." (`resolveOperation` in `features/connectors/openapi-call.ts`; `UC-54.2-02`, SC-CON-02). |
| An MCP connector that is disabled | An agent's call is refused with "`<connector>` is disabled." and its tools are not listed (D223). Disabling updates the row (`setEnabled` in `features/connectors/repository.ts`) but does not push a new set to the runtime; the set, which holds enabled connectors only, is pushed when a connector is tested, saved or connected with OAuth, and by a web process before its first runtime call (`pushToRuntime`, `viaRuntime` in `discovery-service.ts`). A storyline Tool step does not check the flag for an MCP connector: its call reaches the runtime, which serves the connector until the next push. |
| `CONNECTOR_RUNTIME_URL` not set | Every connector call throws "no connector can be reached". |
| The runtime cannot create a stdio connector's workload | `PUT /connectors` answers with `failed`, and the save reports it instead of showing the connector Connected. |
| A tool call fails | The runtime's error text (first 200 characters) or its status is raised to the caller. |
