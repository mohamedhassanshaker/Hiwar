# WhatsApp

| Item | Value |
| --- | --- |
| Purpose | The contract between the platform's channel gateway and WhatsApp: inbound webhook, signature, outbound messages, what a message turns into, error handling, and what is unproven |
| Audience | Developers, integrators, operators |
| Related | [External systems](README.md) · [Microsoft Teams](microsoft-teams.md) · [Engage module: channels](../05-modules/engage.md) · [Flow F-05](../specs/flows.md#f-05-embedded-widget-with-a-strict-storyline-and-handoff) · [Data dictionary: engage](../04-data-model/data-dictionary/engage.md) |
| Last verified against code | 2026-10-29 |

## What it is

WhatsApp is one of the three live channels (Web widget, WhatsApp, Microsoft Teams;
`LIVE_CHANNEL_TYPES`). An administrator enables it on the Channels screen, enters its credentials,
and binds it to one of: an **embedded deployment** (the deployment's storyline answers), **request
intake** (a message becomes a request), or **discussion rooms** (mirror). The screens are in the
[Engage module](../05-modules/engage.md).

The gateway does not speak the WhatsApp Business (Cloud) API itself. Both directions use one
platform-defined JSON shape, the same for every channel, so a relay that translates between the
provider's API and this shape sits between them. No such relay is part of this repository
(TODO: needs input — which relay or provider adapter carries WhatsApp traffic in Test and Live).

## Inbound

| Item | Value |
| --- | --- |
| Endpoint | `POST /api/channels/WhatsApp/inbound` (`apps/web/src/app/api/channels/[channelType]/inbound/route.ts`) |
| Reachability check | `GET` on the same URL answers `{ channel, enabled }`, or 404 for an unknown channel. It carries no configuration. |
| Signature | Header `x-awp-signature: sha256=<hex>` (prefix optional): HMAC-SHA256 of the raw body with the channel's **inbound secret**, compared in constant time (`signatureMatches` in `features/engage/gateway.ts`) |
| Body | `{ "from": "<sender key>", "name": "<display name>", "text": "<message>", "conversation": "<provider conversation id>" }`; `from` and `text` are required |
| Answer | `{ "action": "Process" \| "Offline" \| "Throttled" \| "Dropped", "detail": "…", "replies": [{ "en": "…", "ar": "…" }] }` — the replies are what the relay should send back to the sender |

| Refusal | Status |
| --- | --- |
| No such channel | 404 |
| The channel has no inbound secret configured (a channel without one accepts nothing) | 401 |
| Signature missing or wrong (logged as a warning) | 401 |
| Body not JSON, or no `from` or `text` | 400 |

### What happens to a message

Each message gets one decision, in this order (`features/engage/inbound.ts`):

1. A channel type that is not live is dropped (Coming soon).
2. A disabled channel drops the message.
3. An unknown sender is dropped when the channel's policy is Ignore; otherwise the sender becomes an
   external contact.
4. More messages from the sender in the last minute than the channel's rate limit: answered with a
   notice and not handled (Throttled).
5. With business hours set to the working calendar, a holiday, a non-working day or a time outside
   working hours answers with the channel's offline message, and the message is still taken in
   (Offline).
6. Otherwise it is processed by the binding:
   - **Embedded deployment** — a deployment conversation is opened for the sender and the storyline
     takes the turn; the newest assistant messages after the sender's, up to three, are returned as
     replies in the widget's text form, with chips and lists numbered (`degrade`, widget
     specification 13.4). Out of hours the message is taken in and the storyline runs later.
   - **Request intake** — exactly one published request type must take `WhatsApp` intake; the
     message becomes a request from the external contact, titled with its first 120 characters, and
     the reply is "Your request is `<key>`." With none or several matching types, the message is not
     routed.
   - **Room mirror** — see [Microsoft Teams](microsoft-teams.md#room-mirroring).

Every inbound message, handled or not, is recorded with its action and reason
(`UC-61.1-08`; `repository.recordChannelMessage`).

## Outbound

The platform sends to the channel's configured **endpoint URL** with `POST`, body
`{ "to": "<address>", "text": "<message>" }` and `Authorization: Bearer <channel secret>` when one
is stored, timeout 5 seconds. Three paths use it. The one-time code and the room mirror go through
the egress proxy (`egressFetch`, D234), so the endpoint's host has to be on its allow-list; the
Test channel check calls the endpoint directly:

| Path | Source |
| --- | --- |
| A storyline Verify step delivering a one-time code ("Your one-time code is 123456.") to the conversation's phone, email or mobile slot | `deliverOtp` in `features/engage/conversation-effects.ts` |
| A reply posted in a mirrored room | `mirrorOutbound` in `features/engage/gateway.ts` |
| The Test channel screen's "Outbound message delivered" check | `features/engage/channel-test.ts` |

Storyline replies to an inbound message travel back in the inbound HTTP answer, not through the
endpoint URL.

## Credentials

The channel secret and the inbound secret are entered on the Channels screen, stored encrypted with
`APP_KEK`, and never read back (`configureChannelInput` in `features/engage/schema.ts`). No agent tool takes them (D277, D294).

## Error handling

| Situation | Result |
| --- | --- |
| Outbound endpoint refuses or times out | One-time code: the conversation is marked undeliverable; room mirror: logged as a warning, the room keeps working; test: the check fails with the status or "No answer within 5000 ms". |
| The request cannot be raised from an intake message | Logged as an error; the sender gets no reply. |
| The deployment the channel is bound to no longer exists | Recorded as the reason; no reply. |

## Not proven

WhatsApp end to end has not been exercised: no real channel credentials exist in any environment
([open questions U-4](../specs/open-questions.md#5-unmeasured-claims)). The gateway is tested
against a local provider only.

## Known gaps

| Gap | Evidence |
| --- | --- |
| The business-hours decision uses the UTC weekday and time, while its own comment says the organisation's time zone. A UAE installation (UTC+4) is judged four hours early. | `handleInbound` in `features/engage/gateway.ts`; `inbound.ts` `InboundConditions` |
| A known sender is matched by email only (`personByEmail(senderKey)`), so a WhatsApp phone number never matches a person and is always an external contact. | `handleInbound` in `features/engage/gateway.ts` |
| The Test channel screen's outbound check calls the endpoint with `fetch`, not through the egress proxy, so in a cluster whose default-deny policy leaves the proxy as the web pod's only way out, the check fails for an endpoint the one-time code and the room mirror can reach. | `runChannelChecks` in `features/engage/channel-test.ts` |
| The WhatsApp phone and business IDs from the handoff design are not configurable. | handoff v2 §10 |
