# 05 — API & Integrations

> API contracts and integration specs.
> Owner: Backend lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [External systems](external-systems.md) | draft | 1.0 | 2026-10-30 |
| [Identity provider (OIDC single sign-on)](identity-provider.md) | draft | 1.0 | 2026-10-30 |
| [Model providers](model-providers.md) | draft | 1.0 | 2026-10-30 |
| [External MCP servers (connectors)](mcp-connectors.md) | draft | 1.0 | 2026-10-30 |
| [Microsoft Teams](microsoft-teams.md) | draft | 1.0 | 2026-10-30 |
| [WhatsApp](whatsapp.md) | draft | 1.0 | 2026-10-30 |
| [Host websites (embedded widget and intake form)](host-websites.md) | draft | 1.0 | 2026-10-30 |
| [Any Platform Assistant: Embedded Widget Specification](embedded-widget-spec.md) | draft | 1.0 | 2026-10-30 |

[external-systems.md](external-systems.md) is the entry point: it lists every external system and points to its
document. The platform's own HTTP routes, and the agent service's `/agui/runs…`, `/healthz` and
`/documents/extr…` endpoints, have no contract document yet; see

The agent service's `GET /healthz/workers` (internal, called by the web app's `/api/health`) answers
`{"queues": {"agent-runs": {"pollers": n}, "ingestion": {"pollers": n}, "maintenance": {"pollers": n}}}`
from Temporal's task-queue description, or 503 when Temporal is not connected. For the rest
[solution-design.md](../03-architecture/solution-design.md) for what exists.
