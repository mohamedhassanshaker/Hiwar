# Any Platform Assistant: Embedded Widget Specification

| Item | Value |
|---|---|
| Document | Embedded chat widget and conversation scenarios |
| Platform | Juman Platform, AI Capabilities, Embedded Deployment |
| Deployment surface | Widget (WhatsApp and Teams reuse the same message protocol, see section 13) |
| Version | 0.1 (draft for review) |
| Status | Draft. Business rules marked **[Confirm]** must be validated with the owning entity before build |

---

## Table of contents

1. Purpose and scope
2. Architecture
3. Embedding and configuration
4. Widget anatomy (what the user sees)
5. Widget states and behaviour
6. Message protocol (what the backend sends, what the widget renders)
7. Conversation modes: Guided, Strict
8. Quick actions (entry buttons) configuration
9. Scenario specifications (one per quick action)
10. Flow engine rules (interruptions, validation, resume)
11. Identity, OTP step-up and security
12. Human handoff
13. Voice, language, accessibility and other surfaces
14. API contract
15. Audit and analytics events
16. Error and empty states
17. Acceptance criteria
18. Open questions

---

## 1. Purpose and scope

The widget is a floating chat assistant that can be embedded in any website or platform. The assistant name, welcome message and quick actions come from the deployment, so the same widget serves any host. It greets the visitor, offers quick-action buttons, and runs long service scenarios such as paying a bill or filing a complaint, one step at a time.

**In scope**
- Rendering the widget exactly like the reference screen (launcher, panel, header, disclaimer, message list, quick-action chips, composer with a mic when Voice input is on).
- A message protocol rich enough for long scenarios: lists, cards, field prompts, OTP, summaries, receipts, status timelines and handoff.
- Two conversation modes (Guided, Strict), mixable within one scenario.
- Full specification of the five quick actions in the reference screen.
- Mapping every widget behaviour to the existing Embedded Deployment settings.

**Out of scope**
- The internal design of each entity's back-end service (for example the e& billing API or the customs system). This spec defines only the tool contracts the assistant calls.
- Payment gateway screens. The widget hands off to the existing payment page or wallet flow and receives the result.

**Guiding rule.** The language model understands and phrases. Code enforces. Anything that must never break (identity before personal data, confirmation before payment, exact amounts, required fields) is enforced by the flow engine and tools, never by prompt text alone.

---

## 2. Architecture

```mermaid
flowchart LR
  subgraph Host["Host website (allowed origin)"]
    S[Embed script loader]
    L[Launcher button]
  end
  subgraph W["Widget (sandboxed iframe)"]
    UI[Chat UI renderer]
    ST[Local session state]
  end
  subgraph J["Juman Platform"]
    G[Embed gateway<br/>origin check, rate limit, session]
    LA[Leader agent<br/>skills + knowledge]
    FE[Flow engine<br/>storylines: Guided / Strict]
    ID[Identity service<br/>OTP, UAE PASS]
    T[Tool layer<br/>scoped service account]
    H[Human handoff queue]
    A[Audit and logs]
  end
  subgraph B["Entity back-ends"]
    E1[Flight information]
    E2[e& billing]
    E3[Airport services]
    E4[Consumer protection case system]
    E5[Customs]
    P[Payment gateway / wallet]
  end
  S --> L --> UI
  UI <-->|HTTPS + SSE / WebSocket| G
  G --> LA
  LA <--> FE
  LA --> T
  FE --> T
  FE --> ID
  T --> E1 & E2 & E3 & E4 & E5 & P
  LA --> H
  G --> A
  FE --> A
  T --> A
```

**Component responsibilities**

| Component | Responsibility |
|---|---|
| Embed script loader | Injects the launcher and the iframe; passes the deployment key and page context; never holds secrets |
| Widget iframe | Renders messages and input controls; stores only the session token and UI preferences |
| Embed gateway | Validates origin against **Allowed origins**, applies **Rate limit per visitor**, creates the session at the visitor identity level set in **Visitor identity** |
| Leader agent | Detects intent, extracts values from free text, answers questions from knowledge, chooses which scenario to start |
| Flow engine | Runs storylines: holds scenario state, enforces step order in Strict phases and required checkpoints in Guided phases |
| Identity service | Sends and verifies OTP, handles UAE PASS login, raises the session level |
| Tool layer | Calls entity back-ends using the account in **Agent acts as**; every tool checks session level and tokens itself |
| Handoff queue | Receives conversations routed to people (the **Human handoff queue** setting) |

---

## 3. Embedding and configuration

### 3.1 Embed code

The **Copy embed code** button on the deployment screen produces:

```html
<script
  src="https://<juman-host>/embed/v1/widget.js"
  data-deployment="shj3"
  data-lang="auto"
  data-position="bottom-right"
  defer></script>
```

| Attribute | Required | Values | Notes |
|---|---|---|---|
| `data-deployment` | Yes | Deployment code (for example `shj3`) | Public identifier, not a secret |
| `data-lang` | No | `auto`, `en`, `ar` | `auto` follows the host page `<html lang>` |
| `data-position` | No | `bottom-right`, `bottom-left` | Flips automatically in RTL |
| `data-open` | No | `true`, `false` | Open the panel on load (default `false`) |
| `data-context` | No | JSON string | Page context, for example `{"page":"customs"}`, used to rank quick actions |

### 3.2 JavaScript API (optional)

```js
window.AnyPlatformAssistant.open();
window.AnyPlatformAssistant.close();
window.AnyPlatformAssistant.startAction("pay_eand_bills");
window.AnyPlatformAssistant.setLanguage("ar");
window.AnyPlatformAssistant.on("conversation:end", (e) => { /* analytics */ });
```

### 3.3 Mapping to Embedded Deployment settings

| Deployment setting (screen) | Widget behaviour |
|---|---|
| Name (English / Arabic) | Header title per language, for example "Any Platform Assistant". Each host sets its own name |
| Default agent | The leader agent that receives every message |
| Status | `Disabled` hides the launcher and returns HTTP 403 to the widget |
| Surfaces: Widget | Enables this embed script |
| Allowed origins | Exact origins with port. `null` is for local testing only and must not be used in production |
| Visitor identity | Starting identity level. Recommended: **Anonymous, step-up with OTP** |
| Human handoff queue | Target of "Talk to a person". Must not be `None` for production. With `None`, Talk to a person is not offered and the server refuses a `handoff` action (D340) |
| Agent acts as | Service account used for anonymous answers. Must be a dedicated account with public-read and gated-tool access only. `Nobody` means anonymous visitors get no answer outside storylines |
| Rate limit per visitor | Message limit per visitor per window **[Confirm window, for example per 10 minutes]** |
| Storylines (Guided / Strict) | Define the scenarios in section 9 |
| Simulate / Publish | Every scenario must pass its simulation set (section 17) before publishing |

**New settings this spec needs on the deployment screen**

| Setting | Type | Purpose |
|---|---|---|
| Welcome message (EN / AR) | Text | Greeting bubble |
| Disclaimer text (EN / AR) | Text | Grey banner under the header |
| Disclaimer dismissible | Toggle | Show the X on the banner |
| Quick actions | Ordered list | The chips under the greeting (section 8) |
| Voice input | Toggle, on by default (D386; was off, D340) | Show the mic button |
| Read aloud | Toggle | Show the speaker icon on bot messages |
| Session idle timeout | Minutes | End or lock the session after inactivity |
| Saved progress retention | Minutes | How long a half-finished scenario can be resumed |

---

## 4. Widget anatomy

```
 ┌───────────────────────────────────────────┐
 │ ✦  Any Platform Assistant         —   ⤢  │  ← Header
 ├───────────────────────────────────────────┤
 │ I'm continuously learning and         ✕   │  ← Disclaimer banner
 │ improving, so some of my responses...     │
 ├───────────────────────────────────────────┤
 │  ┌─────────────────────────────────────┐  │
 │  │ Hello! I am Any Platform            │  │  ← Bot message bubble
 │  │ Assistant. I'm here to assist you   │  │
 │  │ with our services...                │  │
 │  │ (Flight Arrivals Today) (Pay e&...) │  │  ← Quick-action chips
 │  │ (Sharjah Airport Services)          │  │
 │  │ (Consumer Protection Complaint)     │  │
 │  │ (Sharjah Custom Services)           │  │
 │  └─────────────────────────────────────┘  │
 │  🔊 9:31 PM                               │  ← Read-aloud + timestamp
 │                                           │  ← Message list (scrolls)
 ├───────────────────────────────────────────┤
 │ Ask Any Platform Assistant           (🎤) │  ← Composer
 └───────────────────────────────────────────┘
                                         (✕)   ← Launcher (open state)
```

### 4.1 Elements

Visual appearance (colors, typography, spacing, shapes, motion and responsive sizing) comes from the Juman Platform design system and is not defined in this document.

| # | Element | Content and behaviour |
|---|---|---|
| 1 | Launcher | Floating button. Closed: assistant icon. Open: ✕. Shows an unread dot when a message arrives while closed |
| 2 | Panel | Chat container opened from the launcher |
| 3 | Header icon | Assistant icon |
| 4 | Header title | Deployment name in the current language |
| 5 | Minimize (—) | Collapses to the launcher; keeps the conversation |
| 6 | Expand (⤢) | The panel fills the host page; Restore (⤡) puts it back (D340) |
| 7 | Disclaimer banner | Notice under the header, dismissible with ✕. Dismissal is remembered for the session |
| 8 | Bot bubble | Assistant message, on the leading side (mirrored in Arabic) |
| 9 | Quick-action chips | Tappable options inside the bot message, wrapping to new lines |
| 10 | Message footer | Speaker icon (read aloud) and send time |
| 11 | User bubble | User message, on the trailing side (mirrored in Arabic) |
| 12 | Composer | Placeholder "Ask {assistant name}", taken from the deployment name; mic button on the trailing side when Voice input is on (D340); turns into a send button when text is entered |

---

## 5. Widget states and behaviour

| State | What the user sees | Trigger |
|---|---|---|
| Closed | Launcher only | Default |
| Opening | Panel opens | Launcher click, `open()` |
| Greeting | Welcome bubble with quick actions | New session |
| Idle | Composer active | After any bot reply |
| Bot typing | Typing indicator | Waiting for the first streamed token |
| Streaming | Text appears progressively | Server-sent events |
| Awaiting field | Composer replaced or constrained by a field control (section 6.3) | Flow engine asks a field in a Strict step |
| Verifying | OTP control shown; the rest of the chat is read-only | Step-up required |
| Handed off | Banner "You are now chatting with a person", agent name shown | Handoff accepted |
| Rate limited | Notice with wait time; composer disabled | Gateway returns 429 |
| Offline | Notice "Connection lost. Retrying…"; unsent messages kept | Network loss |
| Ended | "Conversation ended" with "Start a new conversation" | Idle timeout or user ends |
| Minimized | Launcher with unread dot when new messages arrive | Minimize button |

**Persistence**
- The session token and the conversation are kept in the iframe's session storage, so a page navigation on the same site restores the panel.
- A half-finished scenario is saved on the server for the **Saved progress retention** period. On return, the bot offers "Continue where you left off" or "Start over".
- Personal data shown after verification is cleared from the screen when the session ends or the verified level expires.

---

## 6. Message protocol

Every bot turn is a **message** made of ordered **blocks**, plus an optional **input** instruction that controls the composer. The widget renders blocks; it never builds business logic from text.

### 6.1 Message envelope

```json
{
  "id": "msg_01J9X…",
  "role": "assistant",
  "ts": "2026-10-23T21:31:00+04:00",
  "lang": "en",
  "blocks": [ { "type": "text", "text": "…" } ],
  "input": { "mode": "free" },
  "flow": {
    "scenario": "pay_eand_bills",
    "phase": "collect",
    "mode": "guided",
    "step": "account_number",
    "progress": { "current": 2, "total": 5 }
  },
  "speakable": "Plain text version for read aloud"
}
```

| Field | Required | Notes |
|---|---|---|
| `role` | Yes | `assistant`, `user`, `human_agent`, `system` |
| `blocks` | Yes | Rendered top to bottom inside one bubble; cards and lists may break out to full width |
| `input` | No | Default `{ "mode": "free" }` |
| `flow` | No | Present while a scenario is running; drives the "Cancel" chip. The widget draws no step counter from its `progress` (D341) |
| `speakable` | No | Used by the speaker icon; falls back to the text blocks |

### 6.2 Block types

| Type | Purpose | Key properties |
|---|---|---|
| `text` | Paragraphs | `text` (limited Markdown: bold, italic, links, bullet lists) |
| `chips` | Quick replies and quick actions | `items[]` of `{id, label, action, icon?}`; `persist` (stay clickable after the next message, default false) |
| `list` | Selectable or browsable rows | `items[]` of `{id, title, subtitle?, meta?, badge?, action?}`, `selectable: none / single / multi`, `page`, `filters[]` |
| `card` | One record | `title`, `subtitle?`, `fields[]` of `{label, value}`, `badge?`, `actions[]` |
| `carousel` | Several cards side by side | `cards[]` |
| `summary` | Review before submit or pay | `rows[]` of `{field, label, value, editable}`, `total?`, `actions[]` |
| `receipt` | Result of a payment or submission | `reference`, `status`, `amount?`, `date`, `fields[]`, `actions[]` (download, share) |
| `timeline` | Case or flight status | `events[]` of `{label, ts, state: done / current / pending}` |
| `notice` | Info, warning, error | `level`, `text`, `actions[]?` |
| `progress` | Step indicator. Not sent: the widget shows no "Step x of y" bar (D341) | `current`, `total`, `label` |
| `handoff` | Human handoff status | `state: queued / connected / ended`, `position?`, `agentName?` |
| `link_out` | Leave the widget (payment page, official form) | `label`, `url`, `opensIn: tab / overlay`, `returnsTo` |
| `attachment` | File the bot shares | `name`, `size`, `url` (short-lived) |

### 6.3 Input instructions (composer control)

| `input.mode` | Composer behaviour | Used in |
|---|---|---|
| `free` | Normal text box, and the mic when Voice input is on | Guided steps, and after a Guided script runs out |
| `field` | Shows a typed control for one field; typing free text is still allowed if `allowFreeText` is true | Guided and Strict steps |
| `locked` | Composer disabled with a reason, for example "Waiting for payment" | Payment in progress, handoff queue |

**Field control types** (`input.field.type`)

| Type | Control | Validation shown in the widget | Final validation |
|---|---|---|---|
| `text` | Single-line input with placeholder example | `pattern`, `minLength`, `maxLength` | Server |
| `textarea` | Multi-line, counter | `maxLength` | Server |
| `number` / `amount` | Numeric keyboard, currency suffix | `min`, `max`, `step` | Server |
| `phone` | Country code + number, defaults to +971 | E.164 | Server |
| `email` | Email keyboard | Format | Server |
| `date` / `time` / `datetime` | Picker | `min`, `max` | Server |
| `select` | Chips (≤ 6 options) or searchable list (> 6) | Must be an option | Server |
| `multiselect` | Checkbox list with "Done" | `minItems`, `maxItems` | Server |
| `lookup` | Text input → server lookup → confirm card | n/a | Server |
| `file` | Upload button, camera on mobile | `accept`, `maxSizeMb`, `maxFiles` | Server (virus scan) |
| `otp` | Segmented 6-digit input, resend timer | Digits only | Identity service |
| `consent` | Statement + "I agree" button, never pre-ticked | Required | Server |
| `location` | Emirate → area dependent selects | Must be options | Server |

**Example: field prompt**

```json
{
  "blocks": [
    { "type": "text", "text": "Enter your e& account number. You can find it at the top of your bill." }
  ],
  "input": {
    "mode": "field",
    "field": {
      "id": "account_number",
      "type": "text",
      "placeholder": "e.g. 1.23456789",
      "pattern": "^[0-9.]{6,20}$",
      "allowFreeText": true,
      "required": true,
      "help": "Where do I find this?",
      "mask": false
    }
  }
}
```

### 6.4 Actions (what a chip or button sends)

| `action.type` | Sent to server | Shown as user bubble |
|---|---|---|
| `postback` | `{ "type":"postback", "payload": {...} }` | The chip label |
| `start_scenario` | `{ "type":"start_scenario", "scenario":"…" }` | The chip label |
| `field_submit` | `{ "type":"field_submit", "field":"…", "value": … }` | Display value (masked if `mask`) |
| `edit_field` | `{ "type":"edit_field", "field":"…" }` | "Change {label}" |
| `confirm` | `{ "type":"confirm", "token":"…" }` | "Confirm" |
| `cancel` | `{ "type":"cancel" }` | "Cancel" |
| `handoff` | `{ "type":"handoff", "reason":"user_request" }` | "Talk to a person" |
| `open_url` | none (client only) | none |
| `load_more` | `{ "type":"load_more", "list":"…", "page": n }` | none |
| `back` | `{ "type":"back" }` | "Back" |
| `main_menu` | `{ "type":"main_menu" }` | "Main menu" |

**Rules**
- After a chip is used, the chips in that message become inactive unless `persist` is true. Quick actions in the greeting are always `persist: true`.
- Every action carries the `flow.step` it belongs to. The server rejects stale actions (for example tapping an old "Confirm") with a `notice`.

---

## 7. Conversation modes

A scenario is split into **phases**. Each phase has one mode, Guided or Strict (D339). This lets one quick action start as a menu or a list, become a guided form, and end with a strict confirm-and-pay.

| Mode | Who controls the next step | Composer | Typical use |
|---|---|---|---|
| **Guided** | The storyline suggests the next step: its choices as chips, its fields as controls. Anything else the visitor writes goes to the leader agent | Open, with field hints | Menus, browsing records, questions, most data collection |
| **Strict** | Flow engine only; fixed order; no skipping | Field control | OTP, consent, confirm, pay, submit |

### 7.1 Mode rules

**Guided**
- A step's choices are suggestions. A reply that is none of them is answered by the agent, using the knowledge and tools available to the **Agent acts as** account, and the step's choices are offered again under the answer. The agent may suggest starting a scenario.
- Results come from a tool, never from the model's memory. A Tool step's result is shown as a list, a card or a timeline; tapping a row answers the next step.
- If the user gives several values in one message, the engine takes the ones a later field recognises, validates each, confirms what it understood and asks only for what is missing. A typed field's value still has to pass its check.
- [Back] returns to the previous question and [Main menu] to the first; the answers given from there on are cleared.
- When the script runs out, the conversation stays open for the agent. If the visitor gave details that no Tool or Create work step acted on, the agent receives them and does what it can or says it cannot; its answer takes the place of the closing message.

**Strict**
- Steps run in the configured order. The widget shows the field control for the current step.
- Free text is allowed only for help questions; the answer is short and the same step is asked again.
- Leaving a Strict phase is only possible through Cancel or handoff.
- Money movement and official submissions always run in Strict.

### 7.2 Choosing a mode per phase

| If the phase… | Use |
|---|---|
| Informs, shows records from a system, or collects data where order does not matter | Guided |
| Verifies identity, takes consent, confirms, pays or submits | Strict |

---

## 8. Quick actions configuration

Quick actions are the chips under the greeting. Each one starts a scenario.

```yaml
quick_actions:
  - id: flight_arrivals_today
    label: { en: "Flight Arrivals Today", ar: "الرحلات القادمة اليوم" }
    scenario: flight_arrivals_today
    entry_mode: guided
    min_identity: anonymous
    order: 1
    show_on_pages: ["*"]
  - id: pay_eand_bills
    label: { en: "Pay e& Bills", ar: "دفع فواتير e&" }
    scenario: pay_eand_bills
    entry_mode: guided
    min_identity: anonymous        # OTP step-up happens inside the scenario
    order: 2
  - id: sharjah_airport_services
    label: { en: "Sharjah Airport Services", ar: "خدمات مطار الشارقة" }
    scenario: sharjah_airport_services
    entry_mode: guided
    min_identity: anonymous
    order: 3
  - id: consumer_protection_complaint
    label: { en: "Consumer Protection Complaint", ar: "شكوى حماية المستهلك" }
    scenario: consumer_protection_complaint
    entry_mode: guided
    min_identity: anonymous        # OTP required before submission
    order: 4
  - id: sharjah_customs_services
    label: { en: "Sharjah Custom Services", ar: "خدمات جمارك الشارقة" }
    scenario: sharjah_customs_services
    entry_mode: guided
    min_identity: anonymous
    order: 5
```

| Property | Meaning |
|---|---|
| `scenario` | Storyline or skill-led scenario id |
| `entry_mode` | Mode of the first phase (for display hints only; the scenario defines the real phases) |
| `min_identity` | Level needed to start. Most start anonymous and step up later |
| `show_on_pages` | Page context filter from `data-context` |
| `order` | Display order; page context may promote the most relevant chip to first |

**Starting a scenario by typing.** The leader agent can start the same scenario from free text ("I want to pay my etisalat bill"). It passes any values it extracted (for example the account number) as `prefill`, which the engine validates like any other answer.

### 8.1 Scenario definition schema

```yaml
scenario:
  id: string
  title: { en, ar }
  owner_entity: string               # [Confirm]
  version: semver
  phases:
    - id: string
      mode: guided | strict
      min_identity: anonymous | otp_verified | logged_in
      steps:
        - id: string
          type: ask_field | select | lookup_confirm | list_browse | verify | consent |
                confirm | pay | submit | call_tool | condition | handoff | message
          field: { id, type, label, required, validation, source, depends_on, mask }
          tool: string                # for lookup, list, call_tool, pay, submit
          on_success: step_id | phase_id | end
          on_error: { retry: n, then: step_id | handoff | end }
      exit: { required_fields: [], next: phase_id | end }
  interruptions:
    side_questions: allow | allow_brief | deny
    topic_switch: offer_save | cancel
  timeouts: { idle_minutes, resume_minutes }
  end_states: [ success, cancelled, failed, handed_off, abandoned ]
```

---

## 9. Scenario specifications

The five scenarios below are the example quick actions from the reference deployment; any host configures its own quick actions and scenarios the same way. Each one lists its phases, steps, tools, sample conversation and edge cases. Field names, formats, fees and limits are placeholders until confirmed by the owning entity **[Confirm]**.

### 9.1 Flight Arrivals Today

| Item | Value |
|---|---|
| Goal | Find today's arriving flights at Sharjah International Airport, see details, and optionally follow a flight |
| Owner | Sharjah Airport Authority **[Confirm]** |
| Phases | P1 Guided (browse and filter) → P2 Guided (questions about a flight) → P3 Guided (optional: notify me) |
| Identity | Anonymous. Notifications need a verified phone (OTP) |
| Tools | `flights.search_arrivals`, `flights.get_flight`, `notify.subscribe_flight` |
| End states | Viewed, subscribed, handed off |

**Phase P1: Guided**

| Step | Type | Bot prompt / output | Input | Rules |
|---|---|---|---|---|
| P1.1 | list_browse | "Here are today's arrivals. Filter by time, airline or origin, or type a flight number." | Filter chips: [Next 2 hours] [Morning] [Afternoon] [Evening] [Airline ▾] [Origin ▾]; free text | Default: arrivals from now until 23:59 local time, sorted by scheduled time |
| P1.2 | list (render) | Rows: flight number and airline, origin city, scheduled time, estimated time, status badge (On time, Delayed, Landed, Cancelled), terminal | Tap a row | 5 rows per page, "Show more" |
| P1.3 | lookup_confirm | When the user types a flight number: show its card directly | Flight number pattern `^[A-Z0-9]{2}[0-9]{1,4}$` | If not found today: offer "Search yesterday / tomorrow" |

**Phase P2: Guided (flight card)**

Card fields: flight, airline, origin, scheduled, estimated, actual, status, terminal, baggage belt, arrival hall **[Confirm available fields]**.
Card actions: [Notify me of changes] [Directions to arrivals] [Parking options] [Back to list].
The user can ask questions such as "Why is it delayed?" The agent answers only from the flight record and airport knowledge; it does not speculate on causes.

**Phase P3: Guided (notify me)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P3.1 | select | "How should I notify you?" | [SMS] [WhatsApp] **[Confirm channels]** | |
| P3.2 | ask_field | "Enter your mobile number." | `phone` | +971 default |
| P3.3 | verify | OTP to that number | `otp` | Confirms ownership of the number |
| P3.4 | consent | "I agree to receive status messages for this flight until it lands." | `consent` | |
| P3.5 | call_tool | `notify.subscribe_flight` | | Subscription ends automatically after landing |
| P3.6 | message | "Done. I'll message you about changes to {flight}." | | |

**Sample conversation**

> **Bot:** Here are today's arrivals from now. *(list of 5)* [Show more] [Next 2 hours] [Airline ▾]
> **User:** only from Cairo after 6pm
> **Bot:** 2 flights from Cairo after 6:00 PM. *(list of 2)*
> **User:** *(taps G9 6xx)*
> **Bot:** *(flight card, status Delayed, estimated 20:45, belt 4)* [Notify me of changes] [Parking options]
> **User:** notify me
> **Bot:** How should I notify you? [SMS] [WhatsApp]

**Edge cases**
- Flight data source unavailable: show a notice with the time of the last update, and a link to the official arrivals page.
- Status changes while the list is open: the list refreshes when the user asks again; the card shows "Updated {time}".
- Cancelled flight: show the airline contact action instead of "Notify me".

---

### 9.2 Pay e& Bills

| Item | Value |
|---|---|
| Goal | Look up and pay one or more e& bills |
| Owner | Payment channel operator; biller e& **[Confirm integration route]** |
| Phases | P1 Guided (service and account) → P2 Guided (bills found) → P3 Guided (amount) → P4 Strict (verify, confirm, pay) → P5 Guided (receipt and follow-up) |
| Identity | Anonymous to look up **[Confirm: does a balance lookup by account number need OTP?]**; OTP-verified or logged in to pay; wallet payment needs login and the 2FA threshold rule |
| Tools | `eand.lookup_account`, `eand.get_bills`, `payment.prepare`, `payment.execute`, `payment.status`, `receipt.get` |
| End states | Paid, partially paid, cancelled, payment failed, handed off |

```mermaid
stateDiagram-v2
  [*] --> SelectService
  SelectService --> EnterAccount
  EnterAccount --> ConfirmAccount: lookup found
  EnterAccount --> EnterAccount: not found (max 3)
  ConfirmAccount --> ShowBills
  ShowBills --> NoBills: nothing due
  ShowBills --> ChooseAmount: bills selected
  ChooseAmount --> StepUp: not verified
  ChooseAmount --> Summary: verified
  StepUp --> Summary: OTP ok
  StepUp --> [*]: OTP failed / cancel
  Summary --> ChooseMethod: confirm
  Summary --> ChooseAmount: edit
  ChooseMethod --> Paying
  Paying --> Receipt: success
  Paying --> PaymentFailed: failed
  PaymentFailed --> ChooseMethod: retry
  Receipt --> [*]
  NoBills --> [*]
```

**Phase P1: Guided (service and account)**

| Step | Type | Prompt | Input | Validation / source |
|---|---|---|---|---|
| P1.1 | select | "Which e& service do you want to pay?" | [Mobile postpaid] [Home internet / TV] [Landline] [Prepaid recharge] **[Confirm list]** | Options from `eand.services` |
| P1.2 | ask_field | Depends on P1.1: "Enter the mobile number" or "Enter the account number" | `phone` or `text` | Format per service **[Confirm]** |
| P1.3 | lookup_confirm | "I found account ending ••6789, holder A•••• K••••. Is this the right account?" | [Yes] [No, re-enter] | Name masked for anonymous users; 3 attempts, then suggest login or handoff |

Prepaid recharge branches to P3 with fixed denominations (no bill list).

**Phase P2: Guided (bills)**

| Step | Type | Output | Input | Rules |
|---|---|---|---|---|
| P2.1 | list (multi-select) | Each bill: period, due date, amount, status (Due, Overdue) | Checkboxes, [Select all], [Continue] | Overdue bills pre-selected **[Confirm: is oldest-first payment mandatory?]** |
| P2.2 | message | Total of the selection | | |

**Phase P3: Guided (amount)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P3.1 | select | "Pay the full amount of AED {total}, or a different amount?" | [Full amount] [Other amount] | |
| P3.2 | ask_field | "Enter the amount in AED." | `amount` | Min and max from biller rules **[Confirm partial payment allowed]** |

**Phase P4: Strict (verify, confirm, pay)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P4.1 | verify | "To pay, I need to verify you. Choose: [Send code to ••42] [Log in with UAE PASS]" | `otp` or login | Skipped if already verified. Code goes to the number registered on the account **[Confirm source of contact]** |
| P4.2 | confirm (summary) | Service, account (masked), bills, amount, service fee, total | [Confirm] [Change amount] [Cancel] | `payment.prepare` returns a confirmation token valid 10 minutes |
| P4.3 | select | "How do you want to pay?" | [Card] [Apple Pay] [Tahseel wallet] **[Confirm methods]** | Wallet needs logged-in level; wallet deductions above the threshold trigger 2FA |
| P4.4 | pay | Opens payment page in an overlay (`link_out`) | Payment page | Composer locked: "Waiting for payment" |
| P4.5 | call_tool | `payment.status` | | Poll or webhook; timeout after 15 minutes → "Payment not completed" |

**Phase P5: Guided (result)**

- Success: `receipt` block with reference, amount, date, bills paid, [Download receipt] [Email receipt] [Pay another bill].
- Failure: `notice` with the reason in plain words and [Try again] [Choose another method] [Talk to a person]. No amount is shown as paid unless `payment.status` returns success.
- After the receipt, the user can ask free questions ("When will it show on my account?"), answered from knowledge.

**Sample conversation**

> **User:** *(taps Pay e& Bills)*
> **Bot:** Which e& service do you want to pay? [Mobile postpaid] [Home internet / TV] [Landline] [Prepaid recharge]
> **User:** my home internet, account 1.23456789
> **Bot:** Got it, Home internet, account 1.23456789. Checking… I found an account ending 6789. Is this yours? [Yes] [No]
> **User:** Yes
> **Bot:** You have 2 bills: September AED 389 (overdue), October AED 389 (due 5 Nov). *(selectable list)* [Continue]
> **User:** just the overdue one
> **Bot:** AED 389 selected. To pay, I need to verify you. [Send code to ••42] [Log in with UAE PASS]
> **User:** *(enters code)*
> **Bot:** *(summary)* Total AED 389 + fee AED 3 = AED 392. [Confirm] [Change amount] [Cancel]

**Edge cases**
- User types a different account mid-flow: the bot asks "Switch to account …? Your current selection will be cleared." [Switch] [Keep current].
- Bill amount changes between lookup and payment: `payment.prepare` fails; the bot reloads bills and explains.
- Duplicate payment protection: if the same bill was paid in the last 24 hours, warn before the summary **[Confirm rule]**.
- User closes the payment overlay: return to P4.3 with "Payment not completed".

---

### 9.3 Sharjah Airport Services

| Item | Value |
|---|---|
| Goal | Explore airport services and complete simple requests (bookings, enquiries, lost items) |
| Owner | Sharjah Airport Authority and service providers **[Confirm]** |
| Phases | P1 Guided (service catalogue) → P2 Guided (service information) → P3 Guided/Strict (per-service request, see sub-flows) |
| Identity | Anonymous to browse; OTP to book or report |
| Tools | `airport.services_catalogue`, `airport.service_details`, `airport.check_availability`, `airport.create_booking`, `airport.report_lost_item`, `payment.*` |
| End states | Informed, booked, reported, handed off |

**Phase P1: Guided (catalogue)**

Categories **[Confirm catalogue]**: Parking, Lounges, Meet and assist, Baggage services, Lost and found, Transport (taxi, bus), Special assistance, Travel documents help.
Shown as a `list` with icons; free text such as "where can I park for 3 days" jumps directly to Parking with the duration prefilled.

**Phase P2: Guided (service details)**

The agent answers from the airport knowledge base: description, location, hours, prices, how to book. Every answer ends with relevant actions, for example [Book meet and assist] [Calculate parking cost].

**Phase P3 sub-flows**

*P3-A Parking cost calculator (Guided, anonymous)*

| Step | Type | Prompt | Input |
|---|---|---|---|
| A1 | select | "Which car park?" | Options from catalogue |
| A2 | ask_field | "When will you enter?" | `datetime` (not in the past) |
| A3 | ask_field | "When will you leave?" | `datetime` (after A2) |
| A4 | call_tool | `airport.parking_quote` → card with cost and directions | |

*P3-B Meet and assist booking (Guided → Strict)*

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| B1 | select | "Arrival or departure?" | [Arrival] [Departure] | |
| B2 | lookup_confirm | "Enter your flight number and date." | `text` + `date` | Validated with `flights.get_flight` |
| B3 | ask_field | "How many passengers?" | `number` 1–9 | |
| B4 | multiselect | "Any extras?" | [Porter] [Fast track] [Wheelchair] **[Confirm]** | |
| B5 | ask_field | Lead passenger name as in passport | `text` | |
| B6 | ask_field | Contact mobile | `phone` | |
| B7 | verify | OTP to contact mobile | `otp` | Strict from here |
| B8 | call_tool | `airport.check_availability` | | If unavailable: offer the nearest slot or handoff |
| B9 | confirm | Summary with price | [Confirm] [Edit] [Cancel] | |
| B10 | pay | As in 9.2 P4.3 to P4.5 | | |
| B11 | receipt | Booking reference, meeting point, what to bring | | |

*P3-C Lost and found report (Guided → Strict)*

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| C1 | select | "Where did you lose it?" | [On the plane] [In the terminal] [Car park] [Not sure] | "On the plane" → airline contact info, then end |
| C2 | ask_field | "When?" | `datetime` | Within the last 90 days **[Confirm]** |
| C3 | select | "What kind of item?" | [Bag] [Phone] [Documents] [Wallet] [Other] | |
| C4 | ask_field | "Describe it: color, brand, any marks." | `textarea` ≤ 500 | Agent may ask one follow-up for missing details |
| C5 | file | "Add a photo if you have one (optional)." | `file` image ≤ 5 MB | |
| C6 | ask_field | Contact mobile | `phone` | |
| C7 | verify | OTP | `otp` | |
| C8 | confirm | Summary | | |
| C9 | submit | `airport.report_lost_item` → reference and timeline | | |

**Edge cases**
- Flight in B2 is not on the selected date: offer the nearest matching dates.
- A passport or ID is reported lost: also show the police and embassy guidance from knowledge.

---

### 9.4 Consumer Protection Complaint

| Item | Value |
|---|---|
| Goal | File a consumer complaint against a merchant, and track existing complaints |
| Owner | Consumer Protection Department, Sharjah Economic Development Department **[Confirm]** |
| Phases | P0 Guided (choose: new complaint, track complaint, know your rights) → P1 Strict (identity) → P2 Guided (merchant) → P3 Guided (purchase and issue) → P4 Guided (evidence) → P5 Strict (review, consent, submit) → P6 Guided (reference and tracking) |
| Identity | OTP-verified at minimum before personal details are collected; logged in to see complaint history |
| Tools | `cpd.search_merchant`, `cpd.complaint_types`, `files.upload`, `cpd.submit_complaint`, `cpd.get_complaint_status` |
| End states | Submitted, tracked, informed, cancelled, saved as draft, handed off |

**Phase P0: Guided (entry)**

> **Bot:** I can help you file a complaint, check an existing one, or explain your rights as a consumer. [File a complaint] [Track my complaint] [Know my rights]

- *Know my rights* is answered by the agent in Guided mode, from the consumer protection knowledge base.
- *Track my complaint*: ask the reference number → OTP to the complainant's registered mobile → `timeline` block.

**Phase P1: Strict (identity)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P1.1 | select | "How would you like to verify?" | [Log in with UAE PASS] [Verify with mobile number] | |
| P1.2 | ask_field | "Enter your mobile number." | `phone` | Only for the OTP path |
| P1.3 | verify | OTP | `otp` | 3 attempts, 5-minute validity **[Confirm]** |
| P1.4 | ask_field | Full name, Emirates ID number (OTP path only; prefilled for UAE PASS) | `text`, `text` with EID pattern `^784-?[0-9]{4}-?[0-9]{7}-?[0-9]$` | Masked after entry |

**Phase P2: Guided (merchant)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P2.1 | lookup_confirm | "What is the shop or company name?" | `text` → `cpd.search_merchant` returns matches | Show up to 5 matches as a list, plus [Not in the list] |
| P2.2 | location | "Where is the branch?" | Emirate → area | Sharjah only, or route out-of-emirate complaints elsewhere **[Confirm]** |
| P2.3 | ask_field | "Trade license number, if you know it (optional)." | `text` | Skip allowed |
| P2.4 | select | "Did you buy in store or online?" | [In store] [Online] [Phone order] | Online → ask website or app name |

**Phase P3: Guided (purchase and issue)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P3.1 | select | "What is the complaint about?" | Options from `cpd.complaint_types`: [Defective product] [Refund refused] [Warranty not honoured] [Misleading price or offer] [Service not delivered] [Other] | Determines conditional steps below |
| P3.2 | ask_field | "What did you buy?" | `text` | |
| P3.3 | ask_field | "Purchase date" | `date` (past only) | If older than the complaint window, warn and allow continue **[Confirm window]** |
| P3.4 | ask_field | "Amount paid (AED)" | `amount` | |
| P3.5 | ask_field | "Did you contact the merchant first? What did they say?" | `textarea` | Required for refund cases **[Confirm]** |
| P3.6 | ask_field | "Describe the problem in your own words." | `textarea` ≤ 2000 | Agent may ask up to 2 follow-ups to fill gaps (dates, names, promises made) |
| P3.7 | select | "What outcome do you want?" | [Refund] [Replacement] [Repair] [Other] | |
| P3.8 | condition | Warranty case → ask warranty end date and card | `date`, `file` | Only for "Warranty not honoured" |

The agent writes a neutral one-paragraph **case summary** from P3.6 and the follow-ups. The user sees it in the review step and can edit it. The original text is always submitted alongside the summary.

**Phase P4: Guided (evidence)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P4.1 | file | "Upload the invoice or receipt." | `file` pdf/jpg/png ≤ 10 MB | Required for refund and warranty cases **[Confirm]** |
| P4.2 | file | "Any other evidence? Photos, messages, warranty card." | up to 5 files | Optional |

**Phase P5: Strict (review and submit)**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P5.1 | summary | All sections with [Edit] per row, case summary, attachments | [Edit …] [Continue] | Editing returns to that step, then back here |
| P5.2 | select | "How should the department contact you?" | [Phone] [Email] [Both] | Email field if chosen |
| P5.3 | consent | "I confirm the information is true and agree to share it with the merchant for resolution." | `consent` | Wording from the department **[Confirm]** |
| P5.4 | submit | `cpd.submit_complaint` | | Idempotency key per session to avoid duplicates |
| P5.5 | receipt | Reference, date, expected first response time, [Track this complaint] [Download copy] | | |

**Phase P6: Guided**

The user can ask what happens next; the agent answers from knowledge. "Track this complaint" shows a `timeline` from `cpd.get_complaint_status`.

**Save and resume**
- At any point after P1, the user can say "continue later". The draft is kept for the retention period and resumed after re-verification.

**Edge cases**
- Abusive or threatening language in the description: the agent asks the user to rephrase, and does not submit until the description is acceptable; this is never used to refuse the complaint itself.
- Merchant outside Sharjah: explain the right authority and offer its link **[Confirm routing]**.
- The user wants to complain about a government entity: route to the general complaints channel, not consumer protection.

---

### 9.5 Sharjah Customs Services

| Item | Value |
|---|---|
| Goal | Find customs services, check declaration status, pay duties, and get traveller guidance |
| Owner | Sharjah Customs **[Confirm]** |
| Phases | P1 Guided (service menu) → sub-flows: P2 Guided (traveller guidance), P3 Guided (declaration status), P4 Guided → Strict (pay duties), P5 Guided (refund of deposit) |
| Identity | Anonymous for guidance; OTP or login for declaration details; login for payment by company accounts **[Confirm]** |
| Tools | `customs.services`, `customs.get_declaration`, `customs.get_dues`, `payment.*`, `customs.refund_request` |

**Phase P1: Guided (menu)** **[Confirm services]**
[Traveller allowances and restricted items] [Declaration status] [Pay customs duties] [Deposit refund] [Contact customs]

**P2 Guided: traveller guidance**
- Answers from customs knowledge: duty-free allowances, restricted and prohibited items, cash declaration thresholds, travelling with medicine.
- When a question needs a ruling ("Can I bring this specific product?"), the agent gives the general rule and offers [Contact customs] rather than deciding.

**P3 Guided: declaration status**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P3.1 | ask_field | "Enter the declaration number." | `text` **[Confirm format]** | |
| P3.2 | verify | OTP to the declarant's registered mobile, or login | `otp` | Declaration data is personal or commercial |
| P3.3 | call_tool | `customs.get_declaration` → card + `timeline` | | Shows status, inspection, release, outstanding dues |
| P3.4 | chips | [Pay outstanding dues] [Ask about this declaration] [Talk to a person] | | |

**P4 Guided → Strict: pay duties**

| Step | Type | Prompt | Input | Rules |
|---|---|---|---|---|
| P4.1 | lookup_confirm | Declaration number (prefilled from P3) → `customs.get_dues` | | |
| P4.2 | list (multi-select) | Dues: duty, fees, fines, each with amount | Select | Mandatory items cannot be deselected **[Confirm]** |
| P4.3 | verify | Step-up if not verified | `otp` | |
| P4.4 | confirm | Summary and total | | Confirmation token |
| P4.5 | pay | As 9.2 P4.3 to P4.5 | | |
| P4.6 | receipt | Receipt, and release status if available | | |

**P5 Guided: deposit refund request**

| Step | Type | Prompt | Input |
|---|---|---|---|
| P5.1 | ask_field | Declaration or deposit reference | `text` |
| P5.2 | verify | Login (company or individual) | |
| P5.3 | ask_field | IBAN for refund | `text` with IBAN check `^AE[0-9]{21}$` |
| P5.4 | file | Supporting documents | `file` |
| P5.5 | summary + consent + submit | | |
| P5.6 | receipt | Reference and expected processing time | |

---

## 10. Flow engine rules

### 10.1 Interruptions inside a scenario

| User does | Guided | Strict |
|---|---|---|
| Asks a side question | Answered by the agent; the step's choices are offered again | Short answer, then re-ask current step |
| Gives several values at once | Extract all, validate each, confirm, ask the rest | Only the current step's value is accepted; others are kept as suggestions for later steps |
| Goes back | [Back] to the previous question, [Main menu] to the first; answers from there are cleared | Same |
| Changes an earlier answer | Update, re-validate dependent fields, re-run lookups | Allowed only from the summary's [Edit] |
| Starts another topic | Offer: [Save and switch] [Finish this first] | Offer: [Cancel this payment and switch] [Finish this first] |
| Says "cancel" | Confirm cancel; discard or save draft | Confirm cancel; void any confirmation token |
| Says "talk to a person" | Handoff with collected data | Handoff with collected data; payment not executed |
| Goes silent | Reminder after 5 min; save draft at idle timeout | Void token at idle timeout |

### 10.2 Validation

1. Client-side checks only improve the experience; the server is the source of truth.
2. Error messages state what is wrong and how to fix it, with an example of a valid value.
3. After 3 invalid attempts on the same field: show [Show me an example] [Talk to a person]; never loop endlessly.
4. Lookups never reveal whether a record exists before verification; the message is the same for found and not found where personal data is involved.

### 10.3 Value extraction by the agent

- The agent proposes values; the engine accepts them only after validation.
- Extracted values are echoed back ("Got it: Home internet, account 1.23456789") so the user can correct them.
- The agent never fills a required field with a guess. If unsure, it asks.

### 10.4 State storage

| Data | Where | Retention |
|---|---|---|
| Scenario state (step, answers) | Flow engine, encrypted | Saved progress retention, then deleted |
| Confirmation tokens | Payment service | 10 minutes, single use |
| Uploaded files | Temporary store, virus-scanned | Until submission, then moved to the entity system; deleted if abandoned |
| Transcript | Audit store | Per records-retention policy **[Confirm]** |

---

## 11. Identity, OTP step-up and security

### 11.1 Identity levels

| Level | How reached | Allows |
|---|---|---|
| Anonymous | Default (deployment setting "Anonymous, step-up with OTP") | Agent answers and lists from public data; starting scenarios |
| OTP-verified | OTP to the contact registered on the record, or to a number the user proves they own (for notifications) | Read personal data for that record; submit requests; pay by card |
| Logged in | UAE PASS or Tahseel app login | Everything, including wallet payments, history, saved drafts across devices |

### 11.2 OTP step-up in the widget

```
 ┌───────────────────────────────────────────┐
 │ To continue, I need to verify you.        │
 │ We sent a 6-digit code to ••••••42.       │
 │                                           │
 │   [ _ ] [ _ ] [ _ ] [ _ ] [ _ ] [ _ ]     │
 │                                           │
 │   Resend code in 0:45                     │
 │   (Use UAE PASS instead)  (Cancel)        │
 └───────────────────────────────────────────┘
```

| Rule | Value |
|---|---|
| Code length | 6 digits |
| Validity | 5 minutes **[Confirm]** |
| Resend | After 60 seconds, maximum 3 per 15 minutes |
| Attempts | 3 wrong codes → lockout 15 minutes **[Confirm]** |
| Delivery target | Contact registered on the record, shown masked; the user cannot type a new number for record verification |
| Handling | The code is sent to the identity service directly from the OTP control; it never passes through the language model, and it is not stored in the transcript |
| Autofill | `autocomplete="one-time-code"` for SMS autofill on mobile |

### 11.3 Security controls

- **Origins:** the gateway rejects any request whose origin is not in Allowed origins; the iframe sets `frame-ancestors` to the same list.
- **Tokens:** short-lived session token (JWT, 30 minutes sliding) carrying the identity level and scenario scope; refreshed silently.
- **Tool scope:** each tool checks the identity level and, for payments, the confirmation token itself. The agent cannot bypass this by calling a tool directly.
- **Agent acts as:** a dedicated service account with only public-read and gated tools. Never a staff account.
- **Masking:** IDs, phone numbers, account numbers and names are masked in the chat after submission (for example `784-••••-•••••12-3`).
- **Prompt injection:** content from tools, files and web pages is treated as data. Uploaded files are never read as instructions.
- **Rate limits:** messages per visitor (deployment setting), plus separate limits on OTP sends, OTP attempts, lookups per identifier, and file uploads.
- **Content Security Policy** for the widget: scripts and styles from the Juman host only; no third-party trackers inside the iframe.
- **Logs:** no OTP values, card data or full IDs in logs.

---

## 12. Human handoff

| Item | Rule |
|---|---|
| Triggers | User asks; 3 failed validations; tool failure on a transaction; agent confidence below threshold on a ruling question; sensitive topics (complaint escalation) |
| Target | The deployment's **Human handoff queue** (routing by scenario owner) **[Confirm queues per entity]** |
| What is passed | Identity level, verified identifiers (masked), scenario, phase, collected answers, case summary, transcript link |
| What the user sees | `handoff` block: "Connecting you to a person. You are number 3 in line." Composer stays open for messages to the person |
| Outside working hours | Offer a callback request (Guided: phone, preferred time, consent) or leave a message |
| Return to bot | When the person closes the conversation, the bot resumes with "Is there anything else I can help with?" |
| Payments | A person never takes card details in chat; payments always go through the payment page |

---

## 13. Voice, language, accessibility and other surfaces

### 13.1 Voice

| Feature | Behaviour |
|---|---|
| Mic (speech to text) | Tap to record, tap to stop (at most two minutes); the recording is sent to `POST /embed/v1/sessions/{id}/transcriptions` and its text is added to the composer for editing before send; Arabic and English (D386) |
| Speaker (read aloud) | Reads the message's `speakable` text; never reads masked values or codes |
| Field controls | For select fields, spoken answers are matched to options and echoed back for confirmation |
| Privacy | Neither the audio nor the transcript is stored by the transcription call; the text is kept only once the visitor sends it (D386) |

### 13.2 Language and RTL

- The widget follows `data-lang`, then the host page language, then the browser.
- A language switch in the header menu changes the UI and the agent's reply language for the rest of the session.
- Arabic: full RTL mirroring (bubble sides, chip order, launcher position). Numbers stay in Western digits unless configured otherwise **[Confirm]**.
- Scenario prompts, options and error messages are configured in both languages; the agent does not translate field labels on the fly.

### 13.3 Accessibility (WCAG 2.1 AA)

- The panel is a `role="dialog"` with a label; focus moves into the panel on open and returns to the launcher on close.
- The message list is an `aria-live="polite"` region; streaming text is announced once complete.
- Every chip, icon and control has an accessible name; the mic and speaker buttons announce their state.
- Keyboard: Tab through controls, Enter to activate, Escape to minimize.
- Contrast, focus indication, touch-target size and motion follow the platform design system.

### 13.4 Other surfaces

The same message protocol is reused for WhatsApp and Teams with a degradation map:

| Block | WhatsApp | Teams |
|---|---|---|
| chips (≤ 3) | Reply buttons | Adaptive Card actions |
| chips (> 3) / select | List message (≤ 10 rows) | Adaptive Card choice set |
| list | List message or numbered text | Adaptive Card |
| card / summary / receipt | Formatted text + document (PDF receipt) | Adaptive Card |
| otp | Plain text code entry | Adaptive Card input |
| file | Media message | File upload |
| link_out | URL button | Action.OpenUrl |

---

## 14. API contract

Base path: `https://<juman-host>/embed/v1`

| Method | Path | Purpose |
|---|---|---|
| POST | `/sessions` | Start a session. Body: `deployment`, `lang`, `context`. Returns `sessionToken`, `identityLevel`, `welcome` message |
| POST | `/sessions/{id}/messages` | Send user text. Body: `text`, `clientMessageId` |
| POST | `/sessions/{id}/actions` | Send an action (section 6.4) |
| GET | `/sessions/{id}/stream` | Server-sent events: `message.start`, `message.delta`, `message.end`, `typing`, `handoff.update`, `session.update`, `error` |
| POST | `/sessions/{id}/files` | Upload a file for the current `file` step. Returns `fileId` |
| POST | `/sessions/{id}/transcriptions` | The raw recording as the body (`audio/webm`, `audio/ogg`, `audio/mp4`, `audio/mpeg`, `audio/wav`, at most 5 MB). Returns `{ text }`. 403 `VALIDATION_FAILED` when Voice input is off, 429 `RATE_LIMITED` past the deployment's per-visitor limit a minute, 503 `TOOL_UNAVAILABLE` when no Transcription model answers (D386) |
| POST | `/sessions/{id}/otp/send` | Send OTP for the current verify step |
| POST | `/sessions/{id}/otp/verify` | Verify OTP. Returns new token with raised level |
| POST | `/sessions/{id}/resume` | Resume a saved scenario |
| DELETE | `/sessions/{id}` | End the session |

**Stream event example**

```
event: message.start
data: {"id":"msg_42","role":"assistant"}

event: message.delta
data: {"id":"msg_42","blockIndex":0,"text":"You have 2 bills"}

event: message.end
data: {"id":"msg_42","blocks":[…],"input":{…},"flow":{…}}
```

**Error format**

```json
{ "error": { "code": "OTP_INVALID", "message": "The code is not correct. 2 attempts left.", "retryAfter": null } }
```

| Code | Meaning | Widget behaviour |
|---|---|---|
| `ORIGIN_NOT_ALLOWED` | Origin check failed | Hide the widget, log to console |
| `DEPLOYMENT_DISABLED` | Status disabled | Hide the launcher |
| `RATE_LIMITED` | Too many messages | Notice with `retryAfter`, composer disabled |
| `IDENTITY_REQUIRED` | Step needs a higher level | Show the verify step |
| `OTP_INVALID` / `OTP_EXPIRED` / `OTP_LOCKED` | OTP problems | Inline error on the OTP control |
| `VALIDATION_FAILED` | Field value rejected | Inline error with `message` |
| `STALE_ACTION` | Old button used | Notice: "That option is no longer available" |
| `TOKEN_EXPIRED` | Confirmation token expired | Re-show summary with refreshed amounts |
| `TOOL_UNAVAILABLE` | Back-end down | Notice + [Try again] [Talk to a person] |

---

## 15. Audit and analytics events

| Event | Key properties |
|---|---|
| `widget.opened` / `widget.closed` | page, lang |
| `quick_action.clicked` | action id, position |
| `scenario.started` | scenario, entry (chip / typed / page context) |
| `scenario.step_completed` | scenario, step, duration, attempts |
| `scenario.validation_failed` | scenario, field, error code (no value) |
| `identity.step_up` | method (OTP / UAE PASS), result |
| `scenario.handoff` | scenario, step, reason |
| `scenario.ended` | scenario, end state, total duration |
| `payment.result` | scenario, status, amount band (not exact amount in analytics) |
| `feedback.submitted` | rating, scenario |

**Dashboards to build:** completion rate per scenario, drop-off by step, average steps per completion, handoff rate, OTP success rate, top free-text intents without a scenario (candidates for new quick actions).

Add a thumbs up / down control under bot messages and a one-question rating at scenario end.

---

## 16. Error and empty states

| Situation | Message (EN) | Actions |
|---|---|---|
| No bills due | "There's nothing to pay on this account right now." | [Pay another account] [Done] |
| No flights match filters | "No arrivals match these filters." | [Clear filters] |
| Lookup not found (non-personal) | "I couldn't find that flight number today." | [Search another date] [Re-enter] |
| Lookup not found (personal) | "If this matches a record, you'll get a code on the registered number." | [Use UAE PASS instead] |
| Back-end unavailable | "The {service} system isn't responding. Your progress is saved." | [Try again] [Talk to a person] |
| File rejected | "This file is larger than 10 MB. Upload a smaller file or a photo." | [Upload again] |
| Session expired | "Your session ended for your security. Start again to continue." | [Start again] |
| Payment not completed | "The payment wasn't completed and you haven't been charged." **[Confirm wording with payment operator]** | [Try again] [Choose another method] |

---

## 17. Acceptance criteria

### 17.1 Rendering

- [ ] The widget shows all elements of the reference screen: launcher, panel, header with minimize and expand, dismissible disclaimer, greeting with five quick actions, read-aloud and timestamp, and composer with mic when Voice input is on.
- [ ] Arabic mirrors the full layout correctly.
- [ ] Every block type in section 6.2 and every field type in section 6.3 renders correctly, including on WhatsApp and Teams per the degradation map.

### 17.2 Behaviour

- [ ] Each quick action starts its scenario; typing the same intent starts the same scenario with extracted values prefilled.
- [ ] Guided steps accept several values in one message and ask only for what is missing.
- [ ] Strict steps cannot be skipped by typing; side questions are answered and the same step is asked again.
- [ ] Editing a value from the summary re-validates all dependent values.
- [ ] Side questions never lose collected answers.
- [ ] A saved scenario resumes after re-verification within the retention period.

### 17.3 Security

- [ ] No personal data is shown before the required identity level.
- [ ] Lookups with personal data return the same message for found and not found.
- [ ] OTP values never appear in transcripts, logs or model inputs.
- [ ] Payment is impossible without a valid, unexpired, single-use confirmation token.
- [ ] Requests from origins not in Allowed origins are rejected.

### 17.4 Simulation set before publishing (per scenario)

| Test | Expected result |
|---|---|
| Happy path by chips only | Scenario completes |
| Happy path by free text only | Scenario completes with the same data |
| All values in the first message | Bot confirms and skips to the next missing step |
| Invalid value 3 times | Example and handoff offered |
| Side question at every step | Answered, then the same step resumes |
| Cancel at every step | Clean cancel; no token or draft left behind unless saved |
| Topic switch mid-scenario | Save-and-switch offered |
| OTP wrong, expired, locked | Correct message each time |
| Back-end failure on lookup and on payment | Correct notice; no false "paid" message |
| Prompt injection in a free-text field | Treated as data; no change in behaviour |
| Arabic run of the happy path | Correct language and RTL throughout |

---

## 18. Open questions

1. Which identifiers and formats does each entity accept (e& account, declaration number, complaint reference)?
2. Does an e& balance lookup by account number require OTP, or is it public as on other payment channels?
3. Are partial payments allowed for e& bills and customs dues?
4. Which payment methods are offered in the widget, and is the Tahseel wallet included at launch?
5. What are the handoff queues and working hours per entity?
6. Is the complaint routed only for Sharjah merchants, and what is the complaint time window?
7. What are the records-retention rules for transcripts and uploaded files?
8. Should these five scenarios run as Guided or Strict storylines in the platform, or as skills of the leader agent with the tools enforcing the rules (see the earlier storyline vs skills discussion)? This spec works with both, as long as the Strict phases stay in the flow engine.

---

## 19. Implementation status

The platform side of this specification as built (D231), checked against `apps/web/src/app/embed/v1/`
and `apps/web/src/features/engage/` on 2026-10-29. The module view is
[Engage](../05-modules/engage.md#widget-s-65) and the host contract is [Host websites](host-websites.md).

| Section | Status | Detail |
|---|---|---|
| 2. Architecture | Built | Loader, sandboxed frame served from the platform, session gateway with origin check and per-visitor rate limit, switched off for every deployment by the Embedded deployments flag, storyline engine in the web app, the deployment's default agent for answers outside the script (acting as **Agent acts as**, D221), handoff to a discussion room. There is no separate leader agent or identity service. |
| 3.1 Embed code | Built | The attributes as specified; Copy embed code gives this snippet. |
| 3.2 JavaScript API | Built | `open`, `close`, `startAction`, `setLanguage`, `on`. `startAction` takes a quick action's id, or a storyline code. `on` fires `open`, `close` and `conversation:end`. |
| 3.3 Settings | Built | The new settings are on the deployment (migration 0053). The rate limit window is 1 minute. |
| 4. Anatomy | Built | Launcher with unread dot, panel, header with menu, minimise and expand (the panel fills the host page, D340), dismissible disclaimer, greeting with quick actions, read aloud, timestamps, composer with a microphone when Voice input is on (off by default, D340). |
| 5. States | Built, partly | All states are drawn. Idle timeout is applied when the visitor next starts a session, not while the panel is open. Personal data is not cleared from the screen when a verified level expires, because the level does not expire within a conversation. |
| 6.1–6.3 Protocol | Built, partly | Envelope, blocks, `input` and `flow` as specified (`protocol.ts`). The engine emits text, chips, list, card, summary, receipt, timeline, notice and handoff; `carousel`, `link_out`, `attachment` and `progress` are drawn but nothing emits them (progress is carried in `flow` only, D341). Every field type has a control and is checked on the server (`fields.ts`); `lookup` and `location` are a text input checked as text. |
| 6.4 Actions | Built, partly | Every action is accepted and stale ones are refused with `STALE_ACTION`. `load_more` does nothing, because lists are not paged. `show_example` is accepted but the widget does not offer it. |
| 7. Modes | Built, partly | Guided and Strict, per storyline and per step (D339), with Back and Main menu. A tool's list does not page (5 per page), filter or turn text into filters. In Strict a side question gets a fixed redirect rather than a short answer. |
| 8. Quick actions | Built, partly | Ordered list on the deployment, ranked and filtered by `data-context` page. `min_identity` `logged_in` is refused, because sign-in is not built. `entry_mode` is not stored. Starting a scenario by typing is the deployment's agent's: it lists the quick actions with `conversation_scenario_list` and starts an anonymous one with `conversation_scenario_create`, passing the values the visitor gave as a prefill the engine checks. |
| 8.1 Scenario schema | Different | A scenario is a storyline of steps, each with an optional phase mode; per-phase `min_identity`, `interruptions` and per-scenario timeouts are not configurable. |
| 9. Scenarios | Not built | None is seeded. Each needs the owning entity's back-end and its rules **[Confirm]**. |
| 10.1 Interruptions | Built, partly | Side questions, several values at once (Guided, by field pattern), Back and Main menu, Edit from the summary, Cancel and Talk to a person are built. Not built: the save-and-switch offer, a confirm before Cancel, re-running dependent fields after an edit, and the silence reminder. |
| 10.2 Validation | Built, partly | The server decides; refusals give the field's example. After the step's maximum attempts the step's On error runs (by default a handoff) instead of offering [Show me an example] [Talk to a person]. |
| 10.3 Extraction | Built, partly | Values are found by each field's pattern, not by the agent, checked, and echoed ("Got it: …"). |
| 10.4 State storage | Built, partly | Scenario state is the conversation's `state_json`, not encrypted apart from the database, and not deleted when the retention passes. Uploaded files are kept as attachments of the conversation. |
| 11.1 Identity levels | Built, partly | Anonymous and OTP-verified. Logged in (UAE PASS) is not built. A host-signed visitor token cannot be passed to the widget. |
| 11.2 OTP | Built, partly | 6 digits, 5 minutes, resend after 60 seconds, 3 resends and 3 wrong codes per step, then the step stops; the code is never in the transcript or a model input; `one-time-code` autofill. A code is delivered only through a channel conversation's outbound endpoint: there is no SMS sender for a number the visitor types, so the public widget cannot deliver one (the console preview shows it). |
| 11.3 Security | Built, partly | `frame-ancestors` is the allowed origins and the console; the session start checks the host origin; the session token is 30 minutes and renewed on every answer, but carries no identity level or scenario scope (both are in the conversation's state). Tool steps do not check the identity level. OTP sends and attempts have their own limits; lookups and uploads do not. |
| 12. Handoff | Built, partly | Talk to a person is offered only when the deployment has a handoff queue (D340). Talk to a person, or a step's On error, moves the conversation into a room in the queue's project with its transcript; later visitor messages reach the room and a person's reply reaches the widget; the `handoff` block reads queued, then connected. Not built: a queue position, routing by scenario owner, the outside-hours callback, and returning to the bot. Apart from handoff, a holder of `conversations:answer` can take a conversation over from AI Capabilities → Conversations, write to the visitor as a human agent, resume the agent or end it (D342, D343, D344). |
| 13.1 Voice | Built | The mic records in the browser and the platform turns the recording into text with the first Transcription model allowed on a connection it can call (D386); read aloud uses the browser's speech synthesis. The microphone sits beside Send and is shown only when the deployment's Voice input is on, on by default (D386). Without a Transcription model the mic answers "Voice input is not set up". Spoken answers are not matched to a select field's options. |
| 13.2 Language | Built, partly | `data-lang`, the page language, then the browser; the header menu switches the language and the messages. The deployment's agent answers in the visitor's language. |
| 13.3 Accessibility | Built | Dialog role, live region, Escape to minimise, focus back to the launcher, labelled controls. Not audited against WCAG 2.1 AA. |
| 13.4 Other surfaces | Built, partly | WhatsApp and Teams receive the text form of the blocks (`degrade`); reply buttons, list messages and Adaptive Cards are not built. |
| 14. API | Built | Every endpoint, plus `GET /config/{code}`, `GET /sessions/{id}`, `/feedback`, `/events` and `/language`; errors in the specified shape. `TOKEN_EXPIRED` is never returned, because there is no confirmation token. |
| 15. Events | Built, partly | Every event except `payment.result`, without durations, the quick action's position or the validation error code (`ai.widget_event`). The deployment's Last 30 days card shows completion and handoff rates per scenario, drop-off by step and OTP success. Not built: average steps per completion and top free-text intents. Thumbs and the end rating are built. |
| 16. Error and empty states | Built, partly | Session expired, file too large and offline are built; a back-end failure shows a general notice with Talk to a person. The rest are written per storyline. |
| 17. Acceptance criteria | Not assessed | The storyline editor's Simulate runs a scenario, but the simulation set is not required before publishing. |
| 18. Open questions | Open | All eight. Also open: payment page and confirmation tokens (sections 1, 7.1, 11.3), which nothing in the platform provides yet (D231). |
