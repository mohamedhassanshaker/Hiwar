# 11 — Operations

> Runbooks, monitoring, incident response.
> Owner: Ops lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Runbook](runbook.md) | draft | 1.0 | 2026-10-30 |

`runbook.md` lists known failures with symptom, cause and fix. Daily use of the local platform (start, seed,
logs, tear-down) is in [local-platform.md](../12-user-and-developer-guides/local-platform.md). No monitoring,
alert or incident-response document exists yet.
