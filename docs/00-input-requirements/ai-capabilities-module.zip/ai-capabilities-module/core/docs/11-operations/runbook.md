# Runbook

| Item | Value |
| --- | --- |
| Purpose | Known failures of the local platform and the verification gate, what causes each, and how to fix it |
| Audience | Developers, operators |
| Related | [Operations](../operations.md) · [Deployment](deployment.md) · [Configuration](configuration.md) · [Conventions](../08-development/conventions.md) |
| Last verified against code | 2026-10-29 |

Each entry names the symptom you see, the cause, and the fix. Entries come from incidents recorded
in [docs/CHANGELOG.md](../CHANGELOG.md) and the dated [reports](../reports/delivery-tracker.md),
kept only where the cause still exists in the current code and scripts.

## Quick reference

| Symptom | Cause | Fix |
| --- | --- | --- |
| `make: command not found` | `make` is not on `PATH` (Git Bash on Windows ships without it). | Run the script the target wraps ([Operations, Without `make`](../operations.md#without-make)), or `winget install GnuWin32.Make`. |
| `infra/kind/bootstrap.sh` stops naming a tool or a capacity figure | A prerequisite is missing, too old, or Docker has too few CPUs, too little memory, or the disk too little free space for the profile. | Install or upgrade the tool, or give Docker more resources, or use `PROFILE=core` ([Operations, Prerequisites](../operations.md#prerequisites)). |
| `verify` stops with "No DATABASE_URL set and the awp-dev-db container is not running" | Working as intended: the database suites are required, so `scripts/verify.sh` refuses to skip them. | `make dev-local`, or export `DATABASE_URL`. |
| A Pod in `ImagePullBackOff` | The image was never pushed to `localhost:5001` (`make deploy` does not build images), or the registry container is gone. | `REBUILD=1 scripts/build-images.sh` then `make deploy`; if the registry is gone, `make kind-reset` recreates both. |
| A code change does not appear after `make deploy` | The image tag did not change, so Kubernetes left the running Pod alone. | `kubectl -n awp-app rollout restart deployment <name>`, or `make deploy-web` / `make deploy-agent` ([Deployment](deployment.md#changing-application-code)). |
| The browser refuses the certificate | Expected once: the certificate comes from the cluster's own CA. | Accept it; `curl -k` and the suite accept it already. |
| `curl` gets "connection refused" on `awp.localtest.me` | The client tried `::1` first; kind publishes on IPv4 only. | `curl -4`, or `--resolve awp.localtest.me:8443:127.0.0.1` ([Operations, IPv4 only](../operations.md#ipv4-only)). |
| Changing `HTTP_PORT`/`HTTPS_PORT` has no effect | The host ports are bound only when the cluster is created. | `make kind-reset` with the new values ([Operations, host ports](../operations.md#the-host-ports-8080-and-8443)). |

## A port-forward to 8080 fails

**Symptom.** `kubectl port-forward ... 8080:8080` fails with "address already in use".

**Cause.** With the default `HTTP_PORT=8080`, the kind control-plane container holds host port
8080 for the gateway's HTTP listener (`infra/kind/kind-config.yaml`). Two commands use that local
port: the Adminer forward, and the AI gateway forward in `scripts/dev-forward.sh`
(`awp-ai svc/ai-gateway 8080:8080`). Read from the configuration; not reproduced.

**Fix.** Forward to another local port (`18080:8080`). For host mode, point `AGW_LLM_URL` at the
port you chose, or create the cluster with `HTTP_PORT=80` where port 80 is free.

## A port-forward drops in the middle of a run

**Symptom.** A long test or seed run starts failing every database query with `ECONNREFUSED` part
of the way through.

**Cause.** On Windows a single `kubectl port-forward` closes under the connection pattern a full
browser suite produces.

**Fix.** Use the scripts, which supervise their forwards and restart a dropped one
(`scripts/port-forward.sh`, used by `seed.sh`). `make verify`
deliberately uses the `make dev-local` container rather than a forward for the same reason.

## Docker runs out of disk

**Symptom.** Docker's API answers HTTP 500 for every call and the cluster is unreachable; the
drive holding Docker's virtual disk is full.

**Cause.** Each `REBUILD=1` image build writes a new layer set (the agent image carries the
document parsing stack: torch, spaCy, Tesseract), and Docker Desktop's virtual disk keeps its
high-water mark after the space inside it is freed. Superseded image digests also stay on every
kind node.

**What the scripts already do.** `scripts/build-images.sh` prunes the build cache and unused
images once either passes 20 GB (`CACHE_CEILING_GB`, `IMAGE_CEILING_GB`; `0` turns a ceiling off)
and prunes unused images on every kind node (`PRUNE_NODES=1`).

**Fix when it happens anyway.**

1. Free host space from rebuildable artefacts only: `apps/web/.next`, the services' `.venv`
   folders, Playwright results.
2. Restart Docker Desktop and WSL.
3. `docker builder prune -af` to reclaim space inside the virtual disk. Do not prune containers or
   volumes: that takes the cluster, and other work on the machine, with it.
4. To return the space to the host, stop the VM and compact the disk file (elevated PowerShell):

   ```powershell
   wsl --shutdown
   Optimize-VHD -Path '<path to docker_data.vhdx>' -Mode Full
   ```

   Moving Docker's data root to a larger drive is the lasting fix.

## The agent test suite seems to hang

**Symptom.** `uv run pytest` in `services/agent` never prints a summary.

**Cause.** A backgrounded run was killed before pytest printed its summary, and orphaned
`pytest`/`python` child processes kept holding the virtualenv, so later runs contended with them.

**Fix.** Run the suite in the foreground (`scripts/verify.sh` does). Kill orphaned `pytest` and
`python` processes before re-running.

## The browser suite fails a different handful of cases each run

**Symptom.** A full `make test-e2e` run fails a random set of single-locale cases with
`net::ERR_TIMED_OUT` or `net::ERR_NO_BUFFER_SPACE` while navigating, and a different set the next
time.

**Cause.** The browser never reached the server: local network and socket pressure after hours of
sustained load. Traefik's connection handling degraded measurably on the build machine (2 of 40
concurrent requests timed out after three hours of heavy use, 0 of 40 after a restart). CI does
not run this suite, so the gate is not affected.

**Fix.** `kubectl -n awp-system rollout restart deploy/traefik`, then re-run the failed cases with
`GREP=<pattern> make test-e2e`. A case that fails the same way in isolation is a real failure.

## A live-model case times out

**Symptom.** A browser case that needs a real model (a mission, the agentic request entry's typed
classification) times out or the classification
answers 503.

**Cause.** The seeded OpenRouter routes run on free models ([D208, D245](../harness-decisions.md)),
which are often overloaded, carry OpenRouter's daily request cap, and do not reliably hold to a
structured-output schema. The typed classification retries twice and then answers 503 on purpose,
so the console falls back to the template form (`UC-28.2-06`). Agentic request entry is off by
default ([D310](../harness-decisions.md)); its cases run only with `AWP_AGENTIC_ENTRY=on`.

**Fix.** None in code. A paid provider key removes the variable; which providers are allowed is
an open owner decision ([open questions](../specs/open-questions.md), SD-6, SD-7).

## Every run stays Running and the timeline stays empty

**Symptom.** New runs show Running with 0 tokens for ever; a run's live stream holds only `RUN_STARTED`;
knowledge ingestions do not progress; the Temporal frontend logs `Slow gRPC call ... QueryWorkflow` and
`consistent query buffer is full`; `/api/health` still reports every dependency up.

**Cause.** The three agent workers started before the `awp` Temporal namespace was registered. Each logged
`Network error while describing namespace ... NotFound` once and then served nothing, without exiting, so
Kubernetes never restarted them (2026-10-31). Queries on the stuck ingestion workflows then saturated the
frontend.

**Seen on.** The System screen and `/api/health` show a `… worker` line as Error, and the live test
`TC-AGT-960` fails.

**Fix.** `kubectl -n awp-app rollout restart deploy/agent-worker-agent-runs deploy/agent-worker-ingestion
deploy/agent-worker-maintenance`. Since 2026-10-31 a worker checks the namespace at start and exits when it
is missing (`worker.namespace_missing` in its log), so Kubernetes retries it until
`scripts/temporal-namespace.sh` has registered the namespace. That script now calls the admin tools with the
frontend's full service name, because the short name timed out inside the admin tools Pod.

## A run token change leaves runs stuck

**Symptom.** After deploying a web image that changed the run token's claims, runs that were in
flight stall and then fail.

**Cause.** A token minted before a claim existed carries nothing for it, and the server reads an
absent claim as "nothing".

**Fix.** Drain before such a deploy ([Deployment, Draining](deployment.md#draining-in-flight-runs-first)).
`scripts/deploy-cluster.sh` refuses to deploy while workflows are running unless
`ALLOW_IN_FLIGHT=1`.

## The cluster database was reseeded and old data is gone

**Symptom.** The demo organisation the browser suite expects is missing after `make seed`.

**Cause.** `make seed` loads the minimal organisation a fresh install ships with; the demo
organisation is test data.

**Fix.** Load the fixtures: `DATABASE_URL=<the cluster's, port-forwarded> npm --prefix apps/web run test:seed`
([Operations, Seeding](../operations.md#seeding)). Restore the minimal seed with `make seed` when
you are done, so the shared cluster is left as a fresh install.
