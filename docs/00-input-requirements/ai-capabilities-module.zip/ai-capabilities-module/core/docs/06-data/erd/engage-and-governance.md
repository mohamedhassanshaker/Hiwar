# Entity relationships: engage and governance

| Item | Value |
| --- | --- |
| Purpose | The entities for channels, embedded deployments and storylines (`ai`), and for setup, budgets, integrations, settings, email notifications and audit (`gov`, `audit`), and how they relate |
| Audience | Developers, architects, business analysts |
| Related | [Data model overview](../overview.md) · [Organisation and work](organisation-and-work.md) · [Agents and capabilities](agents-and-capabilities.md) · [Data dictionary](../data-dictionary/README.md) |
| Last verified against code | 2026-10-29 |

Sources: `ai.ts` (channels to conversations), `gov.ts` and `audit.ts` under
`apps/web/src/db/schema/`. The diagram conventions are those of
[organisation and work](organisation-and-work.md).

## Channels, deployments and storylines

```mermaid
erDiagram
  CHANNEL ||..o| EMBEDDED_DEPLOYMENT : bound_to
  AGENT ||--o{ EMBEDDED_DEPLOYMENT : default_agent_of
  PERSON ||--o{ EMBEDDED_DEPLOYMENT : run_as
  EMBEDDED_DEPLOYMENT ||--o{ DEPLOYMENT_SURFACE : publishes_on
  CHANNEL ||--o{ DEPLOYMENT_SURFACE : carries
  EMBEDDED_DEPLOYMENT ||--o{ STORYLINE : has
  STORYLINE ||--o{ STORYLINE_VERSION : versions
  STORYLINE_VERSION ||--o{ STORYLINE_STEP : contains
  STORYLINE_STEP ||--o{ STORYLINE_STEP : next
  AGENT ||--o{ STORYLINE_STEP : overrides
  EMBEDDED_DEPLOYMENT ||--o{ DEPLOYMENT_CONVERSATION : serves
  STORYLINE_VERSION ||--o{ DEPLOYMENT_CONVERSATION : pinned_by
  STORYLINE_STEP ||--o{ DEPLOYMENT_CONVERSATION : current_step_of
  DISCUSSION_ROOM ||--o{ DEPLOYMENT_CONVERSATION : mirrors
  REQUEST ||--o{ DEPLOYMENT_CONVERSATION : created_by
  PERSON ||--o{ DEPLOYMENT_CONVERSATION : takes_over
  DEPLOYMENT_CONVERSATION ||--o{ CONVERSATION_MESSAGE : contains
  CHANNEL ||--o{ CHANNEL_MESSAGE : carried
  DEPLOYMENT_CONVERSATION ||--o{ CHANNEL_MESSAGE : part_of
  DISCUSSION_ROOM ||--o{ CHANNEL_MESSAGE : mirrored_in
  REQUEST ||--o{ CHANNEL_MESSAGE : intake_of
  EMBEDDED_DEPLOYMENT ||--o{ WIDGET_EVENT : counts
  DEPLOYMENT_CONVERSATION ||--o{ WIDGET_EVENT : raised_in
```

| Entity | Table | Description |
| --- | --- | --- |
| Channel | `ai.channel` | One row per channel type: enabled flag, status, binding (embedded deployment, room mirror or request intake; `binding_id` is polymorphic), unknown-sender policy, rate limit, business hours, encrypted credentials, outbound endpoint, inbound webhook secret, offline message and the last test result. Hot-reloaded on save |
| EmbeddedDeployment | `ai.embedded_deployment` | An agent published to websites and channels: default agent, status, allowed origins, visitor identity (with a signed-JWT secret and fallback), the person the deployment's agent acts as when it answers a visitor (`run_as_person_id`, D221), handoff queue, per-visitor rate limit, branding, disclaimer, quick actions, voice input, read aloud, session idle timeout and saved-progress retention (migration `0053`, D231). `active_storyline_version_id` has no foreign key |
| DeploymentSurface | `ai.deployment_surface` | Widget, WhatsApp or Teams, with the channel it rides on |
| Storyline | `ai.storyline` | A script for a deployment, with a code unique within the deployment. The one whose code is the deployment's code opens conversations; the others are started by quick actions (D231) |
| StorylineVersion | `ai.storyline_version` | Guided or Strict (D339); Draft, Published or Superseded. Conversations pin the version |
| StorylineStep | `ai.storyline_step` | A typed step with its agent override, bilingual message, verbatim flag, type-specific fields, next step and on-error rule |
| DeploymentConversation | `ai.deployment_conversation` | A visitor conversation: channel, visitor key, engine state, slots, current step, outcome, request created, rating, and the person who took it over from the agent (`agent_paused_by`, `agent_paused_at`, D342). `external_contact_id` and `channel_id` have no foreign key |
| ConversationMessage | `ai.conversation_message` | One line of a visitor conversation in order, kept as the engine emitted it; a person's reply after a handoff has the role `HumanAgent` |
| ChannelMessage | `ai.channel_message` | Every message a channel carried, inbound or outbound, with the gateway's decision (Process, Offline, Throttled, Dropped); the rate limiter counts over it |
| WidgetEvent | `ai.widget_event` | One widget event (name, properties, time) for a deployment and, where there is one, a conversation; the deployment's completion, handoff, drop-off and OTP figures are counted over it (D231) |

## Budgets

```mermaid
erDiagram
  AGENT ||--o{ AGENT_BUDGET : limited_by
  ROUTE ||--o{ AGENT_BUDGET : cheaper_route_of
  AGENT_BUDGET ||--o{ BUDGET_PERIOD : has
  AGENT_BUDGET ||--o{ BUDGET_EVENT : logs
  BUDGET_PERIOD ||--o{ BUDGET_EVENT : in
  AGENT_BUDGET ||--o{ BUDGET_CHANGE : changed_by
  PERSON ||--o{ BUDGET_CHANGE : made
```

| Entity | Table | Description |
| --- | --- | --- |
| AgentBudget | `gov.agent_budget` | An estimated-cost limit for an agent over a period, with effective dates, warning threshold, action at 100% and the cheaper route. Status (Active, Scheduled, Expired) is derived from the dates |
| BudgetPeriod | `gov.budget_period` | One period's estimated spend and run count; usage percentage is derived |
| BudgetEvent | `gov.budget_event` | Warning sent, hard limit reached, action applied |
| BudgetChange | `gov.budget_change` | The budget changes log |

Estimated cost per run is stored on `ai.run` and `ai.run_step`; daily and monthly figures are
computed from runs. Agent budgets are separate from the per-run money ceilings that D73 removed.

## Integrations

```mermaid
erDiagram
  PERSON ||--o{ INTEGRATION_CLIENT : owns
  INTEGRATION_CLIENT ||--o{ CLIENT_KEY : has
  INTEGRATION_CLIENT ||--o{ CLIENT_PERMISSION : allowed
  INTEGRATION_CLIENT ||--o{ CLIENT_AGENT : may_run
  AGENT ||--o{ CLIENT_AGENT : run_by
  INTEGRATION_CLIENT ||--o| CLIENT_MCP_EXPOSURE : exposes
  INTEGRATION_CLIENT ||--o| CLIENT_AGUI_EXPOSURE : exposes
```

| Entity | Table | Description |
| --- | --- | --- |
| IntegrationClient | `gov.integration_client` | An external system with a client id, owner, status and whether it may run all agents |
| ClientKey | `gov.client_key` | A key stored as a visible prefix and a hash, with expiry, last use and status |
| ClientPermission | `gov.client_permission` | The client's allowed permissions |
| ClientAgent | `gov.client_agent` | The agents a client may run when not all agents |
| ClientMcpExposure, ClientAguiExposure | `gov.client_mcp_exposure`, `gov.client_agui_exposure` | One row each per client: the platform MCP tools exposed, and the AG-UI events and origins allowed |

## Governance and settings

```mermaid
erDiagram
  PERSON ||--o{ SETTINGS_VERSION : changed
  PERSON ||--o{ BRANDING_ASSET : uploaded
  PERSON ||--o{ SYSTEM_STATE : paused
  PERSON ||--o{ MAIL_NOTIFICATION : emailed
```

The remaining governance tables stand alone: `gov.feature_flag`, `gov.doc_page`, `gov.log_entry`,
`gov.outbox_event` and `audit.audit_entry`, whose actor and object are polymorphic.

| Entity | Table | Description |
| --- | --- | --- |
| AuditEntry | `audit.audit_entry` | The append-only audit trail: actor, action, object, detail, outcome (Allowed or Denied), correlation id and address. Partitioned by month on `at` |
| SettingsVersion | `gov.settings_version` | Every saved version of the settings, as a JSON object |
| BrandingAsset | `gov.branding_asset` | The light and dark logos and the favicon, one per kind |
| FeatureFlag | `gov.feature_flag` | A named, grouped switch |
| SystemState | `gov.system_state` | One row: whether all agents are paused, by whom and when |
| DocPage | `gov.doc_page` | An in-product documentation guide in English and Arabic |
| LogEntry | `gov.log_entry` | Application and run log lines read by the Logs screen |
| OutboxEvent | `gov.outbox_event` | The transactional outbox: a domain event written with its row and relayed to Temporal or Valkey afterwards |
| MailNotification | `gov.mail_notification` | One email to one person (a request or work item notification, an invitation, an agent's email or a test), keyed so a retry writes nothing twice, with its status and retries (D240, D242, D247). `subject_id` and `run_id` are polymorphic or have no foreign key |
