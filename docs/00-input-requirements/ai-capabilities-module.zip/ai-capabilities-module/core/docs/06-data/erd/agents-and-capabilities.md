# Entity relationships: agents and capabilities

| Item | Value |
| --- | --- |
| Purpose | The entities of the `ai` schema that describe agents, runs, the inbox, skills, connectors, memory, knowledge and model routes, and how they relate |
| Audience | Developers, architects, business analysts |
| Related | [Data model overview](../overview.md) · [Organisation and work](organisation-and-work.md) · [Engage and governance](engage-and-governance.md) · [Agent runtime specification](../../agent-runtime-spec.md) · [Data dictionary](../data-dictionary/README.md) |
| Last verified against code | 2026-10-29 |

Drawn from the foreign keys in `apps/web/src/db/schema/ai.ts` and migration `0033`. Dotted lines
are relationships without a foreign key. Fields are in the [data dictionary](../data-dictionary/README.md).

## Agents, runs and the inbox

```mermaid
erDiagram
  ORG_UNIT ||--o{ AGENT : places
  AGENT ||--o{ AGENT_VERSION : versions
  PERSON ||--o{ AGENT_VERSION : publishes
  AGENT_VERSION }o--o| ROUTE : primary_route
  AGENT_VERSION }o--o| ROUTE : fallback_route
  AGENT_VERSION ||--o{ AGENT_SKILL : enables
  SKILL_VERSION ||--o{ AGENT_SKILL : enabled_as
  AGENT_VERSION ||--o{ AGENT_TOOL_MODE : sets
  CONNECTOR_TOOL ||--o{ AGENT_TOOL_MODE : configured_per_version
  AGENT_VERSION ||--o{ AGENT_PLATFORM_TOOL : grants
  AGENT_VERSION ||--o{ AGENT_MEMORY_ACCESS : grants
  MEMORY_SCOPE ||--o{ AGENT_MEMORY_ACCESS : granted
  AGENT_VERSION ||--o{ AGENT_KNOWLEDGE_ACCESS : grants
  KNOWLEDGE_COLLECTION ||--o{ AGENT_KNOWLEDGE_ACCESS : granted
  AGENT_VERSION ||--o{ PLAYGROUND_TEST : tested_by
  RUN ||--o{ PLAYGROUND_TEST : recorded_as
  AGENT ||--o{ RUN : executes
  AGENT_VERSION ||--o{ RUN : pinned_by
  RUN ||--o{ RUN : parent_of
  RUN ||--o{ RUN : replay_of
  RUN ||--o{ RUN_STEP : has
  RUN ||--o{ APPROVAL : requests
  APPROVAL ||--o{ APPROVAL_DECISION : receives
  PERSON ||--o{ APPROVAL_DECISION : decides
  RUN ||--o{ AGENT_QUESTION : asks
  PERSON ||--o{ AGENT_QUESTION : answers
  PERSON ||--o{ INBOX_ITEM : receives
  PERSON ||--o{ ASSISTANT_CHAT : keeps
  ASSISTANT_CHAT ||--o{ ASSISTANT_CHAT_MESSAGE : contains
  WORK_ITEM ||--o{ APPROVAL : subject_of
  REQUEST ||--o{ APPROVAL : subject_of
```

| Entity | Table | Description |
| --- | --- | --- |
| Agent | `ai.agent` | A versioned AI worker with a code, an org position and a status. `is_system` marks the platform's own agents, whose trust is fixed; `is_builtin` marks the Platform Assistant the platform depends on (D65); `default_version` is the generation of seeded defaults it was created from or reset to (D99). `active_version_id` has no foreign key |
| AgentVersion | `ai.agent_version` | Instructions, execution profile, primary and fallback route (chat routes only, D337), trust, memory switch, run budget, release notes and eval score. One active version per agent |
| AgentSkill | `ai.agent_skill` | Skill versions enabled for an agent version |
| AgentToolMode | `ai.agent_tool_mode` | Auto, Approval or Denied per connector tool; never looser than the tool's tier. The only list of the connector tools a version may use (D227); a T0 read is granted at Auto and any other tool at Approval (D264) |
| AgentPlatformTool | `ai.agent_platform_tool` | The platform and harness-answered tools a version is granted (D38, D80): the tools of the built-in Platform connector, which are read from the catalogue rather than stored as connector tools (D228). No rows means no tools |
| AgentMemoryAccess, AgentKnowledgeAccess | `ai.agent_memory_access`, `ai.agent_knowledge_access` | Memory scopes (Read or ReadWrite) and knowledge collections a version may use |
| PlaygroundTest | `ai.playground_test` | A "Test in playground" input, output, duration and estimated cost |
| Run | `ai.run` | One execution of an agent version: trigger, context, status, timings, tokens, estimated cost, Temporal workflow id, trace id, replay link, the grant it started with (`granted_tools`, D35) and the run that delegated it (`parent_run_id`, D46; `ON DELETE SET NULL`). A finished run can be deleted with its steps, approvals, questions and playground tests (D300). The full trace is in Phoenix |
| RunStep | `ai.run_step` | The run viewer's timeline, built by the agent runtime from the mission's messages and inserted by `run_finish`: a step per model response with text, a step per tool call with its arguments and result, and a closing `finish` step (D300). Partitioned by month on `started_at` |
| Approval | `ai.approval` | A request for a human decision, shown in the Inbox and as a room card; bound to the call's arguments hash and target record version, single use and time limited (D20, D21). `requested_by_id` has no foreign key |
| ApprovalDecision | `ai.approval_decision` | One approver's decision, with a reason required to reject; one per approver per approval |
| AgentQuestion | `ai.agent_question` | A question a run asks a person or group, optionally with options, and its answer |
| InboxItem | `ai.inbox_item` | One per person per item (approval, question, mention, SLA warning, review); the Inbox tabs and badge. `source_id` is polymorphic |
| AssistantChat, AssistantChatMessage | `ai.assistant_chat`, `ai.assistant_chat_message` | Saved page-assistant conversations, per person, latest 30 kept by the service |

## Skills

```mermaid
erDiagram
  PERSON ||--o{ SKILL : authors
  SKILL ||--o{ SKILL_VERSION : versions
  SKILL_VERSION ||--o| SKILL_SCAN_RESULT : scanned_by
  SKILL_VERSION ||--o{ SKILL_TEST_CASE : tested_by
  SKILL_VERSION ||--o{ AGENT_SKILL : enabled_as
```

| Entity | Table | Description |
| --- | --- | --- |
| Skill | `ai.skill` | A package in the Agent Skills format, named by its `SKILL.md`, with a source and tags. `current_version_id` has no foreign key; "Where used" is derived |
| SkillVersion | `ai.skill_version` | A package reference, checksum, front-matter validity, the tools the skill declares (`declared_tools`) and Draft or Published |
| SkillScanResult | `ai.skill_scan_result` | The security scan: scripts, network calls, prompt-injection patterns, embedded secrets, sandbox only |
| SkillTestCase | `ai.skill_test_case` | Test cases of the test bench, which is not offered: kept, unused (D333) |

## Connectors

```mermaid
erDiagram
  CONNECTOR_CATALOG_ENTRY ||--o{ CONNECTOR : installed_as
  CONNECTOR ||--o{ CONNECTOR_TOOL : exposes
  CONNECTOR ||--o{ CONNECTOR_ALLOWED_AGENT : allows
  AGENT ||--o{ CONNECTOR_ALLOWED_AGENT : allowed
  CONNECTOR_TOOL ||--o{ AGENT_TOOL_MODE : configured_per_version
```

| Entity | Table | Description |
| --- | --- | --- |
| Connector | `ai.connector` | An MCP server (Streamable HTTP or stdio) or a REST API described by OpenAPI, with its auth type (`OAuth`, `ClientCredentials`, `Bearer`, `ApiKey`, `Basic`, `None`), one encrypted typed credential (D296), default tier for new tools, enabled flag and handshake status. `internal://platform` is the built-in Platform connector, whose tools are the platform catalogue (D228) |
| ConnectorTool | `ai.connector_tool` | A tool with its MCP annotations and tier; `operation` describes the HTTP call for an OpenAPI connector |
| ConnectorAllowedAgent | `ai.connector_allowed_agent` | Not read or written: which agents use a connector is the agent version's grant (`AGENT_TOOL_MODE`), and a run reaches every enabled connector narrowed by its project's allowed connectors. Dropping the table is an open decision (D227) |
| ConnectorCatalogEntry | `ai.connector_catalog_entry` | A template with default URL, auth and tool count, listed to agents by `connector_list` and named by `connector_create`; the console offers no catalogue to browse |

## Memory

```mermaid
erDiagram
  MEMORY_SCOPE ||--o{ MEMORY_SCOPE : contains
  PERSON ||--o{ MEMORY_SCOPE : owns_private
  MEMORY_SCOPE ||--o{ MEMORY : holds
  MEMORY ||--o{ MEMORY_VERSION : versions
  MEMORY_VERSION ||--o{ MEMORY_ENTRY : contains
  MEMORY ||--o{ MEMORY_REVIEW : reviewed_by
  MEMORY_VERSION ||--o{ MEMORY_REVIEW : proposed_in
  AGENT ||--o{ MEMORY_REVIEW : proposes
  PERSON ||--o{ MEMORY_REVIEW : reviews
```

| Entity | Table | Description |
| --- | --- | --- |
| MemoryScope | `ai.memory_scope` | Organisation, business unit, agent or session, as a tree. An agent scope set for one person (`person_id`) is private to that person and agent (D68, D116) |
| Memory | `ai.memory` | A titled memory in a scope with owner, status, access and write policy, and review dates |
| MemoryVersion | `ai.memory_version` | Content (inline or in object storage), change note, author and the version it was restored from |
| MemoryEntry | `ai.memory_entry` | An entry with its source (agent run, person or document) |
| MemoryReview | `ai.memory_review` | The pending-review flow for an agent-proposed version |

Approved memory entries become Graphiti episodes in per-scope groups on Neo4j, so a superseded rule
is invalidated rather than recalled; that graph is rebuildable.

## Knowledge

```mermaid
erDiagram
  PROJECT ||--o{ KNOWLEDGE_COLLECTION : contains
  KNOWLEDGE_COLLECTION ||--o{ KNOWLEDGE_SOURCE : draws_from
  KNOWLEDGE_SOURCE ||--o{ KNOWLEDGE_DOCUMENT : yields
  KNOWLEDGE_COLLECTION ||--o{ INGESTION_JOB : ingested_by
  KNOWLEDGE_SOURCE ||--o{ INGESTION_JOB : ingested_by
  KNOWLEDGE_COLLECTION ||--o{ RETRIEVAL_TEST : tested_by
  PERSON ||--o{ RETRIEVAL_TEST : runs
```

| Entity | Table | Description |
| --- | --- | --- |
| KnowledgeCollection | `ai.knowledge_collection` | A set of sources ingested for cited retrieval, with index, chunking, models and retrieval configuration as JSON objects, status, last error and entity count |
| KnowledgeSource | `ai.knowledge_source` | An upload, URL crawl or MCP resource, with its configuration, document count, status and last error |
| KnowledgeDocument | `ai.knowledge_document` | A raw document in object storage with checksum, status, chunk count and size. Passages are in `awp_kb`; entities in Neo4j |
| IngestionJob | `ai.ingestion_job` | Ingest, re-index or re-index all, with progress (0–100) and its Temporal workflow id |
| RetrievalTest | `ai.retrieval_test` | A logged retrieval test: query, mode, duration and results |

## Models and routes

```mermaid
erDiagram
  MODEL_PROVIDER ||--o{ PROVIDER_CONNECTION : holds
  PROVIDER_CONNECTION ||--o{ CONNECTION_ALLOWED_MODEL : allows
  ROUTE ||--o{ ROUTE_STEP : chains
  MODEL_PROVIDER ||--o{ ROUTE_STEP : used_by
  PROVIDER_CONNECTION ||--o{ ROUTE_STEP : used_by
```

| Entity | Table | Description |
| --- | --- | --- |
| ModelProvider | `ai.model_provider` | A cloud provider or a custom on-prem engine, with the provider identity agentgateway understands (`gateway_provider`) |
| ProviderConnection | `ai.provider_connection` | A named connection with region, base URL, auth, encrypted secret, and the result and time of its last test |
| ConnectionAllowedModel | `ai.connection_allowed_model` | A model a connection allows, with its kind, modalities, context window and prices. Routes may use only these |
| Route | `ai.route` | An alias (Standard, Typesafe, Voice, Embedding or Decision) with typesafe or voice settings; rendered as an agentgateway route |
| RouteStep | `ai.route_step` | The ordered failover chain: provider, connection and model name. A route step names the model by name; it has no foreign key to `connection_allowed_model` |

Agents using a route are derived from `ai.agent_version`.
