# Entity relationships: organisation and work

| Item | Value |
| --- | --- |
| Purpose | The entities of the `core` and `work` schemas and how they relate |
| Audience | Developers, architects, business analysts |
| Related | [Data model overview](../overview.md) · [Agents and capabilities](agents-and-capabilities.md) · [Engage and governance](engage-and-governance.md) · [Data dictionary](../data-dictionary/README.md) |
| Last verified against code | 2026-10-29 |

The diagrams are drawn from the foreign keys in `apps/web/src/db/schema/core.ts` and `work.ts`.
Where a relationship exists only in the domain layer, with no foreign key, the description table
says so: polymorphic principals (`principal_type` + `principal_id`), references into partitioned
tables, and references across feature boundaries that the schema leaves as plain `uuid`
columns. A foreign key added only by a migration is drawn too and named in the description table.
Fields are in the [data dictionary](../data-dictionary/README.md).

## Organisation and identity

```mermaid
erDiagram
  ORGANISATION }o--o| CALENDAR : "working and holiday calendar"
  CALENDAR ||--o{ CALENDAR_HOLIDAY : has
  ORG_UNIT ||--o{ ORG_UNIT : parent_of
  ORG_UNIT ||--o{ PERSON : contains
  ORG_UNIT ||--o{ AGENT : contains
  PERSON ||--o{ PASSKEY : registers
  PERSON ||--o{ PERSON_INVITATION : receives
  PERSON ||--o| NOTIFICATION_PREFERENCE : has
  PERSON ||--o{ ROLE_ASSIGNMENT : holds
  ROLE ||--o{ ROLE_ASSIGNMENT : granted_by
  ROLE ||--o{ ROLE_PERMISSION : includes
  PERMISSION ||--o{ ROLE_PERMISSION : in
  CORE_GROUP ||--o{ GROUP_MEMBER : has
  PERSON ||--o{ AUTH_ACCOUNT : signs_in_with
  PERSON ||--o{ AUTH_SESSION : has
```

| Entity | Table | Description |
| --- | --- | --- |
| Organisation | `core.organisation` | The single organisation the installation serves; exactly one row (unique index on `true`) |
| Calendar, CalendarHoliday | `core.calendar`, `core.calendar_holiday` | Working days and hours, and dated holidays, used for SLAs and schedules |
| OrgUnit | `core.org_unit` | A department or team; a hierarchy through `parent_org_unit_id`. `lead_person_id` has no foreign key |
| Person | `core.person` | A user of the console. `reports_to_type`/`reports_to_id` is a polymorphic reporting line (person or agent) |
| PersonInvitation | `core.person_invitation` | An emailed invitation to the platform, identified by its token's hash; works once and for 7 days (D248) |
| Passkey | `core.passkey` | A WebAuthn credential (My profile → Security) |
| NotificationPreference | `core.notification_preference` | One row per person: which notifications and system emails leave the product |
| Role, Permission, RolePermission, RoleAssignment | `core.role`, `core.permission`, `core.role_permission`, `core.role_assignment` | Permission sets with Allow or Deny per permission (explicit deny wins), assigned to a person at organisation, org unit or project scope |
| Group, GroupMember | `core.group`, `core.group_member` | Named sets of principals used as audiences and approvers. `CORE_GROUP` in the diagram is `core.group` |
| ExternalContact | `core.external_contact` | A widget, WhatsApp or other sender who is not a user; unique by channel and address |
| Auth.js tables | `core.auth_account`, `core.auth_session`, `core.auth_verification_token` | Server-side sessions and OIDC accounts kept by Auth.js v5; `auth_session` carries user agent and address so My profile can list and revoke sessions |

## Projects

```mermaid
erDiagram
  ORG_UNIT ||--o{ PROJECT : owns
  PERSON ||--o{ PROJECT : owner_of
  PROJECT ||--o{ PROJECT_MEMBER : has
  PROJECT ||--o{ PROJECT_ALLOWED_AGENT : allows
  PROJECT ||--o{ PROJECT_ALLOWED_CONNECTOR : allows
  PROJECT ||--o{ PROJECT_APPROVAL_RULE : requires
  PROJECT ||--o{ DECISION : records
  PERSON ||--o{ DECISION : decided
```

| Entity | Table | Description |
| --- | --- | --- |
| Project | `work.project` | A container for work with its own members, sensitivity and policies. Progress and counts are derived |
| ProjectMember | `work.project_member` | A person or agent with a project role (Owner, Member, Agent); polymorphic principal |
| ProjectAllowedAgent | `work.project_allowed_agent` | Agents allowed in the project; empty means every agent the trust level allows. `agent_id` has no foreign key |
| ProjectAllowedConnector | `work.project_allowed_connector` | Connectors allowed in the project. `connector_id` has no foreign key |
| ProjectApprovalRule | `work.project_approval_rule` | The "Human approval for" list: an action or tool raised to a minimum tier; a rule can only raise a tier |
| Decision | `work.decision` | "Recent decisions": a title with its source (approval, change set or room); no change-set decision is recorded since D371 |

## Discussion rooms

```mermaid
erDiagram
  PROJECT ||--o{ DISCUSSION_ROOM : contains
  DISCUSSION_ROOM ||--o{ DISCUSSION_ROOM : forked_into
  DISCUSSION_ROOM ||--o{ ROOM_PARTICIPANT : has
  DISCUSSION_ROOM ||--o{ ROOM_MESSAGE : contains
  DISCUSSION_ROOM ||--o{ ROOM_WORK_ITEM_LINK : links
  PERSON ||--o{ MESSAGE_FEEDBACK : gives
  ROOM_MESSAGE ||..o{ MESSAGE_FEEDBACK : receives
  ROOM_WORK_ITEM_LINK }o..|| WORK_ITEM : points_to
  DISCUSSION_ROOM ||..o| CONTEXT_HANDOFF : keeps
```

Dotted lines are relationships without a foreign key.

| Entity | Table | Description |
| --- | --- | --- |
| DiscussionRoom | `work.discussion_room` | A topic-scoped room in a project, with type, source, status, turn-taking mode, agent hop limit and cost cap. `mirror_channel_id` has no foreign key |
| RoomParticipant | `work.room_participant` | A person or agent with a room role (Owner, Member, LeadAgent, MemberAgent, Observer) |
| RoomMessage | `work.room_message` | Append-only and partitioned by month on `created_at`. `content_json` holds text, mentions and cards; `run_id`, `artifact_id` and `approval_id` have no foreign key |
| MessageFeedback | `work.message_feedback` | Helpful or Not helpful on an agent message, one per person per message; `message_id` has no foreign key because messages are partitioned |
| ContextHandoff | `work.context_handoff` | Goal, decisions, open questions and next step, one per owner (room, work item, request or run); written when a room closes and at the end of every run |
| RoomWorkItemLink | `work.room_work_item_link` | "Linked work items", optionally with the message the item came from |

A fork copies the room's type, turn-taking, hop limit, cost cap and participants, and carries the
"What should change?" text over as the first message of the new room
(`features/rooms/repository.ts` `forkRoom`).

## Requests and request types

```mermaid
erDiagram
  REQUEST_TYPE ||--o{ REQUEST_TYPE_VERSION : versions
  PROJECT ||--o{ REQUEST_TYPE_VERSION : default_project_of
  REQUEST_TYPE_VERSION ||--o{ ATTRIBUTE_DEFINITION : defines
  TRANSITION_STEP |o--o{ ATTRIBUTE_DEFINITION : asks
  REQUEST_TYPE_VERSION ||--o{ TRANSITION_STEP : has
  TRANSITION_STEP ||--o{ STEP_AUDIENCE : has
  TRANSITION_STEP ||--o{ ROUTING_RULE : leaves_by
  ROUTING_RULE }o--o| TRANSITION_STEP : goes_to
  PROJECT ||--o{ REQUEST : contains
  REQUEST_TYPE_VERSION ||--o{ REQUEST : types
  TRANSITION_STEP ||--o{ REQUEST : current_step_of
  PERSON |o--o{ REQUEST : has_taken
  REQUEST ||--o{ REQUEST : parent_of
  DISCUSSION_ROOM ||--o{ REQUEST : origin_of
  REQUEST ||--o{ REQUEST_EVENT : history
  REQUEST ||..o{ ATTACHMENT : has
```

| Entity | Table | Description |
| --- | --- | --- |
| RequestType | `work.request_type` | A configurable kind of request, with a code and a category. `current_published_version_id` has no foreign key; the open count is derived |
| RequestTypeVersion | `work.request_type_version` | Draft, Published or Retired; carries decomposition, SLA, default project, intake channels and entry modes. Requests pin the version |
| AttributeDefinition | `work.attribute_definition` | A dynamic attribute, asked on the request form or, through `step_id`, at one step (`ON DELETE SET NULL`: a deleted step's attributes go back to the form, D304). A list's choices are a `jsonb` array of `{value, labelEn, labelAr}`. One definition is described by `packages/contracts/schemas/attribute-definition.schema.json` |
| TransitionStep | `work.transition_step` | An ordered stage with an SLA, a terminal flag and, on a terminal step, the outcome it leaves the request at |
| StepAudience | `work.step_audience` | Who may act on, be notified of, or view a step; `sequence` orders sequential approval. A terminal step has none |
| RoutingRule | `work.routing_rule` | A condition (`expression`) or an action (`action_name`, optionally with a condition, D262) that moves a request to another step. Deleted with the step it leaves or the step it goes to (`ON DELETE CASCADE` on both, migration 0065) |
| Request | `work.request` | Something a person or external contact asked for, at a current step, with an SLA due time and dynamic attributes. `claimed_by` is the person who took the current step (D147); its foreign key is added by migration 0043 and not declared in `work.ts`. `origin_deployment_id` has no foreign key |
| RequestEvent | `work.request_event` | The "History & audit" tab, with the attribute values an action supplied (D314); append-only and partitioned by month on `at` |
| Attachment | `work.attachment` | A file on a request, work item, room or visitor conversation (polymorphic owner); content in object storage |

## Work items

```mermaid
erDiagram
  PROJECT ||--o{ WORK_ITEM : contains
  WORK_ITEM ||--o{ WORK_ITEM : sub_items
  REQUEST ||--o{ WORK_ITEM : produces
  REQUEST_TYPE_VERSION ||--o{ WORK_ITEM : attribute_schema_of
  WORK_ITEM ||--o{ WORK_ITEM_ACTIVITY : history
  WORK_ITEM ||..o{ ATTACHMENT : has
  PERSON ||--o{ SAVED_VIEW : saves
```

| Entity | Table | Description |
| --- | --- | --- |
| WorkItem | `work.work_item` | A Task, Sub item or Bug assigned to a person, agent, group or nobody, with a reviewer, a due time, an origin and dynamic attributes. "Hot" (open and high priority, blocked or due within 2 days) and progress are derived |
| WorkItemActivity | `work.work_item_activity` | The "Activity" tab; append-only and partitioned by month on `at` |
| SavedView | `work.saved_view` | A named search a person saved on Work Items or Requests |

## Scheduled work items

```mermaid
erDiagram
  PROJECT ||--o{ SCHEDULED_WORK_ITEM : contains
  REQUEST_TYPE ||--o{ SCHEDULED_WORK_ITEM : created_by
  SCHEDULED_WORK_ITEM ||--o{ SCHEDULE_RUN : fires
  SCHEDULE_RUN }o--o| WORK_ITEM : created
  SCHEDULE_RUN }o--o| REQUEST : created
```

| Entity | Table | Description |
| --- | --- | --- |
| ScheduledWorkItem | `work.scheduled_work_item` | Creates either a work item of a type or a request of a request type (exactly one) on a repeat rule or an event, for an agent, person or group. Maps one to one to a Temporal Schedule (`temporal_schedule_id`) |
| ScheduleRun | `work.schedule_run` | One firing: Created, Failed or Skipped, with what it created and the reason |

## Artifacts and files

```mermaid
erDiagram
  PROJECT ||--o{ ARTIFACT : contains
  ARTIFACT ||--o{ ARTIFACT_VERSION : versions
  PROJECT ||--o{ PROJECT_FILE : contains
  PERSON ||--o{ PROJECT_FILE : uploaded
  PROJECT_FILE ||--o{ FILE_ACCESS_GRANT : grants
```

| Entity | Table | Description |
| --- | --- | --- |
| Artifact | `work.artifact` | An output produced by an agent or person, linked to a work item, request or room. `run_id`, `produced_by_id` and `current_version_id` have no foreign key |
| ArtifactVersion | `work.artifact_version` | A versioned content reference with size and type |
| ProjectFile | `work.project_file` | A file a person uploaded, with a scope of use and a status (including Quarantined) |
| FileAccessGrant | `work.file_access_grant` | The people and agents a file is shared with when its scope is Selected; checked before a URL is signed |

## Dashboard card comments

```mermaid
erDiagram
  CARD_COMMENT_THREAD ||--o{ CARD_COMMENT : contains
  PERSON ||--o{ CARD_COMMENT : writes
  CARD_COMMENT ||--o{ CARD_COMMENT_MENTION : names
  PERSON ||--o{ CARD_COMMENT_MENTION : mentioned
  CARD_COMMENT_THREAD ||--o{ CARD_COMMENT_READ : read_by
  PERSON ||--o{ CARD_COMMENT_READ : reads
  WORK_ITEM ||--o{ CARD_COMMENT : raised_from
```

| Entity | Table | Description |
| --- | --- | --- |
| CardCommentThread | `work.card_comment_thread` | One thread per commentable dashboard card (`runs`, `tasks`, `attention`, `live`) |
| CardComment | `work.card_comment` | Text, a captured area of the card, or both; a deleted comment keeps its row. "Make it a task" links the work item it raised |
| CardCommentMention | `work.card_comment_mention` | Who a comment named, written with the comment so the Inbox list and the notification are the same |
| CardCommentRead | `work.card_comment_read` | How far one person has read one thread |
