# 06 — Data

> ERDs, schemas, data flows, data dictionary.
> Owner: Data/Backend lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Data model](data-model.md) | draft | 1.0 | 2026-10-30 |
| [Data dictionary](data-dictionary.md) | draft | 1.0 | 2026-10-30 |

## Entity relationships

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Entity relationships: organisation and work](erd/organisation-and-work.md) | draft | 1.0 | 2026-10-30 |
| [Entity relationships: agents and capabilities](erd/agents-and-capabilities.md) | draft | 1.0 | 2026-10-30 |
| [Entity relationships: engage and governance](erd/engage-and-governance.md) | draft | 1.0 | 2026-10-30 |

## Data dictionary by area

[data-dictionary.md](data-dictionary.md) is the index and explains how the dictionary was built; one file per
entity group follows.

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Organisation and identity](data-dictionary/organisation-and-identity.md) | draft | 1.0 | 2026-10-30 |
| [Projects](data-dictionary/projects.md) | draft | 1.0 | 2026-10-30 |
| [Discussion rooms](data-dictionary/discussion-rooms.md) | draft | 1.0 | 2026-10-30 |
| [Requests and request types](data-dictionary/requests.md) | draft | 1.0 | 2026-10-30 |
| [Work items](data-dictionary/work-items.md) | draft | 1.0 | 2026-10-30 |
| [Scheduled work items](data-dictionary/scheduled-work.md) | draft | 1.0 | 2026-10-30 |
| [Artifacts and files](data-dictionary/artifacts-and-files.md) | draft | 1.0 | 2026-10-30 |
| [Agents, runs and the inbox](data-dictionary/agents-runs-inbox.md) | draft | 1.0 | 2026-10-30 |
| [Skills](data-dictionary/skills.md) | draft | 1.0 | 2026-10-30 |
| [Connectors](data-dictionary/connectors.md) | draft | 1.0 | 2026-10-30 |
| [Memory](data-dictionary/memory.md) | draft | 1.0 | 2026-10-30 |
| [Knowledge](data-dictionary/knowledge.md) | draft | 1.0 | 2026-10-30 |
| [Models and routes](data-dictionary/models-and-routes.md) | draft | 1.0 | 2026-10-30 |
| [Channels, embedded deployments and storylines](data-dictionary/engage.md) | draft | 1.0 | 2026-10-30 |
| [Budgets](data-dictionary/budgets.md) | draft | 1.0 | 2026-10-30 |
| [Integrations](data-dictionary/integrations.md) | draft | 1.0 | 2026-10-30 |
| [Governance and settings](data-dictionary/governance.md) | draft | 1.0 | 2026-10-30 |
| [Dashboard card comments](data-dictionary/comments.md) | draft | 1.0 | 2026-10-30 |
