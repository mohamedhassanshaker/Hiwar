# Data dictionary: channels, embedded deployments and storylines

| Item | Value |
| --- | --- |
| Purpose | Fields of channels, embedded deployments, surfaces, storylines and their versions and steps, visitor conversations, widget events and channel messages |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/engage-and-governance.md#channels-deployments-and-storylines) · [Data model overview](../overview.md) · [Flow F-05](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Channel — `ai.channel`

Stories: S-61 (`UC-61.1-01` … `-10`, FR-073), `SC-CH-01`, `-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Channel | Enum | Yes | Live: `WebWidget`, `WhatsApp`, `MicrosoftTeams`; coming soon (cannot be enabled): `Slack`, `Email`, `Sms`, `VoiceIvr`, `Telegram`, `Webex`, `GoogleChat`, `Instagram`, `FacebookMessenger`; one row per type | `UC-61.1-01`, `-10` | `type text NOT NULL`, unique, `CHECK` against `CHANNEL_TYPES` |
| Enabled | Boolean | — | Off: inbound messages are not processed and senders get the offline behaviour | `UC-61.1-04` | `is_enabled boolean NOT NULL DEFAULT false` |
| Status | Enum | — | `Enabled`, `Degraded`, `Disabled`; Degraded shows on the dashboard and System page | `UC-61.1-01`, `-06` | `status text NOT NULL DEFAULT 'Disabled'`, `CHECK` against `CHANNEL_STATUSES` |
| Bind to | Enum + Reference | — | `EmbeddedDeployment`, `RoomMirror`, `RequestIntake` | `UC-61.1-02`, `SC-CH-02` | `binding_type text` (`CHECK` against `CHANNEL_BINDING_TYPES`), `binding_id uuid` |
| Unknown senders | Enum | — | `ExternalContact`, `Ignore`; ignored messages are dropped and logged | `UC-61.1-02`, `-08` | `unknown_senders text NOT NULL DEFAULT 'ExternalContact'`, `CHECK` |
| Rate limit (messages per minute) | Number | — | Extra messages are throttled with a notice | `UC-61.1-02`, `-09` | `rate_limit_per_minute integer NOT NULL DEFAULT 60` |
| Business hours | Enum | — | `AlwaysOn`, `WorkingCalendar` | `UC-61.1-02`, `-07` | `business_hours text NOT NULL DEFAULT 'AlwaysOn'`, `CHECK` |
| Offline message | Text | — | Sent out of hours or when disabled | `UC-61.1-04`, `-07` | `offline_message_en`, `offline_message_ar text` |
| Credentials | Secret | — | "Changes are hot-reloaded" | `UC-61.1-02` | `secret_ref bytea` (ciphertext) |
| Test result | Date-time, JSON | — | Credentials valid, outbound delivered, inbound webhook reachable, round-trip time; a failing check is marked with the reason | `UC-61.1-03`, `-05` | `last_test_at timestamptz`, `last_test_result_json jsonb` |

Schema-only: `endpoint_url text` (where outbound messages are posted; migration `0011`) and
`inbound_secret_ref bytea` (verifies that an inbound webhook came from the provider).

## Embedded deployment — `ai.embedded_deployment`

Stories: S-62 (`UC-62.1-01` … `-04`, FR-074), S-63 (`UC-63.1-01` … `-09`, FR-075), `SC-EMB-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Name (English, Arabic) | Text | Yes | | `UC-62.1-02`, `UC-63.1-01` | `name_en`, `name_ar text NOT NULL`; `code text NOT NULL` unique (e.g. `dep_7f3a9c`) |
| Default agent | Reference → Agent | Yes | A paused or erroring agent shows a warning and offers the handoff queue | `UC-62.1-02`, `UC-63.1-09` | `default_agent_id uuid` → `ai.agent` |
| Status | Enum | — | `Enabled`, `Disabled`, `Draft`; created Draft; Enabled needs allowed origins for the web widget | `UC-62.1-02`, `UC-63.1-03`, `-04` | `status text NOT NULL DEFAULT 'Draft'`, `CHECK` against `DEPLOYMENT_STATUSES` |
| Allowed origins | List | — | Any other origin does not load and is logged | `UC-63.1-01`, `UC-65.1-10` | `allowed_origins text[] NOT NULL DEFAULT '{}'` (GIN index) |
| Visitor identity | Enum | — | `AnonymousOtpStepUp`, `SignedJwt`; without a valid JWT visitors are anonymous or refused, per configuration | `UC-63.1-01`, `-06` | `visitor_identity text NOT NULL DEFAULT 'AnonymousOtpStepUp'`; `visitor_jwt_fallback text NOT NULL DEFAULT 'Anonymous'` (`Anonymous`, `Refuse`); `visitor_jwt_secret_ref bytea` |
| Human handoff queue | Text | — | Talk to a person is offered only when it is set, and the server refuses a handoff without it (D340) | `UC-63.1-01` | `handoff_queue text` |
| Rate limit per visitor | Number | — | | `UC-63.1-01`, `UC-65.1-12` | `rate_limit_per_visitor integer NOT NULL DEFAULT 30` |
| Widget title, accent colour, welcome message | Text | — | A colour failing the contrast check warns with a suggestion | `UC-63.1-01`, `-05` | `widget_title_en`, `widget_title_ar`, `accent_colour`, `welcome_message_en`, `welcome_message_ar text` |
| Disclaimer | Text, Boolean | — | The notice under the widget's header, in English and Arabic; whether a visitor may close it | Widget specification 3.3, D231 | `disclaimer_en`, `disclaimer_ar text`; `disclaimer_dismissible boolean NOT NULL DEFAULT true` |
| Quick actions | List | — | The chips under the greeting, in order, at most 12: `id` (lowercase letters, digits, underscores; unique), `labelEn`, `labelAr`, `storyline` (one of the deployment's storyline codes), `pages` (`*` is every page), `minIdentity` (`anonymous`, `otp_verified`, `logged_in`) | Widget specification 8, D231 | `quick_actions_json jsonb NOT NULL DEFAULT '[]'`, `CHECK` it is an array |
| Voice input, read aloud | Boolean | — | The microphone in the composer; the speaker on assistant messages. Voice input is off unless switched on (D340, migration `0072`) | Widget specification 3.3, D231, D340 | `voice_input boolean NOT NULL DEFAULT false`, `read_aloud boolean NOT NULL DEFAULT true` |
| Session idle timeout | Number | — | Minutes, 1–1440; an earlier conversation idle longer than this is not picked up again, unless a half-finished scenario in it is within the retention | Widget specification 3.3, D231 | `session_idle_minutes integer NOT NULL DEFAULT 30`, `CHECK` 1–1440 |
| Saved progress retention | Number | — | Minutes, 0–43200, that a half-finished scenario may be resumed for | Widget specification 3.3, D231 | `progress_retention_minutes integer NOT NULL DEFAULT 1440`, `CHECK` 0–43200 |
| Agent acts as | Reference → Person | — | The person the deployment's agent acts as when it answers a visitor; set by an administrator only (`agents:configure`), and only to an active person | D221 | `run_as_person_id uuid` → `core.person` |
| Storyline (name, version, mode), rating, conversations | — | — | Derived; "No ratings yet" when empty. The active version is the opening storyline's, the one under the deployment's own code | `UC-62.1-01`, `UC-63.1-07`, D231 | `active_storyline_version_id uuid` (no foreign key); rating and counts derived from conversations |

## Deployment surface — `ai.deployment_surface`

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Surface | Enum | — | `Widget`, `WhatsApp`, `Teams`, with the bound channel | `UC-62.1-01`, `UC-63.1-01` | `surface text NOT NULL` (`CHECK` against `DEPLOYMENT_SURFACES`), `channel_id uuid` → `ai.channel` |

## Storyline, version and step — `ai.storyline`, `ai.storyline_version`, `ai.storyline_step`

Stories: S-64 (`UC-64.1-01` … `-13`, FR-076), `SC-EMB-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Storyline | Text | — | e.g. card-replacement; code unique within the deployment. The storyline whose code is the deployment's code opens conversations; any other is a scenario a quick action starts | Specification §7.4.11, D231 | `ai.storyline.code text NOT NULL`, `name_en`, `name_ar` |
| Version | Number | — | Publishing creates a new version; conversations in progress keep theirs; one published version per storyline | `UC-64.1-09` | `ai.storyline_version.version_number integer NOT NULL`; partial unique index on Published |
| Mode | Enum | — | `Guided` offers the script and has the deployment's agent answer anything else; `Strict` keeps to the script. A step may name its own phase mode (`mode` in its configuration) (D339, migration `0071`) | `UC-64.1-01` … `-03`, D231, D339 | `mode text NOT NULL DEFAULT 'Guided'`, `CHECK` against `STORYLINE_MODES` |
| Version status | Enum | — | `Draft`, `Published`, `Superseded` | `UC-64.1-09` | `status text NOT NULL DEFAULT 'Draft'`, `CHECK` against `STORYLINE_VERSION_STATUSES` |
| Step type | Enum | Yes | `Message`, `Ask`, `Form`, `Confirm`, `Decide`, `Classify`, `Tool`, `Skill`, `Verify`, `CreateWork`, `Handoff`, `Wait`, `Subflow`, `GoTo`, `End` | `UC-64.1-04`, Specification §7.4.11 | `ai.storyline_step.step_type text NOT NULL`, `CHECK` against `STORYLINE_STEP_TYPES` |
| Step name, order | Text, Number | — | An unreachable step blocks publish | `UC-64.1-10` | `name text NOT NULL`, `sort_order integer NOT NULL` |
| Agent for this step | Reference → Agent | — | "Overrides the default agent for this step only" | `UC-64.1-06` | `agent_override_id uuid` → `ai.agent` |
| Message | Text | — | A missing Arabic message blocks publish when Arabic is enabled | `UC-64.1-04`, `-11` | `message_en`, `message_ar text` |
| Send verbatim (exact) | Boolean | — | Only on a step with a message | `UC-64.1-05` | `send_verbatim boolean NOT NULL DEFAULT false`; `CHECK storyline_step_verbatim_check` |
| Slot, max attempts (Ask), method (Verify), queue (Handoff), tools (Tool), skills (Skill) | Text, Number, List | Per type | A tool the agent is not allowed is flagged | `UC-64.1-04`, `-12` | `slot`, `max_attempts`, `verify_method`, `handoff_queue`, `tool_refs text[]`, `skill_refs text[]` |
| Next step | Reference → StorylineStep | Yes to publish | Steps pointing to a deleted step are flagged | `UC-64.1-04`, `-07`, `-10` | `next_step_id uuid` → `ai.storyline_step` |
| On error | Enum | — | `RetryOnce`, `GoToStep`, `Handoff` | `UC-64.1-04`, `-13` | `on_error text NOT NULL DEFAULT 'Handoff'`, `CHECK` against `STORYLINE_ON_ERRORS` |
| Other configuration | JSON | — | Type-specific settings: choices, a Form step's fields (key, labels, data type, required, optional choices), the step's phase mode (`mode`), an Ask step's typed field (`field`: type, labels, pattern, limits, mask, example), a Tool step's presentation (`present`: list, card or timeline), a Decide step's `branches` and `otherwise`. A key no step reads is refused on save (`stepConfigInput`) | Logical model §16, D231 | `config_json jsonb NOT NULL DEFAULT '{}'` |

## Deployment conversation — `ai.deployment_conversation`

Stories: S-65 (`UC-65.1-01` … `-15`, FR-077), `SC-EMB-02`, `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Storyline version | Reference | — | Pinned for the conversation | `UC-64.1-09` | `storyline_version_id uuid` → `ai.storyline_version` |
| Progress | Reference → StorylineStep | — | "Card replacement · step 3 of 9" | `UC-65.1-01` | `current_step_id uuid` → `ai.storyline_step` |
| Slots | JSON | — | Filled by quick replies or extracted from free text | `UC-65.1-02`, `-06` | `slots_json jsonb NOT NULL DEFAULT '{}'` |
| Visitor | Reference, Text | — | The external contact; the visitor key across turns | `UC-65.1-03` | `external_contact_id uuid` (no foreign key), `visitor_key text` |
| Outcome | Enum | — | `Completed`, `HandedOff`, `Abandoned`, `Cancelled` (the visitor cancelled a scenario), `RequestCreated` | `UC-65.1-14`, D231 | `outcome text`, `CHECK` against `CONVERSATION_OUTCOMES` |
| Request created | Reference → Request | — | A Create work step returns the reference | `UC-65.1-04`, `SC-EMB-02` | `request_id uuid` → `work.request` |
| Rating | Number | — | Asked at the end if enabled | `UC-65.1-14` | `rating integer`, `CHECK` 1–5 |
| Room | Reference → DiscussionRoom | — | The conversation also appears as a room | Logical model §16 | `room_id uuid` → `work.discussion_room` |
| Started, ended | Date-time | — | | — | `started_at timestamptz NOT NULL DEFAULT now()`, `ended_at`; `started_at` indexed for the Conversations screen |
| Taken over by, at | Reference → Person, Date-time | — | Set while a person holding `conversations:answer` answers instead of the agent; cleared when they resume the agent or the conversation ends. One person holds a conversation at a time (D342, D343, migration `0073`) | D342 | `agent_paused_by uuid` → `core.person`, `agent_paused_at timestamptz` |

Schema-only: `channel_id uuid` (null for the widget and the console preview) and `state_json jsonb`
(the storyline engine's state between turns, including the asking steps Back and Main menu return to
(`trail`, D339), the one-time code's hash and counters, whether a half-finished scenario is offered to
resume, and the widget's recent client message ids). One line of
the conversation is a row of `ai.conversation_message` (`sort_order`, `role` in `Visitor`, `Agent`,
`HumanAgent` (a person answering after a handoff), `System`, `kind`, `text_en`, `text_ar`,
`payload_json`, which also holds the visitor's thumbs on the line and, for a tapped choice whose label
is the line's text, the choice's value (D342)), so a conversation can be re-read
or handed to a person without replaying it (`UC-65.1-08`, `-13`). A file a visitor uploads for a file
step is a `work.attachment` row with owner `Conversation` (D231).

## Widget event — `ai.widget_event`

What happened in an embedded widget, read by the deployment's Last 30 days card (widget specification
15, D231). Never holds a value the visitor typed.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Deployment | Reference → EmbeddedDeployment | Yes | Deleted with the deployment | Widget specification 15 | `deployment_id uuid NOT NULL` → `ai.embedded_deployment` (`ON DELETE CASCADE`) |
| Conversation | Reference → DeploymentConversation | — | Deleted with the conversation | Widget specification 15 | `conversation_id uuid` → `ai.deployment_conversation` (`ON DELETE CASCADE`) |
| Event | Text | Yes | `widget.opened`, `widget.closed`, `widget.minimized`, `widget.language`, `widget.restarted`, `quick_action.clicked`, `scenario.started`, `scenario.step_completed`, `scenario.validation_failed`, `scenario.handoff`, `scenario.ended`, `identity.step_up`, `feedback.submitted` | Widget specification 15 | `name text NOT NULL` (no `CHECK`) |
| Properties | JSON | — | For example the scenario, step, end state or result | Widget specification 15 | `props_json jsonb NOT NULL DEFAULT '{}'`, `CHECK` it is an object |
| When | Date-time | — | | — | `at timestamptz NOT NULL DEFAULT now()`; index (`deployment_id`, `at`) |

## Channel message — `ai.channel_message`

Stories: `UC-61.1-08`, `-09`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Message | Text | — | Every message a channel carried | `UC-61.1-08` | `body_text text`, `direction text NOT NULL` (`Inbound`, `Outbound`), `sender_key text NOT NULL` |
| Gateway decision | Enum | Yes | `Process`, `Offline`, `Throttled`, `Dropped`; the rate limiter counts over these rows | `UC-61.1-08`, `-09` | `action text NOT NULL`, `CHECK` against `INBOUND_ACTIONS`; `detail text` |
| Conversation, room, request | Reference | — | | — | `conversation_id`, `room_id`, `request_id uuid` (each `ON DELETE SET NULL`) |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| ENG-1 | StorylineVersion.Status | Logical model §16: Draft, Published | Adds `Superseded` (migration `0012`) | Model drift |
| ENG-2 | Channel endpoint and inbound secret, deployment JWT secret and fallback, conversation state, ConversationMessage, ChannelMessage | Not in the logical model | Present (migrations `0010`, `0011`, `0013`) | Schema extension |
| ENG-6 | Deployment widget settings, WidgetEvent, outcome `Cancelled`, role `HumanAgent`, attachment owner `Conversation` | Not in the logical model; from the widget specification | Present (migration `0053`, D231) | Schema extension |
| ENG-7 | Deployment widget settings, WidgetEvent.Properties | Migration `0053` declares `embedded_deployment_quick_actions_check`, `embedded_deployment_idle_check`, `embedded_deployment_retention_check` and `widget_event_props_check` | `ai.ts` declares none of the four `CHECK`s | Model drift |
| ENG-8 | DeploymentConversation.Taken over by, Deployment.Agent acts as | Not in the logical model | `agent_paused_by`, `agent_paused_at` (migration `0073`, D342); `run_as_person_id` (migration `0050`, D221) | Schema extension |
| ENG-3 | Channel configuration fields on screen | `UC-61.1-02` | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: no Enabled toggle in Configure, no WhatsApp phone and business IDs, Teams app and tenant IDs or widget origins fields (not re-verified here) | Unverified |
| ENG-4 | DeploymentConversation.External contact, Deployment.Active storyline version | Logical model: references | No foreign keys | Constraint gap |
| ENG-5 | Storyline step names and on-error values | Prototype offers "end" as an on-error option | `RetryOnce`, `GoToStep`, `Handoff` only ([reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10) | Value difference |
