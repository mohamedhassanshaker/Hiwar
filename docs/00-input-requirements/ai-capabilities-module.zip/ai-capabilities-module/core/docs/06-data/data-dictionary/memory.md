# Data dictionary: memory

| Item | Value |
| --- | --- |
| Purpose | Fields of memory scopes, memories, their versions and entries, and the review flow |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#memory) · [Data model overview](../overview.md) · [Flow F-08](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Memory scope — `ai.memory_scope`

Stories: S-55 (`UC-55.1-03`, `-06`, `-07`, FR-064).

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Scope | Enum | Yes | `Organisation`, `BusinessUnit`, `Agent`, `Session`; scope chips filter the tree | `UC-55.1-03` | `kind text NOT NULL`, `CHECK` against `MEMORY_SCOPE_KINDS` |
| Tree position | Reference, Text | — | Organisation → business units → agents → sessions; scopes the user cannot access are not shown | `UC-55.1-06`, `-07` | `parent_scope_id uuid` → `ai.memory_scope`; `path text NOT NULL` unique; `ref_id uuid` (org unit, agent or room) |

Schema-only: `person_id uuid` → `core.person`. An agent scope set for one person is private to that
(agent, person) pair; null is a shared scope. One private scope per pair (unique
`memory_scope_agent_person_key`). Decisions D68, D116; migration `0038`. The organisation's own scope
(kind `Organisation`, path `org`) is created by the seed and by migration `0046` where it is missing
(D199).

## Memory — `ai.memory`

Stories: `UC-55.1-01`, `-02`, `-04`, `-05`, `UC-55.2-01` … `-04`, `UC-55.3-06`, `SC-MEM-01` … `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Title | Text | Yes | | `UC-55.1-05`, `UC-55.3-06` | `title_en`, `title_ar text NOT NULL` |
| Scope | Reference → MemoryScope | Yes | | `UC-55.3-06` | `scope_id uuid NOT NULL` → `ai.memory_scope` |
| Path | Text | — | | `UC-55.1-05` | `path text NOT NULL` unique |
| Status | Enum | — | `Active`, `PendingReview`, `NeedsAttention`, `Rejected`, `Archived`; pending is not used in runs; past its review date it shows Needs attention | `UC-55.2-01` … `-03`, `UC-55.3-06` | `status text NOT NULL DEFAULT 'Active'`, `CHECK` against `MEMORY_STATUSES` |
| Owner | Reference → principal | — | Filterable | `UC-55.1-04`, `-05` | `owner_type text NOT NULL`, `owner_id uuid` |
| Access | JSON | — | Who may read and write | `UC-55.1-05` | `access_json jsonb` (object) |
| Write policy | JSON | — | e.g. "PII filter · human approval for new rules"; new memories that need review start Pending | `UC-55.1-05`, `UC-55.3-03`, `-06` | `write_policy_json jsonb` (object) |
| Review due, last reviewed | Date-time | — | Review now clears the warning | `UC-55.2-03`, `UC-55.1-04` | `review_due_at`, `last_reviewed_at timestamptz` |
| Version | Number | — | Shown with History. The row's `version` column is the edit lock a save sends, separate from this content version; a review moves the lock without a new content version (D185) | `UC-55.1-05` | `current_version integer NOT NULL DEFAULT 1` |

## Memory version — `ai.memory_version`

Stories: `UC-55.3-01` … `-05`, `-07`, `SC-MEM-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Content | Long text | Yes | Masked or blocked when it contains PII and the filter is on | `UC-55.3-01`, `-03` | `content text` or `content_ref text` (object storage) |
| Change note | Text | Yes | An empty note blocks save | `UC-55.3-01`, `-02` | `change_note text` |
| Version | Number | — | Edits and restores always create a new version | `UC-55.3-01`, `-05` | `version_number integer NOT NULL`; unique (`memory_id`, `version_number`) |
| Restored from | Number | — | "Creates version 15 with this content" | `UC-55.3-05` | `restored_from_version integer` |
| Created by | Reference → principal | — | | Logical model §13 | `created_by_type text NOT NULL`, `created_by_id uuid` |

## Memory entry — `ai.memory_entry`

Stories: `UC-55.1-04`, `-05`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Entry | Text | Yes | | `UC-55.1-05` | `text text NOT NULL` |
| Source | Enum + Text | — | `AgentRun`, `Person`, `Document`; filterable | `UC-55.1-04`, `-05` | `source_type text NOT NULL` (`CHECK` in those three), `source_ref text` |

## Memory review — `ai.memory_review`

Stories: `UC-55.2-01`, `-02`, `-04`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Proposed by | Reference → Agent | — | | `UC-55.2-01` | `proposed_by_agent_id uuid` → `ai.agent` |
| Reviewer | Reference → Person | — | Not the proposing agent's only owner when policy requires someone else | `UC-55.2-04` | `reviewer_person_id uuid` → `core.person` |
| Decision | Enum | — | `Approved`, `Rejected`; a rejection tells the agent | `UC-55.2-01`, `-02` | `decision text` (`CHECK` in those two), `decided_at timestamptz` |
| Version | Reference | — | | Logical model §13 | `memory_version_id uuid` → `ai.memory_version` |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| MEM-1 | MemoryVersion.Change note | `UC-55.3-02`: required | Nullable; the rule is application-side | Constraint gap |
| MEM-2 | MemoryScope.Person | Not in the logical model | `person_id` (D68, D116) | Schema extension |
| MEM-3 | Memory owner and access editing, New memory scope picker | `UC-55.1-05`, `UC-55.3-06` | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: owner and access read-only, single select in New memory (not re-verified here) | Unverified |
