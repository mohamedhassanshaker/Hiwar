# Data dictionary: models and routes

| Item | Value |
| --- | --- |
| Purpose | Fields of model providers, connections, allowed models, routes and route steps |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#models-and-routes) · [Data model overview](../overview.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Model provider — `ai.model_provider`

Stories: S-59 (`UC-59.1-01`, `-04` … `-06`, FR-071), `SC-MDL-01`, `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Display name | Text | Yes (custom) | | `UC-59.1-05` | `name_en`, `name_ar text NOT NULL` |
| Kind | Enum | — | `Cloud`, `Custom`; filter All, Active, Not active, Custom | `UC-59.1-01` | `kind text NOT NULL DEFAULT 'Cloud'`, `CHECK` against `MODEL_PROVIDER_KINDS` |
| Inference engine | Enum | Yes (custom) | `Ollama`, `VLlm`, `LmStudio`, `Tgi`, `LlamaCpp`, `LocalAi`, `TritonNim`, `OpenAiCompatible`; only on a custom provider | `UC-59.1-05` | `engine text`, `CHECK` against `MODEL_ENGINES`; `CHECK model_provider_engine_required_check` |
| Provider active | Boolean | — | Off: every connection and route step using it is skipped and routes fall back | `UC-59.1-04`, `SC-MDL-03` | `is_active boolean NOT NULL DEFAULT true` |
| Connections, models allowed | Number | — | Derived; "Not connected" when none | `UC-59.1-01` | derived |

Schema-only: `gateway_provider text NOT NULL DEFAULT 'Custom'` (`CHECK` against `GATEWAY_PROVIDERS`;
always `Custom` for a custom provider): the provider identity agentgateway understands, kept as data
so renaming a provider does not break its routes.

## Provider connection — `ai.provider_connection`

Stories: `UC-59.1-02`, `-03`, `-05`, `-07` … `-10`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Connection name | Text | Yes | e.g. Production; unique per provider | `UC-59.1-02` | `name text NOT NULL`; unique (`provider_id`, `name`) |
| Region | Text | — | | `UC-59.1-02` | `region text` |
| Endpoint, base URL | Text | Yes (custom) | | `UC-59.1-02`, `-05` | `base_url text` |
| Authentication | Enum | — | `ApiKey`, `EntraId`, `IamRole`, `BearerToken`, `OAuth`, `None` | `UC-59.1-02` | `auth_type text NOT NULL DEFAULT 'ApiKey'`, `CHECK` against `PROVIDER_AUTH_TYPES` |
| Secret | Secret | — | Never shown; a wrong secret fails the test per model | `UC-59.1-02`, `-08`, `-09` | `secret_ref bytea` (ciphertext) |
| Connection active | Boolean | — | | `UC-59.1-02` | `is_active boolean NOT NULL DEFAULT true` |
| Test result | Date-time, JSON | — | The last test of the saved connection: `{ "results": [{ "model", "ok", "detail", "ms", "untestable" }] }`, one entry per allowed model; `untestable` marks a kind the console cannot test, which is left out of the verdict. Null until a test has run, which the screen shows as Not checked; any failed model reads Failed. A draft test stores nothing, and saving an edited connection clears the result (D196, migration `0044`) | `UC-59.1-03`, `-08` | `last_test_at timestamptz`, `last_test_result_json jsonb`, `CHECK` that it is a JSON object |

A connection that routes still use cannot be removed (`UC-59.1-10`).

## Connection allowed model — `ai.connection_allowed_model`

Stories: `UC-59.1-02`, `-03`, `-05`, `-07`, `UC-60.1-07`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Allowed model | Text | — | Routes can use only models allowed here; none allowed warns that no route can use the connection | `UC-59.1-02`, `-07`, `UC-60.1-07` | `model_name text NOT NULL`; unique (`connection_id`, `model_name`) |
| Kind | Enum | — | `Chat`, `Embedding`, `Image`, `Speech`, `Transcription`, `Rerank`, `Decision`, `Audio`, `Video`; what the test connection and a route picker filter by. A `Decision` model answers at the provider's decisions endpoint and may sit only on a `Decision` route (D290) | Logical model §15 | `kind text NOT NULL DEFAULT 'Chat'`, `CHECK` against `MODEL_KINDS` |
| Modalities, context window | List, Number | — | Realtime voice offers only models that support realtime audio. The context window is in tokens, 1 to 10 000 000, set per model in the connection editor; empty means none recorded. A discussion room shows its lead agent's window as the smallest recorded on the active steps of its primary route | `UC-60.1-05` | `modalities text[] NOT NULL DEFAULT '{text}'`, `context_window integer` |
| Price in, price out | Number | — | Used for estimated cost | Logical model §15 | `price_in`, `price_out numeric(18,6)` |

## Route — `ai.route`

Stories: S-60 (`UC-60.1-01` … `-09`, FR-072), `SC-MDL-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Alias | Text | Yes | Suggested from the use and the primary model; agents reference it; unique | `UC-60.1-02`, `-06` | `alias text NOT NULL`, unique `route_alias_key` |
| Use (kind) | Enum | — | `Standard`, `Typesafe`, `Voice`, `Embedding`, `Decision`. An agent runs only on a `Standard` or `Typesafe` route (D337); a knowledge collection embeds on an `Embedding` route (D257); a `Decision` route's steps are `Decision` models, and a discussion room chooses its answering agent on the Decision route `agent-choice`, which migration `0063` and the seed create where the seeded OpenRouter connection exists (D290) | `UC-60.1-01` … `-05` | `kind text NOT NULL DEFAULT 'Standard'`, `CHECK` against `ROUTE_KINDS` |
| Output schema | JSON | Yes (typesafe) | Must be valid JSON Schema; invalid output is retried, then routed to the fallback | `UC-60.1-03`, `-06` | `output_schema_json jsonb` (object) |
| Confidence threshold, max retries | Number | — | Typesafe | `UC-60.1-03` | `confidence_threshold numeric(5,4)`, `max_retries_on_invalid integer` |
| Voice mode | Enum | — | `Realtime`, `Pipeline` | `UC-60.1-04`, `-05` | `voice_mode text`, `CHECK` against `VOICE_MODES` |
| STT, TTS voice, languages, barge-in, max call length | Text, List, Boolean, Number | — | Voice | `UC-60.1-04` | `stt_model`, `tts_voice text`; `languages text[]`; `barge_in boolean`; `max_call_minutes integer` |
| Agents using it | List | — | Derived; a route used by agents or collections cannot be deleted | `UC-60.1-01`, `-09` | derived |

Schema-only: `route_version integer NOT NULL DEFAULT 1`.

## Route step — `ai.route_step`

Stories: `UC-60.1-02`, `-06`, `-07`, `UC-59.1-04`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Primary and fallbacks | Number | Yes (at least one) | Order 0 is the primary; an empty chain is rejected | `UC-60.1-02`, `-06` | `sort_order integer NOT NULL`; unique (`route_id`, `sort_order`) |
| Provider, connection, model | Reference, Reference, Text | Yes | Only models allowed on the connection are offered | `UC-60.1-02`, `-07` | `provider_id uuid NOT NULL` → `ai.model_provider`; `connection_id uuid NOT NULL` → `ai.provider_connection`; `model_name text NOT NULL` |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| MDL-1 | Route.Kind | `UC-60.1-01` and Specification: Standard, Typesafe, Voice | Adds `Embedding` and `Decision` (D290) | Model drift |
| MDL-2 | RouteStep.Model | `UC-60.1-07`: only allowed models | `model_name` is text with no foreign key to `connection_allowed_model`; enforced in the application | Constraint gap |
| MDL-3 | ModelProvider.Gateway provider, ProviderConnection.Authentication values | Not in the logical model | `gateway_provider`; `PROVIDER_AUTH_TYPES` | Schema extension |
| MDL-4 | Route editor options | Specification §7.4.8 | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: named output schemas, route uses and speech model lists replaced by free JSON Schema and free text (not re-verified here) | Unverified |
