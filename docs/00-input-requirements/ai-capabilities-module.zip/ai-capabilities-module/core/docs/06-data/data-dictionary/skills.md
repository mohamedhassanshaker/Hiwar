# Data dictionary: skills

| Item | Value |
| --- | --- |
| Purpose | Fields of skills, their versions, security scans and test cases |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#skills) · [Data model overview](../overview.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Skill — `ai.skill`

Stories: S-53 (`UC-53.1`, `UC-53.2`, `UC-53.3`, FR-059 … FR-061), `SC-SKL-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Skill name | Text | Yes | Suggested from the title; the `name` in `SKILL.md`; unique | `UC-53.3-01` | `skill_name text NOT NULL`, unique `skill_name_key` |
| Title | Text | Yes | | `UC-53.3-01` | `title_en`, `title_ar text NOT NULL` |
| Description | Long text | Yes | "Agents read this to decide when to load the skill"; empty is rejected | `UC-53.3-01`, `-04` | `description_en`, `description_ar text` |
| Source | Enum | — | `Bundled`, `Uploaded`, `Git`, `Registry`, `Authored`; tabs Installed, My Skills | `UC-53.1-01`, `UC-53.2-03` | `source_type text NOT NULL DEFAULT 'Authored'`, `CHECK` against `SKILL_SOURCE_TYPES`; `source_url text` |
| Tags | List | — | | `UC-53.1-01` | `tags text[] NOT NULL DEFAULT '{}'` (GIN index) |
| Author | Reference → Person | — | My Skills | `UC-53.1-01` | `author_person_id uuid` → `core.person` |
| Agents using it, where used | Number, List | — | Derived; agents pinned to an older version are listed after publish | `UC-53.1-01`, `UC-53.3-03` | derived from `ai.agent_skill` |

Schema-only: `current_version_id uuid` (no foreign key).

## Skill version — `ai.skill_version`

Stories: `UC-53.2-01` … `-06`, `UC-53.3-03`, `UC-51.2-05`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Version | Text | — | | `UC-53.1-01` | `version_label text NOT NULL`; unique (`skill_id`, `version_label`) |
| Package | File | — | `.zip` or Git URL. An import stores the package's files, as the bytes the zip carried, in the `skills` bucket under the prefix `package_ref` names (`skills/<name>/<version>`, D206, D210); the skill's detail lists them and offers them as one `.zip` (D333). A Bundled skill's files are in the agent image only | `UC-53.2-01`, `-03` | `package_ref text` (object storage), `checksum text` |
| `SKILL.md` front-matter valid | Boolean | Yes to import | Missing or invalid blocks import | `UC-53.2-01`, `-05` | `frontmatter_valid boolean NOT NULL DEFAULT false` |
| Tools the skill needs | List | — | A tool from a connector the agent may not use shows a warning | `UC-51.2-05` | `declared_tools text[] NOT NULL DEFAULT '{}'` (migration `0005`; D79) |
| Status | Enum | — | `Draft`, `Published`. Only a Published version reaches a run, and one that is not Bundled only when its security scan passed (D156, D206) | `UC-53.3-01`, `-03` | `status text NOT NULL DEFAULT 'Draft'`, `CHECK` against `SKILL_VERSION_STATUSES` |

## Skill scan result — `ai.skill_scan_result`

Stories: `UC-53.2-01`, `-04`, `-06`, `SC-SKL-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Scripts | Number | — | | Specification §7.4.4 | `scripts integer NOT NULL DEFAULT 0` |
| Network calls | Number | — | "Script makes network calls — will run in sandbox only"; import still allowed | `UC-53.2-04` | `network_calls integer NOT NULL DEFAULT 0` |
| Prompt-injection patterns, embedded secrets | Number | — | Found: import blocked or needs approval, per policy | `UC-53.2-01`, `-06` | `prompt_injection_patterns`, `embedded_secrets integer NOT NULL DEFAULT 0` |
| Sandbox only | Boolean | — | | `UC-53.2-04`, `SC-SKL-01` | `sandbox_only boolean NOT NULL DEFAULT true` |
| Scanned at | Date-time | — | | — | `scanned_at timestamptz NOT NULL DEFAULT now()` |

One row per skill version (`skill_version_id` is the primary key).

## Skill test case — `ai.skill_test_case`

Stories: `UC-53.3-02`, `-05`. The test bench is not offered and publishing does not read the cases
(D333): the table and its rows are kept, and nothing reads or writes them.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Name | Text | Yes | Unique per version | `UC-53.3-02` | `name text NOT NULL` |
| Input, expected | Long text | — | | `UC-53.3-02` | `input`, `expected text` |
| Last result, last duration | Text, Number | — | What a case did when the test bench last ran it; publishing does not read it | `UC-53.3-02`, `-05` | `last_result text`, `last_duration_ms integer` |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| SKL-1 | Skill.Description | `UC-53.3-04`: an empty description is rejected | Columns are nullable; the rule is application-side | Constraint gap |
| SKL-2 | SkillVersion.Declared tools | Not in the logical model | `declared_tools` | Schema extension |
| SKL-3 | Skill files | Specification §7.4.4: a Files view of the package | Read from the object store under `skill_version.package_ref` and listed on the skill's detail (D333); a Bundled skill's files are not readable by the console | Value difference |
| SKL-4 | Git import | `UC-53.2-03`: import from a Git URL | Supported by the model (`source_type` `Git`, `source_url`); the facts sheet found nothing sets `SKILL_GIT_HOSTS`, so Git import is off in every environment | Value difference |
