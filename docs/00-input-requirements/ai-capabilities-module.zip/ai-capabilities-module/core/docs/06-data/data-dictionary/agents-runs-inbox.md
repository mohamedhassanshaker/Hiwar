# Data dictionary: agents, runs and the inbox

| Item | Value |
| --- | --- |
| Purpose | Fields of agents, their versions and grants, playground tests, runs and run steps, approvals, agent questions, inbox items and saved assistant chats |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#agents-runs-and-the-inbox) · [Data model overview](../overview.md) · [Agent runtime specification](../../agent-runtime-spec.md) · [Decision register](../../harness-decisions.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Agent — `ai.agent`

Stories: S-50 (`UC-50.1`, `UC-50.2`, FR-053), S-40 (`UC-40.1-05`, `UC-40.2-01`), `SC-ORG-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Name | Text | Yes | | `UC-50.2-01`, `-02` | `name_en`, `name_ar text NOT NULL` |
| Code | Text | Yes | Unique | `UC-50.2-02` | `code text NOT NULL`, unique `agent_code_key` |
| Avatar | Text | — | Initials | `UC-50.1-01` | `initials text NOT NULL` |
| Org unit | Reference → OrgUnit | — | | `UC-50.2-01` | `org_unit_id uuid` → `core.org_unit` |
| Reports to | Reference → principal | — | The escalation path follows the reporting line | `UC-40.2-01`, `SC-ORG-01` | `reports_to_type text`, `reports_to_id uuid` |
| Status | Enum | — | `Idle`, `Running`, `Waiting`, `Paused`, `Error`, `Retired`; Error shows the failure reason and counts in "Agents in error" | `UC-50.1-01`, `UC-50.2-05` | `status text NOT NULL DEFAULT 'Idle'`, `CHECK` against `AGENT_STATUSES` |
| Version, model, profile | — | — | From the active version | `UC-50.1-01` | `ai.agent_version` (below) |
| Runs, estimated cost, runs in last 30 days | Number, Money | — | Derived | `UC-50.1-01`, `UC-40.1-05` | derived from `ai.run` |

Schema-only columns:

| Column | Type | Reason |
| --- | --- | --- |
| `is_system` | `boolean NOT NULL DEFAULT false` | The platform's own agents (`pa`, and `dir` on an installation seeded before D371), whose trust is fixed; System trust is assignable to no agent (`UC-50.2-04`) |
| `is_builtin` | `boolean NOT NULL DEFAULT false` | The built-in Platform Assistant, which cannot be deleted (D65, D99, migration `0035`) |
| `default_version` | `integer` | Which generation of the seeded defaults the built-in agent sits on, so a seed upgrade does not overwrite a customisation (D99, migrations `0035`, `0039`) |
| `active_version_id` | `uuid` | The active version (no foreign key) |

## Agent version — `ai.agent_version`

Stories: S-51 (`UC-51.1` … `UC-51.4`, FR-054 … FR-057), `SC-AGT-01` … `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Version | Number | — | e.g. v8; one active version per agent; running runs keep theirs; roll back activates an older version | `UC-51.3-02`, `UC-51.4-04`, `-05` | `version_number integer NOT NULL`, unique per agent; `is_active boolean NOT NULL DEFAULT false` with partial unique index |
| System instructions | Long text | — | Markdown; saved as a draft revision | `UC-51.2-01` | `instructions text NOT NULL DEFAULT ''` |
| Execution profile | Enum | Yes on create | `Conversational`, `Task`, `Planner`, `Reviewer`, `Triage`, `Scripted`, `Routine` | `UC-50.2-01`, `UC-51.1-01` | `execution_profile text NOT NULL DEFAULT 'Task'`, `CHECK` against `EXECUTION_PROFILES` |
| Primary model (route) | Reference → Route | Yes on create | A chat route only (kind `Standard` or `Typesafe`); any other is refused on create and on save (D337) | `UC-50.2-01`, `UC-51.1-03` | `primary_route_id uuid` → `ai.route` |
| Fallback route | Reference → Route | — | A chat route only, as the primary (D337) | `UC-51.1-01`, `-03` | `fallback_route_id uuid` → `ai.route` |
| Agent trust | Enum | Yes on create | `Restricted`, `Standard`, `Elevated`, `Coordinator`, `System`; System is not offered on New Agent | `UC-50.2-01`, `-04`, `UC-51.1-04`, `SC-AGT-03` | `trust text NOT NULL DEFAULT 'Standard'`, `CHECK` against `AGENT_TRUSTS` |
| Memory | Boolean | — | Off removes memory tools from runs; existing memory is kept | `UC-51.1-06` | `memory_enabled boolean NOT NULL DEFAULT false` |
| Run budget (soft, hard) | Money | — | Soft must not exceed hard | `UC-51.1-01`, `-05` | `run_budget_soft_aed`, `run_budget_hard_aed numeric(18,4)`; `CHECK agent_version_budget_check` |
| Release notes | Long text | Yes to publish | | `UC-51.3-02`, `-03` | `release_notes text` |
| Eval score | Number | — | A failing evaluation gate blocks publish | `UC-51.1-01`, `UC-51.3-04` | `eval_score numeric(5,2)` |
| Published date, published by | Date-time, Reference → Person | — | | `UC-51.4-04`, Specification §7.4.2 | `published_at timestamptz`, `published_by uuid` → `core.person` |

## Agent grants — `ai.agent_skill`, `ai.agent_tool_mode`, `ai.agent_platform_tool`, `ai.agent_memory_access`, `ai.agent_knowledge_access`

Stories: `UC-51.2-02` … `-05`, `UC-53.2-02`, `UC-58.1-05`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Enabled skills | List of SkillVersion | — | Applies on the next version; a skill whose declared tools the agent cannot reach shows a warning | `UC-51.2-02`, `-05` | `ai.agent_skill (agent_version_id, skill_version_id)` |
| Tool mode | Enum | — | `Auto`, `Approval`, `Denied` per connector tool; never looser than the tool's tier (T2 at least Approval, T3 only Denied). A tool is granted at the mode its tier implies: a T0 read at Auto, any other at Approval; a tool already granted keeps its mode (D264, migration `0061`). This grant is the only list of the connector tools an agent version may use (D227) | `UC-51.2-03`, `-04` | `ai.agent_tool_mode.mode text NOT NULL DEFAULT 'Approval'`; trigger `agent_tool_mode_tier` |
| Memory scopes | List + Enum | — | `Read`, `ReadWrite` | Logical model §10 | `ai.agent_memory_access.access text NOT NULL DEFAULT 'Read'` |
| Knowledge collections | List | — | Retrieval is limited to allowed collections | `UC-58.1-05` | `ai.agent_knowledge_access (agent_version_id, collection_id)` |

Schema-only: `ai.agent_platform_tool (agent_version_id, tool_name)` is the grant of platform and
harness-answered tools, versioned with the agent (D38, D80, D228; migrations `0034`, `0040`, `0058` … `0060`,
`0070`). No rows means no tools (D28). No story names it; it is edited on the agent's Connector tools
tab as the Platform connector's tools (D228).

## Playground test — `ai.playground_test`

Stories: `UC-51.3-01`, `-06`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Sample input | Long text | Yes | | `UC-51.3-01` | `input text NOT NULL` |
| Result | Long text | — | Or the error with the failing step | `UC-51.3-01`, `-06` | `output text` |
| Duration | Number | — | e.g. "Run completed in 9.2s" | `UC-51.3-01` | `duration_ms integer` |
| Estimated cost | Money | — | | `UC-51.3-01` | `estimated_cost_aed numeric(18,4)` |
| Run | Reference → Run | — | | Logical model §10 | `run_id uuid` → `ai.run` |

## Run — `ai.run`

Stories: S-51 run list (`UC-51.4-01`), S-52 (`UC-52.1-01` … `-11`, FR-058), S-10 (`UC-10.1-01`).

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Run (key) | Text | — | | `UC-51.4-01` | `key text NOT NULL`, unique |
| Agent, version | Reference | Yes | The run keeps the version it started with | `UC-51.3-02` | `agent_id uuid NOT NULL` → `ai.agent`; `agent_version_id uuid NOT NULL` → `ai.agent_version` |
| Status | Enum | — | `Queued`, `Running`, `Waiting`, `Blocked`, `Succeeded`, `Failed`, `Cancelled`, `BudgetExceeded`; cancel is not offered on a finished run | `UC-51.4-01`, `UC-52.1-05`, `-09`, `-11` | `status text NOT NULL DEFAULT 'Queued'`, `CHECK` against `RUN_STATUSES` |
| Started, duration | Date-time | — | Duration includes waiting time ("+ 6m waiting") | `UC-51.4-01`, `UC-52.1-01` | `started_at`, `ended_at timestamptz`; `waiting_seconds integer NOT NULL DEFAULT 0` |
| Tokens, cache hit % | Number | — | | `UC-52.1-01` | `tokens_in`, `tokens_out integer NOT NULL DEFAULT 0`; `cache_hit_pct numeric(5,2)` |
| Tool calls | Number | — | Counted by the agent runtime; the run viewer's Tool calls figure narrows the timeline to its tool steps | `UC-52.1-01`, D300 | `tool_call_count integer NOT NULL DEFAULT 0` |
| Estimated cost | Money | — | Not a gate (D73). The agent runtime does not send it, so it reads 0, and the run viewer does not show it (D300; runtime specification conflict 10) | `UC-52.1-01`, `UC-51.4-01` | `estimated_cost_aed numeric(18,4) NOT NULL DEFAULT 0` |
| Open trace | Reference | — | Opens the Phoenix trace for authorised users | `UC-52.1-07`, `-08` | `trace_id text` |
| Replay | Reference → Run, Number | — | A new linked run from a chosen step, with a reason; audited | `UC-52.1-06` | `replay_of_run_id uuid` → `ai.run`; `replay_from_step integer` |
| Trigger | Enum | — | `Mention`, `Assignment`, `RequestStep`, `Schedule`, `Widget`, `Manual`, `Replay`, `Delegation`; the Setup Director's runs are `Manual` since migration `0075` (D375) | Logical model §10 | `trigger text NOT NULL`, `CHECK` against `RUN_TRIGGERS` |
| Context | Enum + Reference | — | `Room`, `WorkItem`, `Request`, `Deployment`, `Console`; the assistant panel runs in `Console`, and so do the Setup Director's runs since migration `0075` (D375) | Logical model §10 | `context_type text NOT NULL`, `CHECK` against `RUN_CONTEXT_TYPES`; `context_id uuid` |

Schema-only columns:

| Column | Type | Reason |
| --- | --- | --- |
| `granted_tools` | `text[]` | The exact grant the run started with, stable across a resume (D35, D50, migration `0032`) |
| `parent_run_id` | `uuid`, foreign key to `ai.run` `ON DELETE SET NULL` and index `run_parent_idx` in migration `0033` | The run that delegated this one, so traces and costs form a tree (D46); delegation depth and fan-out are counted from it (D103, D142) |
| `temporal_workflow_id` | `text` | The Temporal workflow (mission id = workflow id = trace id, D44) |

A finished run can be deleted (Delete run, `run_delete`), by whoever may cancel it (D295), with its
steps, approvals and their decisions, questions, playground tests and the Inbox items they raised, in one
transaction (D300). A replay of it keeps existing with `replay_of_run_id` cleared, and a run it delegated
keeps existing with `parent_run_id` cleared. A run still going is refused.

## Run step — `ai.run_step`

Stories: `UC-52.1-01` … `-04`, `-10`.

The run viewer's timeline. The agent runtime builds it from the mission's own messages when the
mission ends and sends it with the outcome to `run_finish`, which inserts it (D300,
`services/agent/src/awp_agent/mission/timeline.py`). A run with no timeline gets one `Handoff` step
named `finish`. The full trace of model and tool spans is in Phoenix.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Step type | Enum | Yes | `Start`, `Model`, `Tool`, `Skill`, `Approval`, `Question`, `Verify`, `Handoff`. The agent runtime writes a `Model` step for each response with text, a `Tool` step per tool call and a closing `Handoff` step named `finish` | `UC-52.1-02`, D300 | `type text NOT NULL`, `CHECK` against `RUN_STEP_TYPES` |
| Name, status, result | Text | — | Name: `model`, the tool's name or `finish`, cut at 200 characters. Status (no `CHECK`): `Done`; for a tool step `Done`, `Refused` (the call came back as a retry prompt) or `Unanswered` (the mission ended first); for `finish` the run's status. Result: a model step's text; a tool step's arguments and result as one JSON object `{ "arguments", "result" }`; the final answer on `finish`; cut at 4,000 characters | `UC-52.1-02`, `-03`, D300 | `name text NOT NULL`, `status text NOT NULL`, `result text` |
| Hooks applied | List | — | e.g. "pii-mask (pre_model): 2 values masked"; the agent runtime records none | `UC-52.1-02` | `hooks_applied text[] NOT NULL DEFAULT '{}'` |
| Estimated cost by step | Money | — | The agent runtime sends 0 | `UC-52.1-01` | `estimated_cost_aed numeric(18,4) NOT NULL DEFAULT 0` |
| Order, timings | Number, Date-time | — | No duplicate steps after a restart: `run_finish` numbers the steps after the run's highest `seq` | `UC-52.1-10` | `seq integer NOT NULL`; `started_at timestamptz NOT NULL DEFAULT now()` (partition column), `ended_at timestamptz` |

Partitioned by month on `started_at` (`infra/postgres/03-partitions.sql`), primary key (`id`,
`started_at`); `run_id` → `ai.run` with no `ON DELETE` action, so `deleteRun` deletes the steps before the run.

## Approval — `ai.approval`

Stories: S-12 (`UC-12.1-01` … `-11`, FR-013), S-23 room cards (`UC-23.2`, FR-024), `SC-INB-01`, `-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Key | Text | — | e.g. on the room card "Approval required · CS-118" | `UC-23.2-01` | `key text NOT NULL`, unique |
| Requested by | Reference → principal | — | Agent or person | `UC-12.1-01` | `requested_by_type text NOT NULL`, `requested_by_id uuid` |
| Run, work item, request | Reference | — | | `UC-12.1-01` | `run_id` → `ai.run`; `work_item_id` → `work.work_item`; `request_id` → `work.request` |
| Action and arguments (redacted) | Text, JSON | — | | `UC-12.1-01` | `action text NOT NULL`; `arguments_redacted jsonb` (object) |
| Evidence | Text | — | e.g. quotes compared, remaining budget, verifier result | `UC-12.1-01` | `evidence text` |
| Risk | Enum | — | `Low`, `Medium`, `High` | Specification §7.1.1 ("how many are high risk") | `risk text NOT NULL DEFAULT 'Medium'`, `CHECK` against `RISKS` |
| Policy | Enum | — | `Single`, `AnyOf`, `Sequential` | `UC-12.1-03`, `-04` | `policy text NOT NULL DEFAULT 'Single'`, `CHECK` against `APPROVAL_POLICIES` |
| Escalates | Date-time | — | "Expired — escalated to …" | `UC-12.1-08` | `escalate_after timestamptz` |
| Status | Enum | — | `Pending`, `Approved`, `Rejected`, `ChangesRequested`, `Expired`; a cancelled run resolves it with no decision needed | `UC-12.1-02` … `-09` | `status text NOT NULL DEFAULT 'Pending'`, `CHECK` against `APPROVAL_STATUSES` |

Schema-only columns, which bind an approval to exactly what a person agreed to:

| Column | Type | Reason |
| --- | --- | --- |
| `call_id` | `text` | The tool call of the run the approval is for; the run waits on a signal keyed by it (migration `0006`) |
| `arguments_hash` | `text` | Canonical hash of the call's arguments (D20, migration `0031`) |
| `target_version` | `integer` | Version of the record the call targets (D20, D59) |
| `expires_at`, `consumed_at` | `timestamptz` | Time limited and single use; spent in one `UPDATE` (D21, D71) |

## Approval decision — `ai.approval_decision`

Stories: `UC-12.1-02` … `-11`, `UC-23.2-01` … `-05`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Approver | Reference → Person | Yes | Never an agent, never the requester of the approval's request, never the person assigned the approval's work item (trigger). The person who started a run in a room or the assistant panel decides that run's approvals; a call that changes access in a room goes to the other holders of `approvals:decide` (D105, D269, D284). The first of two concurrent decisions wins | `UC-12.1-10`, `-11` | `approver_person_id uuid NOT NULL` → `core.person`; unique (`approval_id`, `approver_person_id`); trigger `approval_decision_independence` |
| Decision | Enum | Yes | `Approved`, `Rejected`, `ChangesRequested` | `UC-12.1-02`, `-05`, `-07` | `decision text NOT NULL`, `CHECK` against `APPROVAL_DECISIONS` |
| Reason, comment | Text | Yes to reject | "Reason (required to reject)" | `UC-12.1-05` … `-07` | `reason text`; `CHECK approval_decision_reason_check` |
| Order | Number | — | Sequential approvers in turn | `UC-12.1-03` | `sequence integer NOT NULL DEFAULT 1` |
| Decided at | Date-time | — | | `UC-12.1-02` | `decided_at timestamptz NOT NULL DEFAULT now()` |

## Agent question — `ai.agent_question`

Stories: S-12 (`UC-12.2-01` … `-04`, FR-014), `SC-INB-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Question | Long text | Yes | | `UC-12.2-01` | `question text NOT NULL` |
| Options | List | — | The user may pick one instead of typing | `UC-12.2-03` | `options text[]` (migration `0007`) |
| Asked to | Reference → Person or Group | Yes | | `UC-12.2-04` | `asked_to_type text NOT NULL` (`CHECK` in Person, Group), `asked_to_id uuid NOT NULL` |
| Answer | Long text | Yes to send | Send is disabled when empty; the answer resumes the run | `UC-12.2-01`, `-02` | `answer text` |
| Answered by, at | Reference → Person, Date-time | — | "Answered by …" for other group members | `UC-12.2-04` | `answered_by uuid` → `core.person`, `answered_at timestamptz` |

## Inbox item — `ai.inbox_item`

Stories: S-12 (`UC-12.3-01` … `-04`, FR-015), S-01 badge (`UC-01.1-06`).

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Kind | Enum | Yes | `Approval`, `Question`, `Mention`, `SlaWarning`, `Review`, `Update` | `UC-12.3-01` … `-03`, `-05` | `kind text NOT NULL`, `CHECK` against `INBOX_KINDS` |
| Status | Enum | — | `Open`, `Resolved`; the badge counts open items | `UC-12.3-01`, `-04`, `UC-01.1-06` | `status text NOT NULL DEFAULT 'Open'`; partial index on open items |
| Source | Reference | — | Opens the room message, work item, request or approval | `UC-12.3-02`, `-03` | `source_type text NOT NULL`, `source_id uuid NOT NULL`; unique per person, kind and source |
| Title | Text | — | English and Arabic words an `Update` carries, since the event it reports (a request moving on) has no row to read them from; empty for the other kinds (D394) | `UC-12.3-05` | `title_en text`, `title_ar text` |
| Link | Text | — | The path an `Update` opens, such as `/requests?open=REQ-9037` | `UC-12.3-05` | `link_path text` |
| Resolved at | Date-time | — | | — | `resolved_at timestamptz` |

## Saved assistant chat — `ai.assistant_chat`, `ai.assistant_chat_message`

Stories: S-03 (`UC-03.1-06`, `-07`, FR-005); design handoff v2 §1.10.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Conversation title | Text | — | The first question asked | Handoff v2 §1.10 | `title text NOT NULL` |
| Screen | Text | — | The screen the conversation was opened on | `UC-03.1-07` | `screen text NOT NULL` |
| Turns | Text + Enum | — | `user`, `assistant`, in order | `UC-03.1-07` | `ai.assistant_chat_message (sort_order, role, body_text)`, `CHECK` against `ASSISTANT_CHAT_ROLES` |

Kept per person (not per browser); the service keeps the latest 30.

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| AGT-1 | AgentVersion.Run budget | `UC-51.1-01`, `-05`, `UC-52.1-09`: soft and hard run budgets in AED; BudgetExceeded at the hard limit | Columns and their `CHECK` remain; D73 removed money ceilings on runs (cost is counted, not enforced) and BudgetExceeded now comes from the effort limit (D93). The configuration screen still edits them and the web app sends them on the run payload as `soft_cost_aed` and `hard_cost_aed`; the agent runtime's `RunBudget` has no such fields, so nothing enforces them. See also the code conflicts in [agent-runtime-spec.md](../../agent-runtime-spec.md) | Value difference |
| AGT-2 | Run.Replay reason | `UC-52.1-06`: replay "with a reason", audited | No column for the reason; only the audit entry could hold it (not verified) | Missing column |
| AGT-3 | Run.Status | Logical model §10 has no `Blocked` | `Blocked` added by migration `0037` (D101) | Model drift |
| AGT-4 | Run.Trigger, Run.Context, RunStep.Type | Logical model §10 | Add `Delegation`; `Console`; `Start` and `Skill` | Model drift |
| AGT-5 | InboxItem.Kind | Logical model §10: Approval, Question, Mention, SlaWarning | Adds `Review` and `Update` | Schema extension |
| AGT-6 | Approval binding | Not in the logical model | `call_id`, `arguments_hash`, `target_version`, `expires_at`, `consumed_at` | Schema extension (D20, D21) |
| AGT-7 | AgentPlatformTool, Agent.is_builtin, Agent.default_version, Run.granted_tools, Run.parent_run_id, AssistantChat | Not in the logical model | Present | Schema extension (D35, D38, D46, D65, D80, D99; handoff v2 §1.10) |
| AGT-8 | Run.parent_run_id | Migration `0033` declares a foreign key (`ON DELETE SET NULL`) and the index `run_parent_idx` | `ai.ts` declares a plain `uuid` with neither | Model drift (see [overview](../overview.md#known-drift-between-the-schema-files-and-the-database)) |
| AGT-9 | Approval.Change set | Logical model: reference to ChangeSet | No column: `change_set_id` dropped by migration `0075` with the change-set tables (D375) | Removed |
