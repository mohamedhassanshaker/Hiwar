# Data dictionary: integrations

| Item | Value |
| --- | --- |
| Purpose | Fields of integration clients, their keys, permissions, agents and MCP and AG-UI exposure |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/engage-and-governance.md#integrations) · [Data model overview](../overview.md) · [Flow F-11](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `gov` (`apps/web/src/db/schema/gov.ts`). Conventions and legend: [README](README.md).

## Integration client — `gov.integration_client`

Stories: S-76 (`UC-76.1-01` … `-03`, FR-085), S-77 (`UC-77.5-01`, FR-090), `SC-INT-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Client name | Text | Yes | | `UC-76.1-02` | `name_en`, `name_ar text NOT NULL` |
| Client ID | Text | Yes | Suggested; unique | `UC-76.1-02`, `-03` | `client_id text NOT NULL`, unique `integration_client_key` |
| Owner | Reference → Person | — | | `UC-76.1-01`, `-02` | `owner_person_id uuid` → `core.person` |
| Allowed agents: all or selected | Boolean | — | | `UC-76.1-02` | `all_agents boolean NOT NULL DEFAULT false` |
| Status | Enum | — | `Active`, `Inactive`; Deactivate stops every key until reactivated | `UC-76.1-01`, `UC-77.5-01` | `status text NOT NULL DEFAULT 'Active'`, `CHECK` against `CLIENT_STATUSES` |
| Keys, MCP on/off, AG-UI on/off | Number, Boolean | — | List columns | `UC-76.1-01` | derived from the tables below |

## Client key — `gov.client_key`

Stories: `UC-77.1-01` … `-04`, `SC-INT-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Key name | Text | Yes | | `UC-77.1-01` | `name text NOT NULL` |
| Expiry | Date | — | Calls with an expired key are rejected and it shows Expired | `UC-77.1-01`, `-04` | `expires_at timestamptz` |
| Secret | Secret | — | Shown once; afterwards only the prefix | `UC-77.1-01` | `prefix text NOT NULL` (unique), `secret_hash bytea NOT NULL` |
| Last used | Date-time | — | | Specification §7.5.6 | `last_used_at timestamptz` |
| Status | Enum | — | `Active`, `Revoked`; Revoke stops it immediately; Rotate shows a new secret once and the old key stops after the grace period | `UC-77.1-02`, `-03` | `status text NOT NULL DEFAULT 'Active'`, `CHECK` against `CLIENT_KEY_STATUSES` |

## Client permission and agents — `gov.client_permission`, `gov.client_agent`

Stories: `UC-76.1-02`, `-03`, `UC-77.4-01`, `-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Allowed permissions | List of Enum | Yes (at least one) | `agents:invoke`, `requests:write`, `work_items:read`, `rooms:read`, `knowledge:search`, `webhooks:receive`; a call outside them is refused and audited | `UC-76.1-02`, `-03`, `UC-77.4-01`, `-02` | `gov.client_permission.permission text NOT NULL`, `CHECK` against `CLIENT_PERMISSIONS` |
| Allowed agents (selected) | List of Agent | — | | `UC-76.1-02` | `gov.client_agent (client_id, agent_id)` |

## MCP exposure — `gov.client_mcp_exposure`

Stories: `UC-77.2-01` … `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Expose platform as MCP server | Boolean | — | "MCP access is off for this client." when off | `UC-77.2-01`, `-03` | `is_enabled boolean NOT NULL DEFAULT false` |
| Exposed tools | List | — | | `UC-77.2-01` | `exposed_tools text[] NOT NULL DEFAULT '{}'` (GIN index) |
| Auth | Enum | — | `OAuth`, `ApiKey`, `None` | `UC-77.2-01` | `auth_type text NOT NULL DEFAULT 'ApiKey'`, `CHECK client_mcp_exposure_auth_check` (see INT-5) |
| Test result | Date-time, Text | — | e.g. "Handshake OK · protocol 2025-06-18 · 3 tools listed" | `UC-77.2-02` | `last_test_at timestamptz`, `last_test_result text` |

## AG-UI exposure — `gov.client_agui_exposure`

Stories: `UC-77.3-01` … `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Expose agents over AG-UI | Boolean | — | "AG-UI streaming is off for this client." when off | `UC-77.3-01`, `-02` | `is_enabled boolean NOT NULL DEFAULT false` |
| Events | List | — | | `UC-77.3-01` | `allowed_events text[] NOT NULL DEFAULT '{}'` |
| Allowed origins | List | — | Other origins are refused by CORS and logged | `UC-77.3-01`, `-03` | `allowed_origins text[] NOT NULL DEFAULT '{}'` (GIN index) |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| INT-1 | ClientKey: rotation grace period | `UC-77.1-02`: the old key stops working after the grace period | No column records a grace period or the key a rotation replaced | Missing column |
| INT-2 | ClientKey.Expired | `UC-77.1-04`: the key shows Expired | No `Expired` status; derived from `expires_at` | Model drift |
| INT-3 | IntegrationClient.Allowed permissions | `UC-76.1-03`: at least one permission | No database rule; application-side (not verified) | Constraint gap |
| INT-4 | MCP endpoint per client | Specification §7.5.6: an endpoint per client | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: one shared `/api/mcp`, autosave, test needs a pasted key (not re-verified here) | Unverified |
| INT-5 | ClientMcpExposure.Auth | Migration `0000` declares `client_mcp_exposure_auth_check` in `OAuth`, `ApiKey`, `None`, and no later migration changes it | `gov.ts` declares it against `CONNECTOR_AUTH_TYPES`, which also has `ClientCredentials`, `Bearer` and `Basic` | Model drift |
