# Data dictionary: knowledge

| Item | Value |
| --- | --- |
| Purpose | Fields of knowledge collections, sources, documents, ingestion jobs and retrieval tests |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#knowledge) · [Data model overview](../overview.md#the-passage-index-in-awp_kb) · [Flow F-07](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`); passages in `awp_kb`. Conventions and legend:
[README](README.md).

## Knowledge collection — `ai.knowledge_collection`

Stories: S-56 (`UC-56.1`, `UC-56.2`, FR-067), S-57 Configuration (`UC-57.2-01` … `-06`, FR-069), `SC-KN-01`, `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Name | Text | Yes | | `UC-56.2-01` | `name_en`, `name_ar text NOT NULL` |
| Collection ID | Text | Yes | Suggested; unique | `UC-56.2-01`, `-02` | `collection_id text NOT NULL`, unique |
| Project | Reference → Project | — | | `UC-56.2-01` | `project_id uuid` → `work.project` |
| Visibility | Enum | — | Uses the data classification levels `Public`, `Internal`, `Confidential`, `Restricted` | `UC-56.2-01`, `UC-57.2-03` | `visibility text NOT NULL DEFAULT 'Internal'`, `CHECK` against `SENSITIVITIES` |
| Index type, distance metric, HNSW m and ef_construct, quantisation | JSON | — | Drives the collection's partial HNSW indexes in `awp_kb`, one per embedding dimension (`passage_hnsw_<collection>__d<n>`, D256) | `UC-56.2-01`, Specification §7.4.7 | `index_config_json jsonb NOT NULL DEFAULT '{}'` |
| Chunking technique, chunk size, overlap, OCR, Arabic normalisation, strip headers and footers, PII masking | JSON | — | Overlap must be less than the chunk size; values in range | `UC-56.2-01`, `UC-57.2-01`, `-04` | `chunking_config_json jsonb NOT NULL DEFAULT '{}'` |
| Embedding route, dimensions, entity-extraction route, re-ranker | JSON | Embedding route yes | The embedding route is a route of kind `Embedding`, and a changed one that is not is refused; the entity-extraction route is a `Standard` or `Typesafe` route, which graph extraction runs on (D257, D260). Changing the embedding route warns and re-indexes the whole collection | `UC-56.2-01`, `-02`, `UC-57.2-02` | `models_config_json jsonb NOT NULL DEFAULT '{}'` |
| Top-k, minimum score, sync schedule, maximum size | JSON | — | At maximum size new documents are rejected | `UC-57.2-03`, `-05` | `retrieval_config_json jsonb NOT NULL DEFAULT '{}'` |
| Status | Enum | — | `Ready`, `Ingesting`, `Error`; progress comes from the ingestion job | `UC-56.2-03`, `-04` | `status text NOT NULL DEFAULT 'Ready'`, `CHECK` against `KNOWLEDGE_COLLECTION_STATUSES` |
| Error reason | Text | — | Shown with a re-index action | `UC-56.2-04` | `last_error text` (migration `0026`) |
| Last sync | Date-time | — | | Specification §7.4.7 | `last_sync_at timestamptz` |
| Documents, chunks, entities | Number | — | KPIs | `UC-56.1-01` | entities: `entity_count integer NOT NULL DEFAULT 0` (written back from Neo4j); documents and chunks derived |

## Knowledge source — `ai.knowledge_source`

Stories: S-57 Document sources (`UC-57.1-01` … `-09`, FR-068).

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Type | Enum | Yes | `Upload` (PDF, DOCX, XLSX, HTML, MD), `UrlCrawl`, `McpResource`; unsupported files or invalid URLs are rejected | `UC-57.1-01` … `-03`, `-07` | `type text NOT NULL`, `CHECK` against `KNOWLEDGE_SOURCE_TYPES` |
| Name | Text | — | | Specification §7.4.7 | `name text NOT NULL` |
| Start URL, max depth, include pattern; connector and resource path | JSON | Per type | | `UC-57.1-02`, `-03` | `config_json jsonb NOT NULL DEFAULT '{}'` |
| Document count | Number | — | | `UC-57.1-01` | `document_count integer NOT NULL DEFAULT 0` |
| Status | Enum | — | `Indexed`, `Indexing`, `Error` | `UC-57.1-01`, `-08` | `status text NOT NULL DEFAULT 'Indexed'`, `CHECK` against `KNOWLEDGE_SOURCE_STATUSES` |
| Error reason | Text | — | Crawl blocked, resource unreachable | `UC-57.1-08` | `last_error text` (migration `0014`) |

## Knowledge document — `ai.knowledge_document`

Stories: `UC-57.1-04`, `-05`, `-09`, `UC-57.2-05`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Document | File | Yes | Unchanged documents are not duplicated on re-index. Removing a source, or deleting the collection, first deletes its passages from `awp_kb` and its graph episodes, and the rows go only after that succeeds; it is refused while the collection's ingestion is running (D258) | `UC-57.1-04`, `-05` | `title text NOT NULL`, `raw_ref text NOT NULL`, `checksum text` |
| Status, chunks | Enum, Number | — | A scanned PDF with OCR off warns that text could not be extracted | `UC-57.1-09` | `status text NOT NULL DEFAULT 'Indexed'`, `chunk_count integer NOT NULL DEFAULT 0` |
| Size | Number | — | Needed to enforce the collection's maximum size | `UC-57.2-05` | `size_bytes integer NOT NULL DEFAULT 0` (migration `0009`) |

## Ingestion job — `ai.ingestion_job`

Stories: `UC-56.2-03`, `UC-57.1-04`, `-06`, `UC-57.2-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Kind | Enum | Yes | `Ingest`, `Reindex`, `ReindexAll` | `UC-57.1-04`, `-06` | `kind text NOT NULL`, `CHECK` against `INGESTION_KINDS` |
| Progress | Number | — | e.g. "Ingesting 62%", live | `UC-56.2-03` | `progress integer NOT NULL DEFAULT 0`, `CHECK` between 0 and 100 |
| Status | Enum | — | `Queued`, `Running`, `Succeeded`, `Failed` | — | `status text NOT NULL DEFAULT 'Queued'`, `CHECK` against `INGESTION_STATUSES` |
| Timings, error | Date-time, Text | — | | — | `started_at`, `ended_at timestamptz`; `error text` |

Schema-only: `temporal_workflow_id text`; `source_id uuid` → `ai.knowledge_source`.

## Retrieval test — `ai.retrieval_test`

Stories: S-58 (`UC-58.1-01` … `-06`, FR-070), `SC-KN-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Query | Text | Yes | | `UC-58.1-01` | `query text NOT NULL` |
| Mode | Enum | Yes | `Vector`, `Graph`, `Hybrid`; Graph and Hybrid are disabled when the Graphiti flag is off | `UC-58.1-01`, `-02`, `UC-75.3-03` | `mode text NOT NULL`, `CHECK` against `RETRIEVAL_MODES` |
| Collection | Reference or All | — | Collections the user cannot see are excluded from All | `UC-58.1-03`, `-05` | `collection_id uuid` (null = all) |
| Passages, scores, re-ranked markers, graph facts | JSON | — | "No passages above the minimum score" when empty | `UC-58.1-01`, `-04` | `results_json jsonb` (object) |
| Retrieval time | Number | — | e.g. "Retrieved in 182 ms" | `UC-58.1-01` | `duration_ms integer` |
| Run by, at | Reference → Person, Date-time | — | | Logical model §14 | `run_by uuid`, `run_at timestamptz NOT NULL DEFAULT now()` |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| KN-1 | Collection configuration | Specification §7.4.7 and `UC-57.2-*`: index, chunking, model and retrieval settings | Held in four JSON objects with no database validation; their shape is defined by the feature code and by `IndexConfig` in `services/agent/src/awp_agent/ingestion/vectors.py` | Constraint gap |
| KN-2 | Collection.Visibility | Logical model: generic visibility | Data classification levels (`SENSITIVITIES`) | Model drift |
| KN-3 | Collection.Error reason, Source.Error reason, Document.Size, Collection.Entity count | Not in the logical model | `last_error`, `size_bytes`, `entity_count` | Schema extension |
| KN-4 | Configuration options on screen | Specification §7.4.7 | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: distance metric, HNSW parameters, quantisation, dimensions, re-ranker, crawl depth and include pattern, MCP resource picker not built (not re-verified here) | Unverified |
