# Data dictionary: budgets

| Item | Value |
| --- | --- |
| Purpose | Fields of agent budgets, budget periods, events and the changes log |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/engage-and-governance.md#budgets) · [Data model overview](../overview.md) · [Flow F-09](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `gov` (`apps/web/src/db/schema/gov.ts`). Conventions and legend: [README](README.md).
Every money value is an estimate (`COM-15`). A run's estimated cost is added to its agent's budget
period when `run_finish` records the run; the agent runtime sends 0 (runtime specification conflict 10),
so spend reads 0 for runs on it.

## Agent budget — `gov.agent_budget`

Stories: S-71 (`UC-71.1-01` … `-09`, FR-080), S-72 (`UC-72.1-01` … `-08`, FR-081), `SC-BUD-01` … `-03`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Agent | Reference → Agent | Yes | | `UC-71.1-03` | `agent_id uuid NOT NULL` → `ai.agent` |
| Limit | Money | Yes | Must be greater than 0 | `UC-71.1-03`, `-06`, `UC-72.1-02` | `limit_aed numeric(18,4) NOT NULL` |
| Period | Enum | Yes | `Daily`, `Weekly`, `Monthly`, `Quarterly` | `UC-71.1-03` | `period text NOT NULL DEFAULT 'Monthly'`, `CHECK` against `BUDGET_PERIODS` |
| Effective from | Date | Yes | | `UC-71.1-03` | `effective_from timestamptz NOT NULL` |
| Effective to | Date | No | Cleared by "Keep forever (no end date)"; must be after effective from; budgets for one agent must not overlap. A window includes its start and excludes its end, so one window may start when another ends (D322) | `UC-71.1-04`, `-06`, `-07` | `effective_to timestamptz`; `CHECK agent_budget_window_check`; trigger `agent_budget_no_overlap` |
| Warn at % | Number | — | 1–99 | `UC-71.1-03`, `-06` | `warn_at_pct integer NOT NULL DEFAULT 80`, `CHECK` between 1 and 100 |
| Action at 100% | Enum | — | `NotifyOnly`, `SwitchToCheaperAlias`, `PauseAgent` | `UC-71.1-03`, `UC-72.1-05`, `-06` | `action_at_100 text NOT NULL DEFAULT 'NotifyOnly'`, `CHECK` against `BUDGET_ACTIONS_AT_100` |
| Cheaper route | Reference → Route | Yes with switch to cheaper alias | | `UC-71.1-05`, `SC-BUD-02` | `cheaper_route_id uuid` → `ai.route`; `CHECK agent_budget_cheaper_route_check` |
| Status | Enum | — | `Active`, `Scheduled`, `Expired`, derived from the dates | `UC-71.1-02`, `-03`, `SC-BUD-03` | derived |
| Usage, estimated spend, forecast | Money, Number | — | Derived; KPIs over 90% and ending within 90 days | `UC-71.1-01`, `UC-72.1-01` | derived from `gov.budget_period` and `ai.run` |

## Budget period — `gov.budget_period`

Stories: `UC-72.1-01`, `-07`, `-08`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Period | Date-time | Yes | A new period resets spend; the previous moves to history | `UC-72.1-07` | `period_start`, `period_end timestamptz NOT NULL`; `CHECK budget_period_window_check`; unique (`budget_id`, `period_start`) |
| Estimated spend | Money | — | | `UC-72.1-01` | `estimated_spend_aed numeric(18,4) NOT NULL DEFAULT 0` |
| Runs | Number | — | | Specification §7.5.2 | `runs integer NOT NULL DEFAULT 0` |
| Usage | Number | — | Coloured by band: under 75%, 75–90%, over 90% | Specification §7.5.2 | derived |

## Budget event — `gov.budget_event`

Stories: `UC-72.1-04`, `-05`, `SC-BUD-01`, `-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Event | Enum | Yes | `WarningSent`, `HardLimitReached`, `ActionApplied` | `UC-72.1-04`, `-05` | `type text NOT NULL`, `CHECK` against `BUDGET_EVENT_TYPES` |
| At, period, detail | Date-time, Reference, Text | — | | `UC-72.1-04` | `at timestamptz NOT NULL DEFAULT now()`; `period_id uuid` → `gov.budget_period`; `detail_en`, `detail_ar text` |

## Budget change — `gov.budget_change`

Stories: `UC-72.1-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Description | Text | Yes | e.g. "Limit set to …", "Budget created, effective …, no end date" | `UC-72.1-02` | `description_en`, `description_ar text NOT NULL` |
| Changed by, at | Reference → Person, Date-time | — | | `UC-72.1-02` | `changed_by uuid` → `core.person`; `at timestamptz NOT NULL DEFAULT now()` |

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| BUD-1 | AgentBudget.Warn at % | `UC-71.1-06`: outside 1–99 is rejected | `CHECK` allows 1–100 | Value difference |
| BUD-2 | AgentBudget.Limit | `UC-71.1-06`: a limit ≤ 0 is rejected | No `CHECK` on `limit_aed`; application-side (not verified) | Constraint gap |
| BUD-3 | BudgetPeriod.Usage % | Logical model §18: `UsagePct` attribute | Not stored; derived | Model drift |
| BUD-4 | Budget detail "This month by day" chart | `UC-72.1-01` | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: replaced by "Runs by period" (not re-verified here) | Unverified |
