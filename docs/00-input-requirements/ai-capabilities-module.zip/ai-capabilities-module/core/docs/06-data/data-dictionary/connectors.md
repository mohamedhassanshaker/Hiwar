# Data dictionary: connectors

| Item | Value |
| --- | --- |
| Purpose | Fields of connectors, their tools and tiers, and the catalogue |
| Audience | Business analysts, developers, testers |
| Related | [Dictionary index](README.md) · [Relationships](../erd/agents-and-capabilities.md#connectors) · [Data model overview](../overview.md) · [Flow F-10](../../specs/flows.md) |
| Last verified against code | 2026-10-29 |

Schema: `ai` (`apps/web/src/db/schema/ai.ts`). Conventions and legend: [README](README.md).

## Connector — `ai.connector`

Stories: S-54 (`UC-54.1-01` … `-09`, `UC-54.2-01` … `-08`, FR-062, FR-063), `SC-CON-01`, `-02`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Connector name | Text | Yes for OpenAPI | | `UC-54.1-09` | `name_en`, `name_ar text NOT NULL`; `code text NOT NULL` unique |
| Transport | Enum | — | `StreamableHttp`, `Stdio`, `OpenApi`; prefilled from a catalogue entry | `UC-54.1-01`, `-09` | `transport text NOT NULL DEFAULT 'StreamableHttp'`, `CHECK` against `CONNECTOR_TRANSPORTS` |
| Server URL | Text | Yes (HTTP) | Empty or invalid is rejected. `internal://` marks a connector served by the platform, which cannot be removed; `internal://platform` is the built-in Platform connector (code `platform`, migration `0052`), which also cannot be changed or switched off and has no tool rows, because its tools are the platform catalogue (D228) | `UC-54.1-04`, `-06` | `server_url text` |
| Command | Text | Yes (stdio) | The command line the connector runtime runs in the connector's Pod | Logical model §12 | `command text` |
| Authentication | Enum | — | `OAuth` (the authorization-code grant an administrator completes with Connect; MCP servers only), `ClientCredentials` (OAuth 2 client credentials), `Bearer`, `ApiKey` (in a named header or query parameter), `Basic` (user name and password), `None`; the same for MCP and REST API connectors (D296, migration `0064`) | `UC-54.1-01`, `-09` | `auth_type text NOT NULL DEFAULT 'None'`, `CHECK` against `CONNECTOR_AUTH_TYPES` |
| Credentials | Secret | — | One typed credential object, encrypted, whose `type` is the connector's `auth_type` (`features/connectors/credential.ts`); an OAuth sign-in's tokens are kept in it. Secret fields are write-only and an edit that leaves one empty keeps the stored one; the other fields are shown back. A credential saved earlier as a bare string is read in its old form. No agent tool takes a credential (D277, D296) | `UC-54.1-02` | `secret_ref bytea` (ciphertext) |
| Default tier for new tools | Enum | — | `T0` … `T3` | `UC-54.1-03` | `default_tier_for_new_tools text NOT NULL DEFAULT 'T1'`, `CHECK` against `TOOL_TIERS` |
| Connector enabled | Boolean | — | Off: agents get "connector disabled"; a failed handshake allows adding only as Disabled | `UC-54.2-02`, `UC-54.1-05` | `is_enabled boolean NOT NULL DEFAULT false` |
| Status | Enum | — | `Connected`, `Error`, `Disabled`; Error when it goes down at run time | `UC-54.2-07` | `status text NOT NULL DEFAULT 'Disabled'`, `CHECK` against `CONNECTOR_STATUSES` |
| Handshake result | Date-time, Text | — | "Handshake OK · N tools listed" | `UC-54.1-02` | `last_handshake_at timestamptz`, `protocol_version text` |
| Catalogue entry | Reference | — | Set when `connector_create` names a catalogue entry; null for a connector added in the console (D334) | `UC-54.1-01`, `-04` | `catalog_entry_id uuid` → `ai.connector_catalog_entry` |

## Connector tool — `ai.connector_tool`

Stories: `UC-54.1-02`, `-03`, `-07` … `-09`, `UC-54.2-03`, `-06`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Tool | Text | Yes | Listed by the handshake; unique per connector | `UC-54.1-02` | `name text NOT NULL`; `title_en`, `title_ar text NOT NULL`; `description_en`, `description_ar text` |
| Annotations | Boolean | — | Read-only defaults to T0, destructive to T2 | `UC-54.1-07`, `-08` | `read_only_hint`, `destructive_hint boolean` |
| Tier | Enum | — | `T0`, `T1`, `T2`, `T3`; raising T1 to T2 makes new calls need approval; for OpenAPI, GET and HEAD start at T0 and the rest at the default tier | `UC-54.1-03`, `-09`, `UC-54.2-03` | `tier text NOT NULL DEFAULT 'T1'`, `CHECK` against `TOOL_TIERS` |
| Available | Boolean | — | Changed tools are unavailable until reviewed | `UC-54.2-06` | `is_available boolean NOT NULL DEFAULT true` |
| Operation | JSON | Yes for OpenAPI | HTTP method, path, parameter placement and argument schema of the operation | `UC-54.1-09` | `operation jsonb` (object; migration `0028`) |

## Connector allowed agent — `ai.connector_allowed_agent`

The table exists but is not read or written (D227). Which agents use a connector is the agents' own
grant, `ai.agent_tool_mode` (`ai.agent_platform_tool` for the Platform connector); a run reaches every enabled connector, narrowed by its project's
allowed connectors. Dropping the table is an open decision.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| (unused) | List of Agent | — | Not read or written | D227 | `(connector_id, agent_id)`, both foreign keys |

## Connector catalogue entry — `ai.connector_catalog_entry`

Stories: `UC-54.1-01`.

| Field | Type | Req. | Rules and allowed values | Source | Column |
| --- | --- | --- | --- | --- | --- |
| Name, description, logo | Text, File | — | | Specification §7.4.5 | `name_en`, `name_ar`, `description_en`, `description_ar`, `logo_ref` |
| Default URL, auth | Text, Enum | — | Read by `connector_create`, which names an entry by `catalogueId` | `UC-54.1-01`, D334 | `default_url text`, `auth_type text NOT NULL DEFAULT 'None'`, `CHECK` against `CONNECTOR_AUTH_TYPES` |

Schema-only: `tool_count integer NOT NULL DEFAULT 0` (reported by `connector_list` before install).

## Mismatches

| # | Entity.field | Story or logical model | Schema | Class |
| --- | --- | --- | --- | --- |
| CON-1 | Connector.Transport | Logical model §12: StreamableHttp, Stdio | Adds `OpenApi` (migration `0028`, `UC-54.1-09`) | Model drift |
| CON-2 | Connector.Authentication | Logical model §12: OAuth, ApiKey, None | Adds `ClientCredentials`, `Bearer`, `Basic` (migrations `0028`, `0064`) | Model drift |
| CON-3 | Connector.Server URL | `UC-54.1-06`: required and valid | Nullable (stdio has none); validation application-side | Constraint gap |
| CON-4 | ConnectorTool.Operation, CatalogEntry.Tool count | Not in the logical model | Present | Schema extension |
| CON-5 | Connector transports | Specification §7.4.5 | [reports/handoff-v2-changes.md](../../reports/handoff-v2-changes.md) §10: no "Platform MCP" transport or "Run token" auth (not re-verified here). The console has no catalogue to browse (D334) | Unverified |
| CON-6 | Connector.Allowed agents | `UC-54.1-03`, `UC-54.2-04`: the connector names its allowed agents | No list on the connector; the agent version's grant decides (D227); `ai.connector_allowed_agent` unused | Requirement superseded by decision |
