# Data model

| Item | Value |
| --- | --- |
| Purpose | How the platform's data is organised: databases, schemas, conventions, entity groups, enumerations and the integrity rules, bound to the code that implements them |
| Audience | Developers, architects, business analysts |
| Related | [Entity relationship diagrams](erd/organisation-and-work.md) · [Data dictionary](data-dictionary/README.md) · [Business rules](../01-business/business-rules.md) · [Functional requirements](../specs/requirements.md) · [Architecture overview](../03-architecture/overview.md) · [Glossary](../glossary.md) |
| Last verified against code | 2026-10-29 |

The domain database `awp` is the system of record. Its tables are declared once, in Drizzle, under
`apps/web/src/db/schema/` (`core.ts`, `work.ts`, `ai.ts`, `gov.ts`, `audit.ts`, with the shared
helpers in `_conventions.ts` and every enumeration in `enums.ts`). Migrations are generated into
`apps/web/src/db/migrations/` and applied, together with the SQL in `infra/postgres/`, by
`apps/web/src/db/migrate.ts`. Everything outside `awp` is execution state or a rebuildable index.

This document is the map. The relationships of each entity group are drawn in three files under
[`erd/`](erd/organisation-and-work.md); every field, its rules and the user story it comes from are
in the [data dictionary](data-dictionary/README.md).

## Where the data lives

One CloudNativePG cluster, `awp-pg`, carries every relational store, each database owned by its
own role (`infra/platform/values/awp-pg.yaml.gotmpl`).

| Database or store | Holds | Who connects | Defined in |
| --- | --- | --- | --- |
| `awp` | The domain: every entity in this document | `web` and the `db-migrate` Job only | `apps/web/src/db/schema/*.ts`, `apps/web/src/db/migrations/`, `infra/postgres/*.sql` |
| `awp_kb` | Passage vectors for Vector retrieval (pgvector), with extensions `vector` and `pg_trgm` | The agent service's ingestion and retrieval | `services/agent/src/awp_agent/ingestion/vectors.py` (see [below](#the-passage-index-in-awp_kb)) |
| `temporal`, `temporal_visibility` | Temporal persistence and visibility | Temporal | `infra/platform/values/temporal.yaml` |
| `phoenix` | Arize Phoenix traces, datasets and evaluations | Phoenix | `infra/platform/values/phoenix.yaml` |
| Neo4j, through Graphiti | Knowledge entities and facts; memory episodes | The agent service | `infra/platform/values/neo4j.yaml` |
| Object storage over the S3 API | File, artifact, attachment, skill package, memory, branding and raw document content; large Temporal payloads | `web` and the agent service | `apps/web/src/lib/objects.ts`, `infra/charts/awp/values.yaml` (see [below](#data-held-outside-the-domain-database)) |
| Valkey | Live-update channels, AG-UI event streams, the mail job stream | `web` and the agent service | `apps/web/src/lib/valkey.ts`, `infra/platform/values/valkey.yaml` |

**Ownership rule.** Only the web application connects to `awp`. The agent service reads and writes
domain data through the platform MCP server, under the run token's identity, so an agent passes
the same permission check, validation and audit a person does. The agent service owns only
`awp_kb`. Database roles in `infra/postgres/06-roles.sql`: `awp_app` (domain read and write, through
the pooler), `awp_ro` (reporting, on the replica), `awp_migrate` (DDL, the `db-migrate` Job) and
`awp_audit_reader` (`SELECT` on `audit` only).

## Conventions

Implemented once in `apps/web/src/db/schema/_conventions.ts` and used by every table.

| Convention | Rule | Implementation |
| --- | --- | --- |
| Identifier | Every entity has an `id` (UUIDv7, for index locality) | `id()`: `uuid` primary key, default `uuidv7()` (PostgreSQL 18) |
| Codes and keys | Human-facing codes (`key`, `code`, `alias`, `client_id`, `skill_name`, `collection_id`) are unique, suggested from the name and editable before first save. Work and request keys follow `<PROJECT or TYPE PREFIX>-<number>` (e.g. `TSK-2325`, `EXP-4471`, `SES-1042`, `CS-119`) | Unique index per table; surfaced as `COM-13` |
| Bilingual names | User-named records carry `name_en` and `name_ar`; titles and descriptions likewise where shown in both languages | `bilingualName`, `bilingualTitle` (both `NOT NULL`) |
| Audit columns | `created_at`, `created_by`, `updated_at`, `updated_by`, `version` on every mutable entity | `audited` |
| Optimistic concurrency | `version integer NOT NULL DEFAULT 1`, incremented on every update; a stale write is rejected | `audited.version`; the `awp_version_bump` trigger on every table with a `version` column (`infra/postgres/05-integrity.sql`); surfaced as `COM-10` |
| Principals | An actor or assignee is a pair `principal_type` + `principal_id` | `text` + `uuid` with a `CHECK` against `PRINCIPAL_TYPES` (`Person`, `Agent`, `Group`, `Role`, `ExternalContact`, `System`, `Client`); referential integrity enforced in the domain layer |
| Versioning | Published definitions (agents, request types, storylines, skills, memories) have a parent entity plus immutable version rows; running items reference the version they started with | `…_version` tables; one active or published version per parent by partial unique index |
| Dynamic attributes | Requests and work items store type-specific values in `attributes`; a request's values are validated against the attribute definitions of its request type version | `jsonb NOT NULL DEFAULT '{}'` with an object `CHECK` and a `jsonb_path_ops` GIN index; a request's values are checked by `attributesProblem` in `features/requests/attributes.ts` (D304) |
| `…Json` and `…Config` fields | Objects, never arrays or scalars | `jsonObjectCheck()`: `jsonb_typeof(...) = 'object'` |
| Lists of values | Channels, tags, origins, tool names | `text[]` with a GIN index (`arrayIndex()`), or a child table when rows need their own attributes |
| Money | Estimated costs and budgets in AED, always presented as an estimate | `money()`: `numeric(18,4)`; surfaced as `COM-15`. Model prices are `numeric(18,6)` |
| Timestamps | UTC; working calendar and time zone from the organisation for SLAs and schedules | `ts()`: `timestamptz` |
| Enumerations | `text` with a `CHECK`, never a native enum type, so a list can change by migration | `enumCheck()` / `optionalEnumCheck()` over the tuples in `enums.ts` |
| Search keys | Names and titles match across Arabic letter forms and diacritics | `searchKey()`: a generated column over `public.awp_normalise(...)` (`infra/postgres/01-extensions.sql`) with a `pg_trgm` GIN index (`trigramIndex()`) |
| Soft state | Records that can be deactivated carry `is_active` or a `status`; deleting project content keeps its audit records | `isActive()` |
| Secrets | Never stored as readable text; values are write-only | `bytea` ciphertext from the envelope encryption in `src/lib/crypto.ts`; `client_key` stores a prefix and a hash only |
| Append-only | The audit trail and the event tables are insert-only | `audit` schema with an `INSERT`/`SELECT`-only guard trigger (`infra/postgres/04-audit-guard.sql`); monthly range partitions on `audit.audit_entry`, `work.request_event`, `work.work_item_activity`, `work.room_message` and `ai.run_step` (`infra/postgres/03-partitions.sql`), whose primary keys carry the partition column |

## Schemas

Five schemas, 124 tables. Each schema's file opens with the data-model section it implements.

| Schema | Holds | Tables | Feature modules under `apps/web/src/features/` |
| --- | --- | --- | --- |
| `core` | Organisation, OrgUnit, Person, PersonInvitation, Passkey, NotificationPreference, Role, Permission, RolePermission, RoleAssignment, Group, GroupMember, ExternalContact, Calendar, CalendarHoliday, PersonCredential, PasswordReset, Auth.js accounts (UAE PASS links), sessions and verification tokens | 20 | `organisation` |
| `work` | Project and its members, allowed agents, allowed connectors, approval rules and decisions; DiscussionRoom, RoomParticipant, RoomMessage, MessageFeedback, ContextHandoff, RoomWorkItemLink; RequestType and versions, TransitionStep, StepAudience, RoutingRule, AttributeDefinition, Request, RequestEvent, Attachment; WorkItem, WorkItemActivity, SavedView; ScheduledWorkItem, ScheduleRun; Artifact, ArtifactVersion, ProjectFile, FileAccessGrant; dashboard card comments | 34 | `projects`, `rooms`, `requests`, `work-items`, `schedules`, `files`, `comments` |
| `ai` | Agent, AgentVersion and its grants (skills, connector tool modes, platform tools, memory, knowledge), PlaygroundTest, Run, RunStep, Approval, ApprovalDecision, AgentQuestion, InboxItem; Skill and versions, scans, and SkillTestCase, which nothing reads or writes (D333); Connector, ConnectorTool, catalogue, and ConnectorAllowedAgent, which nothing reads or writes (D227); MemoryScope, Memory, MemoryVersion, MemoryEntry, MemoryReview; KnowledgeCollection, KnowledgeSource, KnowledgeDocument, IngestionJob, RetrievalTest; ModelProvider, ProviderConnection, ConnectionAllowedModel, Route, RouteStep; Channel, EmbeddedDeployment, DeploymentSurface, Storyline and versions and steps, DeploymentConversation, ConversationMessage, ChannelMessage, WidgetEvent (D231); saved assistant chats | 49 | `agents`, `inbox`, `skills`, `connectors`, `memory`, `knowledge`, `models`, `engage`, `assistant` |
| `gov` | AgentBudget, BudgetPeriod, BudgetEvent, BudgetChange; IntegrationClient, ClientKey, ClientPermission, ClientAgent, ClientMcpExposure, ClientAguiExposure; SettingsVersion, BrandingAsset, FeatureFlag, SystemState, DocPage, LogEntry, OutboxEvent, MailNotification | 18 | `budgets`, `integrations`, `governance` |
| `audit` | AuditEntry, monthly range partitions, insert-only with a guard trigger | 1 | `governance` |

## Domain map

```mermaid
flowchart LR
  ORG[Organisation and identity] --> PRJ[Projects]
  PRJ --> ROOM[Discussion rooms]
  PRJ --> REQ[Requests]
  PRJ --> WI[Work items]
  PRJ --> SCH[Scheduled work items]
  PRJ --> AF[Artifacts and files]
  REQ --> WI
  AG[Agents and runs] --> WI
  AG --> ROOM
  AG --> REQ
  CAP[Skills, connectors, memory, knowledge, models] --> AG
  ENG[Channels, deployments, storylines] --> AG
  GOV[Budgets, audit, settings, integrations] --> AG
  HIL[Inbox: approvals and questions] --> AG
  COM[Dashboard card comments] --> WI
```

## Entity groups

| Group | Relationships | Fields | Requirements that depend on it |
| --- | --- | --- | --- |
| Organisation and identity | [erd](erd/organisation-and-work.md#organisation-and-identity) | [dictionary](data-dictionary/organisation-and-identity.md) | FR-006 … FR-009, FR-048 … FR-052, FR-084 |
| Projects | [erd](erd/organisation-and-work.md#projects) | [dictionary](data-dictionary/projects.md) | FR-016 … FR-020 |
| Discussion rooms | [erd](erd/organisation-and-work.md#discussion-rooms) | [dictionary](data-dictionary/discussion-rooms.md) | FR-021 … FR-026 |
| Requests and request types | [erd](erd/organisation-and-work.md#requests-and-request-types) | [dictionary](data-dictionary/requests.md) | FR-034 … FR-043 |
| Work items | [erd](erd/organisation-and-work.md#work-items) | [dictionary](data-dictionary/work-items.md) | FR-027 … FR-033 |
| Scheduled work items | [erd](erd/organisation-and-work.md#scheduled-work-items) | [dictionary](data-dictionary/scheduled-work.md) | FR-044, FR-045 |
| Artifacts and files | [erd](erd/organisation-and-work.md#artifacts-and-files) | [dictionary](data-dictionary/artifacts-and-files.md) | FR-046, FR-047 |
| Dashboard card comments | [erd](erd/organisation-and-work.md#dashboard-card-comments) | [dictionary](data-dictionary/comments.md) | none: handoff v2 §5 feature |
| Agents, runs and the inbox | [erd](erd/agents-and-capabilities.md#agents-runs-and-the-inbox) | [dictionary](data-dictionary/agents-runs-inbox.md) | FR-005, FR-010 … FR-015, FR-053 … FR-058 |
| Skills | [erd](erd/agents-and-capabilities.md#skills) | [dictionary](data-dictionary/skills.md) | FR-059 … FR-061 |
| Connectors | [erd](erd/agents-and-capabilities.md#connectors) | [dictionary](data-dictionary/connectors.md) | FR-062, FR-063 |
| Memory | [erd](erd/agents-and-capabilities.md#memory) | [dictionary](data-dictionary/memory.md) | FR-064 … FR-066 |
| Knowledge | [erd](erd/agents-and-capabilities.md#knowledge) | [dictionary](data-dictionary/knowledge.md) | FR-067 … FR-070 |
| Models and routes | [erd](erd/agents-and-capabilities.md#models-and-routes) | [dictionary](data-dictionary/models-and-routes.md) | FR-071, FR-072 |
| Channels, deployments and storylines | [erd](erd/engage-and-governance.md#channels-deployments-and-storylines) | [dictionary](data-dictionary/engage.md) | FR-073 … FR-077 |
| Budgets | [erd](erd/engage-and-governance.md#budgets) | [dictionary](data-dictionary/budgets.md) | FR-080, FR-081 |
| Integrations | [erd](erd/engage-and-governance.md#integrations) | [dictionary](data-dictionary/integrations.md) | FR-085 … FR-090 |
| Governance and settings | [erd](erd/engage-and-governance.md#governance-and-settings) | [dictionary](data-dictionary/governance.md) | FR-082 … FR-084, FR-091, FR-092 |

## Enumerations

Every enumeration is a string tuple in `apps/web/src/db/schema/enums.ts`, used three ways: the
`CHECK` on the column, the TypeScript union a repository returns, and the Zod enum an action input
is validated against. The values below are the code's. The last column records where the code
differs from the logical model v1.2 (`_reference/Tahseel_AWP_Data_Model.md` §21).

| Enumeration | Constant | Values | Difference from logical model v1.2 |
| --- | --- | --- | --- |
| Work item type | `WORK_ITEM_TYPES` | Task, SubItem, Bug | — |
| Work item status | `WORK_ITEM_STATUSES` | Backlog, ToDo, InProgress, InReview, Blocked, Done, Cancelled | — |
| Priority | `PRIORITIES` | High, Medium, Low | — |
| Project status | `PROJECT_STATUSES` | Backlog, Planned, InProgress, Paused, Done, Archived | — |
| Sensitivity | `SENSITIVITIES` | Public, Internal, Confidential, Restricted | Also used for knowledge collection visibility |
| Room status | `ROOM_STATUSES` | Active, Idle, Paused, Closed, Archived | — |
| Room type | `ROOM_TYPES` | Chat, Review, WarRoom, Support, Automation | Logical model writes `War-room` |
| Room source | `ROOM_SOURCES` | Console, Teams, Widget, WhatsApp, Routine | — |
| Turn-taking | `TURN_TAKINGS` | MentionOnly, Autonomous | — |
| Request type version status | `REQUEST_TYPE_VERSION_STATUSES` | Draft, Published, Retired | — |
| Decomposition | `DECOMPOSITIONS` | None, Template, Agent, Hybrid | — |
| Entry mode (request type) | `ENTRY_MODES` | TemplateForm, AgenticInteractive | — |
| Entry mode (request) | `REQUEST_ENTRY_MODES` | Form, Agentic | — |
| Intake channel | `INTAKE_CHANNELS` | Console, Teams, Email, Widget, WhatsApp, Api | Logical model writes `API` |
| SLA unit | `SLA_UNITS` | Minutes, Hours, Days, BusinessDays | Logical model: Hours, BusinessDays only; use-case v1.1 `UC-30.1-01` names all four |
| Terminal outcome | `REQUEST_STEP_OUTCOMES` | Completed, Rejected | — |
| Audience access | `AUDIENCE_ACCESSES` | CanAct, NotifyOnly, ViewOnly | — |
| Work item origin | `WORK_ITEM_ORIGINS` | Manual, Request, Room, Schedule, Agent, Comment | `Comment` added (dashboard card comments) |
| Agent status | `AGENT_STATUSES` | Idle, Running, Waiting, Paused, Error, Retired | — |
| Execution profile | `EXECUTION_PROFILES` | Conversational, Task, Planner, Reviewer, Triage, Scripted, Routine | — |
| Agent trust | `AGENT_TRUSTS` | Restricted, Standard, Elevated, Coordinator, System | — |
| Agent tool mode | `AGENT_TOOL_MODES` | Auto, Approval, Denied | — |
| Tool tier | `TOOL_TIERS` | T0, T1, T2, T3 | Logical model adds the labels Autonomous, Confirm, HumanApproval, Forbidden |
| Run status | `RUN_STATUSES` | Queued, Running, Waiting, Blocked, Succeeded, Failed, Cancelled, BudgetExceeded | `Blocked` added by migration `0037` (D101) |
| Run trigger | `RUN_TRIGGERS` | Mention, Assignment, RequestStep, Schedule, Widget, Manual, Replay, Delegation | `Delegation` added; `Setup` dropped by migration `0075` (D375), its runs now `Manual` |
| Run context | `RUN_CONTEXT_TYPES` | Room, WorkItem, Request, Deployment, Console | `Console` added (page assistant, playground; migration `0030`); `Setup` dropped by migration `0075` (D375), its runs now `Console` |
| Run step type | `RUN_STEP_TYPES` | Start, Model, Tool, Skill, Approval, Question, Verify, Handoff | `Start` and `Skill` added |
| Approval status | `APPROVAL_STATUSES` | Pending, Approved, Rejected, ChangesRequested, Expired | — |
| Approval policy | `APPROVAL_POLICIES` | Single, AnyOf, Sequential | — |
| Inbox kind | `INBOX_KINDS` | Approval, Question, Mention, SlaWarning, Review | `Review` added |
| Memory scope | `MEMORY_SCOPE_KINDS` | Organisation, BusinessUnit, Agent, Session | — |
| Memory status | `MEMORY_STATUSES` | Active, PendingReview, NeedsAttention, Rejected, Archived | — |
| Knowledge source type | `KNOWLEDGE_SOURCE_TYPES` | Upload, UrlCrawl, McpResource | — |
| Retrieval mode | `RETRIEVAL_MODES` | Vector, Graph, Hybrid | — |
| Route kind | `ROUTE_KINDS` | Standard, Typesafe, Voice, Embedding, Decision | `Embedding` and `Decision` added |
| Model kind | `MODEL_KINDS` | Chat, Embedding, Image, Speech, Transcription, Rerank, Decision, Audio, Video | Logical model §15 lists the same |
| Connector transport | `CONNECTOR_TRANSPORTS` | StreamableHttp, Stdio, OpenApi | `OpenApi` added (migration `0028`, `UC-54.1-09`) |
| Connector auth | `CONNECTOR_AUTH_TYPES` | OAuth, ClientCredentials, Bearer, ApiKey, Basic, None | `ClientCredentials`, `Bearer` and `Basic` added (D296) |
| Provider auth | `PROVIDER_AUTH_TYPES` | ApiKey, EntraId, IamRole, BearerToken, OAuth, None | Not in logical model |
| Channel type | `CHANNEL_TYPES` | WebWidget, WhatsApp, MicrosoftTeams (live); Slack, Email, Sms, VoiceIvr, Telegram, Webex, GoogleChat, Instagram, FacebookMessenger (coming soon) | Logical model writes `SMS` |
| Storyline mode | `STORYLINE_MODES` | Guided, Strict | Free and List folded into Guided (migration `0071`, D339) |
| Storyline step type | `STORYLINE_STEP_TYPES` | Message, Ask, Form, Confirm, Decide, Classify, Tool, Skill, Verify, CreateWork, Handoff, Wait, Subflow, GoTo, End | §21 omits `Form`; §16 has it |
| Storyline version status | `STORYLINE_VERSION_STATUSES` | Draft, Published, Superseded | `Superseded` added (migration `0012`) |
| Budget period | `BUDGET_PERIODS` | Daily, Weekly, Monthly, Quarterly | — |
| Budget action at 100% | `BUDGET_ACTIONS_AT_100` | NotifyOnly, SwitchToCheaperAlias, PauseAgent | — |
| File scope of use | `FILE_SCOPES_OF_USE` | OnlyMe, Selected, AllProject | — |
| File status | `FILE_STATUSES` | Active, Inactive, Quarantined | `Quarantined` added (migration `0008`, `UC-33.1-05`) |
| Schedule repeats | `SCHEDULE_REPEATS` | Once, Daily, Weekly, Monthly, OnEvent | — |
| Principal type | `PRINCIPAL_TYPES` | Person, Agent, Group, Role, ExternalContact, System, Client | Logical model §1 names four kinds (Person, Agent, Group/Role, External contact) |
| Audit actor | `AUDIT_ACTOR_TYPES` | Person, Agent, Client, ExternalContact, System | `ExternalContact` added (migration `0029`) |
| Feature flag group | `FEATURE_FLAG_GROUPS` | AgentsAndRuns, MemoryAndKnowledge, Collaboration, Engage, Platform | `Platform` added |
| Client permission | `CLIENT_PERMISSIONS` | agents:invoke, requests:write, work_items:read, rooms:read, knowledge:search, webhooks:receive | — |

The remaining tuples in `enums.ts` (person status, role scope, permission effect, project and room
roles, attachment owners, budget events, ingestion kinds and statuses, visitor identity, gateway
providers, model engines and others) are listed with the field that uses them in the
[data dictionary](data-dictionary/README.md).

## Integrity rules

The ten rules of the logical model (§23) are the validation the product is judged on. Each has an
acceptance criterion that must fail without it. `infra/postgres/05-integrity.sql` enforces in
triggers everything a single statement can decide, so a direct SQL write cannot break it either;
the rest is enforced in the feature services.

| # | Rule | Enforced by | Criterion |
| --- | --- | --- | --- |
| 1 | A sub item's project equals its parent's project | Trigger `work_item_sub_item_project`; `CHECK work_item_sub_item_check` (a SubItem has a parent) | `UC-25.3-05` |
| 2 | A request's attributes validate against its request type version's attribute definitions | `attributesProblem` in `features/requests/attributes.ts` (D304), on raising a request, the widget intake and a step's action. A work item's `attributes` are checked only as a JSON object | `UC-28.1-03`, `UC-30.3-01` |
| 3 | An approval on a request is never decided by its requester, one on a work item never by its person assignee, and never by an agent; a rejection carries a reason. A run's approval in a room or the assistant panel is decided by the person who asked (D105, D284) | Trigger `approval_decision_independence`; `CHECK approval_decision_reason_check` | `UC-12.1-10`, `UC-25.2-04`, `UC-29.2-07` |
| 4 | An agent's tool mode is never looser than the tool's tier, the project's approval rules or the agent's trust | Trigger `agent_tool_mode_tier` for the tier (T3 only Denied, T2 never Auto); feature services for project rules and trust | `UC-51.2-04`, `UC-21.2-04` |
| 5 | A terminal transition step has no audience and no outgoing routing rule | Triggers `step_audience_not_terminal`, `routing_rule_not_terminal` | `UC-30.2-04` |
| 6 | One active version per agent, and one published version per storyline and request type; running items keep their pinned version | Partial unique indexes `agent_version_active_key`, `storyline_version_published_key`, `request_type_version_published_key` | `UC-30.4-01`, `UC-51.3-02`, `UC-64.1-09` |
| 7 | Audit entries are insert-only | Grant scheme plus a statement trigger `audit_guard_<table>` running `audit.reject_change()` on every audit table and partition | `UC-73.1-05` |
| 8 | Secrets are stored only as ciphertext or a hash, and a key's secret is shown once | `bytea` ciphertext columns; feature services (envelope encryption) | `UC-77.1-01` |
| 9 | Codes and keys are unique within their entity | Unique indexes | `COM-13`, `UC-20.2-03`, `UC-27.2-03`, `UC-42.1-03`, `UC-56.2-02`, `UC-60.1-06`, `UC-76.1-03` |
| 10 | Budget periods for the same agent do not overlap | Trigger `agent_budget_no_overlap` (`btree_gist` is not installed, so not an exclusion constraint) | `UC-71.1-07` |

## The passage index in `awp_kb`

`awp_kb` is a rebuildable index, not a system of record. The agent service creates its one table,
`passage`, on first use (`ingestion/vectors.py`):

| Column | Type | Note |
| --- | --- | --- |
| `collection_id` | `text NOT NULL` | The knowledge collection's code; part of the primary key |
| `chunk_id` | `text NOT NULL` | Part of the primary key |
| `doc_id` | `text NOT NULL` | The document the chunk came from |
| `source`, `heading` | `text NOT NULL DEFAULT ''` | Citation details |
| `text` | `text NOT NULL` | The passage |
| `metadata` | `jsonb NOT NULL DEFAULT '{}'` | |
| `embedding` | `vector NOT NULL` | Unconstrained dimension, because collections differ |
| `search` | `tsvector`, generated from `text` | GIN index `passage_search` for keyword search |

A B-tree index `passage_doc` covers (`collection_id`, `doc_id`).

Each collection gets a partial HNSW index per embedding dimension,
`passage_hnsw_<collection>__d<n>`, over its rows with `vector_dims(embedding) = n`, built from the
collection's settings: the distance metric selects the operator class (cosine, L2 or inner
product), `m` and `ef_construction` are the index parameters, and the column is cast to `halfvec`
when the collection asks for half precision or when the dimension exceeds the 2,000 that a plain
`vector` HNSW index accepts. A search reads only the rows of its query's dimension, so rows
embedded by an earlier route are skipped until a re-index replaces them by chunk id (D256,
`UC-57.2-02`). Removing a knowledge source or deleting a collection deletes its passages through
the agent service before the rows in `awp` go (D258).

## Data held outside the domain database

Losing any of this costs time, not data.

| Data | Store | Link from `awp` |
| --- | --- | --- |
| Run execution history: steps, retries, signals, timers | Temporal | `ai.run.temporal_workflow_id`, `work.scheduled_work_item.temporal_schedule_id`, `ai.ingestion_job.temporal_workflow_id` |
| LLM traces, prompts, token usage, eval scores | Arize Phoenix | `ai.run.trace_id` (mission id = Temporal workflow id = trace id, D44) |
| File, artifact, attachment, skill package, memory, branding and raw document content | Object storage over the S3 API, buckets `files`, `artifacts`, `attachments`, `skills`, `memory`, `branding` and `raw-docs` (`buckets` in `apps/web/src/lib/objects.ts`) | `…_ref` columns (`content_ref`, `package_ref`, `raw_ref`, `snapshot_ref`, `capture_ref`, `photo_ref`, `logo_ref`), as `bucket/key` |
| Temporal payloads of 32 KiB or more, encrypted by the payload codec | Bucket `run-payloads`, objects expire after 30 days (D287) | a reference in the Temporal history |
| Passage vectors for Vector retrieval | pgvector in `awp_kb` | collection code + document id + chunk id |
| Knowledge entities and facts, and memory episodes | Neo4j through Graphiti | a chunk's episode has the chunk id as its uuid (D259); one group per collection or memory scope. `ai.knowledge_collection.entity_count` is written back by ingestion |
| Live-update channels (`room:<id>`, `inbox:<person>`, `dash:<scope>`, `conversation:<id>`, `conversations`) | Valkey publish and subscribe | ephemeral |
| A run's AG-UI events | Valkey stream `run:<id>:agui`, read by offset on reconnect | `ai.run.id` |
| Mail jobs | Valkey stream `awp:mail`, consumer group `mailers` (D240) | `gov.mail_notification.id`; the row is the durable record and a sweep sends a lost job |
| Service health | Health endpoints | none |

Application logs are the exception the logical model did not foresee: the Logs screen reads
`gov.log_entry` in `awp` (see the [governance dictionary](data-dictionary/governance.md)).

## One name per component

The logical model was re-issued as v1.2 so that it names the same components as the
specification and the stack specification: Arize Phoenix, pgvector in `awp_kb`, Graphiti on Neo4j,
object storage over the S3 API, Valkey, agentgateway, and the cluster `awp-pg`.
[open-questions.md §2](../specs/open-questions.md#2-conflicts-between-the-source-documents--resolved)
records what changed. Migrations `0000_init.sql` and `0003_trace-id.sql` keep the old trace column
name on purpose: a migration records what was applied, and `0003` is the rename to `trace_id`.

## Known drift between the schema files and the database

| Item | Observation |
| --- | --- |
| `ai.run.parent_run_id` | Migration `0033` adds a foreign key to `ai.run(id)` with `ON DELETE SET NULL` and the index `run_parent_idx`; `ai.ts` declares the column without either. A future `drizzle-kit generate` would propose dropping them |
| Migration snapshots | `meta/` holds Drizzle snapshots for `0000`–`0007` and `0010`–`0030` only; `0008`, `0009` and `0031`–`0074` were written by hand, and number `0036` does not exist. A generated migration diffs against the `0030` snapshot |
| `work.request.claimed_by` | Migration `0043` adds a foreign key to `core.person(id)` (`request_claimed_by_fkey`, no action on delete); `work.ts` declares the column without it |
| Partitioned tables | `infra/postgres/03-partitions.sql` rebuilds `work.request_event`, `work.work_item_activity`, `work.room_message`, `ai.run_step` and `audit.audit_entry` with `LIKE … INCLUDING ALL`, which names the primary key `<table>_pkey` (the schema files say `<table>_pk`) and the indexes after their columns (for example `request_event_request_id_at_idx`, which `work.ts` calls `request_event_request_idx`). It re-adds each foreign key under its own name (`request_event_request_fk`, `work_item_activity_item_fk`, `room_message_room_fk`, `run_step_run_fk`) with no `ON DELETE` action |
| SQL file names in code comments | `audit.ts` names `infra/postgres/03-audit.sql`, `work.ts` and `gov.ts` name `02-integrity.sql`, and `04-audit-guard.sql` names `02-roles.sql`. The files are `04-audit-guard.sql`, `05-integrity.sql` and `06-roles.sql` |
