# 08 — Security

> Threat models, permission matrix, security requirements, dated security reports.
> Owner: Security lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Security architecture](security.md) | draft | 1.0 | 2026-10-30 |

`security.md` covers identity, authorisation, privileges and roles, secrets, network and edge controls. There
is no separate threat model or permission matrix document yet; the privileges and roles are in
`security.md#privileges-and-roles`.

## Dated reports

Evidence of what was true on one date. Never edited afterwards; current facts are in the maintained documents above.

| Date | Report | Records |
|------|--------|---------|
| 2026-10-16 | [Security and compliance report](2026-10-16-security-report.md) | Security and compliance audit: tools, findings, probes, OWASP ASVS / LLM Top 10 / PDPL / NESA / ISO 27001 mapping (2026-10-11 to 2026-10-16) |
