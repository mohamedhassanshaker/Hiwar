# Security architecture

| Item | Value |
| --- | --- |
| Purpose | The identities, trust boundaries and controls the platform enforces today, and the known gaps |
| Audience | Architects, security reviewers, developers |
| Related | [Solution design](solution-design.md#authorisation) · [Agent runtime](../agent-runtime-spec.md) · [Agent runtime decisions](../harness-decisions.md) · [Non-functional requirements](../specs/non-functional.md) · [Security report 2026-10-16](../reports/security-report.md) · [Configuration](../07-operations/configuration.md) |
| Last verified against code | 2026-10-29 |

This document describes the controls in the code. The dated audit, with findings, tool results,
probes and the OWASP ASVS, OWASP LLM Top 10, UAE PDPL, UAE IA/NESA and ISO 27001 mappings, is
[reports/security-report.md](../reports/security-report.md) (last updated 2026-10-16). Findings are
tracked there, not here.

## Principles

- Authorisation is enforced in server code at the resource. Hiding a control is never the control
  (NFR-09). Instructions, tool annotations, skill metadata and client-submitted approvals grant
  nothing.
- An agent acts as the person who asked, bounded by its grant: effective permission is the
  person's permission AND the agent's grant (D31). Deny by default.
- Fail closed: an absent claim grants nothing (D28); a missing room yields a principal that can read
  nothing (D104).

## Identities

| Identity | Credential | Verified by | Lifetime |
| --- | --- | --- | --- |
| Person | OIDC session (Auth.js v5), passkeys from My profile. Only an Active person signs in; an Invited one becomes Active by signing in from their invitation link as the invited address (single use, 7 days, hash stored, D248) | `src/lib/auth.ts`, sessions in PostgreSQL | Session; revocable from My profile |
| Agent mission, model side | Model run token (JWT, `kind: model`) with the granted tools | `/api/mcp` (`verifyRunToken`) | 30 minutes (`RUN_TOKEN_LIFETIME_SECONDS`); the workflow replaces it 25 minutes after minting through `run_token_refresh`, and with each `approve` or `answer` signal (D82, D251) |
| Agent mission, plumbing | Harness run token (`kind: harness`); accepted only for plumbing tools and only for its own run | `/api/mcp` run binding (D33, D52) | As the model token |
| Agent to agentgateway | The generic runtime sends the run's model token as the API key; Graphiti and the agent service's own gateway calls send `AWP_RUN_TOKEN`, which no deployment sets, so they send `anonymous`. agentgateway validates neither | — | — |
| Integration client | Client key, shown once; stored as prefix and hash | `features/integrations/repository.ts` | Until revoked, rotated or expired |
| Visitor | Widget session token: HS256 JWT signed with a key derived from `AUTH_SECRET` for this one purpose, naming the conversation, the deployment, the visitor key and the language; renewed on every answer. Per-visitor rate limit (D231) | `features/engage/widget-session.ts` | 30 minutes, sliding |
| Channel provider | HMAC over the raw body with the channel's inbound secret | `app/api/channels/[channelType]/inbound/route.ts` | Per request |
| Scheduler | `MAINTENANCE_API_TOKEN` | `app/api/maintenance/schedules/[id]/fire/route.ts` | Static secret |

## Trust boundaries and public surfaces

Everything reaches the cluster through Traefik. Routes that answer somebody with no console session
decide for themselves who is asking:

| Route | Who reaches it | What bounds it |
| --- | --- | --- |
| Console screens and server actions | A person with a session | Session, Zod at the boundary, `requirePermission` or the project, org-unit or organisation check in the service (D330) |
| `GET, POST /api/copilotkit/[[...slug]]`, `POST /api/agui/[agentCode]` | A signed-in browser (the AG-UI route is called over loopback by the runtime) | Session; per-request agent registry; tokens minted server-side and never sent to the browser |
| `GET /invite/[token]` | Anyone holding an invitation link | The token's SHA-256 is matched to an open, unexpired, unused invitation; acceptance sets the person's password, spends the invitation and signs them in (D248, D387) |
| `/reports/*` (D388) | `requests:read` or `work_items:read` | A report lists only what the person's list would show them; a record's audit trail appears only for a holder of `audit:read`, otherwise the section is left out |
| `GET /reset-password/[token]` | Anyone holding a Forgot password link | The token's SHA-256 is matched to an open link (30 minutes, once); setting the password spends it and ends every session of the person (D387) |
| `GET /api/uaepass/start`, `/api/uaepass/callback` | Anyone | The state is sealed in an httpOnly cookie under `APP_KEK` and must match on return; the person is found by a linked UAE PASS account or an Emirates ID, and must be Active (D387) |
| `GET, POST /api/auth/[...nextauth]` | A browser signing in | Auth.js OIDC flow (`src/lib/auth.ts`) |
| `GET /embed/v1/frame/[code]` | A website visitor's browser, inside a host page | `frame-ancestors` set per request in the proxy: the deployment's allowed origins and the console's own origin (its Preview tab); a deployment listing `null` admits every page (`frame-ancestors * file:`, D220, D231, D278) |
| `POST /embed/v1/sessions`, `/embed/v1/sessions/[id]/**` | The widget frame (same origin as the platform) | Enabled deployment; the host origin checked against the allowed origins when a session starts; the session token (`Authorization: Bearer`, or `?token=` on the event stream) for every later call; per-visitor rate limit; a preview session needs a console session holding `channels:write`; a file step's upload checked for its declared size and types, the upload rules and quarantine (D231) |
| `GET /embed/v1/widget.js`, `GET /embed/v1/config/[code]`, `GET /api/request-widget/[requestTypeCode]/embed.js` | A host page | Public by design; carries no credential. The config answers 403 for a disabled deployment or a page it does not allow, so no launcher is drawn; the frame's `frame-ancestors` is the control |
| `GET, POST /api/request-widget/[requestTypeCode]` | A website visitor | Request type published with the Widget intake channel |
| `GET, POST /api/channels/[channelType]/inbound` | WhatsApp or Teams | HMAC signature; a channel without an inbound secret accepts nothing; GET is a reachability check |
| `POST /api/mcp` | An agent mission, or an integration client | Run token, or a client key limited to the client's exposed tools and permissions |
| `OPTIONS, POST /api/integrations/[clientCode]/agui` | An integration client | Client key, allowed origins, allowed agents, allowed events |
| `POST /api/maintenance/schedules/[id]/fire` | The `maintenance` Temporal worker | `MAINTENANCE_API_TOKEN` |
| `GET /api/sse/*` | A signed-in browser | Session, then per-channel authorisation; a run's stream only for its requester, `agents:read`, or, for a room run, whoever may read the room (D124, D161); the conversation streams only with `conversations:read` (D343, D344) |
| `GET /api/files`, `GET /api/comments/capture` | A signed-in browser | Session; a file's scope of use |
| `POST /api/speech`, `POST /embed/v1/sessions/[id]/transcriptions` | A signed-in browser; the widget frame | Session (30 recordings a minute per person), or the widget session token where the deployment's Voice input is on (the deployment's per-visitor limit a minute); audio types and 5 MB checked before the provider is called. The recording goes to the configured Transcription provider through the egress proxy; neither audio nor transcript is stored or logged (D386) |
| `GET /api/skills/[name]/files`, `GET /api/skills/[name]/package` | A signed-in browser | Session and `skills:read`; a file path that leaves the package is refused, and a file is served only as text, a raster image or bytes with `nosniff`, so a package's HTML or SVG never runs on the console origin (D333) |
| `GET /api/connectors/oauth/callback` | The browser of an administrator returning from an authorization server | Session holding `connectors:write`; the `state` is bound to the administrator who started the Connect and expires after 10 minutes (D296) |
| `GET /api/health` | Anyone who reaches the gateway | Deliberately unauthenticated; names services and up/down only |
| Admin hosts (`temporal.`, `phoenix.`, `aigateway.`, `s3.`, `minio.`, `neo4j.`, `adminer.`, `redisinsight.awp.localtest.me`) | Operators | Traefik IP allowlist from `ADMIN_ALLOWED_CIDRS`. agentgateway and RedisInsight have no login of their own, and Valkey has no password; on kind the allowlist sees a cluster address for every client, so it admits anyone who reaches the host's port 8443 (D225) |

The agent service is reachable only from inside the cluster; the browser never connects to it
(NFR-13).

## Privileges and roles

Authorisation is evaluated on permission sets, never on role names, and an explicit deny wins
(`apps/web/src/authz/evaluate.ts`). A role scoped to an org unit or a project applies only within
that scope: a write to a project's record is checked with `requireProjectPermission`, to an org
unit's with `requireOrgUnitPermission` (evaluated against that unit's path), and a change to what
every unit uses with `requireOrganisationPermission` (`apps/web/src/lib/session.ts`, D330). The catalogue is
`PERMISSIONS` in `apps/web/src/authz/permissions.ts`; `src/db/permissions-sync.ts` reconciles it into
`core.permission` on every migration. Screens map to the permission that shows them in
`src/authz/screens.ts`.

**The 52 privilege codes** (`setup:read` and `setup:apply` were removed with the Setup Director, D371): `projects:read`, `projects:write`, `rooms:read`, `rooms:write`,
`rooms:moderate`, `work_items:read`, `work_items:write`, `work_items:review`, `requests:read`,
`requests:write`, `request_types:write`, `request_types:publish`, `schedules:read`,
`schedules:write`, `files:read`, `files:write`, `organisation:read`, `organisation:write`,
`permissions:write`, `registrations:approve`, `agents:read`, `agents:write`, `agents:publish`, `agents:invoke`,
`agents:configure`, `skills:read`, `skills:write`, `connectors:read`, `connectors:write`,
`memory:read`, `memory:write`, `knowledge:read`, `knowledge:search`, `knowledge:write`,
`models:read`, `models:write`, `channels:read`, `channels:write`, `conversations:read` (visitor
transcripts, D343), `conversations:answer` (take over and answer them, D343), `inbox:read`, `approvals:decide`,
`budgets:read`, `budgets:write`, `audit:read`, `logs:read`,
`settings:read`, `settings:write`, `integrations:read`, `integrations:write`, `system:read`,
`system:operate`, `exports:create`.

**The ten seeded system roles** (`SYSTEM_ROLES`; the core permission is locked on the role,
`CORE_PERMISSIONS`):

| Role | Allow set | Locked core permission |
| --- | --- | --- |
| Platform Owner | All 53 | `permissions:write` |
| Administrator | All except `permissions:write` (52, including `registrations:approve`, `agents:configure`, D100, and the conversation permissions, D343) | `organisation:write` |
| Agent Designer | `agents:read/write/invoke`, `skills:read/write`, `connectors:read`, `memory:read`, `knowledge:read/search`, `models:read`, `organisation:read`, `projects:read`, `rooms:read`, `work_items:read`, `inbox:read`, `budgets:read` | `agents:write` |
| Publisher | `agents:read/publish`, `skills:read/write`, `request_types:write/publish`, `channels:read/write`, `inbox:read`, `organisation:read` | `agents:publish` |
| Work Lead | `projects`, `rooms` (with `moderate`), `work_items` (with `review`), `requests`, `schedules`, `files` read and write; `agents:read/invoke`, `inbox:read`, `approvals:decide`, `exports:create`, `organisation:read` | `work_items:review` |
| Member | `projects:read`, `rooms:read/write`, `work_items:read/write`, `requests:read/write`, `schedules:read`, `files:read/write`, `agents:read/invoke`, `knowledge:read/search`, `inbox:read`, `organisation:read` | `work_items:write` |
| Approver | `inbox:read`, `approvals:decide`, `requests:read`, `work_items:read`, `rooms:read`, `projects:read`, `organisation:read` | `approvals:decide` |
| Auditor | `audit:read`, `logs:read`, `settings:read`, `budgets:read`, `projects:read`, `rooms:read`, `work_items:read`, `requests:read`, `agents:read`, `exports:create`, `organisation:read` | `audit:read` |
| Guest | `projects:read`, `rooms:read`, `work_items:read` | `projects:read` |
| Widget visitor | `agents:invoke`, `knowledge:read`, `knowledge:search`; meant for a deployment's run-as person (D221, D332) | `agents:invoke` |

The seeded integration-client permission list also names `webhooks:receive`, which is not in the
catalogue (`apps/web/src/db/seed/data/platform.ts`), so granting it allows nothing.

**Field sensitivity.** An agent's edit of a sensitive field needs a bound approval (D57, D58, D109).
The rules live per module in `apps/web/src/features/<module>/privileges.ts` (budgets, files,
knowledge, organisation, projects, requests, work-items); the module documents name the sensitive
fields of their subjects.

## Agent controls

These are specified in [agent-runtime-spec.md](../agent-runtime-spec.md) §5–§6 and decided in
[harness-decisions.md](../harness-decisions.md). In summary, all enforced in `apps/web`:

| Control | Where | Decisions |
| --- | --- | --- |
| A model is shown only the tools its token grants; a call is re-checked independently | `src/mcp/server.ts` | D27–D30, D37 |
| Two tokens; the model can never call plumbing such as `run_finish` | `src/mcp/server.ts`, `lib/run-token.ts` | D33, D43, D52 |
| A child's grant is the parent's run row AND the child's configuration; a resume can shrink a grant, never grow it | `features/agents/grants.ts` | D36, D50 |
| T2 calls need a bound, unexpired, single-use approval, spent atomically | `src/mcp/server.ts` `requireApproval`, `lib/approval-binding.ts` | D20, D21, D49, D71 |
| Per-field escalation of sensitive fields, per value where a rule names values | `lib/field-rules.ts` | D57, D58, D72, D109 |
| Who decides an approval: in a room and in the assistant panel the person who asked, without needing `approvals:decide`; elsewhere the holders of `approvals:decide` other than the requester whose grant covers the run's project; a person decides only from their own Inbox item | `lib/approval-binding.ts` (`REQUESTER_DECIDES_IN`), `features/agents/approval-service.ts` (`requestApproval`), `features/inbox/service.ts` | D105, D243, D269, D281, D330 |
| A tool that changes an agent's configuration or grant, a connector, or what a deployment lets a visitor reach, is T2 or escalates; in a room its approval goes to somebody other than the requester, and in the assistant panel the person asking decides it; no tool changes a role or a permission, takes a credential or invites a person; the one `permissions:write` tool, `person_delete`, is T2 and only removes an invited or suspended person nothing refers to | `tests/platform-tools.test.ts`, `lib/approval-binding.ts` (`ACCESS_CHANGE_SEPARATE_IN`) | D108, D253, D277, D284, D381 |
| Reads in a room are bounded by every human member's permissions, except `knowledge_search`, which is bounded by the agent's Knowledge grant and the requester | `lib/session.ts`, `features/rooms/read-floor.ts` | D104, D291 |
| A room's participants, turn-taking and admins are changed by the room's Owner or an Admin (a participant role, not a privilege), or by a holder of `rooms:moderate`; both need `rooms:read`. The Owner cannot be removed or demoted, an agent is never an admin, and each change is audited as `rooms:moderate`. Mirror, close and delete need `rooms:moderate` | `features/rooms/moderation-service.ts` (`managedRoom`) | D392 |
| Fan-out and depth limits on delegation | `features/agents/delegation-service.ts` | D15, D103 |
| A run's connectors are every enabled connector, narrowed by the project's allowed connectors; the tools it is offered are its agent version's grant, checked again on each call. Connectors keep no list of allowed agents. The Platform connector cannot be removed, changed or switched off | `features/agents/run-start-service.ts` (`connectorsForRun`), `features/connectors/service.ts` (`refuseBuiltin`) | D30, D227, D228 |

## Platform controls

| Concern | Control | Where |
| --- | --- | --- |
| Edge | TLS from cert-manager; security headers middleware (`nosniff`, `DENY` framing, referrer policy, HSTS); admin hosts IP-allowlisted | `infra/gateway/` |
| Content Security Policy | Minted per request with a nonce, `strict-dynamic`, `frame-ancestors 'none'` (`'self'` on `/api/files`, which the console's own preview frames, D178; on the widget frame `/embed/v1/frame/<code>`, `'self'` and the deployment's allowed origins, or `* file:` when it lists `null`, D220, D231, D278), `object-src 'none'`. A browser that honours `frame-ancestors` ignores the edge's `X-Frame-Options: DENY` | `apps/web/src/proxy.ts` (`frameAncestorsFor`) |
| Attaching what the platform holds | A file or artifact is attached to a request, work item or room by id only when the person may read it (project visibility and, for a file, its scope of use) and may change the item; its bytes are copied into the `attachments` bucket. Pickers search on the server among what the person may read | `features/files/upload-service.ts` (`searchHeld`, `attachHeld`), D229 |
| Published example secrets | In production the web application will not start on a published example secret; the list and its one defect are in [configuration.md](../07-operations/configuration.md) | `apps/web/src/lib/env.ts` |
| Credentials at rest | AES-256-GCM envelope encryption with `APP_KEK`; client keys stored as hash; secrets shown once and never returned (NFR-10) | `apps/web/src/lib/crypto.ts` |
| Temporal payloads | AES-GCM `PayloadCodec` on the data converter, so run tokens in workflow history are ciphertext (D81). `TEMPORAL_CODEC_KEY` encrypts; keys in `TEMPORAL_CODEC_PREVIOUS_KEYS` still decrypt, and each payload names its key by fingerprint (D204). A payload of 32 KiB or more is stored after encryption in the `run-payloads` bucket, whose objects expire after 30 days; the S3 client's loggers stay at INFO so request signatures are not logged (D287) | `services/agent/src/awp_agent/temporal/codec.py`, `temporal/storage.py` |
| Database | One role per database; `audit` schema insert-only with a guard trigger | `infra/postgres/` |
| Network | Default-deny NetworkPolicies per namespace (20 policies) plus Cilium API-server egress rules; sandbox pods reach only DNS and the egress proxy. On kind only, the CiliumNetworkPolicy `connector-runtime-to-host` lets the connector runtime reach the Docker host (D222) | `infra/policies/`, `scripts/cluster-host-access.sh` |
| Egress | Squid proxy with a domain allow-list for connectors, sandboxes, the connector runtime's remote MCP sessions (D297) and the web app's own calls to the internet (`apps/web/src/lib/egress.ts`, D234); the local kind values let every destination through (`egressProxy.allowAll`, D297) | `infra/charts/awp/templates/egress-proxy.yaml` |
| Mail | The SMTP password is stored as an `APP_KEK` envelope in the settings version and never returned; a system email carries only what its recipient may already see, and links to the item, which opens under their own permissions. SMTP is not HTTP, so it does not use the egress proxy: the default-deny policy lets the web pod reach only an in-cluster server such as the kind Mailpit sink (D240) | `apps/web/src/lib/mailer.ts`, `infra/kind/mailpit.yaml` |
| Code execution | Sandbox pods: no service-account token, read-only root, all capabilities dropped, resource and time limits, sandbox node pool, optional gVisor | `services/sandbox/src/awp_sandbox/spec.py`; see [its README](../../services/sandbox/README.md) |
| Third-party connector code | One Pod per stdio connector; credentials mounted as files, never returned | `services/connectors`; see [its README](../../services/connectors/README.md) |
| Remote MCP connector credentials | Turned into request headers by the web app and held by the connector runtime in memory only, never in its saved state, logs or answers; OAuth sign-in bound to the administrator who started it, through the egress proxy (D296) | `apps/web/src/features/connectors/credential-auth.ts`; `services/connectors/src/awp_connectors/registry.py` |
| Skill packages | Validated and scanned on import (scripts, network calls, prompt-injection patterns, embedded secrets) | `apps/web/src/lib/skill-package.ts` |
| Logs | Secret-like and personal fields redacted by pino before writing; masked values on the Logs screen (NFR-16) | `apps/web/src/lib/logger.ts`, `lib/log-masking.ts` |
| AG-UI events to the browser | PII redaction of logged events, audit of human-in-the-loop events, RAW events stripped unless trace capture is on | `apps/web/src/agents/middleware.ts` |
| Supply chain | `npm audit`, `pip-audit`, gitleaks, semgrep and trivy in CI (`scan` job) | `.github/workflows/verify.yml` |

## Known gaps

Each is visible in the code on 2026-10-29 and not recorded as accepted.

| Gap | Evidence | Effect |
| --- | --- | --- |
| No PII masking or prompt-injection screening on the mission path | `build_agent` in `services/agent/src/awp_agent/mission/runtime.py` composes no guardrail and no masking (D110); `harness/guardrails.py` is applied only by `PiiMaskHook` in ingestion (`ingestion/activities.py`) | NFR-12 and NFR-15 are not met for agent missions |
| CI dependency scan covers one Python service | `verify.yml` `scan` runs `pip-audit` for `services/agent` only | Connectors, sandbox and modelstub advisories are not caught in CI |
| `PHOENIX_SECRET` refusal never fires | `lib/env.ts:114` compares a key that is not a field of the env schema | A production install can keep the example Phoenix secret |
| agentgateway authenticates nothing | `scripts/secrets-from-env.sh:58-60` creates Secret `awp-ai/run-token` with a comment saying agentgateway validates the run JWT, but nothing in `infra/` or `apps/web/src/agentgateway/` references that Secret or renders a JWT policy | Any in-cluster caller allowed by NetworkPolicy can use the model routes |
| Transcription calls are not metered | D386: `lib/transcription.ts` calls the provider directly; no gateway, no token usage, no spend row | Voice input cost is bounded only by the per-minute limits; the counters are in Valkey, so a `core` install without Valkey has none |
| `next-auth` is a beta | `5.0.0-beta.32` | Authentication depends on a pre-release library |

The detailed agent-runtime conflicts are listed in
[agent-runtime-spec.md](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code).
