# Tahseel AWP — Agentic Work Platform
## Product and Architecture Specification

| Item | Value |
| --- | --- |
| Product | Tahseel AWP — Agentic Work Platform |
| Version | 3.3 |
| Date | 9 Oct 2026 |
| Source of truth for scope | The Claude Design handoff prototype `AWP Console.html` and its change log (`CHANGELOG.md`) |
| Companion document | `Tahseel_AWP_Data_Model.md` — logical data model |
| Deployment model | Single tenant: one installation serves one organisation |
| Orientation | General purpose: nothing about departments, agents, request types or workflows is built in |
| Languages | English and Arabic (full RTL), light and dark themes, Tahseel Design System |

### How to read this document

This specification describes **what the product does and how it is built at the architectural level**, using only the screens in the handoff prototype. It deliberately contains:

- architecture decisions (frameworks, standards, runtime components) and the in-house agent harness;
- the information architecture, every screen, what the user sees and does on it, and the rules behind it;
- the end-to-end flows that cross screens.

It deliberately does **not** contain database schemas, field lists, API endpoints or payload formats. Entities and their relationships are defined in the companion data model document. API contracts will be produced from both documents during implementation.

Where a screen in the prototype uses illustrative sample data (names, amounts, KPIs, budget history, retrieval results), the sample data shows layout and behaviour only.

---

## Table of contents

1. Product summary
2. Scope
3. Terminology
4. Architecture decisions
5. Agent harness
6. Shell and interaction conventions
7. Screens by module
8. End-to-end flows
9. Cross-cutting rules
10. Non-functional requirements
11. Delivery phases and open decisions
12. Appendix — screen inventory and prototype map

---

## 1. Product summary

Tahseel AWP is a single-tenant, general-purpose platform in which **people and AI agents work together**. People raise **requests**. Requests move through configurable **transition steps** and produce **work items**, which people or agents carry out and review. People and agents discuss topics in **discussion rooms** inside projects. Agents are versioned workers with skills, connectors (MCP), memory, knowledge and model routes, governed by trust levels, tool tiers, human approvals and budgets.

A new installation starts empty. The organisation describes itself to the **Setup Director**, an agent that proposes the whole configuration as a **change set**. Nothing is applied until a human approves it. The same mechanism is used for every later change.

Agents can also be published outside the console as **embedded deployments** on websites, WhatsApp and Microsoft Teams. An administrator can bind a deployment to a **storyline** so the agent follows a defined script.

---

## 2. Scope

### 2.1 In scope (present in the handoff screens)

| Group | Screens |
| --- | --- |
| Home | Dashboard (with clickable drill-down records), Inbox |
| Work | Projects, Discussion Rooms (list and room), Work Items (board/list, hot items, advanced search, item drawer), Requests (list, request detail, sub requests, request types, request type detail), Scheduled Work Items, Artifacts, Files |
| Organisation | Org chart (chart and list), People & roles, Org units |
| AI Capabilities | Agents (list, agent detail, run list, run viewer, versions, playground), Skills, Connectors, Memory, Knowledge (collections, collection detail, retrieval test), Models & routes, Channels, Embedded Deployment (list, deployment detail, storylines, widget preview) |
| Govern | Setup Director, Budgets & estimated costs (list and budget detail), Audit, Logs, Settings, Integrations (clients and client detail), System, Documentation |
| Account | My profile, sign out / signed-out page |
| Global | Top bar (search ⌘K, New Discussion Room, New Request, New Work Item, language, theme, page assistant, inbox), user menu |

### 2.2 Removed or deferred (decided during design review)

| Item | Decision |
| --- | --- |
| Webhooks page, Pairing page | Removed from the product navigation |
| Approval policies page | Removed; approvals are defined on request type transition steps (audiences) and on connector tool tiers |
| Blueprint tab in Settings | Removed; blueprint versions are visible through the Setup Director and change sets |
| Separate Agent trust page and tool-tier page | Removed; trust is a field on the agent, and tiers are a property of each connector's tools |
| Connectors "Review" tab | Removed |
| Custom channels | Removed; only Web widget, WhatsApp and Microsoft Teams are live; Slack, Email, SMS, Voice/IVR, Telegram, Webex, Google Chat, Instagram and Facebook Messenger are shown as **Coming soon** |
| Health indicator in the top bar | Removed; health is on the System page |
| Multi-tenancy, software-delivery features | Out of scope |

---

## 3. Terminology

The product uses these names in the UI. Code, documentation and the data model use the same names.

| Term | Meaning |
| --- | --- |
| **Organisation** | The single organisation served by the installation. |
| **Org unit** | A department or team. People and agents belong to org units and report up a line. |
| **Project** | A container for work, with its own members, sensitivity and policies. Discussion rooms, work items, requests, scheduled work items, artifacts and files belong to a project. |
| **Discussion room** | A topic-scoped room inside a project where people and agents talk. It has a type, a source (console, Teams, widget, routine…), a turn-taking mode and a context handoff. |
| **Request** | Something a person (or external contact) asks for. A request has a request type, belongs to a project, moves through the type's transition steps and may have sub requests and work items. |
| **Request type** | A configurable kind of request: category, attributes, transition steps, audiences, routing rules, intake channels, entry modes (template form / agentic interactive), decomposition, SLA, default project. Versioned (Draft / Published). |
| **Transition step** | A stage in a request type's flow. It has an SLA, audiences (Can act / Notify only / View only) and routing rules that lead to the next step. A step can be terminal. |
| **Work item** | A unit of work assigned to a person or an agent: **Task**, **Sub item** or **Bug**. Statuses: Backlog, To do, In progress, In review, Blocked, Done (plus Cancelled). |
| **Sub item** | A work item inside a parent work item (formerly "subtask"). It shares its parent's project. |
| **Hot items** | Open work items that are high priority, blocked, or due within 2 days. |
| **Scheduled work item** | A work item (or request) created on a schedule or event and assigned to an agent, a person or a group. |
| **Artifact** | An output produced by an agent or a person in a project, versioned and linked to its run. |
| **File** | A file a person uploads into a project, with a scope of use (only me / selected people and agents / everyone in the project). |
| **Agent** | A versioned AI worker with instructions, skills, tools (through connectors), memory, knowledge, a model route, an execution profile, an org position, an agent trust level and a budget. |
| **Agent trust** | A single field on the agent: Restricted, Standard, Elevated, Coordinator or System. It sets what the agent may read, which tool tiers it may call and whether it may assign work. |
| **Run** | One execution of an agent version, with a timeline, tool calls, context composition and estimated cost. |
| **Skill** | A reusable capability in the Agent Skills standard (a package with `SKILL.md`). |
| **Connector** | An MCP server that gives agents controlled access to a system. Each connector sets the **tier** of every tool it exposes. |
| **Tool tier** | T0 Autonomous, T1 Confirm, T2 Human approval, T3 Forbidden. Defaults come from MCP annotations (read-only → T0, destructive → T2). Project policies can only raise tiers. |
| **Memory** | Persistent knowledge for agents, organised by scope (Organisation, Business unit, Agent, Session), versioned and reviewed. |
| **Knowledge collection** | A set of document sources ingested into vector and graph stores for cited retrieval, with its own index, chunking, model and sync configuration. |
| **Provider / Connection / Route** | A provider (cloud or custom/on-prem) holds one or more connections; each connection allows specific models. A **route** (alias) chains provider › connection › model with fallbacks. Routes can be standard, **typesafe** (schema-validated output) or **voice**. |
| **Channel** | A messaging surface (Web widget, WhatsApp, Microsoft Teams) bound to an embedded deployment, room mirroring or request intake. |
| **Embedded deployment** | An agent published to websites and channels, with branding, security, surfaces and storylines. |
| **Storyline** | A versioned script for an embedded deployment, in Free, Guided or Strict mode, made of typed steps. |
| **Setup Director** | The system agent that turns a conversation about the organisation into change sets. |
| **Change set** | A proposed group of configuration changes, with a dry run, per-change approval and one-step rollback. Applying a change set creates a new **blueprint version**. |
| **Budget** | A spending limit for an agent, with a period, effective dates, a warning threshold and an action at 100%. |
| **Estimated cost** | Every cost figure in the product is an estimate based on token usage and list prices, and is labelled as such. |
| **Integration client** | An external system with its own keys, allowed permissions, MCP access to the platform and AG-UI access to agents. |

---

## 4. Architecture decisions

### 4.1 Decision record

| # | Decision | Choice | Rationale |
| --- | --- | --- | --- |
| AD-01 | Tenancy | Single tenant per installation | One organisation; simpler security, data and operations. |
| AD-02 | Application framework | **Next.js (App Router, TypeScript), full stack** | One codebase for console UI, domain logic (server actions / route handlers), CopilotKit runtime, platform MCP server and channel gateway. |
| AD-03 | System of record | **PostgreSQL** (CloudNativePG cluster `awp-pg`, database `awp`) | All domain data. Dynamic request and work-item attributes are stored as validated `jsonb`. One PostgreSQL cluster serves the platform, passage vectors, Temporal and Phoenix, each in its own database. See the data model document. |
| AD-04 | Design system | **Tahseel Design System** (tokens, components, RTL stylesheet) as shipped in the handoff `_ds/` folder | Pixel parity with the prototype; light/dark and RTL built in. |
| AD-05 | Agent UI | **CopilotKit** for Next.js: `@copilotkit/react-core` (v2 entry point) in the UI, `@copilotkit/runtime` (v2) in a Next.js route handler, `@ag-ui/client` `HttpAgent` to the agent service | Discussion rooms, agent playground, page assistant, Setup Director conversation, agentic request entry and the embedded widget all use CopilotKit surfaces. The browser talks only to the runtime in the Next.js app. |
| AD-06 | Agent ↔ UI protocol | **AG-UI** | Every agent run streams AG-UI events (text, tool calls, state, custom approval events). The Integrations screen can expose agents to external clients over AG-UI. |
| AD-07 | Tools and connectors | **Model Context Protocol (MCP)**; federating connectors through **agentgateway** is the target design, not current behaviour (stack specification §6.1) | Connectors are MCP servers; today the harness reaches each one directly through `services/connectors` rather than through agentgateway. Tool tiers default from MCP annotations. The platform itself can be exposed as an MCP server to integration clients, also called directly today. |
| AD-08 | Skills | **Agent Skills** standard (`SKILL.md` packages) | Import by zip or Git URL; validated and scanned; enabled per agent. |
| AD-09 | Memory | Standard **memory-tool** contract over scoped, versioned memory files | Agents read and write memory through standard commands; humans review, edit, compare and restore versions in the Memory screen. |
| AD-10 | Agent runtime | **In-house agent harness** in a Python agent service, built on **Pydantic AI v2** (capabilities, hooks, typed model and tool calls) and **Temporal** (durable execution) | Full control of the loop, governance and context; runs survive restarts and long human waits. No external agent product is required. |
| AD-11 | AI gateway | **agentgateway** (LLM gateway today; MCP and A2A gateway are the target design, not yet implemented; Linux Foundation) | One OpenAI-compatible endpoint for all providers and custom/on-prem engines; routes and fallbacks configured in Models & routes are applied here. |
| AD-12 | LLM observability and evaluation | **Arize Phoenix** (database `phoenix` on `awp-pg`) | Traces behind "Open trace", estimated cost, eval scores on agent versions, prompt versions. |
| AD-13 | Knowledge and memory retrieval | **Graphiti** temporal knowledge graph on **Neo4j** (entities, facts, hybrid search), **pgvector** in PostgreSQL (database `awp_kb`) for passage vectors; raw documents in object storage | Matches the Knowledge screen: vector, graph and hybrid retrieval with re-ranking and cited passages and graph facts. |
| AD-14 | Object storage | **Rook** (Ceph RGW, S3 API) | Files, artifacts, raw documents, skill packages, memory content, backups. Code uses only the S3 API. |
| AD-15 | Cache and fan-out | **Valkey** | Live room updates to all participants, presence, rate limits, locks. |
| AD-16 | Internal stores of AI components | Separate databases on the same PostgreSQL cluster for Temporal and Phoenix, each with its own role; agentgateway is stateless (configured from the platform) | One relational engine and one operator to run; databases can be split onto another cluster later without code changes. |
| AD-17 | Authentication | SSO (OIDC) with WebAuthn passkeys, implemented in the Next.js app | Matches My profile → Security (SSO · WebAuthn, passkeys, active sessions). |
| AD-18 | Packaging and orchestration | Container images and Helm charts on **Kubernetes** in every environment; **kind** for local development | One deployment model from laptop to Live; probes, network policies and charts are identical everywhere. |
| AD-19 | Localisation | English and Arabic for every label, name field and message; RTL mirroring | All prototype strings are bilingual; names of records have English and Arabic variants. |
| AD-20 | Cost presentation | All money values are **estimated** and labelled so | Exact provider billing is not available at run time. |

### 4.2 Component view

```mermaid
flowchart TB
  subgraph Web["Next.js full-stack app"]
    UI[Console screens - Tahseel Design System]
    CK[CopilotKit surfaces + runtime]
    DOM[Domain logic: projects, rooms, requests, work items, agents, governance]
    PMCP[Platform MCP server - for agents and integration clients]
    CHG[Channel gateway - Web widget, WhatsApp, Teams]
  end
  subgraph AgentSvc["Agent service - Python"]
    H[Agent harness - Pydantic AI]
    TW[Temporal worker - runs, schedules, ingestion]
    AGUI[AG-UI stream endpoint]
  end
  subgraph AI["AI components"]
    LL[agentgateway - LLM today, MCP+A2A target]
    TP[Temporal]
    LF[Arize Phoenix]
    QD[(PostgreSQL awp_kb - pgvector passages)]
    NJ[(Neo4j - Graphiti)]
  end
  subgraph Store["Stores"]
    SQL[(PostgreSQL awp - system of record)]
    MIO[(Rook Ceph RGW - S3)]
    RD[(Valkey)]
  end
  UI --> DOM --> SQL
  CK -->|AG-UI| AGUI
  DOM -->|start / signal runs| TP
  AGUI --> TW --> H
  H --> LL
  H -->|MCP| LL
  LL -->|MCP| PMCP
  LL -->|MCP| EXT[[Connector MCP servers]]
  TW --> TP
  H --> QD & NJ & MIO
  LL --> LF
  H --> LF
  DOM --> MIO
  DOM --> RD
  CHG --> DOM
  CHG -->|AG-UI| AGUI
```

**Ownership rule.** The Next.js application owns all domain data in PostgreSQL (database `awp`). The agent service changes domain data only through the platform MCP server, so agents pass the same permission checks, validation and audit as people. Temporal holds run execution state, Phoenix holds LLM traces, and the `awp_kb` database (pgvector) and Neo4j (Graphiti) hold rebuildable knowledge indexes.

### 4.3 Modules

| Module | Screens | Main components |
| --- | --- | --- |
| Shell & account | Top bar, navigation, search, page assistant, profile, sign-out | Next.js, CopilotKit (page assistant) |
| Home | Dashboard, records drill-down, Inbox | Domain logic, Temporal signals for approvals and answers |
| Work | Projects, Discussion Rooms, Work Items, Requests, Scheduled Work Items, Artifacts, Files | Domain logic, CopilotKit (rooms, agentic request entry), Temporal schedules, Rook Ceph RGW (S3) |
| Organisation | Org chart, People & roles, Org units | Domain logic, SSO |
| Agents & runs | Agents, runs, run viewer, versions, playground | Harness, Temporal, Phoenix |
| Capabilities | Skills, Connectors, Memory, Knowledge, Models & routes | Skill registry, MCP client, memory store, Graphiti ingestion, agentgateway |
| Engage | Channels, Embedded Deployment, Storylines, widget | Channel gateway, CopilotKit widget, harness scripted mode |
| Setup | Setup Director, change sets | Harness `setup` profile, platform MCP setup tools |
| Governance | Budgets & estimated costs, Audit, Logs, Settings, Integrations, System, Documentation | Domain logic, harness token metering, agentgateway metrics (LLM calls only), AG-UI exposure; MCP exposure is called directly today, not through agentgateway (stack specification §6.1) |

---

## 5. Agent harness

The harness is the platform's own agent runtime. It runs every agent: the Setup Director, room participants, work-item agents, request-step agents, scheduled work items and embedded deployments.

### 5.1 Building blocks

| Block | Role in the harness |
| --- | --- |
| Pydantic AI v2 | Capabilities (skills, connectors, hooks, memory, verifier as composable units with on-demand loading), deferred tool calls for approvals, typed model calls, structured outputs, AG-UI adapter |
| Temporal | Each run is a durable workflow. Model calls and tool calls are activities. Approvals and human answers are signals. Scheduled work items are schedules. Delegations to other agents are child workflows. |
| agentgateway | All model calls go through a route (alias); fallbacks are tried in order. Reaching connector MCP servers and A2A agents through it too is the target design — today the harness reaches each one directly instead (stack specification §6.1). |
| MCP clients | All tools are MCP tools: connectors, the platform MCP server and the sandbox workspace — each reached directly by the harness today, not via agentgateway (target design, stack specification §6.1) |
| Graphiti | Knowledge and memory recall: temporal facts and hybrid search |
| Arize Phoenix | One trace per run (OpenTelemetry / OpenInference); tool, hook and verifier spans; evaluations, datasets and experiments |

### 5.2 Execution profiles

The agent's **execution profile** is chosen on the agent's Configuration card.

| Profile | Used for |
| --- | --- |
| `conversational` | Discussion room replies, page assistant, embedded deployments |
| `task` | Work items and request steps assigned to an agent |
| `planner` | Breaking requests into sub requests and work items; the Setup Director |
| `reviewer` | Reviewing another agent's output (reviewer ≠ author) |
| `triage` | Classifying requests (agentic request entry) and routing |
| `scripted` | Strict storylines |
| `routine` | Scheduled work items |

### 5.3 Loop and controls

1. **Prepare.** Resolve the agent version, skills, tools, memory scopes, knowledge collections, route and budget. Build the context in a fixed order: platform rules, organisation rules, agent instructions, skill index, tool definitions, task frame, loaded skills, retrieved knowledge and memory, conversation, step guidance. The run viewer shows this order as **context composition**.
2. **Model step.** Call the route through agentgateway and stream text over AG-UI. Hooks run before and after, for example PII masking (the run viewer shows "pii-mask (pre_model): 2 values masked").
3. **Tool calls.** Each call is checked in turn:
   - against the agent's tools and connector permissions (allowed agents);
   - against the tool tier, project policy and agent trust;
   - against the remaining budget.

   Outcomes per tier:

   | Tier | What happens |
   | --- | --- |
   | T0 | Runs immediately. |
   | T1 | Asks for confirmation in the room or widget. |
   | T2 | Pauses the run and creates an approval in the Inbox, or a card in the room. The decision resumes the run. |
   | T3 | Never runs. |

4. **Verify.** Before finishing, check that the plan items are done, the output matches its schema and the work item's acceptance criteria are covered. A failed check gives the agent precise feedback.
5. **Finish.** Write outputs, artifacts and the **context handoff** (goal, decisions, open questions, next step), update the run's estimated cost and eval scores.

**Durability.** If the agent service restarts mid-run, the run resumes from the last completed step without repeating side effects. Runs waiting for approval use no worker capacity.

**Limits.** Each run has a budget in estimated cost (soft and hard), a maximum number of steps and tool calls, an agent hop limit in rooms, and a room cost cap. The budget action at 100% (notify, switch to a cheaper route, or pause the agent) comes from the agent's budget.

**Replay.** Operators can replay a run, or replay it from a chosen step, from the run viewer.

**Storylines.** In Strict mode the harness only performs the current step's actions; messages marked "Send verbatim (exact)" are sent exactly. In Guided mode the agent may answer side questions and then returns to the step.

---

## 6. Shell and interaction conventions

### 6.1 Shell

| Element | Behaviour |
| --- | --- |
| Sidebar | Logo (light/dark variant) and product name. Navigation groups: (no heading) Dashboard, Inbox with badge · **Work** · **Organisation** · **AI Capabilities** · **Govern**. The active item is highlighted. Detail screens highlight their parent (room → Discussion Rooms, run → Agents, storyline and widget → Embedded Deployment, records → Dashboard). |
| Top bar | Search box opening the **search palette** (⌘K / Ctrl+K). Buttons: New Discussion Room, New Request, New Work Item (primary). Language switch EN / ع. Theme toggle. Page assistant toggle. Inbox bell with badge. User menu (name, role, avatar). |
| User menu | Name and email, My profile, Settings, Log out. Logging out shows the signed-out page with "Sign in with SSO". |
| Page assistant | A CopilotKit side panel bound to the current page and the user's permissions, with suggested prompts (e.g. "Summarise this page", "What needs my attention today?", "Draft a request type like Expense Claim"). |
| Search palette | Searches everything the user may see: discussion rooms, work items, requests, agents, skills, connectors, knowledge and artifacts. Results are grouped by kind. |
| Landing page | Dashboard. |
| Persistence | Theme, language and last screen are remembered per user. |

### 6.2 Interaction conventions

| Convention | Rule |
| --- | --- |
| Every action is real | Every button opens a modal, drawer or detail screen that shows what the function does. Where no dedicated design exists, a generic **action modal** asks for confirmation and states that the change is recorded in the audit log. |
| Detail layout | Requests, sub requests and work items use the same order: **header** (title, key, tags, actions) → **main info** (details, description, attributes, attachments) → **tabs**. |
| Codes and keys | Users never type codes first. The code field sits at the end of a form and is **suggested from the name or title**; the user can accept or edit it ("Suggested from the name. You can change it.", "auto"). Applies to project keys, request type codes, skill names, collection IDs, client IDs and route aliases. |
| Lists | Tables with search and filters. Where useful, the same data is offered as a board, cards or a chart (Work Items board/list, Artifacts and Files cards/list, Org chart chart/list). |
| Drill-down | Dashboard cards open a records list of the matching items, with search, a status filter, export and navigation to each record's detail. |
| Status tags | Statuses are shown as coloured tags with consistent colours across screens. |
| Costs | Every money figure is labelled "Estimated" or "(est.)". |
| Bilingual names | Records that people name (projects, org units, request types, deployments, agents) have English and Arabic names. |
| Empty states | Every filtered list has an empty message (e.g. "No discussion rooms match these filters."). |
| Destructive actions | Delete and deactivate explain the consequence (e.g. "Deleting removes it from the project. Audit records are kept."). |

---

## 7. Screens by module

Each screen lists its purpose, what it shows, the scenarios it supports, and the rules that apply. Scenario IDs (`SC-…`) are used for acceptance testing.

### 7.1 Home

#### 7.1.1 Dashboard

**Purpose.** The landing page: what is happening and what needs attention.

**Content.**
- A greeting with the date and organisation name, plus New Discussion Room and New Work Item shortcuts.
- KPI cards, each clickable:

| Card | Shows | Drill-down list |
| --- | --- | --- |
| Open work items | Number opened today | All work that is not done, across projects |
| Runs in progress | How many are waiting on people | Agent runs running or waiting |
| Approvals waiting | How many are high risk | Decisions waiting for the user or their groups |
| Agents in error | Which agent and version | Agents whose last run failed or whose connector is down |
| Estimated cost today | Month to date (est.) | Estimated spend by agent since midnight |
| SLA at risk | Items due within 4 hours | Work items and requests due within 4 hours, with time left |

- **All agent runs** panel: current runs with status, step and estimated cost.
- **Open work by status** chart.
- **Estimated budget burn** for the month: used vs limit, % of month elapsed, largest consumer.
- **Discussion room activity**: recent rooms with a link to all rooms.

**Scenarios.**
- **SC-DSH-01** — A user opens the platform and lands on the Dashboard with figures for their organisation.
- **SC-DSH-02** — The user clicks "SLA at risk" and gets a records list (key, title, project, status, assignee, time left). They search it and open a record's detail.
- **SC-DSH-03** — The user opens a run from "All agent runs" in the run viewer.

**Rules.** Figures respect the user's permissions. Cost figures are estimates.

#### 7.1.2 Records (dashboard drill-down)

A generic list page reached only from dashboard cards. It has a title and description for the card, a search box (key or title), a status filter, an export button and a record count. The columns depend on the card (key, title, project, status, assignee, due, agent, started, risk, estimated cost, time left). Clicking a row opens the record's own detail: work item drawer, request detail, run viewer, approval or agent.

#### 7.1.3 Inbox

**Purpose.** Everything that needs the user: approvals, agent questions, mentions and SLA warnings.

**Content.**
- Tabs: All, Approvals, Questions, Resolved.
- An approval item shows:
  - requested by (agent or person), the run and the work item;
  - the policy that applies (e.g. "Sequential: Fatima Noor → Khalid Hassan · escalates in 24h");
  - the action and its arguments, redacted;
  - evidence (e.g. quotes compared, remaining budget, verifier result);
  - actions: Approve, Request changes, Reject. A reason is required to reject.
- A question item shows the agent's question with an answer box. "Your answer resumes the run."

**Scenarios.**
- **SC-INB-01** — An approver approves a T2 purchase order. The run resumes, the item moves to Resolved ("Approved — run resumed") and the decision is audited.
- **SC-INB-02** — An approver rejects with a reason. The reason is recorded in the decision log and the agent is told.
- **SC-INB-03** — A user answers an agent's question. The waiting run continues.
- **SC-INB-04** — A change set from the Setup Director appears as an approval.

**Rules.**
- The badge count matches the open items.
- An agent never appears as an approver.
- A requester cannot approve their own request.

### 7.2 Work

#### 7.2.1 Projects

**Purpose.** Projects are containers for work with their own members and policies.

**List.** Project, key, status (Backlog, Planned, In Progress, Paused, Done, Archived), owner, org unit, sensitivity, work item count and progress. Actions: New Project and filters.

**Project detail.**
- Header: Edit project.
- KPIs: open work items, work items, progress, discussion rooms, requests.
- **Policies**:
  - sensitivity (Public, Internal, Confidential, Restricted);
  - required reviews (e.g. "Reviewer ≠ author on every item");
  - actions that need human approval;
  - allowed agents and allowed connectors.
- **Members**: people and agents with project roles (Owner, Member, Agent), and Add member.
- **In this project**: links to its discussion rooms, work items, requests, scheduled work items, artifacts and files.
- **Recent decisions** (e.g. "Approved CS-118 per-diem change").

**New Project modal.** Name, owner, sensitivity, description, and the project key (suggested from the name).

**Scenarios.**
- **SC-PRJ-01** — An administrator creates a project. The key is suggested from the name and edited before saving.
- **SC-PRJ-02** — The owner restricts the allowed connectors. Agents in the project can no longer call tools from other connectors.
- **SC-PRJ-03** — The owner adds an agent as a member so it can be assigned work in the project.

**Rules.**
- Policies can only make tool tiers stricter.
- Everything in a project inherits its sensitivity.

#### 7.2.2 Discussion Rooms — list

**Purpose.** Topic-scoped rooms inside a project where people and agents work together.

**Content.**
- KPIs: Total, Active, Archived, Messages.
- Filters: search by title or key, project, status. The default status filter is **Active**.
- Table columns: room, project, type (Chat, Review, War-room, Support, Automation…), source (Console, Teams, Widget, Routine…), participants, status (Active, Idle, Paused, Closed, Archived), messages and estimated cost.

**New Discussion Room modal.** Project, title, type, participants (people and agents), status (Active or Paused) and turn-taking (Lead agent, Mention only, Moderated).

#### 7.2.3 Discussion Room

**Layout.**
- **Header:** back, title, status, the line "Project FIN — Finance Operations · Review · Lead-agent policy", and the actions Fork and Close room. The room has no tabs.
- **Conversation:**
  - Messages from people and agents.
  - @mentions of people and agents.
  - Agent messages show meta: tools used, estimated cost, **Open trace**, and Helpful / Not helpful feedback.
  - Artifacts appear inline as cards (name, row count, creator, Open).
  - Approval cards appear inline (e.g. "Approval required · CS-118" with risk, action, changes, approvers, and Approve / Request changes / Reject). After a decision the card shows its state ("Approved by you · applying").
  - A working indicator shows when an agent is busy (e.g. "Expense Reviewer is working: drafting follow-up task…").
  - Composer: "Message the room — type @ to mention a person or agent", and Send.
- **Side panel:**
  - **Participants** with roles: Owner, Member, Lead agent, Member agent, and a Working status.
  - **Turn-taking**: Lead agent, Mention only, Round robin, Moderated, Autonomous. Autonomous is behind a feature flag.
  - Limits: "Agent hop limit 6 · Room cap AED 25.00 · Estimated spend AED 3.84".
  - **Context handoff**: goal, decisions, open questions, next step.
  - **Linked work items.**

**Scenarios.**
- **SC-ROOM-01** — A user mentions an agent. The agent's run starts with the room context and streams its reply to every participant. The reply carries an artifact.
- **SC-ROOM-02** — A user asks the Setup Director in the room to change a request type. The Director posts a change-set approval card. An approver approves in the room and the change is applied.
- **SC-ROOM-03** — The owner switches turn-taking to Moderated. Agent replies are held until a human gives the agent the floor.
- **SC-ROOM-04** — A user forks the room for a sub-topic ("New room title", "What should change?"). The fork is linked to the original.
- **SC-ROOM-05** — The owner closes the room. A final context handoff is written and the linked work items stay.
- **SC-ROOM-06** — With Teams mirroring on, the room is mirrored to a Teams chat both ways.

**Rules.**
- Agents in the room obey the hop limit and the room cost cap.
- Lead and member agents respond according to the turn-taking mode.
- Feedback on agent messages feeds the agent's evaluation.

#### 7.2.4 Work Items

**Purpose.** Tasks, sub items and bugs assigned to people and agents, grouped by project.

**Views.** Board (columns Backlog, To do, In progress, In review, Blocked, Done, with counts) and List (key, title, project, type, status tag, priority, assignee, due).

**Filters.**
- The default view is **Hot items** (high priority, blocked, or due within 2 days). The alternative is **All work items**.
- **Advanced search** fields: keyword (title or key), project, type, status, priority, assignee (anyone, unassigned, a person or an agent), and due from/to. Actions: Search, Clear, Save as view.

**New Work Item modal.**
- Title, project, type (Task, Sub item, Bug), assignee (person, agent or unassigned), priority (High, Medium, Low), due date, reviewer and description.
- A **similar open item** warning appears when a near-duplicate exists (e.g. "Similar open item: TSK-2311 vendor comparison").

**Work item drawer.** Follows the standard detail layout:
- **Header:** key, title, type and status tags.
- **Main info:** assignee, reviewer, project, request type, parent item (for sub items), origin (link to a request, room message or schedule), due date, description, attributes (from the request type's schema) and attachments (Add attachment).
- **Tabs:**
  - **Sub items:** list with a done toggle, progress and Add sub item.
  - **Activity.**
- **Actions by status:**

| Status | Actions |
| --- | --- |
| Blocked | Unblock, Assign to agent |
| In review | Approve, Request changes |
| Done | Reopen |
| Any other | Submit for review, Assign to agent |

**Scenarios.**
- **SC-WI-01** — A user creates a bug assigned to an agent. A run starts and the item moves to In progress.
- **SC-WI-02** — The agent submits for review. The reviewer (who is not the author) approves and the item moves to Done.
- **SC-WI-03** — The reviewer requests changes. The item returns to In progress with the comments and the agent is re-triggered.
- **SC-WI-04** — A user ticks sub items done. The parent's progress updates.
- **SC-WI-05** — A user unblocks an item and assigns it to an agent.
- **SC-WI-06** — A user runs an advanced search and saves it as a view.

**Rules.**
- A sub item always has its parent's project.
- A parent cannot be Done while sub items are open, unless an authorised user overrides with a reason.
- Agents never approve their own work.

#### 7.2.5 Requests

**Purpose.** Every request belongs to a project and a request type, and moves through the type's transition steps.

**Requests tab.**
- Filters: title or key, requester (any, a person, or an external contact), type, status and period, plus Clear.
- Table columns: request, project, type, requester, submitted, status.

**Request types tab.** Request type, category, intake channels, decomposition (none, template, agent, hybrid), SLA, open count and status (Draft, Published). Action: New request type.

**New Request (top bar or list).**
- **Entry mode**: **Template form** or **Agentic interactive**. Agentic interactive is behind a feature flag.
- **Template form:** project, request type, title, the type's attributes (e.g. amount, expense date, category; or item, quantity, budget line; or from/to and leave type) and attachments.
- **Agentic interactive:** a conversation ("Tell me what you need. I will pick the request type and fill the details with you."). The triage agent proposes the type and the attribute values ("This looks like an Expense Claim. Amount AED 186 on 3 October, category ground transport. Shall I submit it to FIN?"). The user confirms and submits.

**Request detail.**
- **Header:** title, key, type, project, status and actions (Request changes, Assign to agent).
- **Main info card:**
  - a step tracker showing the type's transition steps, and the description;
  - a key-details grid: project, type, requester (or external contact), submitted, channel (and form or agentic), current step, SLA (e.g. "Due 11 Oct, 15:30") and parent request;
  - the request type's attributes;
  - attachments with preview and Add attachment.
- **Tabs:**
  - **History & audit** (e.g. "Submitted via Teams", "Classified as Expense Claim", "Agent review: amount within limit, receipt valid", "Moved to In review");
  - **Sub requests**, which open on the same layout with breadcrumbs back to the parent;
  - **Work items** (key, title, status, assignee), e.g. Verify receipt, Approve reimbursement, Release payment.

**Request type detail.**
- **Header** actions: Save draft, Publish.
- **General:**
  - name, category, decomposition, SLA and default project;
  - intake channels (Console, Teams, Email, Widget, WhatsApp, API);
  - entry modes (Template form and/or Agentic interactive);
  - the type code, which is suggested.
- **Transition steps:**
  - An ordered list of steps (Add step), each with a step name, step SLA (e.g. "1 business day") and a Terminal flag.
  - **Audiences** (Add audience). Each audience is a person, role, group or agent with one access level: **Can act**, **Notify only** or **View only**.
  - **Routing rules to next steps** (Add rule): a condition ("When", e.g. `amount_aed >= 5000`) or an action (Submit, Return, Approve, Reject, Paid) and the target step ("Go to step").
  - A terminal step has no audience and no outgoing transitions.
  - Example flow for Expense Claim: Submitted → Agent review → Finance approval or Finance + Work Lead (sequential) → Payment → Closed, with a Return path back to Submitted.
- **Attributes:** name, type, required or optional.

**Scenarios.**
- **SC-REQ-01** — An employee submits an expense claim through the agentic entry from Teams. The type is classified, attributes are confirmed, and the request starts at Submitted.
- **SC-REQ-02** — An agent audience at "Agent review" checks the claim and routes it by amount to the right approval step.
- **SC-REQ-03** — An approver audience approves. The request moves to Payment, the payment agent acts, and the request closes.
- **SC-REQ-04** — An agent decomposes a request into sub requests and work items. They appear in the tabs and link back to the parent.
- **SC-REQ-05** — An administrator edits a request type's steps, saves a draft and publishes a new version. Requests already in flight keep their version.
- **SC-REQ-06** — A request from an external contact (e.g. a widget visitor) shows the contact instead of an internal requester.

**Rules.**
- Only "Can act" audiences can move a request out of a step.
- Step SLAs and the overall SLA run on the working calendar.
- Publishing creates a new request type version.

#### 7.2.6 Scheduled Work Items

**Purpose.** Work items created on a schedule or event, assigned to an agent or a person.

**List.**
- Filter by audience (All, Agents, Humans).
- Columns: scheduled work item, project, assignee (agent, human or group), schedule, last run (Created, Failed or Skipped), next run, status (Active or Paused).
- Actions: Run now, Edit, Pause all, New Scheduled Work Item.

**New Scheduled Work Item modal.**
- Title, project, and the work item type (Task, or a request type such as Purchase Request).
- Audience: agent, human or group, plus the person.
- Repeats: Once, Daily, Weekly, Monthly or On event (with the event), plus start date, time and time zone.
- **Skip UAE public holidays and weekends.**
- Instructions: "What should be done each time?"

**Scenarios.**
- **SC-SCH-01** — An administrator creates a monthly vendor review assigned to an agent. Each month a work item is created and the agent runs.
- **SC-SCH-02** — A schedule falls on a public holiday and is skipped. Last run shows Skipped.
- **SC-SCH-03** — An administrator uses Pause all during an incident. No new items are created until resumed.

#### 7.2.7 Artifacts and Files

**Artifacts.** Outputs produced by agents and people inside a project, versioned and linked to their run.
- Grouped by project, with card and list views.
- Columns: name, project, produced by, linked to, status (Active, Inactive) and size.
- Actions: View (preview modal with metadata), Activate/Deactivate, Delete, Download.

**Files.** Files that people upload into a project.
- **Upload file modal:** project and scope of use:
  - **Only me** — only the uploader, and agents acting on their behalf;
  - **Selected** — the chosen people and agents;
  - **All project members & agents**.
- The same views and actions as Artifacts.

**Rules.**
- An agent can read a file only if the file's scope includes it.
- Deleting removes the item from the project but keeps the audit records.
- Deactivated items are not used by agents.

### 7.3 Organisation

#### 7.3.1 Org chart

People and agents in one hierarchy. Agents are shown in blue.
- **Views:** Chart (interactive) and List. Search by name, and filter All, People or Agents.
- **List columns:** name, kind (person or agent), role or version, org unit, reports to, direct reports.
- **Selecting someone opens a detail panel:**
  - for people: email;
  - for agents: model, runs in the last 30 days, and the actions Open agent and Agent run list;
  - for both: Change reporting line.

**Scenario.**
- **SC-ORG-01** — An administrator changes an agent's reporting line from the chart. The change is audited, and the agent's escalation path follows the new line.

#### 7.3.2 People & roles

"Authorisation is evaluated on permission sets, never role names. Explicit deny wins."

| Tab | Content |
| --- | --- |
| People | Name, role, org unit, sign-in method, status. Action: Invite people (email addresses, role). |
| Roles | Platform Owner, Administrator, Agent Designer, Publisher, Work Lead, Member, Approver, Auditor, Guest. Each shows its member count and scope (Organisation, or an org unit / project). Action: Edit permissions. |

#### 7.3.3 Org units

Departments and teams. Columns: unit, lead, people, agents, projects. New org unit modal: name, parent, lead, and a suggested code.

### 7.4 AI Capabilities

#### 7.4.1 Agents — list

"Versioned workers with skills, tools, memory and an org position."

- **Columns:** agent (avatar, name), org unit, version, model, execution profile, status (Idle, Running, Waiting, Paused, Error), runs and estimated cost.
- **New Agent modal:** name, org unit, execution profile, agent trust, model route.

#### 7.4.2 Agent detail

**Header.** Agent name, version and status. Actions:
- **Test in playground:** sample input → Run test → result, duration and estimated cost.
- **Publish new version:** release notes → publish.

**Tabs.**

| Tab | Content |
| --- | --- |
| Overview | **Configuration** card with Edit: execution profile, primary model, fallback route, reports to, **agent trust**, memory (e.g. "Agent memory on · 1.2 MB") and run budget (soft and hard, e.g. "AED 2.00 soft · AED 5.00 hard"). **Last 30 days:** runs, success rate, estimated cost and eval score, with View runs. |
| Instructions | System instructions (markdown) and Edit. |
| Skills | Enabled skills, with add and remove. |
| Tools | Tools from the agent's connectors, each with its connector and its mode for this agent (Auto, Approval or Denied). |
| Agent run list | Status filter (All, Running, Waiting, Succeeded, Failed) and Newest first. Columns: run, started, duration, status and estimated cost. Opens the run viewer. |
| Versions | Version, published date, published by, eval score and Active flag. Action: Roll back. |

**Agent trust presets** (one value per agent):

| Preset | Defaults |
| --- | --- |
| Restricted | Own items only · T0 tools |
| Standard | T0/T1 · T2 via approval |
| Elevated | Cross-project · can assign |
| Coordinator | Can propose new agents |
| System | Setup tools · proposals only |

No agent ever has the approve permission.

**Scenarios.**
- **SC-AGT-01** — A designer edits the instructions, tests them in the playground, and publishes v8 with release notes. New runs use v8; running runs keep their version.
- **SC-AGT-02** — An eval drop after publishing leads the designer to roll back to v7.
- **SC-AGT-03** — An administrator changes an agent's trust from Standard to Restricted. Its T1 tools stop running autonomously.

#### 7.4.3 Run viewer

- **Header:** agent and run, with the actions Replay (or replay from a step, with a reason) and Cancel run.
- **KPIs:**
  - duration (including waiting time, e.g. "+ 6m waiting");
  - tokens, with cache hit %;
  - estimated cost against the run budget;
  - tool calls, with how many need approval.
- **Timeline** of steps, including waiting steps. Selecting a step shows its **detail**:
  - the step type and result;
  - hooks applied;
  - for approvals, a link "Open in Inbox".
- **Context composition:** tokens by context block.
- **Estimated cost by step.**
- **Open trace** links to the run's trace in Phoenix.

#### 7.4.4 Skills

"Reusable capabilities in the Agent Skills standard format."

- **Tabs:**
  - **Installed:** name, source, version, tags and the number of agents using it.
  - **Discover:** skills from configured sources.
  - **My Skills:** skills the user authored.
- **Import skill package**, in two steps:
  1. Drop a `.zip`, or import from a Git URL.
  2. Validate the package: files listed, `SKILL.md` front-matter valid, no embedded secrets, warnings (e.g. "Script makes network calls — will run in sandbox only"). Choose which agents to enable it for, then Import.
- **New skill modal:** title, description ("Agents read this to decide when to load the skill") and the skill name for `SKILL.md`, which is suggested.
- **Skill detail:**
  - **Files.**
  - **Security scan:** scripts, network calls, prompt-injection patterns, embedded secrets.
  - **Where used:** agents and scheduled work items.
  - **Test bench:** test cases with pass rate and average time.
  - Publish.

**Scenario.**
- **SC-SKL-01** — An administrator imports a skill from a Git URL. The scan flags network calls, so the skill is limited to the sandbox. It is enabled for two agents and appears on their Skills tab.

#### 7.4.5 Connectors

"MCP servers that give agents controlled access to systems. Each connector sets the tier of every tool it exposes."

- **Tabs:**
  - **Connected:** connector, transport, auth, a summary of tool tiers, and status. The connector title opens its configuration.
  - **Browse:** the catalog. Each entry has a **+** button ("Add and configure").
- **Connect your own:** server URL and auth.
- **Connector drawer** (add or configure):
  - Connector enabled. When off, agents cannot call any of its tools.
  - Transport, authentication, server URL and credentials.
  - **Test connection**, which performs the MCP handshake and lists the tools ("Handshake OK · 12 tools listed").
  - **Default tier for new tools**, with the note: "Read-only tools default to T0 and destructive tools to T2 from MCP annotations. Project policies can only raise tiers."
  - **Tools and tiers:** a tier (T0–T3) per tool.
  - **Allowed agents.**
  - Remove, and Save changes.

**Scenarios.**
- **SC-CON-01** — An administrator adds a catalog connector, tests it, sets "submit purchase order" to T2 and allows two agents.
- **SC-CON-02** — An administrator disables a connector. Agents that try its tools receive a clear "connector disabled" result.

#### 7.4.6 Memory

"Manage persistent knowledge, agent context and governance."

- **Header:** New memory.
- **Cards:** Total memories, Pending review, Active agents and Needs attention.
- **Search:** across memories, policies, agents and keywords.
  - The **Filters** button opens advanced filters: owner, status, last reviewed and source.
  - **Scope chips:** All scopes, Organisation, Business unit, Agent, Session.
- **Memory explorer:** a collapsible tree (Organisation → business units → agents → sessions). Items pending review or needing attention show a status dot.
- **Detail panel:**
  - Title, path and status.
  - Version number with **History**.
  - Memory entries, each with its source.
  - **Memory details:** scope, owner, last reviewed, access and write policy (e.g. "PII filter · human approval for new rules").
  - **Edit memory.**
  - An overdue-review warning with Review now.
  - For pending memories ("Proposed by the agent. Approve before it is used in runs."): Approve and Reject.
- **Modals:**
  - **Version history:** Compare (side-by-side diff with the current version) and Restore ("Creates version 15 with this content. The change is audited.").
  - **Edit:** content and change note, saved as a new version.
  - **New memory:** title, scope and content.

**Scenarios.**
- **SC-MEM-01** — An agent proposes a new rule in Finance memory. It shows as Pending review. A reviewer approves it, and later runs use it.
- **SC-MEM-02** — An administrator compares version 12 with the current version and restores it. A new version is created.
- **SC-MEM-03** — A memory passes its review date. It shows "Needs attention" until reviewed.

**Rules.**
- Agents use memory only within the scopes their configuration allows.
- New organisation-scope rules need review (feature flag "Memory writes require review for org scope").
- The PII filter applies to memory writes.

#### 7.4.7 Knowledge

"Collections ingested into vector and graph stores for cited retrieval."

**List.**
- KPIs: collections, documents, chunks, entities.
- Columns: collection, project, index type, chunking, embedding route and status (e.g. "Ingesting 62%").
- Row actions: Test retrieval and Configure.
- Header actions: **Test knowledge retrieval** and **New collection**.
- **New collection modal:** name, project, index type, chunking technique, embedding route, visibility, and the collection ID (suggested).

**Collection page.** Header actions: Test retrieval and Save changes. KPIs: documents, chunks, entities, last sync. Two tabs.

**Tab 1 — Details: document sources.**
- Columns: source, type (Upload, URL crawl or MCP resource), document count, status and updated.
- Actions: Add source, Re-index, Remove, Re-index all.
- **Add source modal:**
  - Upload: drop PDF, DOCX, XLSX, HTML or MD files.
  - URL crawl: start URL, max depth, include pattern.
  - MCP resource: connector and resource path.
  - Then **Add and index**.

**Tab 2 — Configuration.**

| Group | Settings |
| --- | --- |
| Index | Index type, distance metric, HNSW m / ef_construct, quantisation |
| Chunking | Technique, chunk size (tokens), overlap (tokens), pre-processing: OCR for scanned PDFs, Arabic normalisation, strip headers/footers, PII masking |
| Models | Embedding route and dimensions ("Changing the embedding route re-indexes the whole collection"), entity-extraction route for the graph, re-ranker |
| Retrieval & sync | Top-k, minimum score, sync schedule (every 6 hours, daily at 02:00, on change, manual), visibility, maximum collection size |

**Test knowledge retrieval popup.** Opens from the page header (all collections), a collection row, or the collection page.
- Inputs: a query box, a Vector / Graph / Hybrid switch, and the collection (or All collections).
- Results:
  - passages with scores and a re-ranked marker;
  - graph facts;
  - retrieval time (e.g. "Retrieved in 182 ms").

**Scenarios.**
- **SC-KN-01** — An administrator creates an "HR policies" collection, uploads PDFs with Arabic normalisation and OCR on, and watches ingestion progress.
- **SC-KN-02** — An administrator tests a query in Hybrid mode and sees cited passages and graph facts.
- **SC-KN-03** — An administrator changes the embedding route, is warned about a full re-index, confirms, and the collection re-indexes.

#### 7.4.8 Models & routes

"Providers hold one or more connections; each connection allows specific models. Routes chain provider › connection › model."

**Providers tab.**
- Filters: All, Active, Not active, Custom.
- Each provider shows: cloud or custom, number of connections, models allowed, and "Not connected" when it has none.
- **Provider drawer:**
  - Provider active. When off, every connection and route step using the provider is skipped.
  - Connections list, with Add connection and Configure.
  - Allowed models.
  - Models offered by the provider.
  - **Test connection:** sends a short completion to each allowed model.
  - Remove.
- **Connection editor:**
  - connection name (e.g. Production), region, endpoint, authentication and secret;
  - **allowed models on this connection** ("Routes can only use models allowed here");
  - connection active.
- **Add custom provider** (on-prem):
  - inference engine: Ollama, vLLM, LM Studio, Hugging Face TGI, llama.cpp server, LocalAI, NVIDIA Triton/NIM, or another OpenAI-compatible engine;
  - display name, base URL and optional API key;
  - **Discover models**, then choose which to allow.

**Routes tab.**
- Columns: alias, kind (Standard, Typesafe or Voice), chain (provider › connection › model), fallback, the agents using it, and Edit.
- **Route editor:**
  - Alias: "Agents reference this alias". It is suggested from the use and the primary model.
  - **Use**: Standard, Typesafe or Voice.
  - **Typesafe:** an output schema; "Responses must validate against the schema; invalid output is retried, then routed to the fallback". Also a confidence threshold and max retries on invalid output. Example route: `classifier-typed`.
  - **Voice:**
    - Mode: realtime speech-to-speech, or a pipeline STT → LLM → TTS.
    - Speech-to-text and text-to-speech voice.
    - Languages.
    - Barge-in: allowed or off.
    - Max call length.
  - **Chain:** primary and fallbacks, each a provider, connection and model. Add fallback and Remove.

**Scenarios.**
- **SC-MDL-01** — An administrator adds an on-prem vLLM server, discovers its models, allows two of them, and uses one as a fallback in `reasoning-default`.
- **SC-MDL-02** — An administrator creates a typesafe classification route used by agentic request entry. Invalid outputs are retried, then fall back.
- **SC-MDL-03** — A provider is switched off. Routes skip its steps and use their fallbacks.

#### 7.4.9 Channels

"Enable or disable a channel and configure its credentials. Changes are hot-reloaded."

**Live channels table.** Columns: enable toggle, channel (Web widget, WhatsApp, Microsoft Teams), status (Enabled, Degraded, Disabled), bound to, and Configure.

**Configure drawer.**
- Enabled.
- Credentials for the channel type.
- **Bind to:** an embedded deployment, Discussion rooms (mirror) or Request intake.
- **Unknown senders:** treat as an external contact, or ignore.
- Rate limit (messages per minute).
- Business hours: always on, or the working calendar.
- Save. "Changes are hot-reloaded."

**Test channel modal.**
- Send to and Message, then Send test message.
- Checks: credentials valid, outbound message delivered, inbound webhook reachable, round-trip time.

**Coming soon.** Slack, Email, SMS, Voice/IVR, Telegram, Webex, Google Chat, Instagram, Facebook Messenger.

**Scenarios.**
- **SC-CH-01** — An administrator configures WhatsApp, binds it to the website-assistant deployment, sends a test, and enables it.
- **SC-CH-02** — An administrator binds Teams to discussion rooms. Rooms mirror into Teams.

#### 7.4.10 Embedded Deployment

"Agents published to websites and channels, with branding, security and storylines."

**List.** Columns: deployment, default agent, surfaces (Widget, WhatsApp, Teams), storyline (name, version and mode), status (Enabled, Disabled, Draft), rating ("No ratings yet" when empty). Action: New deployment.

**Deployment detail.** Header actions: Copy embed code and Save changes. Three tabs.

**Tab — Deployment details.**

| Card | Fields |
| --- | --- |
| Main details | Name (English), name (Arabic), default agent with agent details, status (Enabled, Disabled, Draft) |
| Surfaces | Web widget and the bound channels |
| Security & access | Allowed origins; visitor identity (anonymous with OTP step-up, or a signed JWT from the host site); human handoff queue; rate limit per visitor |
| Branding | Widget title, accent colour, welcome message |
| Last 30 days | Conversations, rating |

**Tab — Storylines.** The storyline editor (§7.4.11).

**Tab — Preview.** The widget as a visitor sees it (§7.4.12).

#### 7.4.11 Storyline editor

- **Header:** version (e.g. "Version 3"), mode (**Free**, **Guided** or **Strict**), Simulate (test variables → Start simulation) and Publish.
- **Steps list:** each step shows its type and whether it is configured or overrides the agent. Action: Add step.
- **Step types:** Message, Ask, Confirm, Decide, Classify, Tool, Skill, Verify, Create work, Handoff, Wait, Subflow, Go to, End.
- **Step panel:**
  - step name and step type;
  - **Agent for this step:** "Uses the deployment default agent", or an override ("Overrides the default agent for this step only");
  - message (for Message, Ask and Confirm) or configuration;
  - **Send verbatim (exact)**;
  - type-specific fields: slot and max attempts (Ask), method (Verify), queue (Handoff), tools (Tool), skills (Skill);
  - next step, and On error (e.g. Retry once);
  - Delete step.

**Rules.**
- In Strict mode the agent may only perform the current step, and exact messages are sent verbatim.
- In Guided mode the agent may answer side questions and then returns to the step.
- Publishing creates a new storyline version. Conversations in progress keep their version.

#### 7.4.12 Widget preview

The prototype shows a host website with the widget open. The widget has:
- a title ("Tahseel Assistant") and progress ("Card replacement · step 3 of 9");
- an identity badge ("Identity verified by OTP");
- quick replies (Lost, Stolen, Damaged);
- a confirmation card (Yes, confirm / Change);
- a "Talk to a person" handoff, a message box and Minimise;
- a launcher ("Need help?").

Copy embed code gives the script snippet for the host site.

**Scenarios.**
- **SC-EMB-01** — A designer builds a strict card-replacement storyline, simulates it with test variables, publishes it and copies the embed code.
- **SC-EMB-02** — A visitor completes the storyline. A request is created ("Create work" step) and the reference is returned.
- **SC-EMB-03** — A visitor chooses "Talk to a person". The conversation moves to the human handoff queue with its context.

### 7.5 Govern

#### 7.5.1 Setup Director

"Describe your organisation. The Director proposes a blueprint; nothing changes until you approve."

**Layout.**
- **Left — Conversation.** A CopilotKit chat with the Director. It can ask clarifying questions, e.g. "Should Vendor Onboarding requests move from Finance to Procurement?" or "Who should the Procurement Planner report to? I assumed Khalid Hassan."
- **Right — Change set** (e.g. CS-119):
  - status (Awaiting approval, or Applied · blueprint v14);
  - "Blueprint v13 → v14";
  - a summary (7 additions, 2 modifications, 0 removals);
  - the changes grouped by section, each with Approve or Reject;
  - actions: **Dry run**, and **Approve all and apply** ("Applies as one versioned change with rollback").

**What the Director can propose.** Org units, agents (with skills, connectors, memory, trust, route and budget), request types (attributes, transition steps, audiences, routing), projects and policies, scheduled work items, knowledge collections, channels bindings, embedded deployments and storylines, and settings.

**Scenarios.**
- **SC-SET-01 — First setup.** A new installation opens in setup mode. The owner describes the organisation and uploads documents. The Director proposes a full change set, and the owner approves and applies it. Blueprint v1 is created.
- **SC-SET-02 — Change by prompt.** "Add a procurement department under Finance with two agents… POs above AED 50,000 need Finance and Work Lead approval." The Director asks two questions, then proposes CS-119. The owner approves and it is applied as blueprint v14.
- **SC-SET-03 — Partial approval.** The owner rejects one change and approves the rest. Only the approved changes are applied.
- **SC-SET-04 — Rollback.** The owner rolls back an applied change set. The configuration returns to the previous blueprint version.

**Rules.**
- The Director only proposes. Applying needs a human approval.
- The Director never handles secrets: credentials are entered by people in Connectors, Channels and Models.
- Every applied change is audited.

#### 7.5.2 Budgets & estimated costs

"Budgets apply to agents. All costs are estimates based on token usage and list prices."

**List.**
- KPIs: estimated month to date, agents with a budget, over 90%, and ending within 90 days.
- Status filter: All, Active, Scheduled, Expired.
- Columns: agent, period, effective dates, status, usage this period (bar), estimated spend, limit, and History / Edit.
- Actions: Export, New agent budget.

**Budget form.**
- Agent, limit (AED, estimated), and period (daily, weekly, monthly or quarterly).
- **Effective from / to**, with **Keep forever (no end date)**.
- Warn at (%).
- **At 100%:** notify only, switch to a cheaper alias, or pause the agent.

**Budget detail.**
- Cards: limit, estimated spend for the current period, estimated forecast, and the action at 100%.
- **Consumption history** (estimated) for 6 months, coloured by usage band (under 75%, 75–90%, over 90%).
- **This month by day.**
- **Period history:** period, estimated spend, usage, runs and events (Warning sent, Hard limit reached).
- **Budget changes** log ("Limit set to…", "Budget created, effective…, no end date").
- Open agent.

**Scenarios.**
- **SC-BUD-01** — An agent reaches the warning threshold. The owner is notified and the event is logged.
- **SC-BUD-02** — An agent hits 100% with "switch to a cheaper alias". Its runs continue on the cheaper route and the event is logged.
- **SC-BUD-03** — A scheduled budget becomes Active on its effective-from date. An expired budget no longer applies.

#### 7.5.3 Audit

"Append-only record of configuration, permissions, approvals, publishes, secret access, exports and logins."

- Filters: actor (All actors, People, Agents) and period.
- Columns: time, actor, action, object and detail. Examples: "Per-diem change set", "Blueprint v13 → v14", "Reveal denied (never returned)", "T2 tool erp/purchase_order.submit".
- Action: Export.

#### 7.5.4 Logs

Application and run logs across services, with a level filter (All levels, info, warn, error) and service and run filters.

#### 7.5.5 Settings

"Validated against schema. Every change is kept in history." Action: Save changes. Three tabs.

**General.**
- Organisation name in English and Arabic.
- Time zone and languages.
- Working calendar (e.g. Mon–Fri 07:30–15:30).
- Holidays (e.g. UAE public holidays 2026).

**Branding.**
- Logos for the light and dark themes (upload; SVG or PNG, at least 240×80).
- Favicon (64×64 PNG).
- **Application colours:**
  - primary brand colour with a colour picker;
  - a live preview of a primary button, a secondary button and links;
  - the colour applies to buttons, links, active navigation and the embedded widget;
  - "Contrast is checked against WCAG 2.2 AA before saving."

**Feature flags.** Grouped toggles:

| Group | Flags |
| --- | --- |
| Agents & runs | Allow agents to assign work to other agents · Mixture-of-agents for high-stakes outputs · Verifier step on every T2 tool call · Capture full traces (RAW events) |
| Memory & knowledge | Memory writes require review for org scope · Graph retrieval (Graphiti) · PII filter on memory writes |
| Collaboration | Autonomous turn-taking in discussion rooms · Mirror rooms to Microsoft Teams · Agentic interactive request entry |
| Engage | Embedded deployments · Voice / IVR channel · Visitor ratings in widget |

#### 7.5.6 Integrations

"External clients and what they may do. Each client has its own keys, MCP connection and AG-UI exposure."

**List.** Columns: client, owner, allowed permissions, agents, keys, MCP (On/Off), AG-UI (On/Off), status. Action: New client (client name, owner, allowed permissions, allowed agents — selected only or all, and a suggested client ID).

**Client detail.** Header actions: Activate or Deactivate, and Save changes. Four tabs.

| Tab | Content |
| --- | --- |
| Keys | Create key (key name, expiry). "The secret is shown once." Per key: name, key prefix, last used, Rotate, Revoke. |
| MCP connection | **Expose platform as MCP server**, endpoint, auth, exposed tools. **Test connection** calls `tools/list` with this client's credentials (e.g. "Handshake OK · protocol 2025-06-18 · 3 tools listed"). Shows a message when MCP access is off. |
| AG-UI expose | **Expose agents over AG-UI**, stream endpoint, agents available to this client, events, allowed origins (CORS). Shows a message when AG-UI streaming is off. |
| Permissions | Allowed permissions: run allowed agents, submit requests, read work items, read discussion rooms, search knowledge, receive outbound events. |

**Scenario.**
- **SC-INT-01** — An administrator creates a "CRM integration" client and creates a key (shown once). They enable MCP with three tools, test it, and allow AG-UI for one agent from one origin.

#### 7.5.7 System

"Versions and health of every platform service."
- **KPIs:** active runs, queue depth, active rooms, uptime (30 days).
- **Service list** with version and health: web app, agent service, Temporal, agentgateway, Phoenix, PostgreSQL, Neo4j, Valkey, Ceph (Rook).
- **Pause all agents / Resume all agents:** "All agents are paused. Running workflows are drained; new runs are queued."

#### 7.5.8 Documentation

In-product guides, including:
- Getting started (start with the Setup Director);
- Discussion rooms;
- Approvals ("Agents never approve their own work. T2 tools pause the run until a human decides…");
- Storylines;
- Connectors & tiers.

### 7.6 Account

**My profile.**

| Card | Content |
| --- | --- |
| Photo | Change photo |
| Personal details | Name (English), name (Arabic), mobile, preferred language |
| Notifications | Approvals waiting for me · mentions in discussion rooms · SLA warnings on my work items · daily email digest |
| Security | Sign-in method (SSO · WebAuthn), passkeys, active sessions |

**Signed out.** Logo, the message, and Sign in with SSO.

---

## 8. End-to-end flows

### 8.1 First setup by prompt

```mermaid
sequenceDiagram
  actor O as Platform Owner
  participant SD as Setup Director (conversation)
  participant CS as Change set panel
  participant P as Platform
  O->>SD: Describe the organisation, upload documents
  SD->>O: Clarifying questions
  O->>SD: Answers
  SD->>CS: Change set (sections, additions / modifications / removals)
  O->>CS: Dry run
  CS-->>O: Validation and impact
  O->>CS: Approve all and apply (or per change)
  CS->>P: Apply as one versioned change → blueprint v1
  P-->>O: Agents, request types, projects, budgets available
```

### 8.2 Agentic request to closure

```mermaid
flowchart LR
  A[Employee: New Request - Agentic interactive] --> B[Triage agent proposes type and attributes]
  B --> C{Employee confirms?}
  C -- edit --> B
  C -- yes --> D[Request created at step Submitted]
  D --> E[Agent review step - agent audience acts]
  E -->|amount < 5000| F[Finance approval]
  E -->|amount >= 5000| G[Finance + Work Lead sequential]
  E -->|Return| D
  F -->|Approve| H[Payment step - payment agent]
  G -->|Approve| H
  F -->|Reject| Z[Closed]
  G -->|Reject| Z
  H -->|Paid| Z
```

At each step, "Can act" audiences receive the step in their Inbox (people) or as a run (agents). "Notify only" audiences are notified. Work items created along the way appear in the request's Work items tab.

### 8.3 Work item with agent and review

1. A work item is created (manually, from a request step, from a room message or by a schedule) and assigned to an agent.
2. The agent's run starts and the status moves to In progress. The run may create sub items and artifacts.
3. A T2 tool call pauses the run. The approver decides in the Inbox, and the run resumes.
4. The agent submits for review. The reviewer approves (Done) or requests changes (back to In progress, and the agent runs again).
5. When it is done, the parent's progress, the linked request and the dashboard figures update.

### 8.4 Mention in a discussion room

1. A user posts "@Expense Reviewer please check…".
2. The agent runs with the room context and streams its reply to all participants.
3. The reply includes an artifact card, and its meta shows tools, estimated cost and Open trace.
4. Another participant asks the Setup Director for a configuration change. An approval card appears in the room. An approver acts in the room, and the change is applied.
5. The context handoff (goal, decisions, open questions, next step) updates.

### 8.5 Embedded widget with strict storyline and handoff

```mermaid
sequenceDiagram
  actor V as Visitor
  participant W as Widget (CopilotKit)
  participant A as Agent (scripted)
  participant Q as Human handoff queue
  V->>W: Opens widget on allowed origin
  W->>A: Start storyline card-replacement v3 (strict)
  A->>V: Message (exact) → Ask reason (quick replies)
  A->>V: Verify (OTP) → Confirm address
  alt completed
    A->>A: Create work (request of type Card Replacement)
    A->>V: Reference number
  else Talk to a person / too many off-script turns
    A->>Q: Handoff with context
    Q->>V: Human continues the conversation
  end
```

### 8.6 Scheduled work item

1. The schedule fires (Once, Daily, Weekly, Monthly or On event), unless the date is a UAE public holiday or weekend and skipping is on.
2. A work item (or request) is created in the project with the instructions, and assigned to the agent, person or group.
3. The last-run status (Created, Failed or Skipped) and the next run update.

### 8.7 Knowledge collection

1. Create the collection (name, project, index, chunking, embedding route, visibility).
2. Add sources (upload, URL crawl or MCP resource). Ingestion runs with progress.
3. Test retrieval in Vector, Graph or Hybrid mode.
4. Agents with access to the collection retrieve cited passages and graph facts at run time.

### 8.8 Memory review

1. An agent proposes a memory entry, which shows as Pending review.
2. A reviewer approves or rejects it.
3. Approved entries create a new version and become available to runs in that scope.
4. Edits and restores always create new versions with a change note.

### 8.9 Budget enforcement

1. Each run adds estimated cost to the agent's current budget period.
2. At the warning percentage: notify and log.
3. At 100%, the configured action runs: notify only, switch to a cheaper alias, or pause the agent.
4. Period history and the consumption charts update.

### 8.10 Connector and tool tiers

1. Add a connector, from Browse or Connect your own.
2. Test the MCP handshake.
3. Review the tool list. Tiers default from the MCP annotations. Adjust them and choose the allowed agents.
4. Agents call tools within their tier, trust and project policy.

### 8.11 Integration client

1. Create the client and a key. The key is shown once.
2. Enable MCP exposure, with the exposed tools, and/or AG-UI exposure, with the agents and allowed origins.
3. The external system calls the platform with its key. Every call is limited to the client's allowed permissions and is audited.

---

## 9. Cross-cutting rules

| Area | Rule |
| --- | --- |
| Approvals | A human always decides T2 actions, change sets and approval steps. Agents never approve. The requester cannot approve their own request. A rejection requires a reason. |
| Permissions | Permission sets, not role names; explicit deny wins. Agents are limited by agent trust, connector allowed-agents, tool tiers, project policy and file scope. |
| Versioning | Agents, skills, request types, storylines, memory and blueprints are versioned. Running items keep the version they started with. |
| Estimated cost | Shown on runs, rooms, agents, budgets and the dashboard; always labelled as estimated. |
| Audit | All configuration changes, permission changes, approvals, publishes, secret reveal attempts, exports and logins are written to the append-only audit log. |
| Secrets | Shown once on creation and never returned afterwards ("Reveal denied (never returned)"). |
| Codes | Suggested from names; editable before saving; unique. |
| Localisation | Every label is in English and Arabic; layout mirrors in RTL; record names have English and Arabic fields. |
| Theming | Light and dark themes; brand colour from Settings applies to the console and widget after a WCAG 2.2 AA contrast check. |
| Notifications | Per-user preferences in My profile (approvals, mentions, SLA warnings, daily digest). |

---

## 10. Non-functional requirements

| Area | Requirement |
| --- | --- |
| Performance | List and detail screens respond in under 300 ms at p95. The first streamed agent token appears in under 1.5 s at p95, excluding provider delays. Retrieval tests return in under 500 ms at p95. |
| Durability | Agent runs survive service restarts without repeating side effects; waiting runs consume no workers. |
| Availability | 99.9% with at least two replicas of web and agent services on Kubernetes and a highly available PostgreSQL cluster (CloudNativePG, 3 instances). |
| Security | SSO and passkeys; OWASP ASVS L2; prompt-injection and data-exfiltration controls on tool results and documents; sandboxed skill scripts. |
| Privacy | PII masking in runs, memory and knowledge pre-processing; retention rules; erasure across stores. |
| Accessibility | WCAG 2.2 AA for the console and widget. |
| Localisation | Full English/Arabic parity; RTL mirroring; Arabic normalisation for knowledge. |
| Observability | Every run traced (Phoenix) and its workflow history kept (Temporal); logs per service. |
| Installability | Local: `make kind-up` then `make deploy` on a kind cluster. Test and Live: the same Helm charts applied by the organisation's CD. `.env` (local) or the secret store (Test, Live) plus real secrets is the only manual step. |

---

## 11. Delivery phases and open decisions

### 11.1 Phases

| Phase | Screens delivered | Exit criterion |
| --- | --- | --- |
| 1 — Foundation | Shell, sign-in, My profile, Settings (General, Branding, Feature flags), People & roles, Org units, Org chart, System, Audit, Logs, Documentation | Bilingual shell with SSO; audit and settings history working |
| 2 — Agents core | Agents (all tabs), run viewer, Models & routes, Connectors, Skills, Budgets, Inbox (approvals and questions) | An agent runs, calls an MCP tool with a T2 approval, and its estimated cost is counted against its budget |
| 3 — Setup | Setup Director with change sets, dry run, apply, rollback | An empty installation is configured by prompt |
| 4 — Work | Projects, Requests (both entry modes, request types with steps and audiences), Work Items, Scheduled Work Items, Artifacts, Files, Dashboard and drill-downs | The Expense Claim example runs end to end |
| 5 — Collaboration and knowledge | Discussion Rooms (all turn-taking modes, Teams mirroring), Memory, Knowledge | A room with people and agents works live; memory review and retrieval tests work |
| 6 — Engage | Channels (Web widget, WhatsApp, Teams), Embedded Deployment, storyline editor, widget, Integrations | A strict storyline runs on a website and WhatsApp, with handoff |

### 11.2 Open decisions

- The Next.js data-access library for PostgreSQL (recommended: Drizzle ORM).
- PostgreSQL 17 or 18.
- One long-lived Temporal workflow per discussion room, or one short workflow per turn.
- The sandbox technology for skill scripts.
- External secrets vault, or application-level envelope encryption in PostgreSQL only.
- Allowed model providers and regions (residency).
- The order in which the Coming soon channels are released.

---

## 12. Appendix — screen inventory and prototype map

| Screen / component | Prototype component | File |
| --- | --- | --- |
| Shell, navigation, top bar, user menu, page assistant, My profile, signed out | `App`, `MyProfile`, `SignedOut` | `awp-app.jsx` |
| Shared UI (Card, Modal, Drawer, Tabs, Toggle, Seg, Kpi, Bar, avatars, tags) | `Card`, `Modal`, `Drawer`, … | `awp-shell.jsx` |
| Dashboard, Discussion Rooms list, Discussion Room | `Dashboard`, `SessionsList`, `SessionRoom` | `awp-screens-1.jsx` |
| Work Items, work item drawer, Inbox, Setup Director | `Tasks`, `TaskDrawer`, `Inbox`, `SetupDirector` | `awp-screens-2.jsx` |
| Agents, agent runs, run viewer, storyline editor, widget preview | `Agents`, `AgentRuns`, `RunViewer`, `Storyline`, `Widget` | `awp-screens-3.jsx` |
| Search palette, Projects, Requests, request detail, request type detail, Scheduled Work Items, Artifacts, Files | `SearchPalette`, `Projects`, `Requests`, `RequestDetail`, `RequestTypeDetail`, `Routines`, `Artifacts`, `Files` | `awp-screens-4.jsx` |
| Org chart, People & roles, Org units, Skills | `OrgChart`, `People`, `OrgUnits`, `Skills` | `awp-screens-5.jsx` |
| Channels, Embedded Deployment list and detail, Audit, Logs, Settings, Integrations, client detail, System, Documentation | `Channels`, `Deployments`, `DeploymentDetail`, `Audit`, `Logs`, `Settings`, `Integrations`, `ClientDetail`, `SystemPage`, `Docs` | `awp-screens-6.jsx` |
| Knowledge, collection detail, retrieval test | `Knowledge`, `CollectionDetail`, `RetrievalTest` | `awp-knowledge.jsx` |
| Memory | `Memory` | `awp-memory.jsx` |
| Budgets, budget detail, budget form | `Budgets`, `BudgetDetail`, `BudgetForm` | `awp-budgets.jsx` |
| Connectors, connector drawer | `Connectors`, `ConnectorDrawer` | `awp-connectors.jsx` |
| Models & routes, provider drawer, connection editor, custom provider, route editor | `Models`, `ProviderDrawer`, `ConnEditor`, `CustomProviderModal`, `RouteEditor` | `awp-models.jsx` |
| Dashboard records, code field, new project / request type / skill / client modals | `Records`, `CodeField`, `NewProjectModal`, `NewRequestTypeModal`, `NewSkillModal`, `NewClientModal2` | `awp-records.jsx` |
| Action modals: new room, request, work item, schedule, upload, skill import, channel add/test/configure, file preview, generic action modal | `NewRoomModal`, `NewRequestModal`, `NewWorkItemModal`, `NewScheduleModal`, `UploadFileModal`, `ImportSkillModal`, `AddChannelModal`, `TestChannelModal`, `ConfigChannelDrawer`, `PreviewModal`, `ActionModal` | `awp-actions.jsx` |

The prototype also carries `AgentTrust` in `awp-screens-5.jsx`. Section 2.2 removed that page: trust is a field on the agent, shown on the agent's Configuration card, so the platform has no screen for it.
| Design system | Tahseel Design System tokens, components, RTL | `_ds/tahseel-design-system-…/` |

The design changes that produced these screens are listed, in order, in `CHANGELOG.md` at the root of the handoff package.

---
*End of specification.*
