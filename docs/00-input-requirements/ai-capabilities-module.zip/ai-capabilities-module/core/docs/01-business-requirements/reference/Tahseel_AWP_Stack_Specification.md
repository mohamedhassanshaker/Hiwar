# Tahseel AWP — Technology Stack Specification

| Item | Value |
| --- | --- |
| Version | 1.0 |
| Date | 10 Oct 2026 |
| Companion to | `Tahseel_AWP_Specification.md`, `Tahseel_AWP_Data_Model.md`, `Tahseel_AWP_Screens_Use_Cases.md` |
| Scope | The components AWP builds, configures and ships: application code, AI platform services, data stores and the developer toolchain. Cluster infrastructure is listed only as prerequisites (§3.3). |
| Deployment model | Single tenant on Kubernetes; **kind** for local development; the same Helm charts for Test and Live |

---

## 1. Principles

| # | Principle | Effect on the stack |
| --- | --- | --- |
| SP-1 | Two application runtimes | **Next.js (TypeScript)** for UI and domain logic; **Python** for the agent harness, Temporal workers and knowledge ingestion. |
| SP-2 | One relational engine | **PostgreSQL** holds domain data, passage vectors (pgvector), Temporal state and Phoenix traces, in one cluster with separate databases. |
| SP-3 | Standards over proprietary formats | MCP, Agent Skills, AG-UI, CopilotKit, OpenAI-compatible model API, A2A, Gateway API, S3 API, OpenTelemetry. |
| SP-4 | One gateway for AI traffic | Every model call goes through **agentgateway**. MCP-connector and A2A traffic are this principle's design target, not its current state — see the implementation status in §6.1. |
| SP-5 | Durable by default | Every agent run, schedule and ingestion job is a Temporal workflow. |
| SP-6 | Minimum moving parts | A component is in the stack only if no component already present can do the job. Infrastructure concerns (networking, certificates, secrets, logging, metrics, node hardening) belong to the cluster platform, not to AWP. |
| SP-7 | Pin everything | Images by digest, packages in lock files, versions recorded in `versions.lock.md`. |
| SP-8 | One orchestration model | Kubernetes in every environment, with kind locally. |

---

## 2. Layered view

```mermaid
flowchart TB
  subgraph Edge["North–south"]
    TR[Traefik Proxy - Gateway API]
  end
  subgraph App["Next.js full stack - web"]
    UI[Console - Tahseel DS + CopilotKit v2]
    CKRT["CopilotKit runtime /api/copilotkit/[[...slug]]"]
    Domain[Domain layer]
    PMCP[Platform MCP server]
    CHG[Channel gateway]
  end
  subgraph Agent["Agent service - Python"]
    AGUI[FastAPI AG-UI endpoints]
    Harness[Agent harness - Pydantic AI]
    Worker[Temporal workers + sandbox launcher]
    KG[Graphiti]
  end
  subgraph AI["AI platform"]
    AGW[agentgateway: LLM today, MCP + A2A target]
    Temporal[Temporal]
    Phoenix[Arize Phoenix]
  end
  subgraph Data["Data"]
    PG[(PostgreSQL cluster: awp · awp_kb · temporal · phoenix)]
    NJ[(Neo4j - Graphiti graph)]
    VK[(Valkey)]
    RGW[(Rook Ceph RGW - S3)]
  end
  subgraph Sandbox["awp-sandbox namespace"]
    SB[Sandbox pods - no egress]
    CP[stdio MCP connector pods]
  end
  CR[services/connectors runtime]
  TR --> UI & CKRT & CHG
  CKRT -->|AG-UI via HttpAgent| AGUI
  Domain --> PG & VK & RGW
  Domain -->|start / signal| Temporal
  AGUI --> Worker --> Harness
  Harness -->|OpenAI-compatible| AGW
  AGW --> Providers[[Model providers / on-prem engines]]
  %% MCP and A2A through agentgateway are the target design (stack specification 6.1),
  %% not current behaviour - dashed. Solid edges below are the real current path.
  Harness -.->|MCP, target design| AGW
  AGW -.-> PMCP
  AGW -.-> CP
  AGW -.-> ExtMCP[[Remote MCP servers / A2A agents]]
  Harness -->|MCP, direct, today| PMCP
  Harness -->|MCP, direct, today| CR --> CP
  Harness --> KG --> NJ
  Harness --> PG & RGW & VK
  Worker --> SB
  AGW -->|OTel| Phoenix
  Harness -->|OTel| Phoenix
  Temporal --> PG
  Phoenix --> PG
```

---

## 3. Stack inventory

### 3.1 Platform services (deployed by AWP)

| Component | Baseline | Role | Licence (confirm at build) | Namespace |
| --- | --- | --- | --- | --- |
| **agentgateway** | 1.x (Kubernetes mode) | LLM gateway (OpenAI-compatible, failover, token rate limits, cost attribution), MCP gateway (federation, OpenAPI→MCP, MCP auth), A2A gateway | Apache-2.0 (Linux Foundation) | `awp-ai` |
| **Temporal** server + UI | Current 1.2x | Durable execution for runs, schedules, ingestion, setup apply | MIT | `awp-ai` |
| **Arize Phoenix** | Current | LLM traces, evaluations, datasets, experiments, prompt management | Elastic License 2.0 (confirm) | `awp-ai` |
| **PostgreSQL** via **CloudNativePG** | PostgreSQL 17 min · 18 recommended | One cluster: domain (`awp`), passage vectors with **pgvector** (`awp_kb`), Temporal (`temporal`, `temporal_visibility`), Phoenix (`phoenix`) | PostgreSQL / Apache-2.0 | `awp-data` |
| **Neo4j** Community | 5.26+ | Graph store behind Graphiti | GPLv3 | `awp-data` |
| **Valkey** | 8.x | Pub/sub fan-out, AG-UI event streams, rate-limit buckets, locks, caches | BSD-3-Clause | `awp-data` |
| **Rook** + Ceph RGW | Current | S3-compatible object storage | Apache-2.0 / LGPL | `rook-ceph` |
| **Traefik Proxy** | v3.x (Gateway API provider) | North–south ingress for console, widget, webhooks and admin UIs | MIT | `awp-system` |

### 3.2 Application and libraries

| Layer | Component | Role |
| --- | --- | --- |
| Runtime | Node.js (Active LTS ≥ 20), Python 3.12 | Application runtimes |
| Web | Next.js (App Router) 15+, React 19, TypeScript 5 (strict) | Full-stack web application |
| UI | Tahseel Design System (`_ds/`) | Tokens, components, RTL, fonts |
| Agent UI | `@copilotkit/react-core` (v2 entry point), `@copilotkit/runtime` (v2 entry point), `@ag-ui/client` | Agent surfaces, runtime route, `HttpAgent` (§4.3) |
| Web libraries | Drizzle ORM + `pg`, Zod, Ajv, React Hook Form, TanStack Query, next-intl, date-fns + `@date-fns/tz`, Recharts (on DS tokens), React Flow, MDXEditor, AWS SDK v3 S3 client, `iovalkey`, `@temporalio/client`, `@modelcontextprotocol/sdk`, Auth.js v5 + SimpleWebAuthn, `@kubernetes/client-node` | See §4.2 |
| Agent service | FastAPI, Uvicorn, Pydantic v2, **Pydantic AI v2** (OpenAI-compatible provider + AG-UI extra), `ag-ui-protocol`, `temporalio`, `mcp`, `graphiti-core`, `neo4j`, `psycopg` + `pgvector`, `boto3`, `valkey`, `kubernetes`, `docling`, Presidio, OpenTelemetry + `arize-phoenix-otel` / `arize-phoenix-client` | See §5.2 |
| Developer toolchain | kind, Helm 3, kubectl, make, Docker Buildx, pnpm, uv, ESLint/Prettier/oxlint, ruff/mypy, Vitest, Playwright, pytest | §12 |

### 3.3 Infrastructure prerequisites (provided by the cluster platform, not by AWP)

| Prerequisite | Requirement | Local kind |
| --- | --- | --- |
| Container network | CNI that enforces Kubernetes `NetworkPolicy` | kind's default network plugin (NetworkPolicy support built in since kind v0.24) |
| Storage | A default StorageClass for PVCs | kind `standard` (local-path) |
| TLS certificates | A TLS Secret for the public hosts | Self-signed via `mkcert`, created by bootstrap |
| Secrets | Secrets delivered as Kubernetes Secrets from the organisation's secret store | Created from `.env` by bootstrap |
| Logs | Pod logs collected into a log store with a query API, read by the Logs screen | Kubernetes API pod logs |
| Metrics, alerting | Prometheus-compatible scraping of the workloads' `/metrics` | Not used |
| Registry | Organisation container registry with image scanning and SBOM in CI | Local registry `localhost:5001` |
| Node hardening, backups of volumes, cluster upgrades | Platform team | — |

---

## 4. Web application (Next.js full stack)

### 4.1 Responsibilities

- Console screens and modals (all screens in the use-case document).
- Domain logic and authorisation for every entity, through server actions and route handlers.
- **CopilotKit runtime** — the single browser-facing agent endpoint (§4.3).
- Platform MCP server for agents and integration clients, called directly today; routing it through agentgateway is the target design, not current behaviour (§6.1).
- Rendering of agentgateway `AgentgatewayModel` routes from Models & routes (through a narrow-scoped Kubernetes service account). Connectors and Integrations render nothing to agentgateway yet (§6.1); stdio connector pods are created by the Python `services/connectors` runtime, not by the web app.
- Channel gateway: web widget, WhatsApp and Microsoft Teams webhooks; translation of AG-UI events to channel messages.
- Embeddable widget bundle.
- Domain outbox relay to Temporal and Valkey.

**Ownership rule.** Only the web app connects to the `awp` database. The agent service reads and writes domain data through the platform MCP server; it owns only the `awp_kb` database (passage vectors), which is a rebuildable index.

### 4.2 Libraries

| Concern | Library | Notes |
| --- | --- | --- |
| UI kit | Tahseel Design System (`_ds/…`) | Recreate prototype components on DS tokens; DS adherence enforced with the bundled oxlint config |
| Agent UI | `@copilotkit/react-core` — **v2 entry point** (`@copilotkit/react-core/v2`) | Provider, `CopilotChat`/`CopilotSidebar`/`CopilotPopup`, tool renderers, human-in-the-loop, shared state, styles. `@copilotkit/react-ui` is **not** required with the v2 entry point. |
| Agent runtime | `@copilotkit/runtime` — **v2 entry point** (`@copilotkit/runtime/v2`) | `CopilotRuntime` + multi-route handler in a catch-all App Router route |
| AG-UI client | `@ag-ui/client` (`HttpAgent`) | One `HttpAgent` per AWP agent/room, pointing at the agent service |
| Data access | **Drizzle ORM** + `pg` | Typed `jsonb`, generated columns, SQL-first migrations (drizzle-kit) |
| Validation | Zod (forms/actions), Ajv (JSON Schema 2020-12 for dynamic attributes) | |
| Forms / server state | React Hook Form, TanStack Query | |
| i18n | next-intl | English/Arabic, RTL `dir` switch |
| Dates | date-fns + `@date-fns/tz` | Working calendar, SLA |
| Charts / graphs | Recharts styled with DS tokens; React Flow for the org chart and storyline map | |
| Markdown editing | MDXEditor | Instructions, skills, memory |
| Auth | Auth.js v5 (OIDC) with the Drizzle adapter, SimpleWebAuthn | Sessions in PostgreSQL |
| Object storage | AWS SDK v3 S3 client → Rook Ceph RGW | Path-style addressing, presigned URLs |
| Realtime | SSE route handlers + Valkey pub/sub (`iovalkey` or `ioredis`, which is protocol compatible) | Room fan-out, inbox badge, live dashboard cards |
| MCP server | `@modelcontextprotocol/sdk` (Streamable HTTP) | Called directly by the harness today; publishing it to agents through agentgateway is the target design (§6.1) |
| Temporal client | `@temporalio/client` | Start, signal, query and cancel workflows |
| Kubernetes client | `@kubernetes/client-node` | Applies agentgateway `AgentgatewayModel` routes only (scoped RBAC); stdio connector Deployments are applied by the Python `services/connectors` runtime instead |
| Testing | Vitest, Testing Library, Playwright (EN/AR, light/dark, RTL) | Use-case IDs in test names |

### 4.3 CopilotKit with Next.js — the setup

Checked against current CopilotKit documentation:
- The `CopilotKit` provider, the chat/sidebar components and the stylesheet all come from `@copilotkit/react-core/v2`.
- The runtime's v2 handlers are multi-route, served from a catch-all route (`app/api/copilotkit/[[...slug]]/route.ts`) with a `basePath`.
- The Python FastAPI endpoint speaks AG-UI, not the CopilotKit runtime protocol. Pointing `runtimeUrl` at it fails, so a CopilotKit runtime must sit in front of it and reach it through an `HttpAgent`.

#### 4.3.1 Packages

```bash
pnpm add @copilotkit/react-core @copilotkit/runtime @ag-ui/client
```

**Pinning rule.** `@copilotkit/react-core` and `@copilotkit/runtime` are pinned to the same release. `@ag-ui/client` is pinned to the version that runtime release declares, so the `HttpAgent` types match. All three are upgraded together, in one PR, with the Playwright agent suite.

#### 4.3.2 Runtime route (server)

```ts
// apps/web/app/api/copilotkit/[[...slug]]/route.ts   (illustrative — follow the pinned version's API)
import { CopilotRuntime, createCopilotRuntimeHandler } from "@copilotkit/runtime/v2";
import { HttpAgent } from "@ag-ui/client";
import { resolveAgentsForRequest } from "@/src/agents/registry";   // AWP agents the user may use

export const runtime = "nodejs";          // not the edge runtime: needs DB, auth and streaming
export const dynamic = "force-dynamic";

async function buildRuntime(req: Request) {
  const { user, agents } = await resolveAgentsForRequest(req);   // auth + permission check
  return new CopilotRuntime({
    agents: Object.fromEntries(agents.map(a => [
      a.key,
      new HttpAgent({
        url: `${process.env.AGENT_SERVICE_URL}/agui/agents/${a.id}`,
        headers: { Authorization: `Bearer ${a.runToken}` },        // short-lived, minted server-side
      }),
    ])),
  });
}

export const { GET, POST } = createCopilotRuntimeHandler({
  basePath: "/api/copilotkit",
  runtime: buildRuntime,                  // per-request runtime with the user's permitted agents
});
```

**Rules**
- **Agent registration.** Agents are registered per request from the AWP agent registry, filtered by the user's permissions, project membership and the Integrations settings. A room registers its lead and member agents. The embedded widget registers only its deployment's agent.
- **Token handling.** Run tokens are minted on the server and never reach the browser.
- **AG-UI middleware** (`agent.use`) on each `HttpAgent` handles:
  - PII redaction of logged events;
  - audit of human-in-the-loop decisions;
  - stripping `RAW` events unless trace capture is enabled for the run.
- **No direct connection.** The browser never connects to the agent service: `agents__unsafe_dev_only` is not used, and the agent service is only reachable inside the cluster.
- **Conversation persistence.** Conversations are stored by AWP in PostgreSQL (rooms and messages). No hosted CopilotKit persistence service is used.

#### 4.3.3 Provider and components (client)

```tsx
// apps/web/app/(console)/providers.tsx
"use client";
import { CopilotKit } from "@copilotkit/react-core/v2";
import "@copilotkit/react-core/v2/styles.css";        // then overridden by Tahseel DS tokens (rtl.css last)

export function AgentProviders({ children, agentKey }: { children: React.ReactNode; agentKey?: string }) {
  return (
    <CopilotKit runtimeUrl="/api/copilotkit" agent={agentKey}>
      {children}
    </CopilotKit>
  );
}
```

| Surface | Component / hook (v2 entry point) | Notes |
| --- | --- | --- |
| Discussion room | Chat component with custom message renderers | Participants, mentions, approval cards, artifact cards; AG-UI `CUSTOM` events rendered as DS cards |
| Agent playground, Setup Director, agentic request entry | Chat component | The Setup Director binds its change-set panel to shared agent state |
| Page assistant | `CopilotSidebar` | Page context passed as readable context; suggested prompts |
| Tool calls | Default and per-tool render hooks (e.g. `useDefaultRenderTool`, tool-specific renderers) | Generative UI per tool (e.g. calendar event card) |
| Human in the loop | Interrupt/approval renderers | Decision posted to the domain API → Temporal signal |
| Embedded widget | `CopilotPopup` inside a web component | Uses the same runtime endpoint with a deployment token instead of a session cookie |
| Development | CopilotKit Inspector (AG-UI events) | Enabled only in kind and Test |

**Styling.** The CopilotKit stylesheet loads first. Tahseel DS tokens and `rtl.css` override it, so chat surfaces follow the console theme in light, dark and RTL.

#### 4.3.4 Agent service side (Python)

- AG-UI endpoints are implemented in FastAPI with `ag-ui-protocol` (types and event encoder) and Pydantic AI v2's AG-UI adapter API.
- Because runs execute as Temporal workflows, the endpoint does two things. It starts or attaches to the run workflow. Then it streams the run's AG-UI events, which the harness publishes to a Valkey stream per run, back to the runtime. Reconnects replay from the stream offset, and late joiners get `MESSAGES_SNAPSHOT`.

| Endpoint | Purpose |
| --- | --- |
| `POST /agui/agents/{agentId}` | Start a turn or run with an agent (playground, page assistant, request entry, widget) |
| `POST /agui/rooms/{roomId}` | Room stream (lead/member agents per turn policy) |
| `GET /agui/runs/{runId}/events` | Re-attach to a running run's event stream |

### 4.4 Structure

```
apps/web/
  app/
    (console)/                 # authenticated screens
    (auth)/                    # sign-in, signed-out
    api/
      copilotkit/[[...slug]]/  # CopilotKit runtime (v2 multi-route handler)
      mcp/                     # platform MCP server (Streamable HTTP)
      channels/                # whatsapp, teams, widget webhooks
      sse/                     # live streams (rooms, inbox, dashboard)
  src/
    agents/registry.ts         # per-request agent resolution + run-token minting
    domain/  db/  authz/  i18n/  ui/
  widget/                      # embeddable widget (web component wrapping CopilotPopup)
```

---

## 5. Agent service (Python)

### 5.1 Responsibilities

- AG-UI endpoints (§4.3.4).
- **Agent harness:** context assembly, model steps, MCP tool execution, tiers and approvals, memory tool, verifier, hooks and delegation.
- **Temporal workers:** run workflows, schedules, ingestion, and Setup Director dry-run/apply.
- **Knowledge and memory indexing and retrieval** with Graphiti (§6.5) and pgvector passages in `awp_kb`.
- **Sandbox launcher** for workspace tools and skill scripts (§6.4).

### 5.2 Libraries

| Concern | Library | Notes |
| --- | --- | --- |
| Packaging | `uv`, `pyproject.toml` | |
| HTTP | FastAPI, Uvicorn (uvloop) | |
| Models | Pydantic v2, pydantic-settings | |
| Agent primitives | **Pydantic AI v2** (`pydantic-ai`, OpenAI-compatible provider, AG-UI extra) | Capabilities, hooks, deferred tools, agent specs; `openai-chat:` provider pointed at **agentgateway** (§5.4) |
| AG-UI | `ag-ui-protocol` | Types and encoder |
| Durable execution | `temporalio` + Pydantic data converter | |
| Sandbox launcher | `kubernetes` (Python client) with a Role limited to Pods in `awp-sandbox` | §6.4 |
| Gateway client | One `gateway_client` module (OpenAI-compatible client with base URL = agentgateway LLM route) | The only place model and embedding calls are built |
| MCP client | `mcp` | Connects directly to each connector's real endpoint (`services/connectors`, or the platform MCP server for platform tools) — **not** through agentgateway; see the implementation status in §6.1 |
| Knowledge graph | `graphiti-core` with the Neo4j driver | LLM, embedder and cross-encoder clients configured to use agentgateway aliases |
| Vector store | `psycopg` 3 + `pgvector` | Passages in the `awp_kb` database (Vector mode) |
| Object storage | `boto3` (S3 API) → Rook Ceph RGW | |
| Cache / streams | `valkey` (redis-py compatible) | AG-UI event streams per run, room fan-out |
| Parsing and OCR | `docling` with its built-in OCR engine configured for Arabic and English | PDF, DOCX, XLSX, HTML, MD; scanned PDFs |
| Arabic normalisation | In-house function (alef, yaa, taa-marbuta forms, diacritics, tatweel), shared with the PostgreSQL search-key logic | No external dependency |
| PII | Presidio (analyzer + anonymizer) with Arabic recognisers | Pre-model hook, memory writes, knowledge pre-processing |
| Observability | `opentelemetry-sdk` + `arize-phoenix-otel` / OpenInference conventions (OTLP → Phoenix), `arize-phoenix-client` for datasets, experiments, evaluations and prompts | W3C `traceparent` propagated to agentgateway, so LLM spans join the run trace |
| Quality | ruff, mypy, pytest, Temporal test environment | |

### 5.3 Process model

| Process | Workload | Scale |
| --- | --- | --- |
| FastAPI (AG-UI) | `agent-service` | Horizontal, stateless |
| Temporal worker — runs, schedules, setup, sandbox launcher | `agent-worker` (task queues `agent-runs`, `setup`, `maintenance`) | By queue backlog |
| Temporal worker — ingestion | `agent-worker-ingest` (task queue `ingestion`) | By queue backlog; Graphiti extraction is LLM-heavy, so concurrency is capped by the budget per collection |

### 5.4 Pydantic AI v2 in the harness

The harness is built on **Pydantic AI v2** (`uv add pydantic-ai`, pinned). v2 bundles an agent's instructions, tools, lifecycle hooks and model settings into one composable unit, the **capability**. AWP's harness concepts are implemented as capabilities. The loop control, governance and durability remain AWP code.

| AWP harness concept | Pydantic AI v2 mechanism |
| --- | --- |
| Skills (Agent Skills, progressive disclosure) | One `Capability` per enabled skill (id, description, instructions, optional toolset) with **`defer_loading=True`**: the model sees only the one-line description in a compact catalog, and loads the whole skill when it decides to |
| Connectors (target design: MCP via agentgateway; today: direct) | Tool definitions are exposed to the model as an `ExternalToolset` capability; the actual call is the harness's own `mcp` SDK client dialing the connector's real endpoint directly (§6.1), not Pydantic AI's `MCPToolset` against a gateway URL. Installed connectors load eagerly, permitted connectors use `defer_loading=True` |
| `tool_search` (permitted tools) | Built-in `ToolSearch` capability |
| Hooks (PII masking, rules, injection screening, result truncation and offload) | Custom capabilities using the **hooks** API to read and rewrite tools, instructions and message history at each step |
| Approvals (T1/T2 tiers) | **Deferred tool calls**: the tool call is returned unexecuted, the Temporal workflow waits for the human decision (signal), then resumes the run with the result |
| Room messages arriving mid-run, steering | **Pending message queue** (inject messages mid-run) |
| Context compaction | AWP compaction capability (provider-neutral, through agentgateway); provider server-side compaction is not used, because traffic goes through the gateway |
| Memory tool, verifier, delegation | AWP custom capabilities |
| Execution profiles and agent versions | Agent versions compile to a Pydantic AI **agent spec** (serializable capabilities); each execution profile is a set of capabilities |
| Instrumentation | Pydantic AI's instrumentation capability (OpenTelemetry, instrumentation version 5 with aggregated token-usage attributes) exported to Phoenix |
| AG-UI | Pydantic AI's AG-UI adapter (`ag-ui` extra) with `ag-ui-protocol` |

**v2 settings the harness pins explicitly**

| Setting | Value | Why |
| --- | --- | --- |
| Model prefix | **`openai-chat:`** with base URL = agentgateway | In v2 the `openai:` prefix uses the Responses API. The gateway route is called through Chat Completions. Moving to the Responses API needs an agentgateway compatibility check first. |
| Native web tools | `WebSearch` / `WebFetch` **not enabled** | They run natively at the provider by default and would bypass agentgateway and tool governance. Web access is provided as MCP connectors. |
| MCP | Not pinned to `MCPToolset` in practice | The harness does not use Pydantic AI's `MCPToolset` — it calls each connector's real endpoint directly with its own `mcp` SDK client (§6.1, §5.2's MCP client row). Routing all MCP traffic through the gateway is the target design, not the current pin. |
| `end_strategy` | Set explicitly per profile | v2 runs function tools requested alongside a successful output tool (`graceful`); the verifier and approval flow must account for this |
| Provider extras | Only the OpenAI-compatible provider | v2 makes the long tail of providers opt-in; agentgateway handles provider differences |
| Pydantic AI durable execution | Not used | AWP runs every run as its own Temporal workflow (§5.3); Pydantic AI's durable-execution layer is not mixed in |

**Pydantic AI Harness package.** The first-party `pydantic-ai-harness` capabilities (memory, guardrails, context management, file system access, code mode on Monty) are **not** dependencies by default. Individual capabilities may be adopted after review (SD-13). Any adopted capability runs under AWP governance: tiers, budgets and tracing.

**Version policy.** Pydantic AI v2 guarantees no breaking changes within a major version and deprecations before removals. The window between majors is three months. Upgrades follow the latest v2 minor; deprecation warnings fail CI.

---

## 6. AI platform components

### 6.1 agentgateway (LLM, MCP and A2A gateway)

agentgateway is the intended single path for all AI traffic; today it is the path for model traffic only.
- It exposes a unified OpenAI-compatible API across major providers, with load balancing, failover, budget and spend controls.
- It is also designed to work as an MCP gateway (tool federation, OpenAPI-to-MCP, MCP authorization) and an A2A gateway — the MCP and A2A gateway roles below are the target design, not yet built.
- It is a Linux Foundation project and conformant to the Kubernetes Gateway API.

**Implementation status.** Only the LLM gateway role is implemented and in use. The harness (`services/agent/src/awp_agent/gateway_client.py`) calls agentgateway for every model and embedding call, exactly as the LLM gateway row below describes. The MCP gateway, A2A gateway and "platform MCP through agentgateway" roles are not implemented: connector tool calls go directly from the harness (`harness/tools/pool.py`) to a separate `services/connectors` runtime, and the platform MCP server (`apps/web/src/mcp/server.ts`) is called directly too — agentgateway's MCP listener (`AGW_MCP_BASE_URL`) is configured in every environment but has no caller. There is no `AgentgatewayBackend` or `AgentgatewayPolicy` rendering code anywhere in `apps/web/src/agentgateway/`, only `AgentgatewayModel` rendering for routes. The rows below describe the target design for MCP and A2A; read them as such, not as current behaviour, until this note is removed.

| Role | How AWP uses it |
| --- | --- |
| **LLM gateway** *(implemented)* | Each **route (alias)** from Models & routes becomes an agentgateway LLM backend/route. The harness, Graphiti and the ingestion pipeline call one OpenAI-compatible endpoint (`http://agentgateway.awp-ai.svc/…`) and select the alias. Failover follows the route's fallback chain. Token-based rate limits apply per agent (run-token claims) and per integration client. |
| **Provider connections** *(implemented)* | Cloud providers (OpenAI, Anthropic, Azure, Gemini, Bedrock, …) and on-prem engines (vLLM, Ollama, TGI, NIM, any OpenAI-compatible URL) are backends. Credentials are Kubernetes Secrets referenced by the backend; they never leave the gateway. |
| **MCP gateway** *(target design, not implemented)* | Every connector from the Connectors screen would be published by agentgateway as an MCP endpoint. Remote MCP servers would be proxied with MCP authorization (OAuth). REST/OpenAPI systems would be exposed as MCP tools by the gateway. Stdio servers run in connector pods (§6.4); today they and every other connector are reached directly by the harness through `services/connectors`, not through agentgateway. |
| **Defence in depth for tools** | Tool tiers, approvals, agent trust and project policy stay in the **harness**: they need run context and human decisions. Today that is the only layer: with the MCP gateway not implemented, agentgateway adds no identity check, allowed-agent rule, rate limit or trace to a tool call. Once built, agentgateway would add identity checks (run-token JWT), per-connector allowed-agent rules (CEL policies), rate limits and OTel tracing, so a compromised harness still could not reach tools an agent is not allowed. |
| **A2A gateway** *(target design, not implemented)* | Remote A2A agents registered as tools would be reached through the gateway. AWP agents published over A2A would be exposed through it. |
| **Platform MCP for integration clients** *(target design, not implemented)* | The Integrations screen's "Expose platform as MCP server" would publish the platform MCP server through agentgateway, with per-client authentication, tool allowlists and rate limits. Today the platform MCP server is called directly, gated by its own run-token/client-key verification instead. |
| **Observability** *(implemented, LLM spans only)* | agentgateway emits OpenTelemetry traces and metrics for LLM calls, including token usage, to Phoenix (OTLP, OpenInference conventions) and the metrics stack. The harness propagates `traceparent`, so gateway spans appear inside each run's trace. No MCP or A2A spans exist yet, since no MCP or A2A traffic passes through it. |

**Configuration management.**
- The web app renders agentgateway resources from Models & routes only: `AgentgatewayModel` Gateway API routes. Connectors and Integrations do not yet render anything to agentgateway (see the implementation status above); connector config instead drives `services/connectors` directly.
- It applies them through a narrow-scoped Kubernetes service account. Changes take effect without restarting the agent service.
- In kind, the same resources are rendered from `values-local.yaml` and applied by `make deploy`.

**Estimated cost.** The harness records token usage per call from the gateway's response metadata and computes the estimated cost from the price catalog in the `awp` database, which the Models screen maintains. Gateway cost metrics are used for reconciliation only.

**Items to verify before adoption** (SD-7)
1. Which features used here are in the open-source project and which are only in a vendor enterprise edition:
   - model failover with priority groups;
   - per-key budgets;
   - the management UI.
2. Support for the **voice** route kinds:
   - speech-to-text and text-to-speech endpoints;
   - realtime speech-to-speech over WebSocket.

   If they are not supported, the voice path uses an HTTP passthrough route on agentgateway, with the same auth, rate limits and tracing.
3. Structured-output (`response_format`) passthrough for **typesafe** routes, for each provider in use.

### 6.2 Temporal

| Aspect | Specification |
| --- | --- |
| Deployment | Official Temporal Helm chart; SQL persistence and visibility in databases `temporal` and `temporal_visibility` on the AWP PostgreSQL cluster; Elasticsearch disabled |
| Namespace / queues | Namespace `awp`; task queues `agent-runs`, `ingestion`, `setup`, `maintenance` |
| Schedules | Scheduled work items map 1:1 to Temporal Schedules |
| UI | Temporal UI on an admin host (Traefik IP allowlist) with Temporal UI's built-in OIDC login |

### 6.3 Arize Phoenix (LLM observability and evaluation)

| Aspect | Specification |
| --- | --- |
| Deployment | Phoenix Helm chart: **one Deployment** (UI, OTLP collector, evaluations). No other services. |
| Storage | PostgreSQL database `phoenix` on the AWP cluster (`PHOENIX_SQL_DATABASE_URL`) |
| Ingestion | OTLP (HTTP/gRPC) from the harness and agentgateway, using OpenInference semantic conventions; trace ID = run ID |
| Features used | Trace view behind "Open trace"; LLM-as-judge and code evaluators; datasets and experiments for agent, skill and storyline evaluation suites and publish gates; prompt management (versions, tags, playground) for harness prompts |
| Retention | Trace retention policy (default 60 days, configurable) to keep the `phoenix` database small; datasets, experiments and prompts are kept |
| Access | Admin host on Traefik (IP allowlist middleware); Phoenix's own authentication with the organisation's OIDC provider where supported, otherwise Phoenix users; API keys for the harness and CI |
| Licence | Confirm the Phoenix licence (believed to be Elastic License 2.0) is acceptable for internal self-hosting |

### 6.4 Sandboxes and stdio connector pods

No separate sandbox or connector services are deployed. Both are plain Pods in the `awp-sandbox` namespace, created by components that already exist.

| Item | Specification |
| --- | --- |
| **Sandbox pods** | Created and deleted by the **sandbox launcher** inside `agent-worker`, through the Kubernetes API, with a Role limited to Pods and PVCs in `awp-sandbox`. Curated images (`awp-sandbox-base`, `awp-sandbox-python-data`, `awp-sandbox-office`); read-only root; ephemeral or PVC-backed `/workspace`; CPU, memory and time limits; no service-account token. A small warm pool is kept by a Temporal schedule on the `maintenance` queue. |
| **Sandbox network** | **No network egress at all** (NetworkPolicy denies all egress except DNS). Files move in and out through the launcher (object storage ↔ `/workspace`). A skill or workbench task that needs an external system uses an MCP tool, called directly by the harness today rather than through agentgateway (§6.1) — never a direct network call from the sandbox either way. |
| **stdio connector pods** *(differs from current code)* | Confirmed against `infra/policies/network-policies.yaml`: no NetworkPolicy scoped to a per-connector bridge pod exists today, and nothing renders a generic `awp-mcp-stdio-bridge` Deployment. What actually runs a stdio connector is the Python `services/connectors` runtime's own control mode (`pods.py`), which builds the Deployment/Service directly via the Kubernetes client — not the web app, and not agentgateway. |

### 6.5 Knowledge and memory: Graphiti + pgvector

**Graphiti** is a temporal knowledge graph engine:
- it ingests **episodes** (text or JSON);
- it records facts with validity windows and invalidates contradicted facts instead of overwriting them;
- it retrieves with hybrid search (semantic embeddings, BM25 keyword search and graph traversal) with graph-distance re-ranking.

It runs on Neo4j and calls models through agentgateway's OpenAI-compatible API. **Passages** for Vector mode are stored with **pgvector** in the `awp_kb` database, so no separate vector database is needed.

| Use | Design |
| --- | --- |
| **Ingestion** (Temporal workflow) | Raw document in RGW → `docling` parsing and OCR → Arabic normalisation → Presidio PII masking → chunking per collection settings → (1) passage row + embedding in `awp_kb` → (2) the same chunk becomes a Graphiti **episode** in group `kc_<collectionId>`, with the document and chunk ID as source. Idempotent per chunk. |
| **Passage index** (`awp_kb`) | Table `passage(collection_id, doc_id, chunk_id, text, embedding vector(n) or halfvec(n), metadata jsonb)`. One **partial HNSW index per collection**, built from that collection's settings: distance metric → operator class (cosine / L2 / inner product); HNSW `m` / `ef_construction` → index parameters; quantisation → `halfvec` or binary-quantised expression index. Full-text column for keyword search. |
| **Retrieval modes** | **Vector:** pgvector top-k over the collection's partial index. **Graph:** Graphiti hybrid search over the collection's group (entities and facts). **Hybrid:** both, merged; passages and graph facts shown separately, with citations to chunk and document. |
| **Configuration mapping** | Embedding route → both pgvector and Graphiti embeddings (same alias and dimensions; changing it re-indexes). Entity-extraction route → Graphiti LLM client (structured-output alias). Re-ranker → cross-encoder or graph-distance re-ranking. Top-k and minimum score → search settings. |
| **Memory recall** | Memory files remain the source of truth (`awp` + RGW). Approved memory entries become Graphiti episodes in per-scope groups (`mem_org`, `mem_unit_<id>`, `mem_agent_<id>`, `mem_session_<id>`), so superseded rules are invalidated rather than recalled. Rejected or deleted memories are removed. |
| **Isolation** | The harness passes only the collections and memory groups the agent is allowed to use. |
| **Rebuild** | `awp_kb` and Neo4j are both rebuildable from `awp` and RGW. |
| **Cost** | Graphiti calls an LLM per episode. Ingestion concurrency and the extraction alias are budgeted per collection, and the cost is shown as an estimate on the collection. |

---

## 7. Data stores

### 7.1 PostgreSQL (one CloudNativePG cluster)

| Aspect | Specification |
| --- | --- |
| Version / operator | PostgreSQL 17 minimum, **18 recommended**; CloudNativePG |
| Cluster | `awp-pg`. Instances: local 1 · Test 2 · Live 3 (synchronous replication) |
| Databases and owners | `awp` — domain, system of record (role `awp_app`, web only) · `awp_kb` — passage vectors (role `awp_kb`, agent service only) · `temporal`, `temporal_visibility` (Temporal) · `phoenix` (Phoenix). Each component has its own role and can reach only its database. |
| Extensions | `awp`: `pgcrypto`, `pg_trgm`, `unaccent`, `btree_gin`, `pg_stat_statements` · `awp_kb`: `vector`, `pg_trgm` |
| Read path | Dashboards, drill-downs, budget charts and exports use the `-ro` replica service |
| Domain features | `jsonb` + GIN for dynamic attributes; stored generated columns for promoted attributes; `tsvector` + `pg_trgm` + `unaccent` + Arabic normalisation for search; ICU collations; `numeric(18,4)`; `timestamptz`; `uuid`; partitioning for messages, audit and run steps |
| Concurrency | Integer `version` column (ETag/If-Match) |
| Encryption | TLS (`sslmode=verify-full`); envelope encryption for sensitive attributes and secret references; volume encryption is a prerequisite (§3.3) |
| Audit | `audit` schema: INSERT/SELECT only, guard trigger, monthly partitions |
| Backups | CNPG barman-cloud to the RGW bucket `pg-backups`: WAL archiving, scheduled base backups, point-in-time recovery; restore tested quarterly |
| Pooling | CNPG `Pooler` (PgBouncer, transaction mode) for the web app |
| Retention | Phoenix traces 60 days (configurable); run-step and message partitions per retention policy |
| Split rule | If trace or vector load affects domain latency, `phoenix` and `awp_kb` can be moved to a second cluster without code changes (connection strings only) |

### 7.2 Other stores

| Store | Configuration |
| --- | --- |
| Neo4j 5.26+ Community | Graphiti graph (entities, facts with validity windows, episodes, communities), partitioned by `group_id`; Graphiti-managed indexes; scheduled dumps to RGW (rebuildable anyway) |
| Valkey 8 | Channels `room:<id>`, `inbox:<person>`, `dash:*`; Streams `run:<id>:agui` for AG-UI event replay; rate-limit buckets; locks; caches. RDB snapshots (the data is reconstructible). |

### 7.3 Object storage — Rook (Ceph RGW)

| Aspect | Specification |
| --- | --- |
| Operator and store | Rook operator (`rook-ceph` chart) and cluster (`rook-ceph-cluster` chart); `CephObjectStore` `awp-store` starts the RGW with the S3 API |
| Buckets | ObjectBucketClaims: `raw-docs`, `files`, `artifacts`, `attachments`, `skills`, `memory`, `run-payloads`, `branding`, `pg-backups`, `neo4j-dumps`. Each claim yields a ConfigMap and Secret mounted only into the workloads that need that bucket. |
| Versioning | On `files`, `artifacts` and `memory` (set by the `object-buckets` Job) |
| Access | S3 API only (AWS SDK v3, `boto3`), path-style addressing |
| Live | ≥ 3 storage nodes with raw disks; 3× replication, or erasure coding when there are ≥ 6 OSD hosts |
| kind | Single-node test cluster: 1 mon, 1 mgr, 1 OSD on a loop device, pool size 1, one RGW. Linux hosts; on macOS and Windows run kind in a Linux VM or use `--no-rook` with a shared dev RGW. |
| Console | Ceph Dashboard on an admin host (Traefik IP allowlist) with its own login |

---

## 8. Orchestration and workload topology (Kubernetes; kind for local development)

### 8.1 Clusters

| Environment | Cluster | Notes |
| --- | --- | --- |
| Local dev | **kind** | Control plane plus workers `app` and `storage`; local registry; `make` targets |
| Test | Conformant Kubernetes | Same charts, `values-test.yaml` |
| Live | Conformant Kubernetes | Same charts, `values-live.yaml` |

### 8.2 kind cluster (local)

```yaml
# infra/kind/kind-config.yaml
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: awp
nodes:
  - role: control-plane
    extraPortMappings:                    # Traefik NodePorts → host 80/443
      - { containerPort: 30080, hostPort: 80, protocol: TCP }
      - { containerPort: 30443, hostPort: 443, protocol: TCP }
  - role: worker
    labels: { awp/pool: app }
  - role: worker
    labels: { awp/pool: storage }
    extraMounts:                          # loop device for the single Ceph OSD (Linux hosts)
      - { hostPath: /dev/loop-awp-osd, containerPath: /dev/loop-awp-osd }
containerdConfigPatches:
  - |-
    [plugins."io.containerd.grpc.v1.cri".registry]
      config_path = "/etc/containerd/certs.d"   # local registry localhost:5001
```

kind's default network plugin enforces NetworkPolicy, so no extra CNI is installed.

**Bootstrap** (`make kind-up`, idempotent):

1. Start the local registry `localhost:5001`, create the OSD loop device, and create the cluster.
2. Install the Gateway API CRDs and **Traefik** (Kubernetes Gateway provider, NodePorts 30080/30443). Create the `*.awp.localtest.me` TLS Secret with `mkcert`.
3. Install the **CloudNativePG** and **Rook** operators. Create the `awp-pg` cluster, the test `CephCluster`, the `CephObjectStore` and the bucket StorageClass.
4. Install **agentgateway** (GatewayClass `agentgateway`).
5. Create the namespaces, and Secrets from `.env`.
6. Install the remaining platform charts with Helm in dependency order (Temporal, Phoenix, Neo4j, Valkey), waiting for each to be ready (`helm upgrade --install --wait`).

Then `make deploy` builds the AWP images, pushes them to `localhost:5001` and installs `charts/awp` with `values-local.yaml`.

**Local hosts:**

| Host | Purpose |
| --- | --- |
| `awp.localtest.me` | Console and widget |
| `temporal.awp.localtest.me` | Temporal UI |
| `phoenix.awp.localtest.me` | Phoenix |
| `aigateway.awp.localtest.me` | agentgateway's UI, and its model API under `/v1` |
| `ceph.awp.localtest.me` | Ceph Dashboard |
| `s3.awp.localtest.me` | RGW S3 endpoint for local tools |

### 8.3 Namespaces

| Namespace | Workloads |
| --- | --- |
| `awp-system` | Traefik, CloudNativePG operator |
| `rook-ceph` | Rook operator, Ceph daemons, RGW |
| `awp-data` | PostgreSQL `awp-pg` + pooler, Neo4j, Valkey |
| `awp-ai` | agentgateway, Temporal, Phoenix |
| `awp-app` | web, agent-service, agent-worker, agent-worker-ingest, Jobs |
| `awp-sandbox` | Sandbox pods, stdio connector pods |

### 8.4 Workloads

| Workload | Kind | Source | Notes |
| --- | --- | --- | --- |
| `web` | Deployment (+ HPA) | `charts/awp` | Console, domain API, CopilotKit runtime, platform MCP, channel gateway; renders agentgateway `AgentgatewayModel` routes (connector pods are rendered by `services/connectors`, not `web` — §6.1) |
| `agent-service` | Deployment | `charts/awp` | AG-UI endpoints; reachable only from `web` |
| `agent-worker` | Deployment | `charts/awp` | Runs, schedules, setup, sandbox launcher |
| `agent-worker-ingest` | Deployment | `charts/awp` | Knowledge ingestion (Graphiti + pgvector) |
| `db-migrate` | Job (Helm hook) | `charts/awp` | drizzle-kit migrations on `awp` |
| `object-buckets` | Job (Helm hook) + ObjectBucketClaims | `charts/awp` | Buckets, versioning, lifecycle |
| agentgateway | Controller + internal Gateway | agentgateway chart | ClusterIP; the data plane's admin port is published through Traefik as an admin host (§8.6) |
| Temporal | Deployments + schema Job | Temporal chart | Databases on `awp-pg` |
| Phoenix | Deployment | Phoenix chart | Database `phoenix` on `awp-pg` |
| PostgreSQL `awp-pg` | CNPG `Cluster` + `Pooler` | CNPG | Five databases (§7.1) |
| Neo4j | StatefulSet | Neo4j chart | Graphiti backend |
| Valkey | StatefulSet | Valkey chart | |
| Rook / Ceph | Operator + `CephCluster` + `CephObjectStore` | Rook charts | |
| Traefik | Deployment | Traefik chart | The only externally exposed workload |

Images are pinned by digest and mirrored to the organisation registry (and to `localhost:5001` for kind).

### 8.5 Start-up ordering

- Readiness probes on every workload.
- Init containers wait for dependencies (e.g. `agent-service` waits for the Temporal frontend and the agentgateway LLM route).
- Helm hook Jobs: `db-migrate`, `object-buckets`, the Temporal schema Job. Phoenix migrates its own schema on start.
- Locally, `make kind-up` installs charts in order with `helm --wait`. In Test and Live, the organisation's CD applies the same charts in order: operators → data → AI → app.

### 8.6 Networking

| Concern | Implementation |
| --- | --- |
| North–south | **Traefik Proxy** as the Gateway API implementation (GatewayClass `traefik`). `HTTPRoute`s: the console/widget host → `web`, including `/api/copilotkit/*` with streaming timeouts; webhook paths → `web`; admin hosts → Temporal UI, Phoenix, Ceph Dashboard, the AI gateway. |
| Admin hosts | Traefik IP-allowlist middleware plus each tool's own login: Temporal UI OIDC, Phoenix authentication, Ceph Dashboard users. The AI gateway has no login of its own, so the allowlist is its only control, and the route publishes neither `/quitquitquit` nor the pprof endpoints. |
| Public edge policies | Traefik middlewares: security headers, rate limits on widget and webhook routes, request size limits |
| AI traffic | **agentgateway** internal Gateway (GatewayClass `agentgateway`), listening for both LLM and MCP routes. Only the LLM listener actually carries traffic today (`AgentgatewayModel` routes); the MCP listener accepts `HTTPRoute`/`AgentgatewayBackend` but nothing renders one, so it is provisioned and empty (§6.1). Neither listener is exposed outside the cluster; only Traefik's Gateway is. What `aigateway.awp.localtest.me` publishes is the data plane's admin interface on 15000, which serves agentgateway's UI at `/ui`, with `/v1` sent on to the LLM listener so the model API answers on the same host. `adminAddr` binds to loopback by default, so it is set to `0.0.0.0:15000` through the `AgentgatewayParameters` in `infra/gateway/gateway.yaml`. |
| NetworkPolicy | Default deny per namespace. Allows: `web` → `agent-service`, `awp-pg` (pooler), Valkey, RGW, Temporal; `agent-*` → agentgateway, `awp-pg`, Neo4j, Valkey, RGW, Temporal, Phoenix; agentgateway → Phoenix (OTLP), providers (unrestricted egress), and `web`'s platform MCP port — confirmed against `infra/policies/network-policies.yaml`'s `agentgateway-egress` rule. There is **no** rule letting agentgateway reach `awp-sandbox`, so it cannot reach connector pods regardless of application code; `awp-sandbox` sandbox pods → **nothing** (DNS only, plus the egress proxy); connector pods → declared hosts only. |
| Streaming | Raised timeouts and no response buffering on SSE and AG-UI paths (Traefik and agentgateway) |

### 8.7 Developer inner loop (`make`)

Platform services always run in kind. Application code runs in one of two ways.

| Mode | How | When |
| --- | --- | --- |
| **In-cluster** | `make deploy`: build images → push to `localhost:5001` → `helm upgrade --install charts/awp -f values-local.yaml`. `make deploy-web` / `make deploy-agent` rebuild and roll out one component. | Integration checks, channel and widget testing, CI parity |
| **Host mode** (fast edits) | `make dev-forward` opens `kubectl port-forward` to PostgreSQL, Temporal, Valkey, Neo4j, agentgateway, Phoenix and RGW. Then `pnpm --filter web dev` and `uv run` for the agent service and workers on the host, with `.env.local`. | Day-to-day coding with hot reload (Next.js dev server, Uvicorn reload) |

| `make` target | Purpose |
| --- | --- |
| `kind-up` / `kind-down` / `kind-reset` | Create, delete or recreate the cluster and platform services (`PROFILE=full` or `core`; `NO_ROOK=1` uses a shared dev RGW) |
| `deploy`, `deploy-web`, `deploy-agent` | Build, push and install the AWP workloads |
| `dev-forward` | Port-forwards for host mode |
| `seed` | Sample data and a sample knowledge collection |
| `logs SERVICE=…` | Tail logs of a workload |
| `test-e2e` | Playwright suite against the local cluster |

**Profiles.** `full` installs everything. `core` skips Phoenix and Neo4j/Graphiti: Knowledge runs in Vector mode, and traces are visible only in the console run timeline.

**Local resources** allocated to Docker:

| Profile | CPU | Memory | Disk |
| --- | --- | --- | --- |
| full | 8 vCPU | 22 GB | 70 GB, including a 20 GB sparse loop file |
| core | 4 vCPU | 12 GB | 35 GB |

---

## 9. Configuration and secrets

| Group | Variables (illustrative) | Consumer |
| --- | --- | --- |
| Web | `APP_URL`, `AUTH_SECRET`, `AUTH_OIDC_*`, `WEBAUTHN_RP_ID` | web |
| Domain database | `DATABASE_URL` (pooler, `sslmode=verify-full`), `DATABASE_RO_URL`, `DATABASE_MIGRATE_URL` | web, db-migrate |
| Knowledge database | `KB_DATABASE_URL` (role `awp_kb`) | agent-* |
| Agent service | `AGENT_SERVICE_URL` (cluster-internal), `RUN_TOKEN_SIGNING_KEY` | web, agent-* |
| CopilotKit | `COPILOTKIT_DEV_INSPECTOR=true` in kind and Test only | web |
| Temporal | `TEMPORAL_ADDRESS`, `TEMPORAL_NAMESPACE=awp` | web, agent-* |
| agentgateway | `AGW_LLM_URL`, `AGW_MCP_BASE_URL`; provider credentials only as Secrets referenced by agentgateway backends | agent-*, agentgateway |
| Phoenix | `PHOENIX_SQL_DATABASE_URL`, `PHOENIX_ENABLE_AUTH`, `PHOENIX_SECRET`, `PHOENIX_API_KEY`, `OTEL_EXPORTER_OTLP_ENDPOINT` | phoenix, agent-*, agentgateway |
| Object storage | Per bucket from the ObjectBucketClaim ConfigMap/Secret (`BUCKET_HOST`, `BUCKET_NAME`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`); `S3_FORCE_PATH_STYLE=true` | web, agent-*, CNPG |
| Valkey / Neo4j | `VALKEY_URL`, `NEO4J_URI`, `NEO4J_AUTH` | web, agent-* |
| Channels | WhatsApp and Teams credentials entered in the console, stored encrypted | web |

Secrets are Kubernetes Secrets. Locally they are created from `.env`. In Test and Live they come from the organisation's secret store (prerequisite). No secret is committed to git.

---

## 10. Security

| Concern | Control |
| --- | --- |
| Human identity | OIDC SSO (Auth.js), passkeys, server-side sessions in PostgreSQL |
| Agent identity | Per-run JWT minted by `web`, validated by the platform MCP server. The harness's own call to agentgateway for model traffic carries a static per-process token (`AWP_RUN_TOKEN`), not this per-run JWT — agentgateway does not validate it today; per-run JWT validation at the gateway is the target design (§6.1), not current behaviour. |
| Browser ↔ agents | Only through the CopilotKit runtime in `web` |
| Tools | Harness: tiers, approvals, trust, project policy. agentgateway adds none of this today — see the implementation status in §6.1; identity checks, per-connector allowed agents (CEL), rate limits and tracing at the gateway are the target design. |
| Integration clients | API keys; platform MCP exposure called directly today, not yet through agentgateway (§6.1); AG-UI exposure through the CopilotKit runtime; CORS allowlists |
| Edge | Traefik: TLS, headers, rate limits; admin hosts IP-allowlisted with native logins |
| Database | Separate role per database; TLS; envelope encryption for sensitive fields; append-only audit schema |
| Code execution | Sandbox pods without network egress or service-account tokens |
| Content safety | Presidio PII hooks; prompt-injection screening of tool results and documents; output guardrails |
| Supply chain | Lock files, digest-pinned images, skill-package scanning (image scanning and SBOM are CI prerequisites) |

---

## 11. Observability

| Signal | Tooling |
| --- | --- |
| LLM, MCP and run traces | OpenTelemetry (OpenInference conventions) from the harness → **Phoenix**; agentgateway additionally emits its own LLM-call spans (MCP traffic does not pass through it today, so it contributes no MCP spans — §6.1) |
| Evaluations | Phoenix datasets, experiments and evaluators; publish gates read the results |
| Workflow history | Temporal UI |
| Logs | Structured JSON to stdout; the Logs screen queries the cluster log store (prerequisite), or the Kubernetes API locally |
| Health | Readiness/liveness probes; `/healthz` aggregated on the System page; `/metrics` exposed for the platform's scraper |

---

## 12. Repository and build

```
tahseel-awp/
  apps/web/                     # Next.js full stack
  services/agent/               # agent service, workers, sandbox launcher, Graphiti + pgvector
  images/sandbox/               # sandbox images
  images/mcp-stdio-bridge/      # generic stdio MCP connector image
  packages/design-system/       # Tahseel DS
  packages/contracts/           # JSON Schemas: attributes, AG-UI custom events, platform MCP tools
  packages/skills-bundled/      # bundled Agent Skills incl. Setup Director skills
  infra/
    kind/                       # kind-config.yaml, bootstrap.sh, loop-device helper, mkcert
    charts/awp/                 # web, agent-service, agent-worker(s), jobs, OBCs, NetworkPolicies
    charts/values/              # values-local / values-test / values-live
    platform/                   # values for Traefik, CNPG (+ awp-pg), Rook (+ cluster, store),
                                # agentgateway, Temporal, Phoenix, Neo4j, Valkey
    gateway/                    # Traefik Gateway, HTTPRoutes, middlewares; agentgateway Gateway
    agentgateway/               # templates for LLM/MCP/A2A routes, backends, policies
    postgres/                   # databases, roles, extensions, audit schema
  docs/  scripts/  Makefile  .env.example  versions.lock.md
```

| Concern | Tool |
| --- | --- |
| Packages | pnpm workspaces; uv |
| Build | Docker Buildx (multi-stage, non-root, pinned digests) |
| Local orchestration | kind, kubectl, Helm, `make` |
| Quality | ESLint, Prettier, oxlint (DS adherence), TypeScript strict; ruff, mypy |
| Tests | Vitest, Playwright (incl. CopilotKit surfaces); pytest and the Temporal test environment; contract tests for MCP, AG-UI, Agent Skills, agentgateway routes and S3; chaos test for an agent restart mid-run |
| Evaluations | Phoenix datasets and experiments in CI |
| CI | lint → typecheck → unit → integration on an ephemeral kind cluster → e2e → evals → build → publish |

---

## 13. Sizing

**Reference Live capacity** (about 300 concurrent agent runs, 2,000 concurrent room users), total across nodes:
- 20 vCPU and 80 GB RAM for application, AI and data workloads.
- Storage nodes for Ceph with raw SSD/NVMe.
- GPU only when hosting models, on a separate pool behind agentgateway.

**Scaling**
- HPAs on `web` and `agent-service`.
- `agent-worker` replicas scale with Temporal queue backlog.
- agentgateway proxies scale horizontally.
- PostgreSQL scales reads with CNPG replicas, and can be split by database (§7.1).
- Ceph adds OSD nodes.

---

## 14. Version and upgrade policy

| Rule | Detail |
| --- | --- |
| Pinning | Image digests in Helm values; lock files; `versions.lock.md` |
| CopilotKit | `@copilotkit/react-core`, `@copilotkit/runtime` and `@ag-ui/client` upgraded together |
| Pydantic AI | Track the latest v2 minor; CI fails on deprecation warnings; plan major upgrades within the three-month window between majors |
| Freshness | Adopt versions after at least 2 weeks public, plus changelog and security review |
| Cadence | Monthly patches; quarterly minors; majors planned |
| Gateways | agentgateway, Traefik and Gateway API CRDs upgraded together with smoke tests |
| Storage | Rook and Ceph along Rook's supported upgrade path, one minor at a time |
| Harness, standards, database | Replay plus evaluations for the harness; conformance tests for MCP, AG-UI and Agent Skills; expand/migrate/contract migrations through `db-migrate` |

---

## 15. Stack-to-screen map

| Screen group | Main components |
| --- | --- |
| Shell, profile, sign-in | Next.js, Tahseel DS, Auth.js, next-intl, CopilotKit sidebar |
| Dashboard, records, inbox | PostgreSQL replicas, Valkey SSE, Temporal signals |
| Projects, work items, requests, schedules | PostgreSQL `jsonb`, Ajv, Temporal schedules |
| Discussion rooms | CopilotKit runtime + `HttpAgent` → AG-UI, Valkey streams, harness |
| Artifacts, files | Rook RGW (S3), PostgreSQL metadata |
| Agents, run viewer | Harness, Temporal, Phoenix |
| Skills | Agent Skills loader, RGW, sandbox pods |
| Connectors | `services/connectors` runtime, stdio connector pods (agentgateway's MCP gateway is the target design, not yet implemented — §6.1) |
| Memory | Memory tool, PostgreSQL versions, RGW content, Graphiti memory groups |
| Knowledge | Graphiti (Neo4j) + pgvector (`awp_kb`), docling, Presidio |
| Models & routes | agentgateway LLM routes, backends, policies |
| Channels, embedded deployment, widget | Channel gateway, CopilotKit popup, Traefik public routes |
| Setup Director | Harness `setup` profile, platform MCP setup tools, Temporal |
| Budgets | Harness token metering + price catalog → PostgreSQL |
| Integrations | Platform MCP server called directly (agentgateway exposure is the target design, not yet implemented — §6.1), CopilotKit runtime (AG-UI exposure) |
| System | Health of web, agent service, Temporal, agentgateway, Phoenix, PostgreSQL, Neo4j, Valkey, Ceph |

---

## 16. Open stack decisions

| # | Decision | Options | Recommendation |
| --- | --- | --- | --- |
| SD-1 | PostgreSQL data access | Drizzle · Prisma · Kysely | Drizzle |
| SD-2 | PostgreSQL version | 17 · 18 | 18, after compatibility checks with Temporal, Phoenix and pgvector |
| SD-3 | Secrets encryption key | App KEK · organisation KMS/Vault | Organisation KMS where available |
| SD-4 | Document parser | docling · unstructured | docling, after verifying Arabic output |
| SD-5 | Teams integration | In Next.js · separate bot service | In Next.js |
| SD-6 | Allowed model providers and regions | Organisation policy | Decide before the first Live install |
| SD-7 | agentgateway feature coverage | Open-source only · vendor edition | Verify failover priority groups, budgets, voice/realtime and structured-output passthrough (§6.1) |
| SD-8 | Passage retrieval | pgvector · Graphiti episode search only | pgvector (maps the Knowledge screen's index settings per collection) |
| SD-9 | Graphiti graph backend | Neo4j · FalkorDB | Neo4j |
| SD-10 | CopilotKit API surface | v2 entry points only | v2 entry points (`/v2` imports) |
| SD-11 | Phoenix trace retention | 30 · 60 · 90 days | 60 days; datasets, experiments and prompts are kept |
| SD-12 | Phoenix licence | Elastic License 2.0 (to confirm) | Confirm acceptable for internal self-hosting |
| SD-13 | Pydantic AI Harness capabilities | Not used · adopt selected (e.g. code mode on Monty for light calculations instead of a sandbox pod) | Not used in v1 of AWP; evaluate code mode and context management per capability |

---
*End of stack specification.*
