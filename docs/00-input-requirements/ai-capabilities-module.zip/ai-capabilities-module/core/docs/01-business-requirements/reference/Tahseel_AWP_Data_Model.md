# Tahseel AWP — Logical Data Model

| Item | Value |
| --- | --- |
| Version | 1.2 |
| Date | 11 Oct 2026 |
| Companion to | `Tahseel_AWP_Specification.md` v3.3 and `Tahseel_AWP_Stack_Specification.md` v1.2 |
| Scope | Entities needed by the screens in the handoff prototype (`AWP Console.html`) |
| System of record | PostgreSQL — CloudNativePG cluster `awp-pg`, database `awp` (single organisation per installation) |
| Level | Logical: entities, key attributes, relationships and enumerations. Physical details (indexes, partitions, exact column types, DDL) are left to implementation. |

---

## 1. Conventions

| Convention | Rule |
| --- | --- |
| Identifier | Every entity has `Id` (UUID; UUIDv7 recommended for index locality). |
| Code / key | Human-facing codes (`Key`, `Code`, `Alias`, `ClientId`, `SkillName`, `CollectionId`) are unique, suggested from the name and editable before first save. Work and request keys follow `<PROJECT or TYPE PREFIX>-<number>` (e.g. `TSK-2325`, `EXP-4471`, `SES-1042`, `CS-119`). |
| Bilingual names | User-named records carry `NameEn` and `NameAr`; descriptions likewise where shown in both languages. |
| Audit columns | `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`, `Version` (integer, optimistic concurrency) on every mutable entity. |
| Principals | Actors and assignees can be a **Person**, an **Agent**, a **Group/Role** or an **External contact**. Modelled as a pair `PrincipalType` + `PrincipalId`. |
| Versioning | Definitions that are published (agents, request types, storylines, skills, memories, blueprint) have a parent entity plus immutable `…Version` rows. Running items reference the version they started with. |
| Dynamic attributes | Requests and work items store type-specific values in `AttributesJson`, validated against the attribute definitions of their request type version. |
| Money | Estimated costs and budgets in AED (`numeric(18,4)`), always flagged as estimates in the UI. |
| Soft state | Records that can be deactivated have `IsActive` / `Status`; deletes of project content keep audit records. |
| Secrets | Never stored in plain text; entities hold a `SecretRef` to encrypted storage; values are write-only. |
| Time | UTC timestamps; working calendar and time zone from Organisation settings for SLA and schedules. |


### 1.1 PostgreSQL mapping (guidance for implementation)

| Logical type / rule | PostgreSQL implementation |
| --- | --- |
| Id | `uuid` primary key (`uuidv7()` on PostgreSQL 18, otherwise app-generated UUIDv7) |
| Text, bilingual names | `text` with length checks where the UI limits length; ICU collation for sorting |
| Search keys (names, titles) | Generated normalised column (`unaccent` + Arabic normalisation) with `pg_trgm` GIN index; `tsvector` generated column for full-text |
| Enumerations | `text` + `CHECK` constraint (or a lookup table where admins can extend the list); avoid native `enum` types for lists that change |
| Money (estimated) | `numeric(18,4)` |
| Timestamps | `timestamptz` (UTC) |
| `AttributesJson` and `…Json` / `…Config` fields | `jsonb` with `CHECK (jsonb_typeof(...) = 'object')`; validated against the JSON Schema of the request type version in the app; GIN `jsonb_path_ops` index on `attributes` |
| Promoted attributes (filterable or sortable) | `GENERATED ALWAYS AS ((attributes->>'key')::type) STORED` column + B-tree index, created by schema-registry migrations |
| Lists of values (e.g. channels, tags) | `text[]` with a GIN index, or a child table when rows need their own attributes |
| Optimistic concurrency | `version integer NOT NULL DEFAULT 1`, incremented on every update |
| Secrets and sensitive attributes | `bytea` ciphertext (envelope encryption in the app); never plain text |
| Append-only tables (`AuditEntry`, `RequestEvent`, `WorkItemActivity`, `RoomMessage`) | Monthly range partitions; `audit` schema without UPDATE/DELETE grants and with a guard trigger |
| Polymorphic principal (`PrincipalType` + `PrincipalId`) | `text` + `uuid` columns with a `CHECK` on the type; integrity enforced in the domain layer |
| Schemas | `core` (organisation, identity), `work` (projects, rooms, requests, work items, schedules, files), `ai` (agents, runs, skills, connectors, memory, knowledge, models, channels, deployments), `gov` (setup, budgets, settings, integrations), `audit` |

---

## 2. Domain map

```mermaid
flowchart LR
  ORG[Organisation & identity] --> PRJ[Projects]
  PRJ --> ROOM[Discussion rooms]
  PRJ --> REQ[Requests]
  PRJ --> WI[Work items]
  PRJ --> SCH[Scheduled work items]
  PRJ --> AF[Artifacts & files]
  REQ --> WI
  AG[Agents & runs] --> WI
  AG --> ROOM
  AG --> REQ
  CAP[Skills · Connectors · Memory · Knowledge · Models] --> AG
  ENG[Channels · Deployments · Storylines] --> AG
  GOV[Setup · Budgets · Audit · Settings · Integrations] --> AG
  HIL[Inbox: approvals & questions] --> AG
```

---

## 3. Organisation and identity

```mermaid
erDiagram
  ORGANISATION ||--o{ ORG_UNIT : has
  ORG_UNIT ||--o{ ORG_UNIT : parent_of
  ORG_UNIT ||--o{ PERSON : contains
  ORG_UNIT ||--o{ AGENT : contains
  PERSON ||--o{ ROLE_ASSIGNMENT : has
  ROLE ||--o{ ROLE_ASSIGNMENT : granted_by
  ROLE ||--o{ ROLE_PERMISSION : includes
  PERMISSION ||--o{ ROLE_PERMISSION : in
  PERSON ||--o{ PASSKEY : registers
  PERSON ||--|| NOTIFICATION_PREFERENCE : has
  PERSON ||--o{ PERSON : reports_to
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Organisation** | NameEn, NameAr, TimeZone, Languages, WorkingCalendarId, HolidayCalendarId | Exactly one row. |
| **OrgUnit** | Code, NameEn, NameAr, ParentOrgUnitId, LeadPersonId | Hierarchy for org chart and org units list. |
| **Person** | Email, NameEn, NameAr, Mobile, PreferredLanguage, PhotoRef, OrgUnitId, ReportsToType/Id, SignInMethod (SSO), Status (Invited, Active, Suspended) | Users of the console. |
| **Passkey** | PersonId, Label, CreatedAt, LastUsedAt | WebAuthn credentials (My profile → Security). |
| **NotificationPreference** | PersonId, Approvals, Mentions, SlaWarnings, DailyDigest | My profile toggles. |
| **Role** | Code, NameEn, NameAr, IsSystem | Platform Owner, Administrator, Agent Designer, Publisher, Work Lead, Member, Approver, Auditor, Guest (plus custom). |
| **Permission** | Code, Description | Catalog of permissions. |
| **RolePermission** | RoleId, PermissionId, Effect (Allow, Deny) | Explicit deny wins. |
| **RoleAssignment** | PersonId, RoleId, ScopeType (Organisation, OrgUnit, Project), ScopeId | Role membership and scope. |
| **Group** | Code, NameEn, NameAr, Members (Person/Agent) | Used as audiences and approvers (e.g. "Finance Approvers"). |
| **ExternalContact** | DisplayName, Channel, ChannelAddress, VerifiedLevel | Widget, WhatsApp or other senders who are not users. |
| **Calendar** | Name, WorkingDays, WorkingHours, Holidays[] (date, name) | Working calendar and UAE public holidays. |

---

## 4. Projects

```mermaid
erDiagram
  PROJECT ||--o{ PROJECT_MEMBER : has
  PROJECT ||--o{ PROJECT_ALLOWED_AGENT : allows
  PROJECT ||--o{ PROJECT_ALLOWED_CONNECTOR : allows
  PROJECT ||--o{ PROJECT_APPROVAL_RULE : requires
  PROJECT ||--o{ DECISION : records
  ORG_UNIT ||--o{ PROJECT : owns
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Project** | Key, NameEn, NameAr, Description, OwnerPersonId, OrgUnitId, Sensitivity (Public, Internal, Confidential, Restricted), Status (Backlog, Planned, InProgress, Paused, Done, Archived), RequireReviewerNotAuthor | Progress and counts are derived. |
| **ProjectMember** | ProjectId, PrincipalType (Person, Agent), PrincipalId, ProjectRole (Owner, Member, Agent) | |
| **ProjectAllowedAgent** | ProjectId, AgentId | Empty = all agents allowed by trust. |
| **ProjectAllowedConnector** | ProjectId, ConnectorId | |
| **ProjectApprovalRule** | ProjectId, ActionOrToolRef, ApproverType/Id, MinimumTier | "Human approval for" list; can only raise tiers. |
| **Decision** | ProjectId, Title, DecidedBy, DecidedAt, SourceType (Approval, ChangeSet, Room), SourceId | "Recent decisions". |

---

## 5. Discussion rooms

```mermaid
erDiagram
  PROJECT ||--o{ DISCUSSION_ROOM : contains
  DISCUSSION_ROOM ||--o{ ROOM_PARTICIPANT : has
  DISCUSSION_ROOM ||--o{ ROOM_MESSAGE : contains
  ROOM_MESSAGE ||--o{ MESSAGE_FEEDBACK : receives
  ROOM_MESSAGE }o--o| RUN : produced_by
  ROOM_MESSAGE }o--o| ARTIFACT : attaches
  ROOM_MESSAGE }o--o| APPROVAL : shows
  DISCUSSION_ROOM ||--o| CONTEXT_HANDOFF : keeps
  DISCUSSION_ROOM ||--o{ DISCUSSION_ROOM : forked_into
  DISCUSSION_ROOM }o--o{ WORK_ITEM : links
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **DiscussionRoom** | Key, ProjectId, TitleEn, TitleAr, Type (Chat, Review, War-room, Support, Automation), Source (Console, Teams, Widget, WhatsApp, Routine), Status (Active, Idle, Paused, Closed, Archived), TurnTaking (LeadAgent, MentionOnly, RoundRobin, Moderated, Autonomous), AgentHopLimit, CostCapAed, ForkedFromRoomId, MirrorChannelId, MirrorExternalRef | Message count, last activity and estimated cost are derived. |
| **RoomParticipant** | RoomId, PrincipalType, PrincipalId, RoomRole (Owner, Member, LeadAgent, MemberAgent, Observer), JoinedAt | |
| **RoomMessage** | RoomId, Seq, SenderType, SenderId, ContentJson (text, mentions, cards), RunId, ArtifactId, ApprovalId, CreatedAt | Card types: artifact, approval, work item. |
| **MessageFeedback** | MessageId, PersonId, Value (Helpful, NotHelpful), Comment | Feeds agent evaluation. |
| **ContextHandoff** | OwnerType (Room, WorkItem, Run), OwnerId, Goal, Decisions, OpenQuestions, NextStep, UpdatedAt | Also written at run end. |
| **RoomWorkItemLink** | RoomId, WorkItemId, MessageId | "Linked work items". |

---

## 6. Requests and request types

```mermaid
erDiagram
  REQUEST_TYPE ||--o{ REQUEST_TYPE_VERSION : versions
  REQUEST_TYPE_VERSION ||--o{ ATTRIBUTE_DEFINITION : defines
  REQUEST_TYPE_VERSION ||--o{ TRANSITION_STEP : has
  TRANSITION_STEP ||--o{ STEP_AUDIENCE : has
  TRANSITION_STEP ||--o{ ROUTING_RULE : leaves_by
  ROUTING_RULE }o--|| TRANSITION_STEP : goes_to
  PROJECT ||--o{ REQUEST : contains
  REQUEST }o--|| REQUEST_TYPE_VERSION : typed_by
  REQUEST ||--o{ REQUEST : parent_of
  REQUEST ||--o{ REQUEST_EVENT : history
  REQUEST ||--o{ ATTACHMENT : has
  REQUEST ||--o{ WORK_ITEM : produces
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **RequestType** | Code (e.g. EXP), NameEn, NameAr, Category, CurrentPublishedVersionId | List shows open count (derived). |
| **RequestTypeVersion** | RequestTypeId, Version, Status (Draft, Published, Retired), DefaultProjectId, Decomposition (None, Template, Agent, Hybrid), SlaValue, SlaUnit (Hours, BusinessDays), IntakeChannels (Console, Teams, Email, Widget, WhatsApp, API), EntryModes (TemplateForm, AgenticInteractive), PublishedAt, PublishedBy | Requests pin the version. |
| **AttributeDefinition** | RequestTypeVersionId, Key, LabelEn, LabelAr, DataType (Text, LongText, Number, Money, Date, DateTime, Enum, Boolean, Person, File, Table), Required, EnumValues, Validation, Order | Compiled to a JSON Schema per version; also used for work item attributes. |
| **TransitionStep** | RequestTypeVersionId, Order, NameEn, NameAr, SlaValue, SlaUnit, IsTerminal, TerminalOutcome (Completed, Rejected) | e.g. Submitted, Agent review, Finance approval, Payment, Closed. `TerminalOutcome` only applies to a terminal step, and defaults to Completed; a designer flips a rejecting step's own outcome from its screen. |
| **StepAudience** | StepId, PrincipalType (Person, Role, Group, Agent, Requester), PrincipalId, Access (CanAct, NotifyOnly, ViewOnly), Sequence (for sequential approval) | Terminal steps have none. |
| **RoutingRule** | FromStepId, Order, Kind (Condition, Action), Expression (e.g. `amount_aed >= 5000`) or ActionName (Submit, Return, Approve, Reject, Paid), ToStepId | "Routing rules to next steps". |
| **Request** | Key, ProjectId, RequestTypeVersionId, TitleEn/Ar, Description, RequesterType (Person, ExternalContact), RequesterId, Channel, EntryMode (Form, Agentic), CurrentStepId, Status, SubmittedAt, DueAt (SLA), ParentRequestId, AttributesJson, OriginRoomId, OriginDeploymentId | Status derived from current step (open/closed). |
| **RequestEvent** | RequestId, At, ActorType/Id, EventType (Submitted, Classified, StepEntered, ActionTaken, Returned, Assigned, Comment), FromStepId, ToStepId, Detail | "History & audit" tab. |
| **Attachment** | OwnerType (Request, WorkItem, Room), OwnerId, FileName, ContentRef (object storage), Size, MimeType, UploadedBy | Preview and add; a room's attachments and generated artifacts share one "Files" panel on the board. |

---

## 7. Work items

```mermaid
erDiagram
  PROJECT ||--o{ WORK_ITEM : contains
  WORK_ITEM ||--o{ WORK_ITEM : sub_items
  WORK_ITEM }o--o| REQUEST : originates_from
  WORK_ITEM }o--o| SCHEDULED_WORK_ITEM : created_by
  WORK_ITEM }o--o| ROOM_MESSAGE : created_from
  WORK_ITEM ||--o{ WORK_ITEM_ACTIVITY : history
  WORK_ITEM ||--o{ ATTACHMENT : has
  WORK_ITEM ||--o{ RUN : executed_by
  PERSON ||--o{ SAVED_VIEW : saves
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **WorkItem** | Key (e.g. TSK-2325, BUG-311), ProjectId, Type (Task, SubItem, Bug), TitleEn/Ar, Description, Status (Backlog, ToDo, InProgress, InReview, Blocked, Done, Cancelled), Priority (High, Medium, Low), AssigneeType (Person, Agent, Group, None), AssigneeId, ReviewerType/Id, DueAt, ParentWorkItemId, RequestId, RequestTypeVersionId (attribute schema), AttributesJson, OriginType (Manual, Request, Room, Schedule, Agent), OriginId, BlockedReason, CompletedAt | Sub items share their parent's ProjectId (enforced). "Hot item" = open and (High priority or Blocked or due ≤ 2 days) — derived. Progress derived from sub items. |
| **WorkItemActivity** | WorkItemId, At, ActorType/Id, EventType (Created, StatusChanged, Assigned, Commented, SubmittedForReview, Approved, ChangesRequested, Reopened, Unblocked, SubItemAdded), Detail | "Activity" tab. |
| **SavedView** | PersonId, Name, Screen (WorkItems, Requests), FilterJson | "Save as view". |

---

## 8. Scheduled work items

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **ScheduledWorkItem** | TitleEn/Ar, ProjectId, Creates (WorkItemType or RequestTypeId), AudienceType (Agent, Person, Group), AudienceId, Repeats (Once, Daily, Weekly, Monthly, OnEvent), EventName, StartDate, Time, TimeZone, SkipHolidaysAndWeekends, Instructions, Status (Active, Paused), TemporalScheduleId | Next run derived from the schedule. |
| **ScheduleRun** | ScheduledWorkItemId, FiredAt, Outcome (Created, Failed, Skipped), CreatedWorkItemId / CreatedRequestId, Error | "Last run" column. |

---

## 9. Artifacts and files

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Artifact** | ProjectId, NameEn/Ar, ProducedByType (Agent, Person), ProducedById, RunId, LinkedToType (WorkItem, Request, Room), LinkedToId, Status (Active, Inactive), CurrentVersionId | |
| **ArtifactVersion** | ArtifactId, Version, ContentRef (object storage), Size, MimeType, CreatedAt | Versioned outputs. |
| **ProjectFile** | ProjectId, Name, ContentRef, Size, MimeType, UploadedBy, ScopeOfUse (OnlyMe, Selected, AllProject), Status (Active, Inactive), LinkedToType/Id | |
| **FileAccessGrant** | FileId, PrincipalType (Person, Agent), PrincipalId | Used when ScopeOfUse = Selected. |

---

## 10. Agents, runs and the inbox

```mermaid
erDiagram
  AGENT ||--o{ AGENT_VERSION : versions
  AGENT_VERSION ||--o{ AGENT_SKILL : enables
  AGENT_VERSION ||--o{ AGENT_TOOL_MODE : sets
  AGENT_VERSION ||--o{ AGENT_MEMORY_ACCESS : grants
  AGENT_VERSION ||--o{ AGENT_KNOWLEDGE_ACCESS : grants
  AGENT_VERSION }o--|| ROUTE : primary
  AGENT_VERSION }o--o| ROUTE : fallback
  AGENT ||--o{ RUN : executes
  RUN }o--|| AGENT_VERSION : pinned
  RUN ||--o{ RUN_STEP : has
  RUN ||--o{ APPROVAL : requests
  RUN ||--o{ AGENT_QUESTION : asks
  APPROVAL ||--o{ APPROVAL_DECISION : receives
  PERSON ||--o{ INBOX_ITEM : receives
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Agent** | Code, NameEn, NameAr, Initials/Avatar, OrgUnitId, ReportsToType/Id, IsSystem (Setup Director), Status (Idle, Running, Waiting, Paused, Error, Retired), ActiveVersionId | Runs and cost figures derived. |
| **AgentVersion** | AgentId, Version, Instructions (markdown), ExecutionProfile (Conversational, Task, Planner, Reviewer, Triage, Scripted, Routine), PrimaryRouteId, FallbackRouteId, Trust (Restricted, Standard, Elevated, Coordinator, System), MemoryEnabled, RunBudgetSoftAed, RunBudgetHardAed, ReleaseNotes, EvalScore, PublishedAt, PublishedBy, IsActive | Roll back = activate an older version. |
| **AgentSkill** | AgentVersionId, SkillVersionId | |
| **AgentToolMode** | AgentVersionId, ConnectorToolId, Mode (Auto, Approval, Denied) | Agent Tools tab; cannot be looser than the tool tier. |
| **AgentMemoryAccess** | AgentVersionId, MemoryScopeId, Access (Read, ReadWrite) | |
| **AgentKnowledgeAccess** | AgentVersionId, CollectionId | |
| **PlaygroundTest** | AgentVersionId, Input, Output, Duration, EstimatedCostAed, RunId | "Test in playground". |
| **Run** | Key, AgentId, AgentVersionId, Trigger (Mention, Assignment, RequestStep, Schedule, Widget, Setup, Manual, Replay), ContextType (Room, WorkItem, Request, Deployment, Setup), ContextId, Status (Queued, Running, Waiting, Succeeded, Failed, Cancelled, BudgetExceeded), StartedAt, EndedAt, WaitingSeconds, TokensIn, TokensOut, CacheHitPct, ToolCallCount, EstimatedCostAed, TemporalWorkflowId, TraceId, ReplayOfRunId, ReplayFromStep | Header only; full step history lives in Temporal and Phoenix. |
| **RunStep** | RunId, Seq, Type (Model, Tool, Approval, Question, Verify, Handoff), Name, Status, Result, HooksApplied, EstimatedCostAed, StartedAt, EndedAt | Summary rows for the run viewer timeline and cost-by-step. |
| **Approval** | Key, RunId, RequestedByType/Id, WorkItemId, RequestId, ChangeSetId, Action, ArgumentsRedacted, Evidence, Risk (Low, Medium, High), Policy (Single, AnyOf, Sequential), EscalateAfter, Status (Pending, Approved, Rejected, ChangesRequested, Expired) | Shown in Inbox and as room cards. |
| **ApprovalDecision** | ApprovalId, ApproverPersonId, Sequence, Decision, Reason, DecidedAt | Reason required for Reject. |
| **AgentQuestion** | RunId, AskedTo (Person/Group), Question, Answer, AnsweredBy, AnsweredAt | "Your answer resumes the run". |
| **InboxItem** | PersonId, Kind (Approval, Question, Mention, SlaWarning), SourceType, SourceId, Status (Open, Resolved), CreatedAt, ResolvedAt | Inbox tabs and badge. |

---

## 11. Skills

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Skill** | SkillName (from `SKILL.md`), TitleEn/Ar, Description, SourceType (Bundled, Uploaded, Git, Registry, Authored), SourceUrl, Tags, AuthorPersonId, CurrentVersionId | Installed / Discover / My Skills views. |
| **SkillVersion** | SkillId, Version, PackageRef (object storage), Checksum, FrontmatterValid, Status (Draft, Published) | |
| **SkillScanResult** | SkillVersionId, Scripts, NetworkCalls, PromptInjectionPatterns, EmbeddedSecrets, SandboxOnly, ScannedAt | Security scan panel. |
| **SkillTestCase** | SkillVersionId, Name, Input, Expected, LastResult, LastDuration | Test bench. |

Where-used (agents, scheduled work items) is derived from AgentSkill and schedule configuration.

---

## 12. Connectors

```mermaid
erDiagram
  CONNECTOR ||--o{ CONNECTOR_TOOL : exposes
  CONNECTOR ||--o{ CONNECTOR_ALLOWED_AGENT : allows
  CONNECTOR_TOOL ||--o{ AGENT_TOOL_MODE : configured_per_agent
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Connector** | Code, Name, CatalogEntryId (null for custom), Transport (StreamableHttp, Stdio), ServerUrl, Command (Stdio only), AuthType (OAuth, ApiKey, None), SecretRef, DefaultTierForNewTools, IsEnabled, Status (Connected, Error, Disabled), LastHandshakeAt, ProtocolVersion | A `Stdio` connector runs `Command` as a local process rather than reaching `ServerUrl`. |
| **ConnectorTool** | ConnectorId, Name, Title, Description, ReadOnlyHint, DestructiveHint, Tier (T0, T1, T2, T3), IsAvailable | Tier defaults from annotations; editable. |
| **ConnectorAllowedAgent** | ConnectorId, AgentId | |
| **ConnectorCatalogEntry** | Name, Description, LogoRef, DefaultUrl, AuthType | Browse tab. |

---

## 13. Memory

```mermaid
erDiagram
  MEMORY_SCOPE ||--o{ MEMORY_SCOPE : contains
  MEMORY_SCOPE ||--o{ MEMORY : holds
  MEMORY ||--o{ MEMORY_VERSION : versions
  MEMORY_VERSION ||--o{ MEMORY_ENTRY : contains
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **MemoryScope** | Kind (Organisation, BusinessUnit, Agent, Session), RefId (OrgUnit / Agent / Room), ParentScopeId, Path | Explorer tree. |
| **Memory** | ScopeId, TitleEn/Ar, Path, OwnerType/Id, Status (Active, PendingReview, NeedsAttention, Rejected, Archived), Access (who may read/write), WritePolicy (e.g. PII filter, human approval for new rules), ReviewDueAt, LastReviewedAt, CurrentVersion | |
| **MemoryVersion** | MemoryId, Version, ContentRef (object storage) or Content, ChangeNote, CreatedByType/Id, CreatedAt, RestoredFromVersion | Compare and restore. |
| **MemoryEntry** | MemoryVersionId, Text, SourceType (Agent run, Person, Document), SourceRef | Entries with their source. |
| **MemoryReview** | MemoryId, MemoryVersionId, ProposedByAgentId, ReviewerPersonId, Decision (Approved, Rejected), DecidedAt | Pending review flow. |

Approved memory entries become Graphiti episodes in per-scope groups on Neo4j, so a superseded rule is invalidated rather than recalled (rebuildable).

---

## 14. Knowledge

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **KnowledgeCollection** | CollectionId (code), NameEn/Ar, ProjectId, Visibility, Status (Ready, Ingesting, Error), IndexConfigJson (index type, distance metric, HNSW m / ef_construct, quantisation), ChunkingConfigJson (technique, size, overlap, OCR, Arabic normalisation, strip headers/footers, PII masking), ModelsConfigJson (embedding route, dimensions, entity-extraction route, re-ranker), RetrievalConfigJson (top-k, min score, sync schedule, max size), LastSyncAt | Counts of documents, chunks and entities are derived from the stores. |
| **KnowledgeSource** | CollectionId, Type (Upload, UrlCrawl, McpResource), Name, Config (start URL, max depth, include pattern / connector + resource path), DocumentCount, Status (Indexed, Indexing, Error), UpdatedAt | |
| **KnowledgeDocument** | SourceId, Title, RawRef (object storage), Checksum, Status, ChunkCount | Passages live in pgvector in database `awp_kb`, entities in Neo4j through Graphiti, keyed by document and chunk IDs. |
| **IngestionJob** | CollectionId, SourceId, Kind (Ingest, Reindex, ReindexAll), Progress, Status, StartedAt, EndedAt, TemporalWorkflowId | "Ingesting 62%". |
| **RetrievalTest** | CollectionId (or All), Query, Mode (Vector, Graph, Hybrid), DurationMs, ResultsJson, RunBy, RunAt | Optional log of tests. |

---

## 15. Models and routes

```mermaid
erDiagram
  MODEL_PROVIDER ||--o{ PROVIDER_CONNECTION : holds
  PROVIDER_CONNECTION ||--o{ CONNECTION_ALLOWED_MODEL : allows
  ROUTE ||--o{ ROUTE_STEP : chains
  ROUTE_STEP }o--|| CONNECTION_ALLOWED_MODEL : uses
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **ModelProvider** | Name, Kind (Cloud, Custom), Engine (for custom: Ollama, vLLM, LM Studio, TGI, llama.cpp, LocalAI, Triton/NIM, OpenAI-compatible), IsActive | |
| **ProviderConnection** | ProviderId, Name (e.g. Production), Region, Endpoint / BaseUrl, AuthType, SecretRef, IsActive | |
| **ConnectionAllowedModel** | ConnectionId, ModelName, Kind (Chat, Embedding, Image, Speech, Transcription, Rerank, Decision, Audio, Video), Modalities, ContextWindow, PriceIn, PriceOut | "Routes can only use models allowed here"; `Kind` is what a route's own model-picker filters by. |
| **Route** | Alias, Kind (Standard, Typesafe, Voice, Embedding), OutputSchemaJson, ConfidenceThreshold, MaxRetriesOnInvalid (typesafe), VoiceMode (Realtime, Pipeline), SttModel, TtsVoice, Languages, BargeIn, MaxCallMinutes (voice), Version | Rendered as an agentgateway route with its fallback chain. Embedding carries no extra config: the vector size comes from the model's own response at ingestion time, not from the route. |
| **RouteStep** | RouteId, Order (0 = primary), ProviderId, ConnectionId, ModelName | Fallback chain. |

Agents using a route are derived from AgentVersion.

---

## 16. Channels, embedded deployments and storylines

```mermaid
erDiagram
  CHANNEL ||--o| EMBEDDED_DEPLOYMENT : bound_to
  EMBEDDED_DEPLOYMENT }o--|| AGENT : default_agent
  EMBEDDED_DEPLOYMENT ||--o{ DEPLOYMENT_SURFACE : publishes_on
  EMBEDDED_DEPLOYMENT ||--o{ STORYLINE : has
  STORYLINE ||--o{ STORYLINE_VERSION : versions
  STORYLINE_VERSION ||--o{ STORYLINE_STEP : contains
  EMBEDDED_DEPLOYMENT ||--o{ DEPLOYMENT_CONVERSATION : serves
```

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **Channel** | Type (WebWidget, WhatsApp, MicrosoftTeams; others ComingSoon), IsEnabled, Status (Enabled, Degraded, Disabled), BindingType (EmbeddedDeployment, RoomMirror, RequestIntake), BindingId, UnknownSenders (ExternalContact, Ignore), RateLimitPerMinute, BusinessHours (AlwaysOn, WorkingCalendar), SecretRef, LastTestAt, LastTestResultJson | Hot-reloaded on save. |
| **EmbeddedDeployment** | Code (e.g. dep_7f3a9c), NameEn, NameAr, DefaultAgentId, Status (Enabled, Disabled, Draft), AllowedOrigins, VisitorIdentity (AnonymousOtpStepUp, SignedJwt), HandoffQueue, RateLimitPerVisitor, WidgetTitle, AccentColour, WelcomeMessageEn/Ar, ActiveStorylineVersionId | Conversations and rating derived. |
| **DeploymentSurface** | DeploymentId, Surface (Widget, WhatsApp, Teams), ChannelId | |
| **Storyline** | DeploymentId, Code (e.g. card-replacement), NameEn/Ar | |
| **StorylineVersion** | StorylineId, Version, Mode (Free, Guided, Strict), Status (Draft, Published), PublishedAt | Conversations pin the version. |
| **StorylineStep** | StorylineVersionId, Order, Name, StepType (Message, Ask, Confirm, Decide, Classify, Tool, Skill, Verify, CreateWork, Handoff, Wait, Subflow, GoTo, End, Form), AgentOverrideId, MessageEn/Ar, SendVerbatim, Slot, MaxAttempts, VerifyMethod, HandoffQueue, ToolRefs, SkillRefs, NextStepId, OnError (RetryOnce, GoToStep, Handoff) | Step-type-specific fields are nullable or kept in ConfigJson. `Form` collects a request type's own fields all at once rather than conversationally, and can sync them from the request type's attributes. |
| **DeploymentConversation** | DeploymentId, StorylineVersionId, ExternalContactId, RoomId, CurrentStepId, SlotsJson, Outcome (Completed, HandedOff, Abandoned, RequestCreated), RequestId, Rating, StartedAt, EndedAt | Also appears as a discussion room (source Widget/WhatsApp). |

---

## 17. Setup Director and blueprint

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **BlueprintVersion** | Version (e.g. 14), CreatedFromChangeSetId, SnapshotRef (object storage, YAML), CreatedAt | Configuration snapshot after each applied change set. |
| **ChangeSet** | Key (e.g. CS-119), Title, OriginType (SetupConversation, Room, Agent), OriginId, BaseBlueprintVersion, TargetBlueprintVersion, Status (Draft, AwaitingApproval, PartiallyApproved, Applied, Rejected, RolledBack, Failed), Additions, Modifications, Removals, DryRunResultJson, AppliedAt, AppliedBy | |
| **ChangeSetItem** | ChangeSetId, Section (OrgUnits, Agents, RequestTypes, Projects, Schedules, Knowledge, Channels, Deployments, Budgets, Settings), Operation (Add, Modify, Remove), TargetType, TargetId, BeforeJson, AfterJson, Decision (Pending, Approved, Rejected), DecidedBy | Per-change approve / reject. |
| **SetupConversation** | StartedBy, RoomId or ThreadRef, Status | Conversation content lives as room messages. |

---

## 18. Budgets and estimated costs

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **AgentBudget** | AgentId, LimitAed, Period (Daily, Weekly, Monthly, Quarterly), EffectiveFrom, EffectiveTo (null = keep forever), WarnAtPct, ActionAt100 (NotifyOnly, SwitchToCheaperAlias, PauseAgent), CheaperRouteId, Status (Active, Scheduled, Expired — derived from dates) | |
| **BudgetPeriod** | BudgetId, PeriodStart, PeriodEnd, EstimatedSpendAed, Runs, UsagePct | Period history and charts (daily breakdown derived from run costs). |
| **BudgetEvent** | BudgetId, PeriodId, Type (WarningSent, HardLimitReached, ActionApplied), At, Detail | |
| **BudgetChange** | BudgetId, At, ChangedBy, Description (e.g. "Limit set to AED 400") | Budget changes log. |

Estimated cost per run is stored on Run and RunStep; daily and monthly aggregates are computed (or materialised) from runs.

---

## 19. Integrations

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **IntegrationClient** | ClientId (code), Name, OwnerPersonId, Status (Active, Inactive), AllAgents (bool) | |
| **ClientKey** | ClientId, Name, Prefix, SecretHash, ExpiresAt, LastUsedAt, Status (Active, Revoked) | Secret shown once. |
| **ClientPermission** | ClientId, Permission (agents:invoke, requests:write, work_items:read, rooms:read, knowledge:search, webhooks:receive) | |
| **ClientAgent** | ClientId, AgentId | When not all agents. |
| **ClientMcpExposure** | ClientId, IsEnabled, AuthType, ExposedTools[], LastTestAt, LastTestResult | |
| **ClientAguiExposure** | ClientId, IsEnabled, AllowedEvents[], AllowedOrigins[] | |

---

## 20. Governance and platform settings

| Entity | Key attributes | Notes |
| --- | --- | --- |
| **AuditEntry** | At, ActorType (Person, Agent, Client, System), ActorId, Action, ObjectType, ObjectId, Detail, Outcome (Allowed, Denied) | Append-only (no update/delete permitted). |
| **SettingsVersion** | Version, SettingsJson (General, Branding), ChangedBy, ChangedAt | "Every change is kept in history". |
| **BrandingAsset** | Kind (LogoLight, LogoDark, Favicon), ContentRef, UploadedBy | |
| **FeatureFlag** | Key, Group (Agents & runs, Memory & knowledge, Collaboration, Engage), IsEnabled | |
| **SystemState** | AgentsPaused (bool), PausedBy, PausedAt | Pause / resume all agents. |
| **DocPage** | Slug, TitleEn/Ar, BodyEn/Ar | Documentation (may also be static content). |

Logs and service health are read from the logging stack and service health endpoints; they are not stored in the domain database.

---

## 21. Enumerations (summary)

| Enumeration | Values |
| --- | --- |
| Work item type | Task, SubItem, Bug |
| Work item status | Backlog, ToDo, InProgress, InReview, Blocked, Done, Cancelled |
| Priority | High, Medium, Low |
| Project status | Backlog, Planned, InProgress, Paused, Done, Archived |
| Sensitivity | Public, Internal, Confidential, Restricted |
| Room status | Active, Idle, Paused, Closed, Archived |
| Turn-taking | LeadAgent, MentionOnly, RoundRobin, Moderated, Autonomous |
| Request type version status | Draft, Published, Retired |
| Decomposition | None, Template, Agent, Hybrid |
| Entry mode | TemplateForm, AgenticInteractive |
| Audience access | CanAct, NotifyOnly, ViewOnly |
| Agent status | Idle, Running, Waiting, Paused, Error, Retired |
| Execution profile | Conversational, Task, Planner, Reviewer, Triage, Scripted, Routine |
| Agent trust | Restricted, Standard, Elevated, Coordinator, System |
| Agent tool mode | Auto, Approval, Denied |
| Tool tier | T0 Autonomous, T1 Confirm, T2 HumanApproval, T3 Forbidden |
| Run status | Queued, Running, Waiting, Succeeded, Failed, Cancelled, BudgetExceeded |
| Approval status | Pending, Approved, Rejected, ChangesRequested, Expired |
| Memory scope | Organisation, BusinessUnit, Agent, Session |
| Memory status | Active, PendingReview, NeedsAttention, Rejected, Archived |
| Knowledge source type | Upload, UrlCrawl, McpResource |
| Retrieval mode | Vector, Graph, Hybrid |
| Route kind | Standard, Typesafe, Voice |
| Channel type | WebWidget, WhatsApp, MicrosoftTeams (live); Slack, Email, SMS, VoiceIvr, Telegram, Webex, GoogleChat, Instagram, FacebookMessenger (coming soon) |
| Storyline mode | Free, Guided, Strict |
| Storyline step type | Message, Ask, Confirm, Decide, Classify, Tool, Skill, Verify, CreateWork, Handoff, Wait, Subflow, GoTo, End |
| Change set status | Draft, AwaitingApproval, PartiallyApproved, Applied, Rejected, RolledBack, Failed |
| Budget period | Daily, Weekly, Monthly, Quarterly |
| Budget action at 100% | NotifyOnly, SwitchToCheaperAlias, PauseAgent |
| File scope of use | OnlyMe, Selected, AllProject |
| Schedule repeats | Once, Daily, Weekly, Monthly, OnEvent |

---

## 22. Data held outside the domain database

| Data | Store | Link from `awp` |
| --- | --- | --- |
| Run execution history (steps, retries, signals, timers) | Temporal | `Run.TemporalWorkflowId`, `ScheduledWorkItem.TemporalScheduleId`, `IngestionJob.TemporalWorkflowId` |
| LLM traces, prompts, token usage, eval scores | Arize Phoenix | `Run.TraceId` (the trace id is the run id) |
| File, artifact, attachment, skill package, memory and raw document content | Object storage over the S3 API (Rook Ceph RGW) | `…Ref` fields |
| Knowledge passages and embeddings | pgvector, database `awp_kb` | Document ID + chunk ID |
| Knowledge entities and facts; memory episodes | Neo4j through Graphiti | Chunk IDs on nodes and edges; one group per collection or memory scope |
| Live room fan-out, presence, rate limits, AG-UI event streams | Valkey | Ephemeral |
| Logs and service health | Logging stack / health endpoints | None |

---

## 23. Key integrity rules

1. A sub item's `ProjectId` equals its parent's `ProjectId`.
2. A work item's or request's `AttributesJson` validates against the attribute definitions of its request type version.
3. An `ApprovalDecision.ApproverPersonId` is never the requester of the same request or the author of the work being approved. Agents never appear as approvers.
4. An `AgentToolMode` can never be looser than the `ConnectorTool.Tier`, the project's approval rules or the agent's trust.
5. A terminal `TransitionStep` has no `StepAudience` and no outgoing `RoutingRule`.
6. Only one `AgentVersion`, `StorylineVersion` and `RequestTypeVersion` per parent can be active or published at a time. Running items keep their pinned version.
7. `AuditEntry` rows are insert-only.
8. Secrets are stored only as encrypted references or hashes. `ClientKey` stores only the hash and prefix.
9. Codes and keys are unique within their entity.
10. `AgentBudget` periods for the same agent may not overlap.

---
*End of data model.*
