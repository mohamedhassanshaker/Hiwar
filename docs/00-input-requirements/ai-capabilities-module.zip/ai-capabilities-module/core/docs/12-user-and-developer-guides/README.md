# 12 — User & Developer Guides

> README, setup, build/lint/test/run commands, development conventions, user manuals, demo flows.
> Owner: Tech lead. Rules: `docs/AGENTS.md`.

## Index

| Document | Status | Version | Last updated |
|----------|--------|---------|--------------|
| [Operations](local-platform.md) | draft | 1.0 | 2026-10-30 |
| [Development conventions](conventions.md) | draft | 1.0 | 2026-10-30 |
| [Demo flows](demo-flows.md) | draft | 1.0 | 2026-10-30 |
| [Railway deployment](railway-deployment.md) | draft | 1.0 | 2026-11-07 |

- `local-platform.md` (formerly `docs/operations.md`): from a clean machine to a seeded, running console and
  back to nothing; prerequisites, ports, hosts, seeding, e2e, deploy, migrations, logs. It is the source of the
  build, lint, test and run commands.
- `conventions.md`: repository structure, naming, testing and the other development conventions.
- `demo-flows.md`: the demo scenarios used as the deploy gate.
- `railway-deployment.md`: TAWP on Railway beside kind: templates, Docker Hub images, the `scripts/railway`
  commands and the gaps against kind (ADR-0003).
