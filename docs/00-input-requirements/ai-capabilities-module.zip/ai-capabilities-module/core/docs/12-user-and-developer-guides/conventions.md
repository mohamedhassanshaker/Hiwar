# Development conventions

| Item | Value |
| --- | --- |
| Purpose | How the code is organised, named and tested, and how a change gets in |
| Audience | Developers |
| Related | [Code-structure decisions (R01–R16)](../03-architecture/decisions/code-structure.md) · [Solution design](../03-architecture/solution-design.md) · [Tech stack](../03-architecture/tech-stack.md) · [Operations](../operations.md) · [CLAUDE.md](../../CLAUDE.md) |
| Last verified against code | 2026-10-29 |

The conventions below are the ones the code follows and the tests enforce. Where a test enforces a
rule it is named, because the test, not this page, is what stops a change that breaks it. The
reasons behind the structural choices are recorded as R-decisions in
[code-structure.md](../03-architecture/decisions/code-structure.md) and are linked rather than
repeated.

## Repository layout

```
apps/web/                 Next.js full stack: console, domain logic, platform MCP server, CopilotKit runtime
services/agent/           Python agent service (FastAPI) and the Temporal workers, one image
services/connectors/      Connector runtime: control mode and per-connector bridge Pods
services/sandbox/         Sandbox manager; workspace/ is the image a sandbox Pod runs
services/modelstub/       The deterministic local model engine (local and CI only)
packages/contracts/       JSON Schemas both runtimes validate against
packages/skills-bundled/  The Agent Skills every installation ships with
infra/                    kind, Helm charts and values, helmfile, gateway, policies, PostgreSQL SQL
scripts/                  The bash scripts every Makefile target wraps
docs/                     This documentation
```

There is no workspace manager: `apps/web` is an npm project with its own `package-lock.json`, and
each Python service is a uv project with its own `uv.lock`. The stack specification's repository
sketch (pnpm workspaces, `images/sandbox/`, `images/mcp-stdio-bridge/`, `packages/design-system/`,
`infra/agentgateway/`) does not match the repository and is superseded by the layout above.

## The web application (`apps/web/src`)

```
app/(console)/      authenticated screens, one folder per route
app/(auth)/         sign-in, signed-out, invitation acceptance
app/api/            route handlers: CopilotKit runtime, platform MCP, channels, request widget, SSE, health, auth, ...
app/embed/v1/       the embedded widget: loader, frame, configuration and session API
features/<name>/    one module per domain (22, listed below)
components/         ui/ (primitives), shared/ (shell, toast, action modal, ...), guide/
db/                 Drizzle client, schema/, migrations/, seed/, queries/
lib/                infrastructure shared by two or more features
mcp/                the platform MCP server and its tool catalogue
agents/             CopilotKit runtime, agent registry, AG-UI middleware
agentgateway/       rendering of model routes for agentgateway
authz/ ds/ i18n/ hooks/ types/
```

### Feature modules

Every module under `features/` has the same six entries — `components/`, `actions.ts`,
`service.ts`, `repository.ts`, `schema.ts`, `types.ts` — and the set of modules is fixed at 21:
`agents`, `assistant`, `budgets`, `comments`, `connectors`, `engage`, `files`, `governance`, `home`,
`inbox`, `integrations`, `knowledge`, `memory`, `models`, `organisation`, `projects`, `requests`,
`rooms`, `schedules`, `skills`, `work-items` (`setup` was removed with the Setup Director, D371). Adding or removing one means changing the
list in `tests/architecture.test.ts` (R01).

| File | Holds | Rule |
| --- | --- | --- |
| `actions.ts` | Server actions for mutations triggered by the UI | Validates input with Zod (`schema.ts`) before calling the service. A server action's module path is part of its identity, so these files are not split (R15). |
| `service.ts` | Business rules and orchestration | The only place a permission check and an audit write live. A service that outgrows the size limit is split into `<topic>-service.ts` files beside it, and `service.ts` re-exports them (R04, R12). |
| `repository.ts` | Database queries | The only file in a feature that imports the database client; one file per feature (R03). |
| `schema.ts`, `types.ts` | Input schemas and the module's types | |
| `components/` | The module's screens | Compose primitives from `components/ui/` and the design system. |

The layering rule: a route composes and holds no business logic; features may use `lib/`, `ds/`,
`authz/` and `components/`, and those never import a feature.

### What `tests/architecture.test.ts` enforces

- server actions are not imported into client modules;
- exactly the 22 feature modules, each with its six entries;
- no sample-data folder, and no feature, component or route imports sample data or renders a
  hard-coded record;
- the database client is imported only from a feature's `repository.ts` or from `src/db`;
- a repository is called only from its own module's service or actions;
- a page imports no repository and no database client;
- every refusal is written in both console languages (the refusal constructors take the Arabic
  text as a required argument);
- a correlated subquery names the table of every outer column it reaches;
- no `@ts-ignore`, `@ts-expect-error` or `@ts-nocheck`.

### Next.js rules

The handoff's [Next.js rules](../_reference/nextjs-rules.md) are followed as they apply here:

| Rule | How the code meets it |
| --- | --- |
| App Router, routes in `src/app/` | Yes. |
| Separate UI, business logic, data access and validation | The six-file feature module above. |
| Thin routes | Enforced by the architecture test (pages import no repository or database client). |
| Feature-based modules | `src/features/<name>/`. |
| Server Components by default | `"use client"` only where state, effects or browser APIs are needed. |
| Secrets server-only | Server modules are never imported by client components; run tokens are minted on the server and never reach the browser. There is no `server-only` guard package (R05). |
| Centralised database access | One Drizzle client in `src/db/client.ts`, used only by repositories. |
| Validate all inputs | Zod in `schema.ts` for actions and route handlers; Ajv for dynamic request-type attributes; Zod for the environment (`src/lib/env.ts`). |
| Authorisation on the server | In every service; hiding a control in the UI is never the control. |
| Shared code in `components/`, `lib/`, `types/` | Yes. Client code imports each UI primitive from its own file; there is no barrel in `components/ui` (R14). |
| Server actions for UI mutations, route handlers for HTTP APIs | Yes. |
| Consistent error handling | See [Errors and refusals](#errors-and-refusals). |
| Test important logic | See [Testing](#testing). |

The installed Next.js version can differ from what tools assume: `apps/web/AGENTS.md` (written by
`next dev`) points to the guides shipped in `node_modules/next/dist/docs/`.

### Errors and refusals

- **A refusal is a value.** A server action returns an `Outcome<T>` (`src/lib/outcome.ts`): either
  `{ ok: true, value }` or `{ ok: false, reason, reasonAr, ... }`. Next.js replaces a thrown error's
  message with a digest in production, so anything the person has to read is returned, and only
  the unexpected is thrown. `attempt` (`src/lib/outcome.server.ts`) wraps the server side.
- **`orThrow` raises it in the browser** as a `Refused` error, where the message survives. A screen
  that forgets to handle a refusal is a type error rather than silence.
- **Reporting an act.** A screen runs an act through `hooks/use-action.ts`, which runs it in a
  transition and shows the message it returned, or the refusal it threw, in the console-wide toast
  (`components/shared/toast.tsx`). Field validation and a refusal with a list to work through stay
  on the screen they belong to.
- **Route-level errors** go to the `(console)/error.tsx` boundary (`components/shared/error-screen.tsx`),
  which shows a non-technical message with Retry and no raw error text.
- **Logging** is structured JSON to stdout: pino in `src/lib/logger.ts` with redaction of
  secret-like and personal fields before the line is written; structlog in the Python services.
  See [Solution design](../03-architecture/solution-design.md) for what is logged.

### UI, design system and language

- **Design system.** The Tahseel Design System is vendored verbatim in `apps/web/vendor/tahseel-ds/`
  and never edited by hand; `npm run ds:generate` writes the typed module in `src/ds/generated/`.
  Screens compose those primitives and `components/ui/`; they do not invent spacing, typography,
  colour or icons.
- **The designer's rules** are binding and live with the prototype:
  [docs/prototype/CLAUDE.md](../prototype/CLAUDE.md). In short: subtle and simple; design-system
  tokens, components and icons only, no raw hex in UI roles; the AvenirArabic-SharjahGovt font;
  fully rounded buttons, chips and inputs; plain language; every string in English and Arabic;
  animations play once and honour reduced motion; dark mode changes colours only; status colours
  always paired with a label or icon; toolbars collapse into "More" on small screens.
- **Prototype parity.** `tests/handoff-delta.test.ts` checks that the console carries the
  prototype's style block verbatim and that none of the Arabic terms the handoff replaced survive.
- **Language.** Every console string is written inline as `t('English', 'العربية')`, the helper
  from `src/i18n/index.ts`, with direction and date/number formatting from the same module. The
  stack specification named next-intl; the inline helper was kept instead (deviation D-1 in
  [open questions](../specs/open-questions.md)). Record names carry English and Arabic fields and
  fall back to English when the Arabic one is empty.

⚠ **Unresolved conflict.** The non-functional criteria (NFR-32) and the delivery plan say design
system adherence is enforced by "the bundled oxlint config". The config ships in
`apps/web/vendor/tahseel-ds/_adherence.oxlintrc.json`, but oxlint is not a dependency and
`apps/web/eslint.config.mjs` runs only `eslint-config-next`, so nothing runs that config today.

## The Python services

Each service is a uv project laid out as `services/<name>/src/awp_<name>/` with tests in
`services/<name>/tests/`, run by its own entry point (`awp_agent.main:app` and
`python -m awp_agent.worker <queue>`, `awp_connectors.main:app`, `awp_sandbox.main:app`,
`awp_modelstub.main:app`). These package paths are contracts: the Dockerfiles and Helm init
containers name them (R01).

- **One agent definition.** Every agent runs on the single `awp-mission` agent in
  `services/agent/src/awp_agent/mission/runtime.py`; agents differ only by configuration. There is no file
  per agent (R02, [D64, D87](../harness-decisions.md)).
- **No domain database in the agent service.** Domain data is read and written only through the
  platform MCP server, under the run's token.
- **A Temporal workflow may not read the environment.** Everything a mission needs is resolved in
  the API process and carried in its deps ([D119](../harness-decisions.md)).
- **Library before code.** Pydantic AI, `pydantic-ai-harness` and Temporal mechanisms are used
  instead of hand-written equivalents ([D83, D96](../harness-decisions.md)); `pydantic-ai-harness`
  is 0.x, so every API is checked against the installed version first.
- Some harness functions have no caller on the mission path and still exist with their tests
  (`harness/skills/loader.py`, `harness/spend.py` and others); they are listed in conflict 7 of the
  [runtime specification](../agent-runtime-spec.md#-unresolved-conflicts-with-the-code).
- **Style.** ruff with line length 100 and the rule sets in each `pyproject.toml` (Arabic letters
  in source are allowed); `mypy --strict`; type hints throughout.

## Naming

- **Tools in the platform MCP catalogue:** `<subject>_list`, `_get`, `_create`, `_edit`, `_delete`,
  `_publish`; a sub-resource is its own subject; one partial `_edit` per subject
  ([D55, D61](../harness-decisions.md)).
- **Contract names are permanent.** A key, a tool name and an AG-UI event name appear in stored data
  and run histories; renaming one is a migration ([packages/contracts](../../packages/contracts/README.md)).
- **Codes and keys** that people see are suggested from the record's name and editable before the
  first save.
- **Database:** `snake_case` tables in the `core`, `work`, `ai`, `gov` and `audit` schemas; the
  shared column conventions are in [the data model](../04-data-model/overview.md).
- **Files:** kebab-case for TypeScript modules and components (`run-start-service.ts`,
  `task-drawer.tsx`); split services end in `-service.ts`; snake_case modules in Python.

## Testing

### The verification gate

`make verify` runs `scripts/verify.sh`, and CI runs the same script unchanged
([Deployment, CI](../07-operations/deployment.md#continuous-integration)). In order, stopping at
the first failure:

1. `npm run db:migrate` — the schema matches the code under test;
2. `npm run test:seed` — the suites' own fixtures (`apps/web/tests/fixtures/demo`);
3. `npm run lint` (ESLint with `eslint-config-next`);
4. `npm run typecheck` (`tsc --noEmit`, strict);
5. `npm test` (Vitest: unit, component and database suites);
6. `npm run build`;
7. for every `services/*/pyproject.toml`: `uv run ruff check .`, `uv run mypy --strict src tests`,
   `uv run pytest -q`.

It exports `REQUIRE_DATABASE=1`, so a missing database is a loud failure instead of the database
suites skipping and reporting a false pass. Without `DATABASE_URL` it uses the `make dev-local`
container on `127.0.0.1:55432`, and it needs `APP_KEK` (from the environment or `.env`) and the
object store (the `make dev-local` MinIO on 9000 by default). It names `127.0.0.1` rather than
`localhost` because on Windows `localhost` resolves to `::1`, served by WSL's relay, which stalls
new connections for about a minute at a time under the suites' load.

One gate, run the same way locally and in CI, is a project rule: a check that passes locally and
fails in CI is a defect in the gate, not in the check.

### What is tested where

| Suite | Location | Runner | In the gate |
| --- | --- | --- | --- |
| Web unit and component tests | `apps/web/tests/*.test.ts(x)` | Vitest, Node environment, files run one at a time | yes |
| Database suites | `apps/web/tests/db/*.test.ts` against a real PostgreSQL (`tests/db/harness.ts`) | Vitest | yes |
| Screen first-render snapshots | `apps/web/tests/<feature>-render.test.tsx`, server actions stubbed (R13) | Vitest | yes |
| Screen interactions (a click, a re-render with new props) | `apps/web/tests/<feature>-interaction.test.tsx`, `// @vitest-environment happy-dom` per file, rendered through `tests/dom.tsx` with `react-dom/client` (D198) | Vitest | yes |
| Route handlers, called with a real `Request` | `apps/web/tests/` (R16; `next-auth` is inlined in `vitest.config.ts`) | Vitest | yes |
| Architecture rules | `apps/web/tests/architecture.test.ts` | Vitest | yes |
| Acceptance traceability | `apps/web/tests/traceability.test.ts` | Vitest | yes |
| Measurements (NFR-01, NFR-03) | `apps/web/tests/measure/*.measure.ts`, run with `npx vitest run --config vitest.measure.config.ts` | Vitest | no |
| Browser end to end (positive, negative, boundary, regression) and API | `tests/e2e/<feature>/*.spec.ts` and `tests/api/<feature>/*.spec.ts`; page objects in `tests/pages`, fixtures and the failure guard in `tests/fixtures`; every e2e spec runs in ten projects (desktop Chromium, Firefox and WebKit, two tablets, three phones, and two right-to-left) after a `setup` project that signs in each seeded role in English and in Arabic | Playwright, `make test-e2e` (`npx playwright test` in `tests/`) | no; needs the kind deployment |
| Live scenarios | `tests/live/*.spec.ts`, the `live` project: real missions against the deployment's own data, which need the agent service | Playwright, `make test-live` (`npx playwright test --project=live` in `tests/`) | no; needs the kind deployment and the agent service |
| Python services | `services/<name>/tests/` | pytest (the agent's workflow suites use the Temporal test server) | yes |

**Traceability.** `traceability.test.ts` reads
[the use-case document](../Tahseel_AWP_Screens_Use_Cases.md) and every Vitest and Playwright test
title, and fails on any in-scope scenario (`UC-…`, `COM-…`) that no test names, and on any scenario
id a test names that the document does not define. So a test that qualifies an acceptance
criterion carries its id in its title. Non-functional criteria use `NFR-nn`, which is outside the
pattern on purpose ([requirements](../specs/requirements.md)).

**Run-dependent failures are triaged as platform defects first.** The live suite's
`TC-AGT-960` (`tests/api/agents/run-completes-smoke.spec.ts`) starts a one-line Platform Assistant run
and requires it to stream an answer and finish within two minutes. A test that fails because no run
exists, no agent replied, or the agent service is unavailable (its message says "run-dependent") is
not classed as missing test data until `TC-AGT-960` passes in the same run: when the smoke test fails
too, runs are not completing and that is the defect to investigate (on 2026-10-31 the workers had
stopped serving their queues, and 39 such failures were wrongly classed as environment). Check
`/api/health`'s worker lines next.

**What a test should do.** Test observable behaviour and contracts, not implementation details;
cover the refusal and boundary cases, not only the happy path; and include a valid foreign identity
when a permission is involved. The project rules in [CLAUDE.md](../../CLAUDE.md) govern when a new
test is warranted.

## Comments and documentation

- A doc comment on every export, stating what it is for; inline comments explain why, and name the
  requirement, scenario or decision they implement (`UC-31.1-02`, `D73`) where one applies.
- Comments describe current behaviour, not history. History is in git and in
  [docs/CHANGELOG.md](../CHANGELOG.md).
- A behaviour, spec or stack change gets a [CHANGELOG](../CHANGELOG.md) entry and an update to the
  document that owns the topic ([documentation index](../README.md)). A decision about the agent
  runtime is recorded in [harness-decisions.md](../harness-decisions.md).

## Contribution workflow

The working rules — branches, commits, pushes, dependency versions, and what needs the owner's
approval — are in [CLAUDE.md](../../CLAUDE.md) and are not restated here. What the repository itself
provides:

- CI runs on every push to any branch and on every pull request ([deployment](../07-operations/deployment.md#continuous-integration)).
- Run `make verify` before pushing; it is exactly what CI runs.
- Dependency changes go through the native tools (`npm install`, `uv add`) so the lock files stay
  the single record of resolved versions.
