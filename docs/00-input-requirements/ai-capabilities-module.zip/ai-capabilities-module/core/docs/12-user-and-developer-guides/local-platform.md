# Operations

| Item | Value |
| --- | --- |
| Purpose | Bring the local `kind` platform up from a clean machine, use it day to day, and tear it down |
| Audience | Developers, operators |
| Related | [Configuration](07-operations/configuration.md) · [Deployment](07-operations/deployment.md) · [Runbook](07-operations/runbook.md) · [Conventions](08-development/conventions.md) |
| Last verified against code | 2026-10-29 |

From a clean machine to a seeded, running console, and back to nothing. Everything here is
the local `kind` platform; Test and Live are described in [Deployment](07-operations/deployment.md).
Every environment variable is listed in [Configuration](07-operations/configuration.md); known
failures and their fixes are in the [Runbook](07-operations/runbook.md).

- [Prerequisites](#prerequisites)
- [Installing helmfile](#installing-helmfile)
- [Without `make`](#without-make)
- [Configuration: `.env`](#configuration-env)
- [Bringing the platform up](#bringing-the-platform-up)
- [Checking it is healthy](#checking-it-is-healthy)
- [The host ports, 8080 and 8443](#the-host-ports-8080-and-8443)
- [Hostnames](#hostnames)
- [IPv4 only](#ipv4-only)
- [Local-only identity and certificates](#local-only-identity-and-certificates)
- [Seeding](#seeding)
- [The verification gate and the end-to-end suite](#the-verification-gate-and-the-end-to-end-suite)
- [Reaching the stores](#reaching-the-stores)
- [Logs, traces and workflows](#logs-traces-and-workflows)
- [Development without a cluster](#development-without-a-cluster)
- [Host mode](#host-mode)
- [Day-to-day targets](#day-to-day-targets)
- [What will not work without credentials](#what-will-not-work-without-credentials)
- [Tearing down](#tearing-down)

## Prerequisites

Every command below runs from the repository root in `bash`. On Windows use Git Bash; the
Makefile, the bootstrap and every script are bash.

| Tool | Minimum | Why |
| --- | --- | --- |
| Docker | 24.0 | Runs the kind nodes, the local registry and every image |
| kind | 0.23 | Creates the cluster |
| kubectl | 1.30 | Everything that talks to the cluster |
| helm | 3.14 | Installs the charts (4.x is what the repository is used with) |
| **helmfile** | **1.0** | Installs the upstream platform charts in order |
| Node.js | 20.9 | `apps/web`, the seed, the end-to-end suite |
| npm | 10 | Same |
| uv | 0.5 | `services/agent`, `services/sandbox`, `services/connectors`, `services/modelstub` |
| GNU make | 3.81 | The targets below; optional, see [Without `make`](#without-make) |
| bash, curl, openssl | any current | The scripts |

`infra/kind/bootstrap.sh` checks the five it cannot work without — docker, kind, kubectl,
helm, helmfile — and refuses to start with a single line naming the tool and this document
when one is missing or older than the minimum above.

No certificate tool such as `mkcert` is needed: the bootstrap installs cert-manager with a
local certificate authority (see [Local-only identity and certificates](#local-only-identity-and-certificates)).

The Docker daemon must also have, for the profile you choose:

| Profile | CPUs | Memory | Free disk | What it leaves out |
| --- | --- | --- | --- | --- |
| `full` (default) | 8 | 20 GB | 60 GB | nothing |
| `core` | 4 | 12 GB | 30 GB | Phoenix and Neo4j, so knowledge runs Vector retrieval only and traces are visible only in the run timeline |

The bootstrap reads the first two from `docker info` and the third from the filesystem the
repository is on, and stops with the measured figure when one is short
(`infra/kind/bootstrap.sh`, the `need_cpu`/`need_memory`/`need_disk` checks).

### Object storage on a laptop

Object storage in Test and Live is **Rook Ceph RGW**, which needs a raw block device on the
node. A kind node inside Docker Desktop's WSL2 virtual machine has none, so `NO_ROOK=1` is the
default here: Rook is left out and a development object store (MinIO, the `minio` helmfile
release) takes its place on the same S3 API, which is the only thing the application uses.

```bash
make kind-up            # NO_ROOK=1, the development object store
make kind-up NO_ROOK=0  # Rook, on a Linux host with a spare device
```

The Rook path has not been exercised on this machine.

## Installing helmfile

helmfile is not in winget, so a release binary on `PATH` is the plain way.

```bash
# https://github.com/helmfile/helmfile/releases
curl -fsSL -o helmfile.tar.gz \
  https://github.com/helmfile/helmfile/releases/download/v1.8.1/helmfile_1.8.1_linux_amd64.tar.gz
tar -xzf helmfile.tar.gz helmfile && install -m 0755 helmfile ~/.local/bin/helmfile
```

On Windows, take `helmfile_<version>_windows_amd64.tar.gz` from the same release, put the
`.exe` in a directory of your own and add it to the user `PATH`. `make` comes from
`winget install GnuWin32.Make`. A shell started before the `PATH` change does not see it.

## Without `make`

Every target is a thin wrapper over a script, so a shell without `make` runs the script directly
(the `Makefile` is the source for these lines):

| Target | Script |
| --- | --- |
| `make kind-up` | `PROFILE=full CLUSTER_NAME=awp NO_ROOK=1 infra/kind/bootstrap.sh` |
| `make deploy` | `helm upgrade --install awp infra/charts/awp --namespace awp-app --values infra/charts/values/values-local.yaml --set config.appUrl=$(scripts/public-origin.sh https awp.localtest.me) --wait --timeout 15m` |
| `make seed` | `bash scripts/seed.sh` |
| `make verify` | `bash scripts/verify.sh` |
| `make test-e2e` | `bash scripts/test-e2e.sh` |
| `make dev-local` | `bash scripts/dev-local.sh` |
| `make dev-forward` | `bash scripts/dev-forward.sh` |

## Configuration: `.env`

```bash
cp .env.example .env
```

`.env` is git-ignored and is the only manual step. `scripts/secrets-from-env.sh` turns it
into Kubernetes Secrets, prints no value, and is safe to re-run. Every variable in
`.env.example` names its consumer; [Configuration](07-operations/configuration.md) lists every
variable the code reads, including the ones `.env.example` does not carry.

Two things in it are computed rather than written:

- `APP_URL` and `AUTH_URL` come from `scripts/public-origin.sh`, so they follow the host
  ports (below) instead of repeating them.

`UAEPASS_CLIENT_ID` and `UAEPASS_CLIENT_SECRET` hold UAE PASS's public staging pair,
`sandbox_stage` (D387). Leave them empty to offer the password alone.

The four database URLs are **empty** in `.env.example` on purpose: in kind they are written
into the `awp-app` Secret by `scripts/db-credentials.sh`, from the password CloudNativePG
generated for the cluster. Set them only for a deployment that brings its own PostgreSQL.

Everything marked `DEV-ONLY` is a safe local default and must be replaced before Test; the
list, and the start-up check that enforces it, are in
[Configuration](07-operations/configuration.md#values-that-must-be-replaced-before-test).

Leave the provider keys (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`,
`AZURE_API_KEY`) empty unless you have one. Without one the platform installs and runs, and
model calls are answered by the deterministic local engine (`services/modelstub`, enabled by
`values-local.yaml`) instead of a real provider.

## Bringing the platform up

```bash
make kind-up                 # the full profile
make kind-up PROFILE=core    # without Phoenix and Neo4j
```

That one command goes from nothing to a complete platform, and every step is idempotent, so
running it again succeeds without recreating anything (`infra/kind/bootstrap.sh`, in order):

1. the prerequisite and capacity checks above;
2. a local image registry on `localhost:5001`, and the `awp` kind cluster — one control
   plane that publishes the gateway, one `app` worker and one `sandbox` worker, with Cilium
   instead of the default CNI so NetworkPolicy is enforced, and a browser for the registry
   on `localhost:5080` ([Browsing the image registry](#browsing-the-image-registry));
3. the Gateway API CRDs and Traefik, the Gateway API implementation;
4. cert-manager and the self-signed local CA;
5. CloudNativePG and the agentgateway CRDs;
6. the five namespaces and the Secrets from `.env`;
7. the upstream platform charts through `infra/platform/helmfile.yaml` — the `awp-pg`
   PostgreSQL cluster and its five databases, Valkey, Neo4j, the object store, Temporal,
   Arize Phoenix and agentgateway — then the data-tier admin consoles
   (`infra/platform/admin-tools.yaml`);
8. the gateway, the routes, the IP allowlist for the admin hosts, the local identity
   provider, the CoreDNS answer for `*.awp.localtest.me`, the connector runtime's route to
   this machine (`scripts/cluster-host-access.sh`, [D222, D297](harness-decisions.md)), and
   the NetworkPolicies;
9. the Temporal namespace `awp`;
10. the six application images (`awp/web`, `awp/agent`, `awp/sandbox-manager`,
    `awp/sandbox-workspace`, `awp/connector-runtime`, `awp/model-engine`), built and pushed to
    `localhost:5001` by `scripts/build-images.sh`, and `charts/awp`.

A second `make kind-up` reuses the cluster, the registry and any image tag the registry
already holds. `REBUILD=1 make kind-up` builds the images again.

`make deploy` installs or upgrades `charts/awp` on its own, without the rest, and does **not**
build images; see [Deployment](07-operations/deployment.md#changing-application-code).

## Checking it is healthy

```bash
kubectl get pods -A
curl -4 -k https://awp.localtest.me:8443/api/health
```

Nothing should be outside `Running` or `Completed`. `/api/health` lists every dependency as
`up`, `down` or `skipped`; the nine it probes (`apps/web/src/lib/health.ts`) are `web`,
`agent-service`, `temporal`, `agentgateway`, `phoenix`, `postgres`, `neo4j`, `valkey` and
`object-storage`. The console's System screen shows the same list. From inside the cluster,
without the gateway:

```bash
kubectl -n awp-app exec deploy/web -- \
  node -e "fetch('http://127.0.0.1:3000/api/health').then(r=>r.json()).then(j=>console.log(JSON.stringify(j,null,1)))"
```

In the `core` profile the chart still sets `PHOENIX_BASE_URL` and `NEO4J_URI`, so `phoenix`
and `neo4j` are probed and are expected to report `down` rather than `skipped`: those releases
are not installed. (Read from the code; not observed on a `core` install.)

## The host ports, 8080 and 8443

The gateway would normally be published on the host's 80 and 443. **On the build machine
those are held by a web server (IIS, through `http.sys`), which must not be stopped**, so the
repository's default is `8080` and `8443`.

```bash
HTTP_PORT=80 HTTPS_PORT=443 make kind-up    # a machine where 80 and 443 are free
```

Both variables are read by `make kind-up`, `make kind-reset` and `make test-e2e`, and they
reach everything that needs them through `scripts/public-origin.sh`, which is the one place
that decides whether a port belongs in a URL:

```bash
$ scripts/public-origin.sh
https://awp.localtest.me:8443
$ HTTPS_PORT=443 scripts/public-origin.sh
https://awp.localtest.me
$ scripts/public-origin.sh http awp.localtest.me
http://awp.localtest.me:8080
```

Setting `HTTPS_PORT=443` and `HTTP_PORT=80` changes, together and consistently:

- `infra/kind/kind-config.yaml`'s `hostPort` for the gateway's two NodePorts;
- Traefik's `exposedPort` for both entry points in `infra/kind/traefik-values.yaml`;
- `APP_URL` and `AUTH_URL` in `.env`, and therefore the console's UAE PASS callback
  and its links;
- the chart value `config.appUrl`, which the console serves itself at;
- the base URL `make test-e2e` runs the suite against;
- every URL `scripts/dev_up.sh` prints at the end.

`WEBAUTHN_RP_ID` does not change: a relying-party id is a domain and carries no port.

The ports are only bound when the cluster is created, so changing them means
`make kind-reset`, not `make kind-up`. To see what a port pair renders without creating
anything:

```bash
HTTP_PORT=80 HTTPS_PORT=443 scripts/render-infra.sh infra/kind/kind-config.yaml
HTTP_PORT=80 HTTPS_PORT=443 scripts/render-infra.sh infra/kind/traefik-values.yaml
```

Because kind holds host port 8080 by default, a local port-forward to 8080 (for example the
Adminer one below) needs a different local port; see the
[Runbook](07-operations/runbook.md#a-port-forward-to-8080-fails).

## Hostnames

`*.localtest.me` is a public domain that resolves to the loopback address, so nothing has
to be added to `hosts`.

| Host | What | Behind |
| --- | --- | --- |
| `https://awp.localtest.me:8443` | The console and the embedded widget | the console's own sign-in |
| `https://temporal.awp.localtest.me:8443` | The Temporal UI | the admin IP allowlist |
| `https://phoenix.awp.localtest.me:8443` | Arize Phoenix (`full` profile) | the admin IP allowlist |
| `https://aigateway.awp.localtest.me:8443` | The AI gateway UI; `/v1` is its model API | the admin IP allowlist only |
| `https://s3.awp.localtest.me:8443` | The S3 API of the development object store (`NO_ROOK=1`) | the admin IP allowlist and the store's own credentials |
| `https://minio.awp.localtest.me:8443` | The MinIO console (`NO_ROOK=1`) | the admin IP allowlist and the `minio-root` login |
| `https://neo4j.awp.localtest.me:8443` | Neo4j Browser (`full` profile) | the admin IP allowlist and Neo4j's login |
| `https://adminer.awp.localtest.me:8443` | Adminer, for PostgreSQL | the admin IP allowlist and the database login |
| `https://redisinsight.awp.localtest.me:8443` | RedisInsight, for Valkey | the admin IP allowlist only |

The admin allowlist is the `admin-allowlist` Traefik middleware, rendered from
`ADMIN_ALLOWED_CIDRS` (default: loopback plus the private ranges) by `scripts/render-infra.sh`.

Inside the cluster the same names resolve to the Traefik Service, because
`scripts/cluster-dns.sh` teaches CoreDNS to answer them that way. Without it a Pod asking
for `awp.localtest.me` would get `127.0.0.1` and reach itself.

## IPv4 only

`awp.localtest.me` resolves to **both** `::1` and `127.0.0.1`, and kind publishes its port
mappings on IPv4 only. A client that prefers IPv6 and does not fall back gets a refused
connection.

```bash
curl -4 -k https://awp.localtest.me:8443/api/health            # -4 pins curl to IPv4
curl -k --resolve awp.localtest.me:8443:127.0.0.1 https://awp.localtest.me:8443/sign-in
```

Browsers fall back on their own. The end-to-end suite pins Chromium with
`--host-resolver-rules=MAP *.localtest.me 127.0.0.1` when it runs against the cluster.

## Local-only identity and certificates

Two things in this cluster exist only locally and must never be carried to Test or Live:

- **UAE PASS staging.** `.env` carries UAE PASS's public POC pair `sandbox_stage`, which works only
  against `stg-id.uaepass.ae` (D387). Signing in with it needs a UAE PASS staging account on the
  UAE PASS staging app.
- **The certificate authority.** `infra/kind/local-ca.yaml` creates a self-signed root, and
  cert-manager issues the `*.awp.localtest.me` certificate the gateway serves from it. Your
  browser will warn once; `curl -k` and the suite's `ignoreHTTPSErrors` accept it.

Test and Live replace both: UAE PASS credentials from onboarding, and the organisation's CA or ACME.

### Passwords (D387)

People sign in with a password. An invited person chooses one from the invitation; anyone else uses
Forgot password, which needs the platform mail server (Settings → Mail; Mailpit locally). An operator
sets one directly, for the seeded people or a first Platform Owner, with the password in the
environment, never on the command line:

```bash
# in the cluster, through the web pod
kubectl -n awp-app exec deploy/web -- env NEW_PASSWORD='…' \
  node apps/web/db-migrate/db/set-password.js mariam@tahseel.ae layla@tahseel.ae
# outside the cluster
NEW_PASSWORD='…' DATABASE_URL=… npm --prefix apps/web run db:set-password -- mariam@tahseel.ae
```

The live suite signs the seven seeded roles in with `E2E_SIGN_IN_PASSWORD`, read from the git-ignored
`tests/.env.e2e`; set the same password on those seven people first.

## Seeding

```bash
make seed
```

Loads the organisation a fresh install starts with into the cluster's `awp` database through
a port-forward, as the superuser CloudNativePG generated (`scripts/seed.sh`): the people,
roles and permissions, the system agents, one project, the organisation's request types, one
knowledge base and the agent that answers from it, and each feature flag at its declared
default ([D118](harness-decisions.md)). It reads `APP_KEK` and the object store's credentials
from the `awp-app` Secret, and the cluster's provider keys so the seeded model routes order
their fallbacks by the providers the cluster can actually reach. It truncates the `core`,
`work`, `ai` and `gov` schemas before it writes, so it replaces whatever the database held; it
is idempotent: the per-table `count(*)` after a second run equals the count after the first.

The browser suite is written against a much richer organisation, which is test data rather
than anything the platform ships. It lives in `apps/web/tests/fixtures/demo` and is loaded
by `npm --prefix apps/web run test:seed` against whatever `DATABASE_URL` names. On the
cluster, `SEED=test make seed` loads it through the same forwards and secrets as the product
seed, and truncates the same schemas first. Either seed then restarts the console, which
publishes the seeded model routes to agentgateway when it starts (D366).

## The verification gate and the end-to-end suite

```bash
make verify          # what CI runs
make test-e2e        # Playwright against the kind deployment
```

`make verify` (`scripts/verify.sh`) needs a database: either export `DATABASE_URL`, or start
the local one first with `make dev-local`. What it runs, and why it refuses to skip the
database suites, is in [Conventions](08-development/conventions.md#the-verification-gate).

`make test-e2e` runs `apps/web`'s Playwright suite against the kind deployment
(`scripts/test-e2e.sh`): it points `BASE_URL` at the public origin, opens a supervised
port-forward to the cluster database for the cases that check what a write left behind,
accepts the local CA's certificate and pins the browser to IPv4. `GREP=<pattern>` runs one case
or one file. The suite expects the test fixtures, so load them first:

```bash
SEED=test make seed   # replaces the cluster's data with the test organisation
make test-e2e
```

`npx playwright test` in `tests/` (or `npm run test:e2e` at the repository root) runs the suite against `BASE_URL` (default `http://localhost:3000`, which is what `make dev-local` is for; `make test-e2e` sets the kind address). It signs in each seeded role once, in English and in Arabic, reads no database, and refuses a `BASE_URL` that is not `localhost` or `*.localtest.me`. A run picks a mode (tests/AGENTS.md section 3): `npm run test:fast` (`setup`, `api`, `desktop-chromium`: 1 847 tests), `npm run test:normal` (adds `mobile-chromium`, `rtl-desktop`, `rtl-mobile`: 6 752) or `npm run test:full` (all ten browser projects: 16 562, about 12 hours with 2 workers; the gate). `make test-e2e MODE=fast` does the same against kind (default `normal`); `make test-live` runs the `live` missions, which no mode includes. `--project` and `--grep` are for iterating on one failure. Reports are `tests/reports/html` and `tests/reports/results.json`. Set `AWP_AGENTIC_ENTRY=on` for the agentic request entry cases, since its flag is off by
default ([D310](harness-decisions.md)).

`make test-live` (`npx playwright test --project=live` in `tests/`) runs the live missions (`tests/live`, the `live` project) against the kind deployment as it is: it seeds nothing, creates
what it needs under an `E2E-` prefix, and needs the agent service. `BASE_URL` points it elsewhere.

A full QA pass (coverage review, deploy, wipe and test data, the gate, both browser suites, the
browser console, cluster logs and docs) is the `qa-e2e-verification` skill
(`.claude/skills/qa-e2e-verification/SKILL.md`). Each pass is filed by
`scripts/archive-test-report.sh` as `docs/09-testing/reports/<YYYYMMDD>.md` and
the folder `docs/09-testing/reports/<YYYYMMDD>/`; a later pass on a day already filed is
`<YYYYMMDD>_1`, `_2`, and so on, and no pass replaces another. `docs/09-testing/reports/index.html`
links each pass's Playwright HTML reports, with the trace of every result that did not pass
([D353](harness-decisions.md), [D354](harness-decisions.md), [D357](harness-decisions.md),
[D367](harness-decisions.md)). Browse them with
`python -m http.server -d docs/09-testing/reports`. Only the `.md` is committed.

## Reaching the stores

The stores are reached with a port-forward when a local tool needs one:

```bash
kubectl -n awp-data port-forward svc/awp-pg-rw 5432:5432
kubectl -n awp-ai port-forward svc/phoenix 6006:6006
kubectl -n awp-ai port-forward svc/temporal-frontend 7233:7233
```

### Data-tier web consoles

MinIO and Neo4j each carry their own console; PostgreSQL and Valkey do not, so
`infra/platform/admin-tools.yaml` adds Adminer and RedisInsight for them. All four are published
behind the admin IP allowlist (D225):

| Store | Console |
| --- | --- |
| MinIO | `https://minio.awp.localtest.me:8443` |
| Neo4j | `https://neo4j.awp.localtest.me:8443`, connect URL `bolt+s://neo4j.awp.localtest.me:8443` |
| PostgreSQL | `https://adminer.awp.localtest.me:8443` |
| Valkey | `https://redisinsight.awp.localtest.me:8443` |

Neo4j Browser speaks Bolt over a WebSocket to the page's own host, and the route sends an
upgrade request to the Bolt port. Use `bolt+s://`, not `neo4j+s://`: the routing table Neo4j
returns names its in-cluster address.

A port-forward still works without the gateway:

```bash
kubectl -n awp-data port-forward svc/minio-console 9090:9090
kubectl -n awp-data port-forward svc/neo4j 7474:7474 7687:7687  # the browser needs Bolt too
kubectl -n awp-data port-forward svc/adminer 18080:8080         # PostgreSQL; 8080 is kind's
kubectl -n awp-data port-forward svc/redisinsight 5540:5540     # Valkey
```

The AI gateway's UI needs no port-forward; it is at `https://aigateway.awp.localtest.me:8443`.
The admin endpoints the hostname does not publish — `/quitquitquit`, `/debug/pprof/*` — still
need one:

```bash
kubectl -n awp-ai port-forward deploy/ai-gateway 15000:15000
```

MinIO's console takes the `rootUser`/`rootPassword` of the `minio-root` Secret; Neo4j takes
`neo4j` and the password half of the `neo4j-auth` Secret's `NEO4J_AUTH` value. Adminer and
RedisInsight ask for the server themselves: Adminer defaults to `awp-pg-rw.awp-data.svc.cluster.local`
(the application's own `DATABASE_URL` carries the credentials); RedisInsight has no default and
takes `valkey-primary.awp-data.svc.cluster.local:6379`.

### Email

`infra/kind/mailpit.yaml` is a local SMTP sink that keeps every message and delivers none
([D240](harness-decisions.md)). The bootstrap does not apply it:

```bash
kubectl apply -f infra/kind/mailpit.yaml
kubectl -n awp-app port-forward svc/mailpit 8025:8025   # what was sent, at http://localhost:8025
```

In Settings → Email, set the server to `mailpit.awp-app.svc.cluster.local`, port 1025,
security None.

### Browsing the image registry

`kind-registry-ui` (`joxit/docker-registry-ui`) runs beside `kind-registry` on the Docker host
and is at `http://localhost:5080`, with no login. It lists the repositories, each tag with its
digest, size and creation date, and the history of an image, and it can delete a tag. Its nginx
proxies `/v2/` to `http://kind-registry:5000` over the `kind` network. The port is
`REGISTRY_UI_PORT`.

Deleting a tag removes only the manifest. The space comes back after a garbage collection
(prefix with `MSYS_NO_PATHCONV=1` in Git Bash):

```bash
docker exec kind-registry registry garbage-collect --delete-untagged /etc/distribution/config.yml
docker restart kind-registry   # the registry caches blob descriptors in memory
```

A Pod whose tag was deleted keeps running from the node's own copy, but cannot be pulled again
until the image is rebuilt (`REBUILD=1 ONLY=awp/<name> scripts/build-images.sh`).

## Logs, traces and workflows

```bash
make logs SERVICE=web                                  # kubectl -n awp-app logs -f deploy/web
kubectl -n awp-app logs -f deploy/agent-service
kubectl -n awp-app logs -f deploy/agent-worker-agent-runs
kubectl -n awp-system logs -f deploy/traefik
```

Every application log line is JSON, one line per event.

- **Workflows**: `https://temporal.awp.localtest.me:8443` for the UI, or
  `kubectl -n awp-ai exec deploy/temporal-admintools -- temporal workflow list --namespace awp`.
- **Traces and model calls**: `https://phoenix.awp.localtest.me:8443` in the `full`
  profile.
- **Health**: see [Checking it is healthy](#checking-it-is-healthy).

## Development without a cluster

```bash
make dev-local                     # PostgreSQL on 55432, MinIO on 9000
npm --prefix apps/web run dev      # http://localhost:3000
make dev-local-down
```

`scripts/dev-local.sh` starts two containers — `awp-dev-db` (`postgres:18`) and `awp-dev-minio` (the same object store the cluster runs,
with the eight buckets) — writes `apps/web/.env.local` from `apps/web/.env.local.example` when it
does not exist, then migrates and loads the test fixtures (`npm run test:seed`), not the install
seed. The ports can be moved with `AWP_DB_PORT`,
`AWP_OIDC_PORT` and `AWP_MINIO_PORT`. This is the fastest loop for console work, needs no kind
cluster at all, and is the database `make verify` uses when `DATABASE_URL` is not set.

## Host mode

The platform keeps running in kind and the application code runs on the host with hot reload:

```bash
make dev-forward                                          # foreground; Ctrl-C closes all
cd apps/web && npm run dev
cd services/agent && uv run uvicorn awp_agent.main:app --reload
```

`scripts/dev-forward.sh` forwards the PostgreSQL pooler (5432), Valkey (6379), Neo4j (7687),
the object store (9000), the Temporal frontend (7233), the AI gateway (8080) and Phoenix
(6006), skipping any that are not installed.

## Day-to-day targets

| Command | Does |
| --- | --- |
| `make deploy` | Install or upgrade `charts/awp` (no image build) |
| `make deploy-web` | Rebuild the web image and roll out the `web` Deployment only |
| `make deploy-agent` | Rebuild the agent image and roll out `agent-service` and every `agent-worker*` |
| `scripts/deploy-cluster.sh [web\|agent\|connectors]` | Rebuild, migrate, roll out and check every pod runs the new image; refuses while workflows run ([Deployment](07-operations/deployment.md#changing-application-code)). `scripts\deploy-cluster.bat` runs it from Windows |
| `make logs SERVICE=web` | Tail a workload in `awp-app` |
| `make dev-forward` | Port-forward the platform services for host mode |
| `make versions-lock` | Print the current registry digest of every image `versions.lock.md` lists; the file is not rewritten |
| `make kind-reset` | Recreate everything from scratch |
| `make kind-down` | Delete the cluster, keeping the registry cache |

## What will not work without credentials

Said plainly, so it is not mistaken for a broken install.

| Thing | Why | What fixes it |
| --- | --- | --- |
| Agent runs answered by a real model | No provider key is configured, so the seeded routes fall back to the deterministic local engine. | A real key in `.env`, `scripts/secrets-from-env.sh`, `make seed` (it reorders the routes by the keys present) and `make deploy-agent`. The allowed providers and regions are an open decision ([open questions](specs/open-questions.md), SD-6). |
| WhatsApp and Microsoft Teams | No channel credentials. | Real credentials entered on the Channels screen. |
| Email notifications and invitation links | The mail server in Settings → Email is off by default, so notices are recorded as Skipped ([D240, D248](harness-decisions.md)). | Mailpit ([Email](#email)) or a real SMTP server in Settings → Email. |

## Tearing down

```bash
make kind-down        # delete the cluster, keep the image registry and its cache
make kind-reset       # delete the cluster and the registry, then bring everything back
make dev-local-down   # stop and remove the three development containers
```

`make kind-down` leaves `kind-registry` running, so the next `make kind-up` does not rebuild
the application images. `docker rm -f kind-registry kind-registry-ui` removes that cache and
its browser too.
